# Changelog

## 2.4.0 — 2026-11-09

- Added recency-aware exponential forgetting to expert log-weights (`0.9975`, effective half-life about 277 decisive outcomes). Old relative influence fades gradually; recorded P/B/T history is retained in full.
- Bumped learning metadata to version 4. Existing workspace/history formats remain compatible.
- Repaired the developer/standalone build path: `index.html` now references the current modular source files, and the build script fails fast if its template placeholders are missing.
- Added regression coverage to ensure the standalone build contains the current learning engine and adaptive weighting implementation.
- Verified all 41 automated tests pass on Node.js 22.16.0.

## 2.3.0 — supplied baseline

- Multi-shoe chronological online learning, pattern scans, walk-forward evaluation, roadmap rendering, import/export, and local browser persistence.
