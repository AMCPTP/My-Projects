import test from 'node:test';
import assert from 'node:assert/strict';
import {
  buildAllRoads,
  buildBeadPlate,
  buildBigRoad,
  buildDerivedRoad,
  classifyPattern,
  forecastFromPattern,
  backtestPatternForecast,
  normalizeResult,
  validateResults,
  exportSession,
  importSession,
  parseCsvResults,
  exportCsv,
  previewNextDerived
} from '../src/engine.js';

const chars = (value) => value.split('');

test('normalizes supported aliases and rejects unknown results', () => {
  assert.equal(normalizeResult('player'), 'P');
  assert.equal(normalizeResult('Banker'), 'B');
  assert.equal(normalizeResult('เสมอ'), 'T');
  assert.deepEqual(validateResults(['p', 'B', 't']), ['P', 'B', 'T']);
  assert.throws(() => validateResults(['P', 'X']), /ผลลำดับที่ 2/);
});

test('Bead Plate fills from top to bottom and opens a new column after six hands', () => {
  const bead = buildBeadPlate(chars('PBTPBBP'));
  assert.deepEqual(bead.columns, [['P', 'B', 'T', 'P', 'B', 'B'], ['P']]);
  assert.equal(bead.count, 7);
});

test('Tie is recorded on Bead Plate but does not break Big Road streaks', () => {
  const results = chars('BTBP TTP'.replaceAll(' ', ''));
  const bead = buildBeadPlate(results);
  const big = buildBigRoad(results);
  assert.equal(bead.count, 7);
  assert.deepEqual(big.columns.map((column) => column.logicalLength), [2, 2]);
  assert.deepEqual(big.columns.map((column) => column.side), ['B', 'P']);
  assert.equal(big.cells[0].tieCount, 1);
  assert.equal(big.cells[2].tieCount, 2);
  assert.equal(big.totalTies, 3);
});

test('Ties before the first decided hand are attached to the first Big Road bead', () => {
  const big = buildBigRoad(chars('TTP T'.replaceAll(' ', '')));
  assert.equal(big.pendingTies, 0);
  assert.equal(big.cells.length, 1);
  assert.equal(big.cells[0].tieCount, 3);
});

test('a shoe containing only ties has no Big Road runs and retains pending ties', () => {
  const big = buildBigRoad(chars('TTT'));
  assert.equal(big.columns.length, 0);
  assert.equal(big.cells.length, 0);
  assert.equal(big.pendingTies, 3);
});

test('Big Road draws a dragon tail and turns above a blocked cell', () => {
  const big = buildBigRoad([...Array(7).fill('B'), ...Array(6).fill('P')]);
  const banker = big.columns[0].cells;
  const player = big.columns[1].cells;
  assert.deepEqual(banker.map((cell) => [cell.row, cell.col]), [
    [0, 0], [1, 0], [2, 0], [3, 0], [4, 0], [5, 0], [5, 1]
  ]);
  assert.deepEqual(player.map((cell) => [cell.row, cell.col]), [
    [0, 1], [1, 1], [2, 1], [3, 1], [4, 1], [4, 2]
  ]);
});

test('derived road mark counts match the published 16-hand reference sequence', () => {
  const roads = buildAllRoads(chars('BBPBBPPBBPBBPPBP'));
  assert.deepEqual(roads.bigRoad.columns.map((column) => column.logicalLength), [2, 1, 2, 2, 2, 1, 2, 2, 1, 1]);
  assert.deepEqual(roads.derivedRoads.map((road) => road.marks.length), [13, 12, 10]);
});

test('derived road starting points and color comparisons follow offsets', () => {
  const big = buildBigRoad(chars('BPPB'));
  const eye = buildDerivedRoad(big, 1);
  assert.equal(eye.marks[0].sourceColumn, 1);
  assert.equal(eye.marks[0].sourceRow, 1);
  assert.equal(eye.marks[0].color, 'B');
  assert.equal(eye.marks[1].sourceColumn, 2);
  assert.equal(eye.marks[1].sourceRow, 0);
  assert.equal(eye.marks[1].color, 'B');
  assert.equal(eye.marks.length, 2);
  const equalDepthRoad = buildDerivedRoad(buildBigRoad(chars('BPB')), 1);
  assert.equal(equalDepthRoad.marks[0].color, 'R');
  assert.equal(buildDerivedRoad(big, 2).marks.length, 0);
});

test('all six pattern classes are recognized with transparent next-symbol projections', () => {
  assert.equal(classifyPattern(chars('BBBB')).key, 'dragon');
  assert.equal(classifyPattern(chars('BPBPBP')).key, 'pingpong');
  assert.equal(classifyPattern(chars('BBPBBP')).key, 'two-one');
  assert.equal(classifyPattern(chars('BPPBPP')).key, 'one-two');
  assert.equal(classifyPattern(chars('BBPPBBPP')).key, 'two-two');
  assert.equal(classifyPattern(chars('BBPBPB')).key, 'random');
  assert.equal(forecastFromPattern(chars('BBPBBP')).prediction, 'B');
  assert.equal(forecastFromPattern(chars('BBPBPB')).prediction, null);
});

test('Tie outcomes are skipped when reading P/B patterns', () => {
  assert.equal(classifyPattern(chars('B T B T B'.replaceAll(' ', ''))).key, 'dragon');
});

test('walk-forward backtest only counts signals produced before the actual hand', () => {
  const testResults = backtestPatternForecast(chars('BBBBBPBPBPBP'));
  assert.ok(testResults.signals > 0);
  assert.equal(testResults.correct + testResults.incorrect, testResults.signals);
  assert.ok(testResults.records.every((record) => record.handNumber >= 4));
  assert.ok(testResults.accuracy >= 0 && testResults.accuracy <= 100);
});

test('JSON and CSV exports round-trip all P/B/T results', () => {
  const results = chars('BBPTBPTP');
  assert.deepEqual(importSession(JSON.stringify(exportSession(results))), results);
  assert.deepEqual(parseCsvResults(exportCsv(results)), results);
  assert.deepEqual(parseCsvResults('result\nP\nB\nT\n'), ['P', 'B', 'T']);
});

test('next-road previews show conditional derived markers, not side predictions', () => {
  const results = chars('BBPBBPPBBPBBPPBP');
  const b = previewNextDerived(results, 'B');
  const p = previewNextDerived(results, 'P');
  assert.equal(b.length, 3);
  assert.equal(p.length, 3);
  assert.deepEqual(b.map((entry) => entry.color), ['R', 'B', 'B']);
  assert.deepEqual(p.map((entry) => entry.color), ['B', 'R', 'R']);
  assert.throws(() => previewNextDerived(results, 'T'), /P หรือ B/);
});
