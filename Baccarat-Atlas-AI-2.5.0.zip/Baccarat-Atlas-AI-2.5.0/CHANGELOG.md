# Changelog

## 2.5.0 — 2026-11-09

- Added a walk-forward calibration report with decile bins, Expected Calibration Error (ECE), and maximum bin error. The learner now measures whether its displayed B score has historically aligned with the observed rate, without inspecting future outcomes.
- Added an active-shoe context-shift guard. It compares the latest 32 decisive outcomes with the recorded history and labels a large difference as a descriptive warning; it does not claim the game process has changed.
- Strengthened the validated-direction gate: in addition to the existing multi-shoe, confidence-bound, recent-performance, disagreement, and score-distance checks, a direction now requires adequate calibration and enough stable current-shoe context.
- Added the calibration and context-shift diagnostics to the UI and regression coverage for both safeguards.
- Verified all 43 automated tests pass with Node.js 24.22.1.

## 2.4.0 — 2026-11-09

- Added recency-aware exponential forgetting to expert log-weights (`0.9975`, effective half-life about 277 decisive outcomes). Old relative influence fades gradually; recorded P/B/T history is retained in full.
- Bumped learning metadata to version 4. Existing workspace/history formats remain compatible.
- Repaired the developer/standalone build path: `index.html` now references the current modular source files, and the build script fails fast if its template placeholders are missing.
- Added regression coverage to ensure the standalone build contains the current learning engine and adaptive weighting implementation.
- Verified all 41 automated tests pass on Node.js 22.16.0.

## 2.3.0 — supplied baseline

- Multi-shoe chronological online learning, pattern scans, walk-forward evaluation, roadmap rendering, import/export, and local browser persistence.

