/**
 * Baccarat Atlas AI — online, prequential learning engine.
 *
 * This is an adaptive statistical ensemble, not a claim that baccarat
 * sequences are predictable. Every historical forecast is generated using
 * only outcomes that precede it; the realized outcome is then used to update
 * context counts and expert weights. Shoe boundaries reset within-shoe
 * sequence/road state while learned context memory carries across shoes.
 */
import { validateResults, normalizeResult } from './engine.js';

export const LEARNING_VERSION = 5;
export const EXPERTS = Object.freeze([
  { id: 'baseline', label: 'Baseline 50/50', family: 'baseline' },
  { id: 'global', label: 'สถิติรวมหลายชู', family: 'global' },
  { id: 'recent8', label: 'Recent 8', family: 'window' },
  { id: 'recent16', label: 'Recent 16', family: 'window' },
  { id: 'recent32', label: 'Recent 32', family: 'window' },
  ...[1, 2, 3, 4, 5, 6].map((n) => ({ id: `markov${n}`, label: `Sequence ${n}`, family: 'sequence' })),
  { id: 'streak', label: 'Streak Context', family: 'pattern' },
  { id: 'pattern', label: 'Pattern Memory', family: 'pattern' },
  { id: 'bigEye', label: 'Big Eye Boy', family: 'road' },
  { id: 'smallRoad', label: 'Small Road', family: 'road' },
  { id: 'cockroach', label: 'Cockroach Pig', family: 'road' }
]);

const ROAD_OFFSETS = Object.freeze([
  { id: 'bigEye', offset: 1 },
  { id: 'smallRoad', offset: 2 },
  { id: 'cockroach', offset: 3 }
]);
const ETA = 0.14;
// Discount old relative expert performance so the ensemble can adapt to new regimes.
// A 0.9975 factor gives a half-life of about 277 decisive hands. Raw outcomes are never forgotten.
const WEIGHT_FORGETTING = 0.9975;
const WEIGHT_HALF_LIFE = Math.round(Math.log(0.5) / Math.log(WEIGHT_FORGETTING));
const EPSILON = 1e-6;
const CALIBRATION_BIN_COUNT = 10;
const MAX_CALIBRATION_ECE = 0.08;

function emptyCounts() { return { B: 0, P: 0 }; }
function countTotal(counts) { return counts ? counts.B + counts.P : 0; }
function addCount(map, key, actual) {
  if (!key) return;
  const counts = map.get(key) ?? emptyCounts();
  counts[actual] += 1;
  map.set(key, counts);
}
function probability(counts, prior = 0.5, strength = 8) {
  if (!counts) return prior;
  const n = countTotal(counts);
  return (counts.B + (strength * prior)) / (n + strength);
}
function clampProbability(value) {
  return Math.max(0.02, Math.min(0.98, value));
}
function newCalibrationBins() {
  return Array.from({ length: CALIBRATION_BIN_COUNT }, () => ({ count: 0, probabilityTotal: 0, bankerTotal: 0 }));
}
function recordCalibration(bins, probabilityB, actualB) {
  const index = Math.min(CALIBRATION_BIN_COUNT - 1, Math.floor(probabilityB * CALIBRATION_BIN_COUNT));
  const bin = bins[index];
  bin.count += 1;
  bin.probabilityTotal += probabilityB;
  bin.bankerTotal += actualB;
}
function normalizeLogWeights(logWeights) {
  const values = Object.values(logWeights);
  const max = Math.max(...values);
  const expValues = Object.fromEntries(Object.entries(logWeights).map(([key, value]) => [key, Math.exp(value - max)]));
  const total = Object.values(expValues).reduce((sum, value) => sum + value, 0) || 1;
  return Object.fromEntries(Object.entries(expValues).map(([key, value]) => [key, value / total]));
}

function newModel() {
  return {
    observations: 0,
    global: emptyCounts(),
    ngram: Array.from({ length: 6 }, () => new Map()),
    streak: new Map(),
    pattern: new Map(),
    road: { 1: new Map(), 2: new Map(), 3: new Map() },
    logWeights: Object.fromEntries(EXPERTS.map((expert) => [expert.id, 0])),
    expertStats: Object.fromEntries(EXPERTS.map((expert) => [expert.id, {
      samples: 0, correct: 0, brier: 0, logLoss: 0, active: 0
    }]))
  };
}

function newLocalState() {
  return { sequence: [], runs: [], roads: { 1: [], 2: [], 3: [] }, ties: 0, currentStreak: null };
}

function sideStreak(sequence) {
  if (!sequence.length) return null;
  const side = sequence.at(-1);
  let length = 0;
  for (let i = sequence.length - 1; i >= 0 && sequence[i] === side; i -= 1) length += 1;
  return { side, length };
}

/** Returns the strongest currently visible descriptive pattern, not a forecast. */
export function detectLearningPattern(sequence, knownStreak = undefined) {
  if (!sequence.length) return { type: 'random', key: 'random:empty', name: 'รอข้อมูล', sample: '' };
  const recent6 = sequence.slice(-6);
  const recent8 = sequence.slice(-8);
  const repeatsPeriod = (items, period) => items.length >= period * 2 &&
    items.slice(-period).every((value, index) => value === items[items.length - period * 2 + index]);
  const alternating = recent6.length === 6 && recent6.every((value, index) => index === 0 || value !== recent6[index - 1]);
  if (alternating) {
    return { type: 'pingpong', key: `pingpong:${recent6.at(-1)}`, name: 'ปิงปอง', sample: recent6.join('') };
  }
  if (recent6.length === 6 && repeatsPeriod(recent6, 3)) {
    const [a, b, c] = recent6.slice(0, 3);
    if (a === b && b !== c) return { type: 'two-one', key: `two-one:${recent6.at(-1)}:${sideStreak(sequence).length}`, name: 'สองตัวหนึ่ง', sample: recent6.join('') };
    if (a !== b && b === c) return { type: 'one-two', key: `one-two:${recent6.at(-1)}:${sideStreak(sequence).length}`, name: 'หนึ่งตัวสอง', sample: recent6.join('') };
  }
  if (recent8.length === 8 && repeatsPeriod(recent8, 4)) {
    const [a, b, c, d] = recent8.slice(0, 4);
    if (a === b && c === d && a !== c) return { type: 'two-two', key: `two-two:${recent8.at(-1)}:${sideStreak(sequence).length}`, name: 'สองต่อสอง', sample: recent8.join('') };
  }
  // Appends pass the maintained streak state so long runs stay O(1) per hand.
  const streak = knownStreak === undefined ? sideStreak(sequence) : knownStreak;
  if (streak?.length >= 3) {
    const bucket = Math.min(streak.length, 5);
    return { type: 'dragon', key: `dragon:${streak.side}:${bucket}`, name: 'มังกร', sample: sequence.slice(-Math.min(streak.length, 8)).join('') };
  }
  const tail = sequence.slice(-2).join('');
  return { type: 'random', key: `random:${tail || 'start'}`, name: 'ยังไม่ชัดเจน', sample: sequence.slice(-8).join('') };
}


/** Describe several independent sequence dimensions; none is treated as a causal signal. */
export function scanLearningPatterns(inputSequence) {
  const sequence = validateResults(inputSequence).filter((result) => result !== 'T');
  const window = sequence.slice(-12);
  const runs = [];
  for (const side of window) {
    const last = runs.at(-1);
    if (last?.side === side) last.length += 1;
    else runs.push({ side, length: 1 });
  }
  const current = sideStreak(sequence);
  const recent6 = sequence.slice(-6);
  const recent8 = sequence.slice(-8);
  const detections = [];
  const add = (key, name, description, sample) => detections.push({ key, name, description, sample });

  if (recent6.length === 6 && recent6.every((value, index) => index === 0 || value !== recent6[index - 1])) {
    add('pingpong', 'ปิงปอง', '6 ตาล่าสุดสลับฝั่งทุกตา', recent6.join(' '));
  }
  const repeats = (items, period) => items.length >= period * 2 &&
    items.slice(-period).every((value, index) => value === items[items.length - period * 2 + index]);
  if (recent6.length === 6 && repeats(recent6, 3)) {
    const [a, b, c] = recent6.slice(0, 3);
    if (a === b && b !== c) add('two-one', 'สองตัวหนึ่ง (2–1)', 'รูปแบบ 2 ผลฝั่งเดียว ตามด้วย 1 ผลอีกฝั่ง วนซ้ำ', recent6.join(' '));
    if (a !== b && b === c) add('one-two', 'หนึ่งตัวสอง (1–2)', 'รูปแบบ 1 ผลฝั่งหนึ่ง ตามด้วย 2 ผลอีกฝั่ง วนซ้ำ', recent6.join(' '));
  }
  if (recent8.length === 8 && repeats(recent8, 4)) {
    const [a, b, c, d] = recent8.slice(0, 4);
    if (a === b && c === d && a !== c) add('two-two', 'สองต่อสอง (2–2)', 'รูปแบบสองผลต่อฝั่งสลับกันและวนซ้ำ', recent8.join(' '));
  }
  if (current && current.length >= 3) {
    add('dragon', 'มังกร / ทางยาว', `ฝั่ง ${current.side} ต่อเนื่อง ${current.length} ตา`, sequence.slice(-Math.min(current.length, 12)).join(' '));
  }
  const total = window.length;
  const bankerInWindow = window.filter((value) => value === 'B').length;
  const playerInWindow = total - bankerInWindow;
  const switchesInWindow = window.reduce((sum, value, index) =>
    sum + (index > 0 && value !== window[index - 1] ? 1 : 0), 0);
  const switchRateInWindow = total > 1 ? switchesInWindow / (total - 1) : null;
  if (switchRateInWindow !== null && switchRateInWindow >= 0.65) {
    add('switch-heavy', 'สลับฝั่งถี่', 'ช่วงล่าสุดมีอัตราเปลี่ยนฝั่งอย่างน้อย 65%', window.join(' '));
  } else if (switchRateInWindow !== null && switchRateInWindow <= 0.35) {
    add('stick-heavy', 'เกาะฝั่งบ่อย', 'ช่วงล่าสุดมีอัตราเปลี่ยนฝั่งไม่เกิน 35%', window.join(' '));
  }
  if (total >= 8 && Math.abs(bankerInWindow - playerInWindow) <= 2) {
    add('balanced', 'สัดส่วน B/P ใกล้กัน', 'จำนวน Banker และ Player ในหน้าต่างล่าสุดต่างกันไม่เกิน 2 ผล', window.join(' '));
  } else if (total >= 8 && Math.abs(bankerInWindow - playerInWindow) >= 6) {
    add('dominant', 'ฝั่งหนึ่งเด่นในหน้าต่าง', 'ผล B/P ในหน้าต่างล่าสุดเอนข้างหนึ่งอย่างน้อย 6 ผล', window.join(' '));
  }
  // Detect an arbitrary repeated motif over three complete cycles, not only named 2-1/2-2 forms.
  if (sequence.length >= 6) {
    for (let period = 2; period <= 8; period += 1) {
      const motif = sequence.slice(-period);
      const triple = sequence.slice(-(period * 3));
      const repeatsThreeTimes = triple.length === period * 3 &&
        triple.every((value, index) => value === motif[index % period]);
      if (repeatsThreeTimes && new Set(motif).size > 1) {
        if (!detections.some((item) => ['two-one', 'one-two', 'two-two', 'pingpong'].includes(item.key))) {
          add('cycle', `วงรอบซ้ำ ${period} จังหวะ`, `รูปแบบ ${motif.join('')} ซ้ำครบ 3 รอบในข้อมูลล่าสุด`, triple.join(' '));
        }
        break;
      }
    }
  }
  if (!detections.length) {
    add('random', 'ยังไม่พบแพตเทิร์นเด่น', 'ข้อมูลล่าสุดไม่เข้าเกณฑ์รูปแบบที่กำหนด ไม่ได้แปลว่าผลสุ่มผิดปกติ', window.join(' '));
  }
  const banker = bankerInWindow;
  const player = playerInWindow;
  const switchRate = switchRateInWindow;
  const longestRun = runs.reduce((max, run) => Math.max(max, run.length), 0);
  const averageRun = runs.length ? total / runs.length : null;
  const rhythm = switchRate === null ? 'รอข้อมูล' : switchRate >= 0.65 ? 'สลับฝั่งถี่' : switchRate <= 0.35 ? 'เกาะฝั่งบ่อย' : 'จังหวะผสม';
  return {
    detections,
    stats: {
      window: total,
      banker,
      player,
      switchCount: switchesInWindow,
      switchRate,
      currentStreak: current ? { side: current.side, length: current.length } : null,
      longestRun,
      runCount: runs.length,
      averageRun,
      rhythm
    }
  };
}

function featureSnapshot(local) {
  const sequence = local.sequence;
  const streak = local.currentStreak;
  const pattern = detectLearningPattern(sequence, streak);
  const ngrams = {};
  for (let n = 1; n <= 6; n += 1) {
    ngrams[n] = sequence.length >= n ? sequence.slice(-n).join('') : null;
  }
  const roadKeys = {};
  for (const road of ROAD_OFFSETS) {
    const marks = local.roads[road.offset];
    roadKeys[road.offset] = marks.length ? marks.slice(-3).join('') : null;
  }
  return {
    ngrams,
    streakKey: streak ? `${streak.side}:${Math.min(streak.length, 5)}` : null,
    patternKey: pattern.key,
    pattern,
    roadKeys,
    recent8: sequence.slice(-8),
    recent16: sequence.slice(-16),
    recent32: sequence.slice(-32)
  };
}

function predictExperts(model, features) {
  const globalN = countTotal(model.global);
  const globalP = probability(model.global, 0.5, 12);
  const predictions = {};
  const support = {};
  predictions.baseline = 0.5;
  support.baseline = 0;
  predictions.global = globalP;
  support.global = globalN;

  for (const [id, size] of [['recent8', 8], ['recent16', 16], ['recent32', 32]]) {
    const recent = features[`recent${size}`];
    const counts = { B: recent.filter((x) => x === 'B').length, P: recent.filter((x) => x === 'P').length };
    predictions[id] = probability(counts, globalP, 4);
    support[id] = recent.length;
  }

  let parentP = globalP;
  for (let n = 1; n <= 6; n += 1) {
    const key = features.ngrams[n];
    const counts = key ? model.ngram[n - 1].get(key) : null;
    const p = probability(counts, parentP, 7);
    predictions[`markov${n}`] = p;
    support[`markov${n}`] = countTotal(counts);
    parentP = p;
  }

  const streakCounts = features.streakKey ? model.streak.get(features.streakKey) : null;
  predictions.streak = probability(streakCounts, globalP, 9);
  support.streak = countTotal(streakCounts);

  const patternCounts = model.pattern.get(features.patternKey);
  predictions.pattern = probability(patternCounts, globalP, 9);
  support.pattern = countTotal(patternCounts);

  for (const road of ROAD_OFFSETS) {
    const key = features.roadKeys[road.offset];
    const counts = key ? model.road[road.offset].get(key) : null;
    predictions[road.id] = probability(counts, globalP, 12);
    support[road.id] = countTotal(counts);
  }

  const weights = normalizeLogWeights(model.logWeights);
  let ensembleP = 0;
  for (const expert of EXPERTS) ensembleP += weights[expert.id] * predictions[expert.id];
  const pB = clampProbability(ensembleP);
  // Weighted disagreement measures how far specialists are spread around the ensemble.
  // It is a conflict diagnostic, not a probability or confidence interval.
  const disagreement = Math.sqrt(EXPERTS.reduce((sum, expert) => {
    const delta = predictions[expert.id] - pB;
    return sum + (weights[expert.id] * delta * delta);
  }, 0));
  return { pB, predictions, support, weights, disagreement };
}

function updateOnlineModel(model, features, forecast, actual, metrics, includeEvaluation) {
  const y = actual === 'B' ? 1 : 0;
  const p = forecast.pB;
  const brier = (p - y) ** 2;
  const logLoss = -(y * Math.log(Math.max(EPSILON, p)) + (1 - y) * Math.log(Math.max(EPSILON, 1 - p)));
  metrics.totalPredictions += 1;
  if (forecast.side === actual) metrics.totalCorrect += 1;
  metrics.totalBrier += brier;
  metrics.totalLogLoss += logLoss;

  if (includeEvaluation) {
    const baselineP = clampProbability(forecast.experts.global);
    const baselineBrier = (baselineP - y) ** 2;
    const baselineLogLoss = -(y * Math.log(baselineP) + (1 - y) * Math.log(1 - baselineP));
    metrics.evaluated += 1;
    metrics.correct += forecast.side === actual ? 1 : 0;
    metrics.brier += brier;
    metrics.logLoss += logLoss;
    metrics.baselineBrier += baselineBrier;
    metrics.baselineLogLoss += baselineLogLoss;
    recordCalibration(metrics.calibrationBins, p, y);
    metrics.recent.push({ brier, logLoss, baselineBrier, baselineLogLoss, correct: forecast.side === actual ? 1 : 0 });
    if (metrics.recent.length > 100) metrics.recent.shift();
  }

  for (const expert of EXPERTS) {
    const id = expert.id;
    const expertP = clampProbability(forecast.experts[id]);
    const expertLoss = -(y * Math.log(expertP) + (1 - y) * Math.log(1 - expertP));
    const expertBrier = (expertP - y) ** 2;
    const stats = model.expertStats[id];
    stats.samples += 1;
    stats.active += forecast.support[id] > 0 ? 1 : 0;
    stats.correct += (expertP >= 0.5 ? 'B' : 'P') === actual ? 1 : 0;
    stats.brier += expertBrier;
    stats.logLoss += expertLoss;
    // Exponential-weights update: experts that incur more log loss gradually lose influence.
    model.logWeights[id] = Math.max(-60, (model.logWeights[id] * WEIGHT_FORGETTING) - (ETA * expertLoss));
  }

  model.global[actual] += 1;
  for (let n = 1; n <= 6; n += 1) addCount(model.ngram[n - 1], features.ngrams[n], actual);
  addCount(model.streak, features.streakKey, actual);
  addCount(model.pattern, features.patternKey, actual);
  for (const road of ROAD_OFFSETS) addCount(model.road[road.offset], features.roadKeys[road.offset], actual);
  model.observations += 1;
}

/** Incrementally maintain logical Big Road runs and the three derived-road colors. */
function updateLocalState(local, actual) {
  const previous = local.runs.at(-1);
  if (!previous || previous.side !== actual) {
    const column = local.runs.length;
    for (const road of ROAD_OFFSETS) {
      if (column >= road.offset + 1) {
        const same = local.runs[column - 1].length === local.runs[column - 1 - road.offset].length;
        local.roads[road.offset].push(same ? 'R' : 'B');
      }
    }
    local.runs.push({ side: actual, length: 1 });
  } else {
    const column = local.runs.length - 1;
    const row = previous.length;
    for (const road of ROAD_OFFSETS) {
      if (row > 0 && column >= road.offset) {
        const comparison = local.runs[column - road.offset].length;
        const same = (row < comparison) === ((row - 1) < comparison);
        local.roads[road.offset].push(same ? 'R' : 'B');
      }
    }
    previous.length += 1;
  }
  local.sequence.push(actual);
  if (local.currentStreak?.side === actual) {
    local.currentStreak.length += 1;
  } else {
    local.currentStreak = { side: actual, length: 1 };
  }
}

function newMetrics() {
  return {
    totalPredictions: 0, totalCorrect: 0, totalBrier: 0, totalLogLoss: 0,
    evaluated: 0, correct: 0, brier: 0, logLoss: 0,
    baselineBrier: 0, baselineLogLoss: 0,
    evaluatedShoes: 0,
    calibrationBins: newCalibrationBins(),
    recent: []
  };
}

function clusterImprovementInterval(perShoe, modelKey, baselineKey) {
  const shoeImprovements = perShoe
    .filter((shoe) => shoe.evaluated > 0 && Number.isFinite(shoe[modelKey]) && Number.isFinite(shoe[baselineKey]))
    .map((shoe) => (shoe[baselineKey] - shoe[modelKey]) / shoe.evaluated);
  const samples = shoeImprovements.length;
  if (!samples) return null;
  const mean = shoeImprovements.reduce((sum, value) => sum + value, 0) / samples;
  if (samples < 3) return { mean, standardError: null, lower95: null, upper95: null, clusters: samples };
  const squared = shoeImprovements.reduce((sum, value) => sum + ((value - mean) ** 2), 0);
  const variance = squared / (samples - 1);
  const standardError = Math.sqrt(variance / samples);
  // Two-sided 95% Student-t critical values for a small number of shoe-level clusters.
  const tCritical = [
    null, 12.706, 4.303, 3.182, 2.776, 2.571, 2.447, 2.365, 2.306,
    2.262, 2.228, 2.201, 2.179, 2.160, 2.145, 2.131, 2.120, 2.110,
    2.101, 2.093, 2.086, 2.080, 2.074, 2.069, 2.064, 2.060, 2.056,
    2.052, 2.048, 2.045
  ];
  // Include df=30 explicitly; use the normal critical value only for larger samples.
  tCritical.push(2.042);
  const degreesOfFreedom = samples - 1;
  const critical = degreesOfFreedom < tCritical.length
    ? tCritical[degreesOfFreedom]
    : 1.96;
  return {
    mean,
    standardError,
    lower95: mean - (critical * standardError),
    upper95: mean + (critical * standardError),
    clusters: samples
  };
}
function summarizeRecentEvaluation(recent) {
  const samples = recent.length;
  if (!samples) {
    return {
      samples: 0, accuracy: null, brier: null, baselineBrier: null,
      logLoss: null, baselineLogLoss: null
    };
  }
  return {
    samples,
    accuracy: recent.reduce((sum, item) => sum + item.correct, 0) / samples,
    brier: recent.reduce((sum, item) => sum + item.brier, 0) / samples,
    baselineBrier: recent.reduce((sum, item) => sum + item.baselineBrier, 0) / samples,
    logLoss: recent.reduce((sum, item) => sum + item.logLoss, 0) / samples,
    baselineLogLoss: recent.reduce((sum, item) => sum + item.baselineLogLoss, 0) / samples
  };
}

/**
 * Calibration is reported only from walk-forward estimates. It answers whether
 * the model's displayed score has historically matched the observed frequency;
 * it does not turn that score into a true probability of the next hand.
 */
function summarizeCalibration(bins) {
  const samples = bins.reduce((sum, bin) => sum + bin.count, 0);
  if (!samples) return { samples: 0, ece: null, maxError: null, bins: [] };
  let ece = 0;
  let maxError = 0;
  const populatedBins = bins.flatMap((bin, index) => {
    if (!bin.count) return [];
    const meanProbabilityB = bin.probabilityTotal / bin.count;
    const observedBankerRate = bin.bankerTotal / bin.count;
    const error = Math.abs(meanProbabilityB - observedBankerRate);
    ece += (bin.count / samples) * error;
    maxError = Math.max(maxError, error);
    return [{
      from: index / CALIBRATION_BIN_COUNT,
      to: (index + 1) / CALIBRATION_BIN_COUNT,
      samples: bin.count,
      meanProbabilityB,
      observedBankerRate,
      error
    }];
  });
  return { samples, ece, maxError, bins: populatedBins };
}

/**
 * Compare the active shoe's recent mix with recorded history. This is a
 * descriptive drift guard, not evidence that the game process has changed.
 */
function summarizeContextShift(model, local) {
  const recent = local.sequence.slice(-32);
  const historySamples = countTotal(model.global);
  if (recent.length < 24 || historySamples < 80) {
    return {
      level: 'insufficient', samples: recent.length, historySamples,
      recentBankerRate: null, historyBankerRate: null, delta: null
    };
  }
  const recentBankerRate = recent.filter((result) => result === 'B').length / recent.length;
  const historyBankerRate = model.global.B / historySamples;
  const delta = recentBankerRate - historyBankerRate;
  const absoluteDelta = Math.abs(delta);
  return {
    level: absoluteDelta >= 0.20 ? 'high' : absoluteDelta >= 0.10 ? 'moderate' : 'stable',
    samples: recent.length,
    historySamples,
    recentBankerRate,
    historyBankerRate,
    delta
  };
}

function buildForecast(model, local, shoesCount, totalHands, evaluation, perShoe) {
  const features = featureSnapshot(local);
  const expertForecast = predictExperts(model, features);
  const pB = expertForecast.pB;
  const pP = 1 - pB;
  const learnedSampleCount = model.observations;
  const edge = Math.abs(pB - 0.5);
  const patternCounts = model.pattern.get(features.patternKey) ?? emptyCounts();
  const patternSamples = countTotal(patternCounts);
  const samples = evaluation.evaluated;
  // Use shoe-level cluster means because hands within one shoe are not fully independent.
  const brierImprovement = clusterImprovementInterval(perShoe, 'brierTotal', 'baselineBrierTotal');
  const logLossImprovement = clusterImprovementInterval(perShoe, 'logLossTotal', 'baselineLogLossTotal');
  const recent = summarizeRecentEvaluation(evaluation.recent.slice(-30));
  const calibration = summarizeCalibration(evaluation.calibrationBins);
  const contextShift = summarizeContextShift(model, local);

  // A directional call is intentionally difficult to earn: adequate walk-forward
  // volume, evidence across multiple shoes, positive lower 95% bounds on both proper
  // scoring-rule improvements, stable recent performance, and limited expert conflict.
  const hasEnoughEvaluation = samples >= 100 && evaluation.evaluatedShoes >= 5;
  const beatsBaseline = hasEnoughEvaluation &&
    brierImprovement?.lower95 > 0 && logLossImprovement?.lower95 > 0;
  const recentStable = recent.samples >= 30 && recent.brier < recent.baselineBrier && recent.logLoss < recent.baselineLogLoss;
  const calibrationStable = calibration.samples >= 100 && calibration.ece <= MAX_CALIBRATION_ECE;
  const contextAssessable = contextShift.level !== 'insufficient';
  const contextStable = contextShift.level !== 'high';
  const lowConflict = expertForecast.disagreement <= 0.05;
  const hasEdge = edge >= 0.015;
  const leanSide = hasEdge ? (pB >= 0.5 ? 'B' : 'P') : null;
  const side = beatsBaseline && recentStable && calibrationStable && contextAssessable && contextStable && lowConflict && hasEdge
    ? leanSide
    : null;

  let status = 'กำลังเรียนรู้';
  let statusDetail = 'ระบบกำลังรวบรวมข้อมูลและทดสอบแบบเดินหน้า โดยยังไม่ชี้นำฝั่ง';
  if (samples < 100 || evaluation.evaluatedShoes < 5) {
    status = 'หลักฐานยังไม่พอ';
    statusDetail = `ผลทดสอบ ${samples}/100 ตัวอย่าง · ${evaluation.evaluatedShoes}/5 ชูที่มีผลประเมิน · ยังงดฟันธง`;
  } else if (!beatsBaseline) {
    status = 'ยังไม่ผ่านฐาน';
    statusDetail = 'ช่วงความเชื่อมั่นของ Brier และ Log-loss ยังไม่ยืนยันว่าเหนือโมเดลฐานอัตราสถิติรวม · งดชี้ฝั่ง';
  } else if (!recentStable) {
    status = 'ผลงานช่วงล่าสุดอ่อน';
    statusDetail = 'ผลทดสอบสะสมดูดี แต่ช่วงล่าสุดยังไม่ชนะโมเดลฐานทั้งสองคะแนน · งดชี้ฝั่ง';
  } else if (!calibrationStable) {
    status = 'ยังไม่สอบเทียบ';
    statusDetail = `คะแนนโมเดลยังสอบเทียบกับผลจริงไม่พอ (ECE ${calibration.ece === null ? '—' : calibration.ece.toFixed(3)}; ต้องไม่เกิน ${MAX_CALIBRATION_ECE.toFixed(2)}) · งดชี้ฝั่ง`;
  } else if (!contextAssessable) {
    status = 'บริบทชูใหม่ยังน้อย';
    statusDetail = 'ต้องมีผลตัดสินอย่างน้อย 24 ผลในชูปัจจุบัน และประวัติรวม 80 ผล เพื่อเปรียบเทียบบริบทล่าสุดกับความจำเดิม · งดชี้ฝั่ง';
  } else if (!contextStable) {
    status = 'บริบทเปลี่ยนเร็ว';
    statusDetail = 'สัดส่วน B/P 32 ผลล่าสุดต่างจากประวัติรวมมาก จึงพักสัญญาณไว้จนมีข้อมูลบริบทเพิ่ม · ความต่างนี้เป็นเพียงตัวเตือน ไม่ใช่ข้อพิสูจน์ว่าเกมเปลี่ยน';
  } else if (!lowConflict) {
    status = 'โมเดลเห็นต่างกัน';
    statusDetail = 'ผู้เชี่ยวชาญย่อยให้มุมมองกระจายกันมากเกินไป · งดชี้ฝั่ง';
  } else if (!hasEdge) {
    status = 'สัญญาณอ่อน';
    statusDetail = 'คะแนนรวมใกล้ 50/50 เกินกว่าจะชี้ทิศทางอย่างมีนัยใช้งาน';
  } else {
    status = 'ผ่านเกณฑ์ย้อนหลัง';
    statusDetail = 'ผ่านเกณฑ์ตรวจสอบย้อนหลังแบบเข้มงวด แต่ยังไม่ใช่หลักฐานว่ามีความได้เปรียบในการเดิมพันจริง';
  }

  const patternScan = scanLearningPatterns(features.recent32);
  const expertDetails = EXPERTS.map((expert) => {
    const stats = model.expertStats[expert.id];
    return {
      id: expert.id,
      label: expert.label,
      weight: expertForecast.weights[expert.id],
      samples: stats.samples,
      active: stats.active,
      accuracy: stats.samples ? stats.correct / stats.samples : null,
      brier: stats.samples ? stats.brier / stats.samples : null,
      logLoss: stats.samples ? stats.logLoss / stats.samples : null,
      currentProbabilityB: expertForecast.predictions[expert.id],
      support: expertForecast.support[expert.id]
    };
  }).sort((a, b) => b.weight - a.weight);

  return {
    side,
    // Immediate model lean is always available when the score clears the tiny-neutral zone.
    // It is explicitly provisional unless the separate validation gates pass.
    leanSide,
    directionClass: side ? 'validated' : leanSide ? 'provisional' : 'neutral',
    pB,
    pP,
    edge,
    disagreement: expertForecast.disagreement,
    status,
    statusDetail,
    contextShift,
    pattern: features.pattern,
    patternScan,
    observationsLearned: learnedSampleCount,
    shoesLearned: shoesCount,
    adaptation: { weightForgetting: WEIGHT_FORGETTING, weightHalfLife: WEIGHT_HALF_LIFE },
    totalHands,
    evaluation: {
      samples,
      evaluatedShoes: evaluation.evaluatedShoes,
      accuracy: samples ? evaluation.correct / samples : null,
      brier: samples ? evaluation.brier / samples : null,
      baselineBrier: samples ? evaluation.baselineBrier / samples : null,
      logLoss: samples ? evaluation.logLoss / samples : null,
      baselineLogLoss: samples ? evaluation.baselineLogLoss / samples : null,
      brierImprovement,
      logLossImprovement,
      recent,
      beatsBaseline,
      recentStable,
      calibration,
      calibrationStable,
      brierSkillScore: samples ? 1 - ((evaluation.brier / samples) / (evaluation.baselineBrier / samples)) : null
    },
    patternMemory: {
      key: features.patternKey,
      type: features.pattern.type,
      samples: patternSamples,
      bankerRate: patternSamples ? patternCounts.B / patternSamples : null,
      playerRate: patternSamples ? patternCounts.P / patternSamples : null
    },
    experts: expertDetails,
    roadState: Object.fromEntries(ROAD_OFFSETS.map((road) => [road.id, local.roads[road.offset].slice(-6)]))
  };
}
/**
 * Replay all recorded shoes chronologically. Historical prediction at hand t
 * is produced before observing hand t, then the model learns from that result.
 */
function createEmptyLearningSession() {
  return {
    model: newModel(),
    metrics: newMetrics(),
    shoesCount: 0,
    totalHands: 0,
    totalDecisive: 0,
    totalTies: 0,
    perShoe: [],
    activeLocal: newLocalState(),
    activeResults: [],
    activeStats: null
  };
}

/** Start a new shoe without discarding learned cross-shoe model memory. */
export function startLearningShoe(session, shoe) {
  if (!session || !session.model) throw new TypeError('ไม่พบ learning session');
  const id = String(shoe?.id ?? `shoe-${session.shoesCount + 1}`);
  const name = String(shoe?.name ?? `ชู ${session.shoesCount + 1}`);
  session.shoesCount += 1;
  session.activeLocal = newLocalState();
  session.activeResults = [];
  session.activeStats = {
    id, name, hands: 0, decisive: 0, ties: 0,
    evaluated: 0, correct: 0, brierTotal: 0, logLossTotal: 0,
    baselineBrierTotal: 0, baselineLogLossTotal: 0
  };
  session.perShoe.push(session.activeStats);
  return session;
}

/**
 * Append one observed result. A non-Tie result is forecast from prior state,
 * evaluated, then used to update the model. This is the fast normal input path.
 */
export function appendLearningResult(session, inputResult) {
  if (!session?.model || !session.activeStats) throw new TypeError('ต้องเริ่มชูก่อนเพิ่มผล');
  const result = validateResults([inputResult])[0];
  session.activeResults.push(result);
  session.activeStats.hands += 1;
  session.totalHands += 1;

  if (result === 'T') {
    session.activeStats.ties += 1;
    session.totalTies += 1;
    session.activeLocal.ties += 1;
    return result;
  }

  const features = featureSnapshot(session.activeLocal);
  const predicted = predictExperts(session.model, features);
  const forecast = {
    pB: predicted.pB,
    side: predicted.pB >= 0.5 ? 'B' : 'P',
    experts: predicted.predictions,
    support: predicted.support
  };
  const evaluate = session.model.observations >= 12;
  if (evaluate) {
    if (session.activeStats.evaluated === 0) session.metrics.evaluatedShoes += 1;
    const y = result === 'B' ? 1 : 0;
    session.activeStats.evaluated += 1;
    session.activeStats.correct += forecast.side === result ? 1 : 0;
    session.activeStats.brierTotal += (forecast.pB - y) ** 2;
    session.activeStats.logLossTotal += -(y * Math.log(Math.max(EPSILON, forecast.pB)) + (1 - y) * Math.log(Math.max(EPSILON, 1 - forecast.pB)));
    const baselineP = clampProbability(predicted.predictions.global);
    session.activeStats.baselineBrierTotal += (baselineP - y) ** 2;
    session.activeStats.baselineLogLossTotal += -(y * Math.log(baselineP) + (1 - y) * Math.log(1 - baselineP));
  }

  updateOnlineModel(session.model, features, forecast, result, session.metrics, evaluate);
  updateLocalState(session.activeLocal, result);
  session.activeStats.decisive += 1;
  session.totalDecisive += 1;
  return result;
}

/** Build an online learner once by replaying all historical shoes chronologically. */
export function createLearningSession(inputShoes) {
  if (!Array.isArray(inputShoes)) throw new TypeError('shoes ต้องเป็น array');
  const shoes = inputShoes.map((shoe, index) => ({
    id: String(shoe?.id ?? `shoe-${index + 1}`),
    name: String(shoe?.name ?? `ชู ${index + 1}`),
    results: validateResults(shoe?.results ?? [])
  }));
  if (!shoes.length) shoes.push({ id: 'shoe-1', name: 'ชู 1', results: [] });
  const session = createEmptyLearningSession();
  for (const shoe of shoes) {
    startLearningShoe(session, shoe);
    for (const result of shoe.results) appendLearningResult(session, result);
  }
  return session;
}

/** Read-only presentation snapshot. Does not replay or mutate the learner. */
export function snapshotLearningSession(session) {
  if (!session?.model || !session.activeStats) throw new TypeError('ไม่พบ learning session');
  const forecast = buildForecast(
    session.model,
    session.activeLocal,
    session.shoesCount,
    session.totalHands,
    session.metrics,
    session.perShoe
  );
  const metrics = session.metrics;
  return {
    forecast,
    metrics: {
      totalHands: session.totalHands,
      totalDecisive: session.totalDecisive,
      totalTies: session.totalTies,
      shoes: session.shoesCount,
      evaluated: metrics.evaluated,
      evaluatedShoes: metrics.evaluatedShoes,
      accuracy: metrics.evaluated ? metrics.correct / metrics.evaluated : null,
      brier: metrics.evaluated ? metrics.brier / metrics.evaluated : null,
      baselineBrier: metrics.evaluated ? metrics.baselineBrier / metrics.evaluated : null,
      logLoss: metrics.evaluated ? metrics.logLoss / metrics.evaluated : null,
      baselineLogLoss: metrics.evaluated ? metrics.baselineLogLoss / metrics.evaluated : null
    },
    perShoe: session.perShoe.map((shoe) => ({
      id: shoe.id,
      name: shoe.name,
      hands: shoe.hands,
      decisive: shoe.decisive,
      ties: shoe.ties,
      evaluated: shoe.evaluated,
      accuracy: shoe.evaluated ? shoe.correct / shoe.evaluated : null,
      brier: shoe.evaluated ? shoe.brierTotal / shoe.evaluated : null
    })),
    active: {
      results: [...session.activeResults],
      sequence: [...session.activeLocal.sequence],
      currentStreak: session.activeLocal.currentStreak ? { ...session.activeLocal.currentStreak } : null,
      runs: session.activeLocal.runs.map((run) => ({ ...run })),
      roadMarks: Object.fromEntries(Object.entries(session.activeLocal.roads).map(([key, value]) => [key, [...value]]))
    }
  };
}

/** Convenience deterministic replay API used by tests and imported datasets. */
export function learnFromShoes(inputShoes, activeShoeIndex = inputShoes.length - 1) {
  if (!Array.isArray(inputShoes)) throw new TypeError('shoes ต้องเป็น array');
  const normalizedShoes = inputShoes.map((shoe, index) => ({
    id: String(shoe?.id ?? `shoe-${index + 1}`),
    name: String(shoe?.name ?? `ชู ${index + 1}`),
    results: validateResults(shoe?.results ?? [])
  }));
  const requestedIndex = Number.isInteger(activeShoeIndex) ? activeShoeIndex : normalizedShoes.length - 1;
  const lastIncludedIndex = Math.max(-1, Math.min(requestedIndex, normalizedShoes.length - 1));
  const session = createLearningSession(normalizedShoes.slice(0, lastIncludedIndex + 1));
  return snapshotLearningSession(session);
}

export function normalizeWorkspace(value) {
  let parsed = value;
  if (typeof parsed === 'string') parsed = JSON.parse(parsed);
  if (Array.isArray(parsed)) return [{ id: 'shoe-1', name: 'ชู 1', results: validateResults(parsed) }];
  if (Array.isArray(parsed?.shoes)) {
    const shoes = parsed.shoes.map((shoe, index) => ({
      id: String(shoe?.id ?? `shoe-${index + 1}`),
      name: String(shoe?.name ?? `ชู ${index + 1}`),
      results: validateResults(shoe?.results ?? [])
    }));
    return shoes.length ? shoes : [{ id: 'shoe-1', name: 'ชู 1', results: [] }];
  }
  // Backward compatibility with Baccarat Atlas v1 exports.
  if (Array.isArray(parsed?.results)) return [{ id: 'shoe-1', name: 'ชู 1 (นำเข้าจาก v1)', results: validateResults(parsed.results) }];
  throw new TypeError('ไม่พบข้อมูล shoes หรือ results ในไฟล์');
}

export function exportWorkspace(shoes) {
  return {
    app: 'Baccarat Atlas AI',
    version: 2,
    learningVersion: LEARNING_VERSION,
    exportedAt: new Date().toISOString(),
    shoes: shoes.map((shoe, index) => ({
      id: String(shoe.id ?? `shoe-${index + 1}`),
      name: String(shoe.name ?? `ชู ${index + 1}`),
      results: validateResults(shoe.results ?? [])
    }))
  };
}

export function exportWorkspaceCsv(shoes) {
  const rows = ['shoe,hand,result'];
  shoes.forEach((shoe, shoeIndex) => {
    validateResults(shoe.results ?? []).forEach((result, handIndex) => {
      rows.push(`${shoeIndex + 1},${handIndex + 1},${result}`);
    });
  });
  return rows.join('\n');
}

export function parseWorkspaceCsv(csvText) {
  if (typeof csvText !== 'string') throw new TypeError('ไฟล์ CSV ต้องเป็นข้อความ');
  const source = csvText.replace(/^\uFEFF/, '');
  const firstLine = source.split(/\r?\n/, 1)[0] ?? '';
  const delimiter = [',', '\t', ';'].map((candidate) => ({
    candidate,
    count: [...firstLine].filter((character) => character === candidate).length
  })).sort((a, b) => b.count - a.count)[0].candidate;

  // Parse quoted fields (including escaped double quotes) rather than splitting raw lines.
  const rows = [];
  let row = [];
  let field = '';
  let quoted = false;
  for (let index = 0; index < source.length; index += 1) {
    const character = source[index];
    if (quoted) {
      if (character === '"' && source[index + 1] === '"') {
        field += '"';
        index += 1;
      } else if (character === '"') {
        quoted = false;
      } else {
        field += character;
      }
    } else if (character === '"' && field.length === 0) {
      quoted = true;
    } else if (character === delimiter) {
      row.push(field.trim());
      field = '';
    } else if (character === '\n' || character === '\r') {
      if (character === '\r' && source[index + 1] === '\n') index += 1;
      row.push(field.trim());
      if (row.some((value) => value !== '')) rows.push(row);
      row = [];
      field = '';
    } else {
      field += character;
    }
  }
  if (quoted) throw new TypeError('CSV มีเครื่องหมายอัญประกาศไม่ครบ');
  row.push(field.trim());
  if (row.some((value) => value !== '')) rows.push(row);
  if (!rows.length) return [{ id: 'shoe-1', name: 'ชู 1', results: [] }];

  const normalizeHeader = (value) => String(value ?? '').trim().toLowerCase().replace(/[ _-]+/g, '');
  const headers = rows[0].map(normalizeHeader);
  const resultNames = new Set(['result', 'outcome', 'winner', 'ผล']);
  const shoeNames = new Set(['shoe', 'shoeno', 'shoenumber', 'ชู']);
  const handNames = new Set(['hand', 'handno', 'handnumber', 'round', 'ตา', 'มือ']);
  const resultColumn = headers.findIndex((value) => resultNames.has(value));
  const shoeColumn = headers.findIndex((value) => shoeNames.has(value));
  const handColumn = headers.findIndex((value) => handNames.has(value));
  const hasHeader = resultColumn >= 0;

  const groups = new Map();
  const dataRows = rows.slice(hasHeader ? 1 : 0);
  for (let rowIndex = 0; rowIndex < dataRows.length; rowIndex += 1) {
    const fields = dataRows[rowIndex];
    if (!fields.length || fields.every((value) => value === '')) continue;
    let shoeKey = '1';
    let handNumber = null;
    let resultToken;

    if (hasHeader) {
      shoeKey = shoeColumn >= 0 ? (fields[shoeColumn] || '1') : '1';
      resultToken = fields[resultColumn];
      if (handColumn >= 0) {
        const rawHand = fields[handColumn];
        if (!/^\d+$/.test(String(rawHand ?? ''))) {
          throw new TypeError(`CSV: เลขมือต้องเป็นจำนวนเต็มบวกที่บรรทัด ${rowIndex + 2}`);
        }
        handNumber = Number(rawHand);
      }
    } else if (fields.length >= 3 && /^\d+$/.test(fields[0]) && /^\d+$/.test(fields[1])) {
      shoeKey = fields[0];
      handNumber = Number(fields[1]);
      resultToken = fields[2];
    } else if (fields.length === 2 && /^\d+$/.test(fields[0])) {
      handNumber = Number(fields[0]);
      resultToken = fields[1];
    } else {
      resultToken = fields.at(-1);
    }

    if (handNumber !== null && (!Number.isSafeInteger(handNumber) || handNumber < 1)) {
      throw new TypeError(`CSV: เลขมือต้องเริ่มจาก 1 ที่บรรทัด ${rowIndex + (hasHeader ? 2 : 1)}`);
    }
    let result;
    try {
      result = normalizeResult(resultToken);
    } catch {
      throw new TypeError(`CSV: ผลที่บรรทัด ${rowIndex + (hasHeader ? 2 : 1)} ไม่ถูกต้อง (รองรับ P, B, T)`);
    }

    const key = String(shoeKey).trim() || '1';
    const group = groups.get(key) ?? new Map();
    const nextHand = handNumber ?? (group.size + 1);
    if (group.has(nextHand)) throw new TypeError(`CSV: พบเลขมือ ${nextHand} ซ้ำในชู ${key}`);
    group.set(nextHand, result);
    groups.set(key, group);
  }

  if (!groups.size) return [{ id: 'shoe-1', name: 'ชู 1', results: [] }];
  const orderedGroups = [...groups.entries()].sort(([a], [b]) => {
    const an = Number(a); const bn = Number(b);
    if (Number.isFinite(an) && Number.isFinite(bn)) return an - bn;
    return a.localeCompare(b, 'th');
  });
  return orderedGroups.map(([key, handMap], index) => {
    const orderedHands = [...handMap.keys()].sort((a, b) => a - b);
    for (let position = 0; position < orderedHands.length; position += 1) {
      if (orderedHands[position] !== position + 1) {
        throw new TypeError(`CSV: ชู ${key} ขาดข้อมูลมือที่ ${position + 1} จึงไม่สามารถเรียงประวัติได้อย่างปลอดภัย`);
      }
    }
    const number = Number(key);
    const name = Number.isFinite(number) ? `ชู ${number}` : key;
    return {
      id: `shoe-${Number.isFinite(number) ? number : index + 1}`,
      name,
      results: validateResults(orderedHands.map((hand) => handMap.get(hand)))
    };
  });
}

