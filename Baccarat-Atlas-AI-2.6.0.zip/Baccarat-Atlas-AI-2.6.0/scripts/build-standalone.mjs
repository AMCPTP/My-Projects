import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const htmlPath = resolve(root, 'index.html');
const cssPath = resolve(root, 'styles.css');
const enginePath = resolve(root, 'src/engine.js');
const learningPath = resolve(root, 'src/learning.js');
const appPath = resolve(root, 'src/app.js');
const outputPath = resolve(root, 'dist/Baccarat-Atlas-AI.html');

const [html, css, engineSource, learningSource, appSource] = await Promise.all([
  readFile(htmlPath, 'utf8'),
  readFile(cssPath, 'utf8'),
  readFile(enginePath, 'utf8'),
  readFile(learningPath, 'utf8'),
  readFile(appPath, 'utf8')
]);

const cssPlaceholder = '  <link rel="stylesheet" href="./styles.css">';
const appPlaceholder = '  <script type="module" src="./src/app.js"></script>';
if (!html.includes(cssPlaceholder) || !html.includes(appPlaceholder)) {
  throw new Error('index.html must be a developer template with styles.css and src/app.js references; refusing to build a stale standalone snapshot.');
}

const engine = engineSource.replace(/^export\s+/gm, '');
const learning = learningSource
  .replace(/^import\s*\{[\s\S]*?\}\s*from\s*['"]\.\/engine\.js['"];\s*/m, '')
  .replace(/^export\s+/gm, '');
const app = appSource.replace(/^import\s*\{[\s\S]*?\}\s*from\s*['"]\.\/(?:engine|learning)\.js['"];\s*/gm, '');
const standalone = html
  .replace(cssPlaceholder, `  <style>\n${css}\n  </style>`)
  .replace(appPlaceholder, `  <script>\n${engine}\n\n${learning}\n\n${app}\n  </script>`);
if (standalone.includes('src/app.js') || standalone.includes('src/engine.js') || standalone.includes('src/learning.js')) {
  throw new Error('Standalone build still contains external source references.');
}

await mkdir(dirname(outputPath), { recursive: true });
await writeFile(outputPath, standalone, 'utf8');
process.stdout.write(`Built ${outputPath}\n`);



