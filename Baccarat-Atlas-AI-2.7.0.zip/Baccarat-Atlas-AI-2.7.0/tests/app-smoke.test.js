import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import vm from 'node:vm';
import * as engine from '../src/engine.js';
import * as learning from '../src/learning.js';

class FakeElement {
  constructor(id = '') {
    this.id = id;
    this._textContent = '';
    Object.defineProperty(this, 'textContent', { get: () => this._textContent, set: (value) => { this._textContent = String(value ?? ''); } });
    this.innerHTML = '';
    this.className = '';
    this.classList = { add: () => {}, remove: () => {} };
    this.style = {};
    this.disabled = false;
    this.value = '';
    this.files = [];
    this.listeners = new Map();
    this.tagName = 'DIV';
  }
  addEventListener(type, callback) {
    const entries = this.listeners.get(type) ?? [];
    entries.push(callback);
    this.listeners.set(type, entries);
  }
  dispatch(type, event = {}) {
    for (const callback of this.listeners.get(type) ?? []) callback({ target: this, preventDefault() {}, ...event });
  }
  click() { this.dispatch('click'); }
  remove() {}
  append() {}
}

async function mountApp() {
  const appSource = (await readFile(new URL('../src/app.js', import.meta.url), 'utf8'))
    .replace(/^import\s*\{[\s\S]*?\}\s*from\s*['"]\.\/(?:engine|learning)\.js['"];\s*/gm, '');
  const elements = new Map();
  const documentListeners = new Map();
  const storage = new Map();
  let promptValue;
  let nextTimerId = 1;
  const timers = new Map();
  const document = {
    activeElement: null,
    body: new FakeElement('body'),
    getElementById(id) {
      if (!elements.has(id)) elements.set(id, new FakeElement(id));
      return elements.get(id);
    },
    createElement(tag) { return new FakeElement(tag); },
    addEventListener(type, callback) {
      const entries = documentListeners.get(type) ?? [];
      entries.push(callback);
      documentListeners.set(type, entries);
    },
    dispatch(type, event = {}) {
      for (const callback of documentListeners.get(type) ?? []) callback({ preventDefault() {}, ...event });
    }
  };
  const localStorage = {
    getItem(key) { return storage.has(key) ? storage.get(key) : null; },
    setItem(key, value) { storage.set(key, String(value)); },
    removeItem(key) { storage.delete(key); }
  };
  const context = {
    ...engine,
    ...learning,
    document,
    localStorage,
    window: { confirm: () => true, prompt: (_message, fallback) => promptValue === undefined ? fallback : promptValue },
    setTimeout: (callback) => { const id = nextTimerId++; timers.set(id, callback); return id; },
    clearTimeout: (id) => timers.delete(id),
    console,
    Blob,
    URL: { createObjectURL: () => 'blob:test', revokeObjectURL: () => {} }
  };
  vm.runInNewContext(appSource, context, { filename: 'app.js' });
  const flushTimers = () => { while (timers.size) { const [id, callback] = timers.entries().next().value; timers.delete(id); callback(); } };
  return { elements, document, storage, flushTimers, setPromptValue: (value) => { promptValue = value; } };
}

test('AI workspace records results, undoes/redoes and starts a new shoe without losing memory', async () => {
  const { elements, document, storage, flushTimers } = await mountApp();
  const el = (id) => elements.get(id);
  assert.equal(el('entryCount').textContent, '0 HANDS');

  el('addP').click();
  el('addB').click();
  el('addT').click();
  flushTimers();
  assert.equal(el('entryCount').textContent, '3 HANDS');
  assert.match(el('beadBoard').innerHTML, /P/);
  assert.match(el('beadBoard').innerHTML, /B/);
  assert.match(el('beadBoard').innerHTML, /T/);
  assert.ok(storage.has('baccaratAtlas.ai.workspace.v2'));

  el('undo').click();
  assert.equal(el('entryCount').textContent, '2 HANDS');
  el('redo').click();
  assert.equal(el('entryCount').textContent, '3 HANDS');

  document.dispatch('keydown', { key: 'p', ctrlKey: false, shiftKey: false, altKey: false, metaKey: false });
  assert.equal(el('entryCount').textContent, '4 HANDS');
  document.dispatch('keydown', { key: 'z', ctrlKey: true, shiftKey: false, altKey: false, metaKey: false });
  assert.equal(el('entryCount').textContent, '3 HANDS');

  el('newShoe').click();
  assert.equal(el('entryCount').textContent, '0 HANDS');
  assert.equal(el('shoeCount').textContent, '2');
  assert.equal(el('memoryHands').textContent, '2');
  el('addB').click();
  assert.equal(el('memoryHands').textContent, '3');
  assert.match(el('shoeHistory').innerHTML, /ชู 1/);
  assert.match(el('shoeHistory').innerHTML, /ชู 2/);
});

test('reset clears only the active shoe while clear-memory removes all learned history', async () => {
  const { elements } = await mountApp();
  const el = (id) => elements.get(id);
  for (const side of ['addB', 'addP', 'addB', 'addP']) el(side).click();
  el('newShoe').click();
  el('addP').click();
  el('resetShoe').click();
  assert.equal(el('entryCount').textContent, '0 HANDS');
  assert.equal(el('memoryHands').textContent, '4');
  el('clearMemory').click();
  assert.equal(el('shoeCount').textContent, '1');
  assert.equal(el('memoryHands').textContent, '0');
  assert.equal(el('entryCount').textContent, '0 HANDS');
});


test('provisional direction appears immediately while the validation status stays cautious', async () => {
  const { elements } = await mountApp();
  const el = (id) => elements.get(id);
  el('addB').click();
  assert.equal(el('forecastToken').textContent, '~B');
  assert.match(el('forecastTitle').textContent, /เบื้องต้น/);
  assert.match(el('signalState').textContent, /หลักฐานยังไม่พอ/);
});


test('recent sequence keeps only decisive results and remains consistent through undo and redo', async () => {
  const { elements } = await mountApp();
  const el = (id) => elements.get(id);
  for (const side of ['addB', 'addT', 'addP', 'addT', 'addP']) el(side).click();
  assert.equal(el('recentCount').textContent, '3 ผล');
  assert.deepEqual([...el('recentSequence').innerHTML.matchAll(/sequence-token ([BP])/g)].map((match) => match[1]), ['B', 'P', 'P']);
  el('undo').click();
  assert.equal(el('recentCount').textContent, '2 ผล');
  el('redo').click();
  assert.equal(el('recentCount').textContent, '3 ผล');
});

test('macOS command shortcuts undo and redo without being treated as result input', async () => {
  const { elements, document } = await mountApp();
  const el = (id) => elements.get(id);
  el('addB').click();
  document.dispatch('keydown', { key: 'z', ctrlKey: false, metaKey: true, shiftKey: false, altKey: false });
  assert.equal(el('entryCount').textContent, '0 HANDS');
  document.dispatch('keydown', { key: 'z', ctrlKey: false, metaKey: true, shiftKey: true, altKey: false });
  assert.equal(el('entryCount').textContent, '1 HAND');
});

test('editing a historical result rebuilds memory from the corrected record', async () => {
  const { elements, setPromptValue } = await mountApp();
  const el = (id) => elements.get(id);
  for (const id of ['addB', 'addB', 'addP', 'addP']) el(id).click();
  assert.equal(el('memoryHands').textContent, '4');
  setPromptValue('P B P T');
  el('editShoe').click();
  assert.equal(el('entryCount').textContent, '4 HANDS');
  assert.equal(el('memoryHands').textContent, '3');
  assert.match(el('beadBoard').innerHTML, /T/);
  setPromptValue('P Q B');
  el('editShoe').click();
  assert.equal(el('entryCount').textContent, '4 HANDS', 'invalid edit must not overwrite saved results');
});

test('standalone build boots without imports, records results, and runs the learning engine', async () => {
  const standalone = await readFile(new URL('../dist/Baccarat-Atlas-AI.html', import.meta.url), 'utf8');
  const script = standalone.match(/<script>([\s\S]*?)<\/script>/)?.[1];
  assert.ok(script, 'standalone HTML contains an inline application script');
  assert.doesNotMatch(script, /^import\s/m);
  assert.match(script, /const LEARNING_VERSION = 7;/, 'standalone HTML must include the current learning engine');
  assert.match(script, /const CALIBRATION_BIN_COUNT = 10;/, 'standalone HTML must include walk-forward calibration');
  assert.match(script, /Game State Memory/, 'standalone HTML must include state-aware historical retrieval');
  assert.match(script, /STATE_RETRIEVAL_MIN_SAMPLES/, 'standalone HTML must include hierarchical state fallback');
  assert.match(script, /const WEIGHT_FORGETTING = 0\.9975;/, 'standalone HTML must include adaptive expert weighting');
  const elements = new Map();
  const storage = new Map();
  let promptValue;
  const timers = new Map();
  let nextTimerId = 1;
  const document = {
    activeElement: null,
    body: new FakeElement('body'),
    getElementById(id) {
      if (!elements.has(id)) elements.set(id, new FakeElement(id));
      return elements.get(id);
    },
    createElement(tag) { return new FakeElement(tag); },
    addEventListener() {}
  };
  const localStorage = {
    getItem(key) { return storage.get(key) ?? null; },
    setItem(key, value) { storage.set(key, String(value)); },
    removeItem(key) { storage.delete(key); }
  };
  vm.runInNewContext(script, {
    document,
    localStorage,
    window: { confirm: () => true, prompt: (_message, fallback) => promptValue === undefined ? fallback : promptValue },
    setTimeout: (callback) => { const id = nextTimerId++; timers.set(id, callback); return id; },
    clearTimeout: (id) => timers.delete(id),
    console,
    Blob,
    URL: { createObjectURL: () => 'blob:test', revokeObjectURL: () => {} }
  }, { filename: 'Baccarat-Atlas-AI.html' });
  for (let index = 0; index < 14; index += 1) elements.get(index % 2 ? 'addP' : 'addB').click();
  while (timers.size) { const [id, callback] = timers.entries().next().value; timers.delete(id); callback(); }
  assert.equal(elements.get('memorySamples').textContent, '14');
  assert.match(elements.get('forecastToken').textContent, /^(~[BP]|—)$/, 'show an immediate provisional lean without pretending it passed validation');
  assert.match(elements.get('signalState').textContent, /หลักฐานยังไม่พอ/);
  assert.ok(elements.get('patternMetrics').innerHTML.includes('อัตราสลับฝั่ง'));
  assert.ok(storage.has('baccaratAtlas.ai.workspace.v2'));
});





