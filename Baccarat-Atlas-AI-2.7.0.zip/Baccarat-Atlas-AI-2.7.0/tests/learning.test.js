import test from 'node:test';
import assert from 'node:assert/strict';
import { buildAllRoads } from '../src/engine.js';
import {
  learnFromShoes,
  detectLearningPattern,
  scanLearningPatterns,
  analyzeGameState,
  normalizeWorkspace,
  exportWorkspace,
  exportWorkspaceCsv,
  parseWorkspaceCsv
} from '../src/learning.js';

const makeShoe = (id, results) => ({ id, name: id, results: results.split('') });

test('cold start waits for evidence rather than fabricating a directional signal', () => {
  const output = learnFromShoes([makeShoe('short', 'BPBPPBBP')]);
  assert.equal(output.forecast.observationsLearned, 8);
  assert.equal(output.forecast.side, null);
  assert.equal(output.metrics.evaluated, 0);
});

test('online learner evaluates prequentially after the 12-observation warm-up', () => {
  const output = learnFromShoes([makeShoe('long', 'BPBPPBBPBPBPBPPBBPBPBBPPBPPB')]);
  assert.equal(output.metrics.totalDecisive, 28);
  assert.equal(output.metrics.evaluated, 16);
  assert.equal(output.forecast.side, null);
  assert.equal(output.forecast.status, 'หลักฐานยังไม่พอ');
  assert.ok(output.forecast.pB >= 0.02 && output.forecast.pB <= 0.98);
  assert.ok(Math.abs(output.forecast.pB + output.forecast.pP - 1) < 1e-10);
});

test('learning memory crosses shoe boundaries but road sequence resets at each new shoe', () => {
  const output = learnFromShoes([
    makeShoe('shoe-1', 'BBBBPPPPBBBBPPPP'),
    makeShoe('shoe-2', 'BPBPB')
  ]);
  assert.equal(output.metrics.shoes, 2);
  assert.equal(output.metrics.totalDecisive, 21);
  assert.deepEqual(output.active.sequence, ['B', 'P', 'B', 'P', 'B']);
  assert.equal(output.forecast.observationsLearned, 21);
});

test('selected historical shoe replay excludes later shoes to prevent future leakage', () => {
  const first = makeShoe('shoe-1', 'BBBBPPPPBBBBPPPPBPBPBP');
  const laterA = makeShoe('shoe-2', 'BBBBBBBBBBBBBBBB');
  const laterB = makeShoe('shoe-2', 'PPPPPPPPPPPPPPPP');
  const a = learnFromShoes([first, laterA], 0);
  const b = learnFromShoes([first, laterB], 0);
  assert.equal(a.forecast.pB, b.forecast.pB);
  assert.equal(a.forecast.observationsLearned, b.forecast.observationsLearned);
  assert.deepEqual(a.active.sequence, b.active.sequence);
});

test('Tie is stored in hands but excluded from decisive learning observations', () => {
  const output = learnFromShoes([makeShoe('ties', 'TTBPPTBTTB')]);
  assert.equal(output.metrics.totalHands, 10);
  assert.equal(output.metrics.totalTies, 5);
  assert.equal(output.metrics.totalDecisive, 5);
  assert.equal(output.forecast.observationsLearned, 5);
  assert.deepEqual(output.active.sequence, ['B', 'P', 'P', 'B', 'B']);
});

test('expert weights remain normalized and expose historical diagnostics', () => {
  const output = learnFromShoes([makeShoe('a', 'BBPPBPBBPPBBPBPBPBPPBBPPBPPB')]);
  const sum = output.forecast.experts.reduce((total, expert) => total + expert.weight, 0);
  assert.ok(Math.abs(sum - 1) < 1e-10);
  assert.ok(output.forecast.experts.length >= 10);
  for (const expert of output.forecast.experts) {
    assert.ok(expert.weight >= 0 && expert.weight <= 1);
    assert.ok(expert.samples >= 0);
    assert.ok(expert.currentProbabilityB >= 0 && expert.currentProbabilityB <= 1);
  }
});


test('adaptive expert weighting discounts stale influence while preserving the full replay history', () => {
  const first = makeShoe('alternating', 'BP'.repeat(120));
  const second = makeShoe('streaking', 'B'.repeat(120));
  const output = learnFromShoes([first, second]);
  const replay = learnFromShoes([first, second]);

  assert.equal(output.forecast.adaptation.weightForgetting, 0.9975);
  assert.equal(output.forecast.adaptation.weightHalfLife, 277);
  assert.equal(output.metrics.totalDecisive, 360);
  assert.equal(output.metrics.shoes, 2);
  assert.equal(output.forecast.observationsLearned, 360);
  assert.deepEqual(
    output.forecast.experts.map((expert) => [expert.id, expert.weight]),
    replay.forecast.experts.map((expert) => [expert.id, expert.weight]),
    'chronological replay must produce deterministic adaptive weights'
  );
  assert.ok(Math.abs(output.forecast.experts.reduce((sum, expert) => sum + expert.weight, 0) - 1) < 1e-10);
});

test('pattern memory generalizes alternating sequences by current phase', () => {
  const one = detectLearningPattern('BPBPBP'.split(''));
  const two = detectLearningPattern('PBPBPB'.split(''));
  assert.equal(one.type, 'pingpong');
  assert.equal(two.type, 'pingpong');
  assert.equal(one.key, 'pingpong:P');
  assert.equal(two.key, 'pingpong:B');
});



test('multi-angle pattern scan reports rhythm, balance, streak, and descriptive pattern', () => {
  const scan = scanLearningPatterns('BPBPBP'.split(''));
  assert.equal(scan.detections[0].key, 'pingpong');
  assert.equal(scan.stats.window, 6);
  assert.equal(scan.stats.banker, 3);
  assert.equal(scan.stats.player, 3);
  assert.equal(scan.stats.switchCount, 5);
  assert.equal(scan.stats.rhythm, 'สลับฝั่งถี่');
  assert.equal(scan.stats.currentStreak.length, 1);
});



test('scanner can flag overlapping structure and arbitrary repeated motifs', () => {
  const longSide = scanLearningPatterns('BBBBBBBBBBBB'.split(''));
  const longKeys = new Set(longSide.detections.map((item) => item.key));
  assert.ok(longKeys.has('dragon'));
  assert.ok(longKeys.has('stick-heavy'));
  assert.ok(longKeys.has('dominant'));

  const genericCycle = scanLearningPatterns('BPPBPBPPBPBPPBP'.split(''));
  assert.ok(genericCycle.detections.some((item) => item.key === 'cycle'));
});

test('game-state reader describes rhythm and streaks without treating them as future facts', () => {
  const switching = analyzeGameState('BPBPBPBPBPBP'.split(''));
  assert.equal(switching.mode, 'switching');
  assert.equal(switching.windows[8].switchRate, 1);
  assert.match(switching.key, /^state:switching:/);

  const streaking = analyzeGameState('PPPBBBBB'.split(''));
  assert.equal(streaking.mode, 'streaking');
  assert.deepEqual(streaking.currentStreak, { side: 'B', length: 5 });
  assert.ok(streaking.windows[8].entropy >= 0);
});

test('game-state memory is a distinct online specialist with reproducible context evidence', () => {
  const output = learnFromShoes([makeShoe('state-memory', 'BPBPPBBPBPBPBPPBBPBPBBPPBPPB')]);
  const specialist = output.forecast.experts.find((expert) => expert.id === 'situation');
  assert.ok(specialist);
  assert.ok(specialist.currentProbabilityB >= 0 && specialist.currentProbabilityB <= 1);
  assert.match(output.forecast.gameState.key, /^state:/);
  assert.ok(output.forecast.gameStateMemory.samples >= 0);
});

test('state memory transparently backs off from a rare exact state to a supported shape', () => {
  // The final B3 streak is absent from the alternating history, while the
  // broader switching/balanced state occurs repeatedly before it.
  const results = `${'BP'.repeat(70)}BBB`;
  const output = learnFromShoes([makeShoe('hierarchical-state', results)]);
  const evidence = output.forecast.gameStateMemory;
  assert.equal(output.forecast.gameState.mode, 'switching');
  assert.equal(evidence.level, 'shape');
  assert.ok(evidence.samples >= 18);
  assert.equal(evidence.sufficient, true);
  assert.notEqual(evidence.matchedKey, evidence.key);
});

test('direction is withheld when validation spans fewer than five evaluated shoes', () => {
  const sequence = 'BBPPBP'.repeat(45);
  const output = learnFromShoes([makeShoe('only-one-shoe', sequence)]);
  assert.ok(output.forecast.evaluation.samples >= 100);
  assert.equal(output.forecast.evaluation.evaluatedShoes, 1);
  assert.equal(output.forecast.side, null);
  assert.equal(output.forecast.status, 'หลักฐานยังไม่พอ');
  assert.ok(output.forecast.evaluation.brierImprovement.clusters === 1);
});



test('clustered validation exposes shoe-level confidence bounds for multi-shoe histories', () => {
  const shoes = Array.from({ length: 5 }, (_, index) => {
    let seed = 12345 + (index * 98765);
    const results = Array.from({ length: 180 }, () => {
      seed = ((1664525 * seed) + 1013904223) >>> 0;
      return (seed & 0x80000000) ? 'B' : 'P';
    });
    return { id: `shoe-${index + 1}`, name: `shoe-${index + 1}`, results };
  });
  const output = learnFromShoes(shoes);
  assert.ok(output.forecast.evaluation.samples >= 100);
  assert.equal(output.forecast.evaluation.evaluatedShoes, 5);
  assert.equal(output.forecast.evaluation.brierImprovement.clusters, 5);
  assert.equal(output.forecast.evaluation.logLossImprovement.clusters, 5);
  assert.equal(output.forecast.side, null);
});

test('walk-forward calibration is tracked in bins without using future outcomes', () => {
  const output = learnFromShoes([makeShoe('calibration', 'BP'.repeat(90))]);
  const calibration = output.forecast.evaluation.calibration;
  assert.equal(calibration.samples, output.metrics.evaluated);
  assert.ok(calibration.ece >= 0);
  assert.ok(calibration.maxError >= 0);
  assert.equal(calibration.bins.reduce((sum, bin) => sum + bin.samples, 0), calibration.samples);
  for (const bin of calibration.bins) {
    assert.ok(bin.meanProbabilityB >= 0 && bin.meanProbabilityB <= 1);
    assert.ok(bin.observedBankerRate >= 0 && bin.observedBankerRate <= 1);
  }
});

test('a large active-shoe distribution shift is exposed as a guard, not a prediction', () => {
  const shoes = Array.from({ length: 5 }, (_, index) => makeShoe(`history-${index + 1}`, 'P'.repeat(48)));
  shoes.push(makeShoe('active-change', 'B'.repeat(32)));
  const output = learnFromShoes(shoes);
  assert.equal(output.forecast.contextShift.level, 'high');
  assert.equal(output.forecast.contextShift.samples, 32);
  assert.ok(Math.abs(output.forecast.contextShift.delta) >= 0.20);
});


test('the live model exposes a provisional lean immediately but keeps the validated call gated', () => {
  const output = learnFromShoes([makeShoe('cold-start', 'B')]);
  assert.equal(output.forecast.leanSide, 'B');
  assert.equal(output.forecast.directionClass, 'provisional');
  assert.equal(output.forecast.side, null, 'one result cannot qualify as a validated signal');
  assert.match(output.forecast.status, /หลักฐานยังไม่พอ/);
});

test('incremental streak state stays correct across long runs, switches, and ties', async () => {
  const { createLearningSession, appendLearningResult, snapshotLearningSession } = await import('../src/learning.js');
  const session = createLearningSession([{ id: 'streak', results: [] }]);
  for (const result of [...'B'.repeat(4000), 'T', 'B', 'P', 'P', 'T', 'P']) appendLearningResult(session, result);
  const active = snapshotLearningSession(session).active;
  assert.deepEqual(active.currentStreak, { side: 'P', length: 3 });
  assert.equal(active.sequence.length, 4004);
});

test('CSV import restores hand order even when rows are shuffled and rejects gaps or duplicates', () => {
  const shuffled = [
    'shoe,hand,result',
    '2,2,P',
    '1,3,T',
    '1,1,B',
    '2,1,B',
    '1,2,P'
  ].join('\n');
  const restored = parseWorkspaceCsv(shuffled);
  assert.deepEqual(restored.map((shoe) => shoe.results), [['B', 'P', 'T'], ['B', 'P']]);
  assert.throws(() => parseWorkspaceCsv('shoe,hand,result\n1,1,B\n1,1,P'), /ซ้ำ/);
  assert.throws(() => parseWorkspaceCsv('shoe,hand,result\n1,1,B\n1,3,P'), /ขาดข้อมูล/);
});

test('all shoe formats export and import as a reusable training workspace', () => {
  const original = [makeShoe('a', 'BBPPTT'), makeShoe('b', 'PPBBTTBP')];
  const json = exportWorkspace(original);
  const restored = normalizeWorkspace(JSON.stringify(json));
  assert.deepEqual(restored.map((shoe) => shoe.results), original.map((shoe) => shoe.results));
  const csv = exportWorkspaceCsv(original);
  const csvRestored = parseWorkspaceCsv(csv);
  assert.deepEqual(csvRestored.map((shoe) => shoe.results), original.map((shoe) => shoe.results));
});

test('legacy v1 result exports migrate into one training shoe', () => {
  const migrated = normalizeWorkspace({ version: 1, results: ['B', 'P', 'T'] });
  assert.equal(migrated.length, 1);
  assert.deepEqual(migrated[0].results, ['B', 'P', 'T']);
});

test('per-shoe learning diagnostics report evaluated samples only after warm-up', () => {
  const output = learnFromShoes([
    makeShoe('first', 'BBBBBBBBBBBBBBBB'),
    makeShoe('second', 'PPPPPPPPPPPPPPPP')
  ]);
  assert.equal(output.perShoe[0].evaluated, 4);
  assert.equal(output.perShoe[1].evaluated, 16);
  assert.ok(output.perShoe[0].accuracy !== null);
});

test('incremental appends match a clean chronological replay, including a new shoe boundary', async () => {
  const {
    createLearningSession,
    appendLearningResult,
    startLearningShoe,
    snapshotLearningSession
  } = await import('../src/learning.js');
  const firstResults = 'BBPPBPBBPPBBPBPB'.split('');
  const secondResults = 'PBPBBPPBPB'.split('');
  const session = createLearningSession([{ id: 'a', name: 'a', results: firstResults }]);
  startLearningShoe(session, { id: 'b', name: 'b', results: [] });
  for (const result of secondResults) appendLearningResult(session, result);
  const incremental = snapshotLearningSession(session);
  const replay = learnFromShoes([
    { id: 'a', name: 'a', results: firstResults },
    { id: 'b', name: 'b', results: secondResults }
  ]);
  assert.equal(incremental.forecast.pB, replay.forecast.pB);
  assert.equal(incremental.metrics.brier, replay.metrics.brier);
  assert.equal(incremental.metrics.accuracy, replay.metrics.accuracy);
  assert.deepEqual(incremental.active.sequence, replay.active.sequence);
});

test('incremental updates handle a large sequence without rebuilding history per result', async () => {
  const { createLearningSession, appendLearningResult, snapshotLearningSession } = await import('../src/learning.js');
  const session = createLearningSession([{ id: 'large', results: [] }]);
  for (let i = 0; i < 2000; i += 1) appendLearningResult(session, i % 3 === 0 ? 'B' : 'P');
  const output = snapshotLearningSession(session);
  assert.equal(output.metrics.totalDecisive, 2000);
  assert.equal(output.forecast.observationsLearned, 2000);
  assert.equal(output.active.sequence.length, 2000);
});


test('incremental derived-road features match roadmap-engine colors across mixed results', () => {
  const results = Array.from({ length: 240 }, (_, index) => {
    const value = (index * 17 + Math.floor(index / 7) * 3) % 11;
    return value === 0 ? 'T' : value < 5 ? 'B' : 'P';
  });
  const reference = buildAllRoads(results);
  const learned = learnFromShoes([{ id: 'geometry', results }]);
  const expected = {
    1: reference.derivedRoads[0].marks.map((mark) => mark.color),
    2: reference.derivedRoads[1].marks.map((mark) => mark.color),
    3: reference.derivedRoads[2].marks.map((mark) => mark.color)
  };
  assert.deepEqual(learned.active.roadMarks, expected);
});





