/**
 * Baccarat Atlas AI — online, prequential learning engine.
 *
 * This is an adaptive statistical ensemble, not a claim that baccarat
 * sequences are predictable. Every historical forecast is generated using
 * only outcomes that precede it; the realized outcome is then used to update
 * context counts and expert weights. Shoe boundaries reset within-shoe
 * sequence/road state while learned context memory carries across shoes.
 */
import { validateResults } from './engine.js';

export const LEARNING_VERSION = 2;
export const EXPERTS = Object.freeze([
  { id: 'baseline', label: 'Baseline 50/50', family: 'baseline' },
  { id: 'global', label: 'สถิติรวมหลายชู', family: 'global' },
  { id: 'recent8', label: 'Recent 8', family: 'window' },
  { id: 'recent16', label: 'Recent 16', family: 'window' },
  { id: 'recent32', label: 'Recent 32', family: 'window' },
  ...[1, 2, 3, 4, 5, 6].map((n) => ({ id: `markov${n}`, label: `Sequence ${n}`, family: 'sequence' })),
  { id: 'streak', label: 'Streak Context', family: 'pattern' },
  { id: 'pattern', label: 'Pattern Memory', family: 'pattern' },
  { id: 'bigEye', label: 'Big Eye Boy', family: 'road' },
  { id: 'smallRoad', label: 'Small Road', family: 'road' },
  { id: 'cockroach', label: 'Cockroach Pig', family: 'road' }
]);

const ROAD_OFFSETS = Object.freeze([
  { id: 'bigEye', offset: 1 },
  { id: 'smallRoad', offset: 2 },
  { id: 'cockroach', offset: 3 }
]);
const ETA = 0.14;
const EPSILON = 1e-6;

function emptyCounts() { return { B: 0, P: 0 }; }
function countTotal(counts) { return counts ? counts.B + counts.P : 0; }
function addCount(map, key, actual) {
  if (!key) return;
  const counts = map.get(key) ?? emptyCounts();
  counts[actual] += 1;
  map.set(key, counts);
}
function probability(counts, prior = 0.5, strength = 8) {
  if (!counts) return prior;
  const n = countTotal(counts);
  return (counts.B + (strength * prior)) / (n + strength);
}
function clampProbability(value) {
  return Math.max(0.02, Math.min(0.98, value));
}
function normalizeLogWeights(logWeights) {
  const values = Object.values(logWeights);
  const max = Math.max(...values);
  const expValues = Object.fromEntries(Object.entries(logWeights).map(([key, value]) => [key, Math.exp(value - max)]));
  const total = Object.values(expValues).reduce((sum, value) => sum + value, 0) || 1;
  return Object.fromEntries(Object.entries(expValues).map(([key, value]) => [key, value / total]));
}

function newModel() {
  return {
    observations: 0,
    global: emptyCounts(),
    ngram: Array.from({ length: 6 }, () => new Map()),
    streak: new Map(),
    pattern: new Map(),
    road: { 1: new Map(), 2: new Map(), 3: new Map() },
    logWeights: Object.fromEntries(EXPERTS.map((expert) => [expert.id, 0])),
    expertStats: Object.fromEntries(EXPERTS.map((expert) => [expert.id, {
      samples: 0, correct: 0, brier: 0, logLoss: 0, active: 0
    }]))
  };
}

function newLocalState() {
  return { sequence: [], runs: [], roads: { 1: [], 2: [], 3: [] }, ties: 0 };
}

function sideStreak(sequence) {
  if (!sequence.length) return null;
  const side = sequence.at(-1);
  let length = 0;
  for (let i = sequence.length - 1; i >= 0 && sequence[i] === side; i -= 1) length += 1;
  return { side, length };
}

/** Returns the strongest currently visible descriptive pattern, not a forecast. */
export function detectLearningPattern(sequence) {
  if (!sequence.length) return { type: 'random', key: 'random:empty', name: 'รอข้อมูล', sample: '' };
  const recent6 = sequence.slice(-6);
  const recent8 = sequence.slice(-8);
  const repeatsPeriod = (items, period) => items.length >= period * 2 &&
    items.slice(-period).every((value, index) => value === items[items.length - period * 2 + index]);
  const alternating = recent6.length === 6 && recent6.every((value, index) => index === 0 || value !== recent6[index - 1]);
  if (alternating) {
    return { type: 'pingpong', key: `pingpong:${recent6.at(-1)}`, name: 'ปิงปอง', sample: recent6.join('') };
  }
  if (recent6.length === 6 && repeatsPeriod(recent6, 3)) {
    const [a, b, c] = recent6.slice(0, 3);
    if (a === b && b !== c) return { type: 'two-one', key: `two-one:${recent6.at(-1)}:${sideStreak(sequence).length}`, name: 'สองตัวหนึ่ง', sample: recent6.join('') };
    if (a !== b && b === c) return { type: 'one-two', key: `one-two:${recent6.at(-1)}:${sideStreak(sequence).length}`, name: 'หนึ่งตัวสอง', sample: recent6.join('') };
  }
  if (recent8.length === 8 && repeatsPeriod(recent8, 4)) {
    const [a, b, c, d] = recent8.slice(0, 4);
    if (a === b && c === d && a !== c) return { type: 'two-two', key: `two-two:${recent8.at(-1)}:${sideStreak(sequence).length}`, name: 'สองต่อสอง', sample: recent8.join('') };
  }
  const streak = sideStreak(sequence);
  if (streak.length >= 3) {
    const bucket = Math.min(streak.length, 5);
    return { type: 'dragon', key: `dragon:${streak.side}:${bucket}`, name: 'มังกร', sample: sequence.slice(-Math.min(streak.length, 8)).join('') };
  }
  const tail = sequence.slice(-2).join('');
  return { type: 'random', key: `random:${tail || 'start'}`, name: 'ยังไม่ชัดเจน', sample: sequence.slice(-8).join('') };
}

function featureSnapshot(local) {
  const sequence = local.sequence;
  const pattern = detectLearningPattern(sequence);
  const streak = sideStreak(sequence);
  const ngrams = {};
  for (let n = 1; n <= 6; n += 1) {
    ngrams[n] = sequence.length >= n ? sequence.slice(-n).join('') : null;
  }
  const roadKeys = {};
  for (const road of ROAD_OFFSETS) {
    const marks = local.roads[road.offset];
    roadKeys[road.offset] = marks.length ? marks.slice(-3).join('') : null;
  }
  return {
    ngrams,
    streakKey: streak ? `${streak.side}:${Math.min(streak.length, 5)}` : null,
    patternKey: pattern.key,
    pattern,
    roadKeys,
    recent8: sequence.slice(-8),
    recent16: sequence.slice(-16),
    recent32: sequence.slice(-32)
  };
}

function predictExperts(model, features) {
  const globalN = countTotal(model.global);
  const globalP = probability(model.global, 0.5, 12);
  const predictions = {};
  const support = {};
  predictions.baseline = 0.5;
  support.baseline = 0;
  predictions.global = globalP;
  support.global = globalN;

  for (const [id, size] of [['recent8', 8], ['recent16', 16], ['recent32', 32]]) {
    const recent = features[`recent${size}`];
    const counts = { B: recent.filter((x) => x === 'B').length, P: recent.filter((x) => x === 'P').length };
    predictions[id] = probability(counts, globalP, 4);
    support[id] = recent.length;
  }

  let parentP = globalP;
  for (let n = 1; n <= 6; n += 1) {
    const key = features.ngrams[n];
    const counts = key ? model.ngram[n - 1].get(key) : null;
    const p = probability(counts, parentP, 7);
    predictions[`markov${n}`] = p;
    support[`markov${n}`] = countTotal(counts);
    parentP = p;
  }

  const streakCounts = features.streakKey ? model.streak.get(features.streakKey) : null;
  predictions.streak = probability(streakCounts, globalP, 9);
  support.streak = countTotal(streakCounts);

  const patternCounts = model.pattern.get(features.patternKey);
  predictions.pattern = probability(patternCounts, globalP, 9);
  support.pattern = countTotal(patternCounts);

  for (const road of ROAD_OFFSETS) {
    const key = features.roadKeys[road.offset];
    const counts = key ? model.road[road.offset].get(key) : null;
    predictions[road.id] = probability(counts, globalP, 12);
    support[road.id] = countTotal(counts);
  }

  const weights = normalizeLogWeights(model.logWeights);
  let ensembleP = 0;
  for (const expert of EXPERTS) ensembleP += weights[expert.id] * predictions[expert.id];
  return { pB: clampProbability(ensembleP), predictions, support, weights };
}

function updateOnlineModel(model, features, forecast, actual, metrics, includeEvaluation) {
  const y = actual === 'B' ? 1 : 0;
  const p = forecast.pB;
  const brier = (p - y) ** 2;
  const logLoss = -(y * Math.log(Math.max(EPSILON, p)) + (1 - y) * Math.log(Math.max(EPSILON, 1 - p)));
  metrics.totalPredictions += 1;
  if (forecast.side === actual) metrics.totalCorrect += 1;
  metrics.totalBrier += brier;
  metrics.totalLogLoss += logLoss;

  if (includeEvaluation) {
    metrics.evaluated += 1;
    metrics.correct += forecast.side === actual ? 1 : 0;
    metrics.brier += brier;
    metrics.logLoss += logLoss;
    metrics.baselineBrier += 0.25;
    metrics.baselineLogLoss += Math.log(2);
  }

  for (const expert of EXPERTS) {
    const id = expert.id;
    const expertP = clampProbability(forecast.experts[id]);
    const expertLoss = -(y * Math.log(expertP) + (1 - y) * Math.log(1 - expertP));
    const expertBrier = (expertP - y) ** 2;
    const stats = model.expertStats[id];
    stats.samples += 1;
    stats.active += forecast.support[id] > 0 ? 1 : 0;
    stats.correct += (expertP >= 0.5 ? 'B' : 'P') === actual ? 1 : 0;
    stats.brier += expertBrier;
    stats.logLoss += expertLoss;
    // Exponential-weights update: experts that incur more log loss gradually lose influence.
    model.logWeights[id] = Math.max(-60, model.logWeights[id] - (ETA * expertLoss));
  }

  model.global[actual] += 1;
  for (let n = 1; n <= 6; n += 1) addCount(model.ngram[n - 1], features.ngrams[n], actual);
  addCount(model.streak, features.streakKey, actual);
  addCount(model.pattern, features.patternKey, actual);
  for (const road of ROAD_OFFSETS) addCount(model.road[road.offset], features.roadKeys[road.offset], actual);
  model.observations += 1;
}

/** Incrementally maintain logical Big Road runs and the three derived-road colors. */
function updateLocalState(local, actual) {
  const previous = local.runs.at(-1);
  if (!previous || previous.side !== actual) {
    const column = local.runs.length;
    for (const road of ROAD_OFFSETS) {
      if (column >= road.offset + 1) {
        const same = local.runs[column - 1].length === local.runs[column - 1 - road.offset].length;
        local.roads[road.offset].push(same ? 'R' : 'B');
      }
    }
    local.runs.push({ side: actual, length: 1 });
  } else {
    const column = local.runs.length - 1;
    const row = previous.length;
    for (const road of ROAD_OFFSETS) {
      if (row > 0 && column >= road.offset) {
        const comparison = local.runs[column - road.offset].length;
        const same = (row < comparison) === ((row - 1) < comparison);
        local.roads[road.offset].push(same ? 'R' : 'B');
      }
    }
    previous.length += 1;
  }
  local.sequence.push(actual);
}

function newMetrics() {
  return {
    totalPredictions: 0, totalCorrect: 0, totalBrier: 0, totalLogLoss: 0,
    evaluated: 0, correct: 0, brier: 0, logLoss: 0,
    baselineBrier: 0, baselineLogLoss: 0
  };
}

function buildForecast(model, local, shoesCount, totalHands, evaluation) {
  const features = featureSnapshot(local);
  const expertForecast = predictExperts(model, features);
  const pB = expertForecast.pB;
  const pP = 1 - pB;
  const learnedSampleCount = model.observations;
  const edge = Math.abs(pB - 0.5);
  const side = learnedSampleCount >= 12 && edge >= 0.005 ? (pB >= 0.5 ? 'B' : 'P') : null;
  const patternCounts = model.pattern.get(features.patternKey) ?? emptyCounts();
  const patternSamples = countTotal(patternCounts);
  const hasEnoughEvaluation = evaluation.evaluated >= 30;
  const beatsBaseline = hasEnoughEvaluation &&
    (evaluation.brier / evaluation.evaluated) < (evaluation.baselineBrier / evaluation.evaluated) - 0.003 &&
    (evaluation.logLoss / evaluation.evaluated) < (evaluation.baselineLogLoss / evaluation.evaluated) - 0.003;
  let status = 'กำลังเรียนรู้';
  let statusDetail = 'ข้อมูลประเมินแบบเดินหน้า (walk-forward) ยังไม่ถึง 30 ตัวอย่าง';
  if (learnedSampleCount < 12) {
    status = 'กำลังเรียนรู้';
    statusDetail = `มีผลตัดสิน ${learnedSampleCount} ตัวอย่าง · ต้องสะสมอย่างน้อย 12 ตัวอย่างก่อนแสดงทิศทาง`;
  } else if (edge < 0.005) {
    status = 'สัญญาณอ่อน';
    statusDetail = 'คะแนนโมเดล B/P ใกล้ 50/50 มากเกินไป จึงไม่แสดงฝั่งชี้นำ';
  } else if (hasEnoughEvaluation && !beatsBaseline) {
    status = 'ยังไม่เหนือฐาน';
    statusDetail = 'ผลทดสอบยังไม่แสดงว่าโมเดลเหนือกว่าฐาน 50/50';
  } else if (beatsBaseline && edge < 0.015) {
    status = 'สัญญาณอ่อน';
    statusDetail = 'โมเดลผ่านเกณฑ์เทียบฐาน แต่ค่าประเมิน B/P ใกล้กัน';
  } else if (beatsBaseline && edge >= 0.015) {
    status = 'มีแนวโน้ม';
    statusDetail = 'โมเดลทำได้ดีกว่าฐานในชุดทดสอบย้อนหลัง แต่ไม่รับประกันตาถัดไป';
  }

  const expertDetails = EXPERTS.map((expert) => {
    const stats = model.expertStats[expert.id];
    return {
      id: expert.id,
      label: expert.label,
      weight: expertForecast.weights[expert.id],
      samples: stats.samples,
      active: stats.active,
      accuracy: stats.samples ? stats.correct / stats.samples : null,
      brier: stats.samples ? stats.brier / stats.samples : null,
      logLoss: stats.samples ? stats.logLoss / stats.samples : null,
      currentProbabilityB: expertForecast.predictions[expert.id],
      support: expertForecast.support[expert.id]
    };
  }).sort((a, b) => b.weight - a.weight);

  return {
    side,
    pB,
    pP,
    edge,
    status,
    statusDetail,
    pattern: features.pattern,
    observationsLearned: learnedSampleCount,
    shoesLearned: shoesCount,
    totalHands,
    evaluation: {
      samples: evaluation.evaluated,
      accuracy: evaluation.evaluated ? evaluation.correct / evaluation.evaluated : null,
      brier: evaluation.evaluated ? evaluation.brier / evaluation.evaluated : null,
      baselineBrier: evaluation.evaluated ? evaluation.baselineBrier / evaluation.evaluated : null,
      logLoss: evaluation.evaluated ? evaluation.logLoss / evaluation.evaluated : null,
      baselineLogLoss: evaluation.evaluated ? evaluation.baselineLogLoss / evaluation.evaluated : null,
      beatsBaseline,
      brierSkillScore: evaluation.evaluated ? 1 - ((evaluation.brier / evaluation.evaluated) / (evaluation.baselineBrier / evaluation.evaluated)) : null
    },
    patternMemory: {
      key: features.patternKey,
      type: features.pattern.type,
      samples: patternSamples,
      bankerRate: patternSamples ? patternCounts.B / patternSamples : null,
      playerRate: patternSamples ? patternCounts.P / patternSamples : null
    },
    experts: expertDetails,
    roadState: Object.fromEntries(ROAD_OFFSETS.map((road) => [road.id, local.roads[road.offset].slice(-6)]))
  };
}

/**
 * Replay all recorded shoes chronologically. Historical prediction at hand t
 * is produced before observing hand t, then the model learns from that result.
 */
function createEmptyLearningSession() {
  return {
    model: newModel(),
    metrics: newMetrics(),
    shoesCount: 0,
    totalHands: 0,
    totalDecisive: 0,
    totalTies: 0,
    perShoe: [],
    activeLocal: newLocalState(),
    activeResults: [],
    activeStats: null
  };
}

/** Start a new shoe without discarding learned cross-shoe model memory. */
export function startLearningShoe(session, shoe) {
  if (!session || !session.model) throw new TypeError('ไม่พบ learning session');
  const id = String(shoe?.id ?? `shoe-${session.shoesCount + 1}`);
  const name = String(shoe?.name ?? `ชู ${session.shoesCount + 1}`);
  session.shoesCount += 1;
  session.activeLocal = newLocalState();
  session.activeResults = [];
  session.activeStats = {
    id, name, hands: 0, decisive: 0, ties: 0,
    evaluated: 0, correct: 0, brierTotal: 0
  };
  session.perShoe.push(session.activeStats);
  return session;
}

/**
 * Append one observed result. A non-Tie result is forecast from prior state,
 * evaluated, then used to update the model. This is the fast normal input path.
 */
export function appendLearningResult(session, inputResult) {
  if (!session?.model || !session.activeStats) throw new TypeError('ต้องเริ่มชูก่อนเพิ่มผล');
  const result = validateResults([inputResult])[0];
  session.activeResults.push(result);
  session.activeStats.hands += 1;
  session.totalHands += 1;

  if (result === 'T') {
    session.activeStats.ties += 1;
    session.totalTies += 1;
    session.activeLocal.ties += 1;
    return result;
  }

  const features = featureSnapshot(session.activeLocal);
  const predicted = predictExperts(session.model, features);
  const forecast = {
    pB: predicted.pB,
    side: predicted.pB >= 0.5 ? 'B' : 'P',
    experts: predicted.predictions,
    support: predicted.support
  };
  const evaluate = session.model.observations >= 12;
  if (evaluate) {
    const y = result === 'B' ? 1 : 0;
    session.activeStats.evaluated += 1;
    session.activeStats.correct += forecast.side === result ? 1 : 0;
    session.activeStats.brierTotal += (forecast.pB - y) ** 2;
  }

  updateOnlineModel(session.model, features, forecast, result, session.metrics, evaluate);
  updateLocalState(session.activeLocal, result);
  session.activeStats.decisive += 1;
  session.totalDecisive += 1;
  return result;
}

/** Build an online learner once by replaying all historical shoes chronologically. */
export function createLearningSession(inputShoes) {
  if (!Array.isArray(inputShoes)) throw new TypeError('shoes ต้องเป็น array');
  const shoes = inputShoes.map((shoe, index) => ({
    id: String(shoe?.id ?? `shoe-${index + 1}`),
    name: String(shoe?.name ?? `ชู ${index + 1}`),
    results: validateResults(shoe?.results ?? [])
  }));
  if (!shoes.length) shoes.push({ id: 'shoe-1', name: 'ชู 1', results: [] });
  const session = createEmptyLearningSession();
  for (const shoe of shoes) {
    startLearningShoe(session, shoe);
    for (const result of shoe.results) appendLearningResult(session, result);
  }
  return session;
}

/** Read-only presentation snapshot. Does not replay or mutate the learner. */
export function snapshotLearningSession(session) {
  if (!session?.model || !session.activeStats) throw new TypeError('ไม่พบ learning session');
  const forecast = buildForecast(
    session.model,
    session.activeLocal,
    session.shoesCount,
    session.totalHands,
    session.metrics
  );
  const metrics = session.metrics;
  return {
    forecast,
    metrics: {
      totalHands: session.totalHands,
      totalDecisive: session.totalDecisive,
      totalTies: session.totalTies,
      shoes: session.shoesCount,
      evaluated: metrics.evaluated,
      accuracy: metrics.evaluated ? metrics.correct / metrics.evaluated : null,
      brier: metrics.evaluated ? metrics.brier / metrics.evaluated : null,
      baselineBrier: metrics.evaluated ? metrics.baselineBrier / metrics.evaluated : null,
      logLoss: metrics.evaluated ? metrics.logLoss / metrics.evaluated : null,
      baselineLogLoss: metrics.evaluated ? metrics.baselineLogLoss / metrics.evaluated : null
    },
    perShoe: session.perShoe.map((shoe) => ({
      id: shoe.id,
      name: shoe.name,
      hands: shoe.hands,
      decisive: shoe.decisive,
      ties: shoe.ties,
      evaluated: shoe.evaluated,
      accuracy: shoe.evaluated ? shoe.correct / shoe.evaluated : null,
      brier: shoe.evaluated ? shoe.brierTotal / shoe.evaluated : null
    })),
    active: {
      results: [...session.activeResults],
      sequence: [...session.activeLocal.sequence],
      runs: session.activeLocal.runs.map((run) => ({ ...run })),
      roadMarks: Object.fromEntries(Object.entries(session.activeLocal.roads).map(([key, value]) => [key, [...value]]))
    }
  };
}

/** Convenience deterministic replay API used by tests and imported datasets. */
export function learnFromShoes(inputShoes, activeShoeIndex = inputShoes.length - 1) {
  if (!Array.isArray(inputShoes)) throw new TypeError('shoes ต้องเป็น array');
  const normalizedShoes = inputShoes.map((shoe, index) => ({
    id: String(shoe?.id ?? `shoe-${index + 1}`),
    name: String(shoe?.name ?? `ชู ${index + 1}`),
    results: validateResults(shoe?.results ?? [])
  }));
  const requestedIndex = Number.isInteger(activeShoeIndex) ? activeShoeIndex : normalizedShoes.length - 1;
  const lastIncludedIndex = Math.max(-1, Math.min(requestedIndex, normalizedShoes.length - 1));
  const session = createLearningSession(normalizedShoes.slice(0, lastIncludedIndex + 1));
  return snapshotLearningSession(session);
}

export function normalizeWorkspace(value) {
  let parsed = value;
  if (typeof parsed === 'string') parsed = JSON.parse(parsed);
  if (Array.isArray(parsed)) return [{ id: 'shoe-1', name: 'ชู 1', results: validateResults(parsed) }];
  if (Array.isArray(parsed?.shoes)) {
    const shoes = parsed.shoes.map((shoe, index) => ({
      id: String(shoe?.id ?? `shoe-${index + 1}`),
      name: String(shoe?.name ?? `ชู ${index + 1}`),
      results: validateResults(shoe?.results ?? [])
    }));
    return shoes.length ? shoes : [{ id: 'shoe-1', name: 'ชู 1', results: [] }];
  }
  // Backward compatibility with Baccarat Atlas v1 exports.
  if (Array.isArray(parsed?.results)) return [{ id: 'shoe-1', name: 'ชู 1 (นำเข้าจาก v1)', results: validateResults(parsed.results) }];
  throw new TypeError('ไม่พบข้อมูล shoes หรือ results ในไฟล์');
}

export function exportWorkspace(shoes) {
  return {
    app: 'Baccarat Atlas AI',
    version: 2,
    learningVersion: LEARNING_VERSION,
    exportedAt: new Date().toISOString(),
    shoes: shoes.map((shoe, index) => ({
      id: String(shoe.id ?? `shoe-${index + 1}`),
      name: String(shoe.name ?? `ชู ${index + 1}`),
      results: validateResults(shoe.results ?? [])
    }))
  };
}

export function exportWorkspaceCsv(shoes) {
  const rows = ['shoe,hand,result'];
  shoes.forEach((shoe, shoeIndex) => {
    validateResults(shoe.results ?? []).forEach((result, handIndex) => {
      rows.push(`${shoeIndex + 1},${handIndex + 1},${result}`);
    });
  });
  return rows.join('\n');
}

export function parseWorkspaceCsv(csvText) {
  if (typeof csvText !== 'string') throw new TypeError('ไฟล์ CSV ต้องเป็นข้อความ');
  const groups = new Map();
  const lines = csvText.replace(/^\uFEFF/, '').split(/\r?\n/).map((line) => line.trim()).filter(Boolean);
  for (let i = 0; i < lines.length; i += 1) {
    const fields = lines[i].split(/[,;\t]/).map((field) => field.trim().replace(/^"|"$/g, ''));
    if (!fields.length || /^(shoe|ชู)$/i.test(fields[0])) continue;
    let shoeNo = 1;
    let resultToken;
    if (fields.length >= 3 && /^\d+$/.test(fields[0])) {
      shoeNo = Number(fields[0]); resultToken = fields.at(-1);
    } else if (fields.length >= 2 && /^\d+$/.test(fields[0])) {
      resultToken = fields.at(-1);
    } else {
      resultToken = fields.at(-1);
    }
    const token = String(resultToken ?? '').trim().toUpperCase();
    if (!['P', 'B', 'T', 'PLAYER', 'BANKER', 'TIE'].includes(token)) {
      throw new TypeError(`CSV: อ่านผลที่บรรทัด ${i + 1} ไม่ได้`);
    }
    const current = groups.get(shoeNo) ?? [];
    current.push(token); groups.set(shoeNo, current);
  }
  if (!groups.size) return [{ id: 'shoe-1', name: 'ชู 1', results: [] }];
  return [...groups.entries()].sort((a, b) => a[0] - b[0]).map(([number, results]) => ({
    id: `shoe-${number}`, name: `ชู ${number}`, results: validateResults(results)
  }));
}
