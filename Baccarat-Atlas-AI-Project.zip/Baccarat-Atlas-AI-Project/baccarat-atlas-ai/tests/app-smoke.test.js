import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import vm from 'node:vm';
import * as engine from '../src/engine.js';
import * as learning from '../src/learning.js';

class FakeElement {
  constructor(id = '') {
    this.id = id;
    this._textContent = '';
    Object.defineProperty(this, 'textContent', { get: () => this._textContent, set: (value) => { this._textContent = String(value ?? ''); } });
    this.innerHTML = '';
    this.className = '';
    this.classList = { add: () => {}, remove: () => {} };
    this.style = {};
    this.disabled = false;
    this.value = '';
    this.files = [];
    this.listeners = new Map();
    this.tagName = 'DIV';
  }
  addEventListener(type, callback) {
    const entries = this.listeners.get(type) ?? [];
    entries.push(callback);
    this.listeners.set(type, entries);
  }
  dispatch(type, event = {}) {
    for (const callback of this.listeners.get(type) ?? []) callback({ target: this, preventDefault() {}, ...event });
  }
  click() { this.dispatch('click'); }
  remove() {}
  append() {}
}

async function mountApp() {
  const appSource = (await readFile(new URL('../src/app.js', import.meta.url), 'utf8'))
    .replace(/^import\s*\{[\s\S]*?\}\s*from\s*['"]\.\/(?:engine|learning)\.js['"];\s*/gm, '');
  const elements = new Map();
  const documentListeners = new Map();
  const storage = new Map();
  let promptValue;
  const document = {
    activeElement: null,
    body: new FakeElement('body'),
    getElementById(id) {
      if (!elements.has(id)) elements.set(id, new FakeElement(id));
      return elements.get(id);
    },
    createElement(tag) { return new FakeElement(tag); },
    addEventListener(type, callback) {
      const entries = documentListeners.get(type) ?? [];
      entries.push(callback);
      documentListeners.set(type, entries);
    },
    dispatch(type, event = {}) {
      for (const callback of documentListeners.get(type) ?? []) callback({ preventDefault() {}, ...event });
    }
  };
  const localStorage = {
    getItem(key) { return storage.has(key) ? storage.get(key) : null; },
    setItem(key, value) { storage.set(key, String(value)); },
    removeItem(key) { storage.delete(key); }
  };
  const context = {
    ...engine,
    ...learning,
    document,
    localStorage,
    window: { confirm: () => true, prompt: (_message, fallback) => promptValue === undefined ? fallback : promptValue },
    setTimeout: () => 1,
    clearTimeout: () => {},
    console,
    Blob,
    URL: { createObjectURL: () => 'blob:test', revokeObjectURL: () => {} }
  };
  vm.runInNewContext(appSource, context, { filename: 'app.js' });
  return { elements, document, storage, setPromptValue: (value) => { promptValue = value; } };
}

test('AI workspace records results, undoes/redoes and starts a new shoe without losing memory', async () => {
  const { elements, document, storage } = await mountApp();
  const el = (id) => elements.get(id);
  assert.equal(el('entryCount').textContent, '0 HANDS');

  el('addP').click();
  el('addB').click();
  el('addT').click();
  assert.equal(el('entryCount').textContent, '3 HANDS');
  assert.match(el('beadBoard').innerHTML, /P/);
  assert.match(el('beadBoard').innerHTML, /B/);
  assert.match(el('beadBoard').innerHTML, /T/);
  assert.ok(storage.has('baccaratAtlas.ai.workspace.v2'));

  el('undo').click();
  assert.equal(el('entryCount').textContent, '2 HANDS');
  el('redo').click();
  assert.equal(el('entryCount').textContent, '3 HANDS');

  document.dispatch('keydown', { key: 'p', ctrlKey: false, shiftKey: false, altKey: false, metaKey: false });
  assert.equal(el('entryCount').textContent, '4 HANDS');
  document.dispatch('keydown', { key: 'z', ctrlKey: true, shiftKey: false, altKey: false, metaKey: false });
  assert.equal(el('entryCount').textContent, '3 HANDS');

  el('newShoe').click();
  assert.equal(el('entryCount').textContent, '0 HANDS');
  assert.equal(el('shoeCount').textContent, '2');
  assert.equal(el('memoryHands').textContent, '2');
  el('addB').click();
  assert.equal(el('memoryHands').textContent, '3');
  assert.match(el('shoeHistory').innerHTML, /ชู 1/);
  assert.match(el('shoeHistory').innerHTML, /ชู 2/);
});

test('reset clears only the active shoe while clear-memory removes all learned history', async () => {
  const { elements } = await mountApp();
  const el = (id) => elements.get(id);
  for (const side of ['addB', 'addP', 'addB', 'addP']) el(side).click();
  el('newShoe').click();
  el('addP').click();
  el('resetShoe').click();
  assert.equal(el('entryCount').textContent, '0 HANDS');
  assert.equal(el('memoryHands').textContent, '4');
  el('clearMemory').click();
  assert.equal(el('shoeCount').textContent, '1');
  assert.equal(el('memoryHands').textContent, '0');
  assert.equal(el('entryCount').textContent, '0 HANDS');
});

test('editing a historical result rebuilds memory from the corrected record', async () => {
  const { elements, setPromptValue } = await mountApp();
  const el = (id) => elements.get(id);
  for (const id of ['addB', 'addB', 'addP', 'addP']) el(id).click();
  assert.equal(el('memoryHands').textContent, '4');
  setPromptValue('P B P T');
  el('editShoe').click();
  assert.equal(el('entryCount').textContent, '4 HANDS');
  assert.equal(el('memoryHands').textContent, '3');
  assert.match(el('beadBoard').innerHTML, /T/);
  setPromptValue('P Q B');
  el('editShoe').click();
  assert.equal(el('entryCount').textContent, '4 HANDS', 'invalid edit must not overwrite saved results');
});

test('standalone build boots without imports, records results, and runs the learning engine', async () => {
  const standalone = await readFile(new URL('../dist/Baccarat-Atlas-AI.html', import.meta.url), 'utf8');
  const script = standalone.match(/<script>([\s\S]*?)<\/script>/)?.[1];
  assert.ok(script, 'standalone HTML contains an inline application script');
  assert.doesNotMatch(script, /^import\s/m);
  const elements = new Map();
  const storage = new Map();
  let promptValue;
  const document = {
    activeElement: null,
    body: new FakeElement('body'),
    getElementById(id) {
      if (!elements.has(id)) elements.set(id, new FakeElement(id));
      return elements.get(id);
    },
    createElement(tag) { return new FakeElement(tag); },
    addEventListener() {}
  };
  const localStorage = {
    getItem(key) { return storage.get(key) ?? null; },
    setItem(key, value) { storage.set(key, String(value)); },
    removeItem(key) { storage.delete(key); }
  };
  vm.runInNewContext(script, {
    document,
    localStorage,
    window: { confirm: () => true, prompt: (_message, fallback) => promptValue === undefined ? fallback : promptValue },
    setTimeout: () => 1,
    clearTimeout: () => {},
    console,
    Blob,
    URL: { createObjectURL: () => 'blob:test', revokeObjectURL: () => {} }
  }, { filename: 'Baccarat-Atlas-AI.html' });
  for (let index = 0; index < 14; index += 1) elements.get(index % 2 ? 'addP' : 'addB').click();
  assert.equal(elements.get('memorySamples').textContent, '14');
  assert.ok(['B', 'P'].includes(elements.get('forecastToken').textContent));
  assert.ok(storage.has('baccaratAtlas.ai.workspace.v2'));
});
