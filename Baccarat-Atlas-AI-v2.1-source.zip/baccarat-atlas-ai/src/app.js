import {
  buildAllRoads,
  summarizeResults,
  normalizeResult,
  validateResults
} from './engine.js';
import {
  createLearningSession,
  snapshotLearningSession,
  startLearningShoe,
  appendLearningResult,
  normalizeWorkspace,
  exportWorkspace,
  exportWorkspaceCsv,
  parseWorkspaceCsv
} from './learning.js';

const STORAGE_KEY = 'baccaratAtlas.ai.workspace.v2';
const LEGACY_STORAGE_KEY = 'baccaratAtlas.session.v1';
const state = {
  shoes: [{ id: 'shoe-1', name: 'ชู 1', results: [] }],
  activeShoeId: 'shoe-1',
  redoStack: [],
  storageAvailable: true,
  revision: 0,
  analysisCache: null,
  learningSession: null
};
const $ = (id) => document.getElementById(id);
let toastTimer = null;

const PATTERNS = [
  { key: 'dragon', name: 'มังกร / ทางยาว', description: 'ฝั่งเดิมต่อเนื่องอย่างน้อย 3 ตา' },
  { key: 'pingpong', name: 'ปิงปอง', description: '6 ตาล่าสุดสลับ P/B ทุกตา' },
  { key: 'two-one', name: 'สองตัวหนึ่ง (2–1)', description: 'สองซ้ำหนึ่งเปลี่ยน วนซ้ำ 2 รอบ' },
  { key: 'one-two', name: 'หนึ่งตัวสอง (1–2)', description: 'หนึ่งตัวแล้วอีกฝั่งซ้ำ 2 ครั้ง วนซ้ำ 2 รอบ' },
  { key: 'two-two', name: 'สองต่อสอง (2–2)', description: 'สองผลต่อฝั่ง วนซ้ำ 2 รอบ' },
  { key: 'random', name: 'กระจัดกระจาย', description: 'ยังไม่เข้ารูปแบบข้างต้น' },
  { key: 'cycle', name: 'วงรอบซ้ำทั่วไป', description: 'โมทีฟเดิมซ้ำครบ 3 รอบ' },
  { key: 'switch-heavy', name: 'สลับฝั่งถี่', description: 'อัตราเปลี่ยนฝั่งในหน้าต่างล่าสุด ≥ 65%' },
  { key: 'stick-heavy', name: 'เกาะฝั่งบ่อย', description: 'อัตราเปลี่ยนฝั่งในหน้าต่างล่าสุด ≤ 35%' },
  { key: 'balanced', name: 'สัดส่วน B/P ใกล้กัน', description: 'จำนวน B/P ต่างกันไม่เกิน 2 ผล' },
  { key: 'dominant', name: 'ฝั่งหนึ่งเด่น', description: 'จำนวน B/P ต่างกันอย่างน้อย 6 ผล' }
];

function currentShoe() {
  return state.shoes.at(-1) ?? { id: 'shoe-1', name: 'ชู 1', results: [] };
}

function invalidateAnalysis() {
  state.revision += 1;
  state.analysisCache = null;
}

function rebuildLearningSession() {
  state.learningSession = createLearningSession(state.shoes);
  invalidateAnalysis();
}

function getAnalysis() {
  if (state.analysisCache?.revision === state.revision) return state.analysisCache.value;
  if (!state.learningSession) rebuildLearningSession();
  const value = snapshotLearningSession(state.learningSession);
  state.analysisCache = { revision: state.revision, value };
  return value;
}

function showToast(message) {
  const node = $('toast');
  node.textContent = message;
  node.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => node.classList.remove('show'), 2400);
}

function setText(id, value) {
  $(id).textContent = value;
}

function percent(value, digits = 1) {
  return `${(value * 100).toFixed(digits)}%`;
}

function sideLabel(side) {
  return side === 'B' ? 'Banker · B' : side === 'P' ? 'Player · P' : side === 'T' ? 'Tie · T' : '—';
}

function saveState() {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify({
      version: 2,
      shoes: state.shoes,
      activeShoeId: state.activeShoeId
    }));
    try { localStorage.removeItem(LEGACY_STORAGE_KEY); } catch { /* legacy cleanup is best-effort */ }
    state.storageAvailable = true;
    $('saveStatus').innerHTML = '<span class="status-dot"></span> บันทึกความจำอัตโนมัติแล้ว';
  } catch {
    state.storageAvailable = false;
    $('saveStatus').textContent = 'บันทึกอัตโนมัติไม่ได้ · กรุณาส่งออก JSON สำรอง';
  }
}

function loadState() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (parsed?.version !== 2 || !Array.isArray(parsed.shoes)) throw new Error('unsupported workspace version');
      state.shoes = parsed.shoes.map((shoe, index) => ({
        id: String(shoe?.id ?? `shoe-${index + 1}`),
        name: String(shoe?.name ?? `ชู ${index + 1}`),
        results: validateResults(shoe?.results ?? [])
      }));
      if (!state.shoes.length) state.shoes = [{ id: 'shoe-1', name: 'ชู 1', results: [] }];
      const lastId = state.shoes.at(-1).id;
      state.activeShoeId = state.shoes.some((shoe) => shoe.id === parsed.activeShoeId) ? parsed.activeShoeId : lastId;
      // Learning always replays the chronological history; the active shoe is the newest shoe.
      if (state.activeShoeId !== lastId) state.activeShoeId = lastId;
      return;
    }
    // One-time migration from Baccarat Atlas v1's single-shoe storage.
    const legacyRaw = localStorage.getItem(LEGACY_STORAGE_KEY);
    if (legacyRaw) {
      const legacy = JSON.parse(legacyRaw);
      const results = validateResults(legacy.results ?? []);
      state.shoes = [{ id: 'shoe-1', name: 'ชู 1 (ย้ายจากเวอร์ชันเดิม)', results }];
      state.activeShoeId = 'shoe-1';
      invalidateAnalysis();
      return;
    }
  } catch {
    state.shoes = [{ id: 'shoe-1', name: 'ชู 1', results: [] }];
    state.activeShoeId = 'shoe-1';
    state.storageAvailable = false;
    $('saveStatus').textContent = 'อ่านข้อมูลเดิมไม่ได้ · เริ่มพื้นที่ใหม่';
  }
}

function renderStats() {
  const shoe = currentShoe();
  const summary = summarizeResults(shoe.results);
  setText('entryCount', `${summary.total} HAND${summary.total === 1 ? '' : 'S'}`);
  $('undo').disabled = shoe.results.length === 0;
  $('redo').disabled = state.redoStack.length === 0;
  $('editShoe').disabled = shoe.results.length === 0;
  $('resetShoe').disabled = shoe.results.length === 0;
  setText('activeShoeTitle', `ชูปัจจุบัน · ${shoe.name}`);
}

function renderWorkspace(analysis) {
  const totals = analysis.metrics;
  setText('shoeCount', state.shoes.length);
  setText('memoryHands', totals.totalDecisive);
  setText('memorySamples', totals.totalDecisive);
  setText('memoryTies', totals.totalTies);
  setText('workspaceSummary', `ชูปัจจุบันมี ${currentShoe().results.length} ผล · ความจำเรียนรู้จะสะสมจาก ${state.shoes.length} ชูตามลำดับเวลา`);
  setText('memoryNote', 'เริ่มชูใหม่ได้ทุกเมื่อ ระบบจะรีเซ็ตถนนของชู แต่เก็บโมเดลเรียนรู้ข้ามชู');

  const list = $('shoeHistory');
  const rows = analysis.perShoe.slice().reverse();
  list.innerHTML = rows.map((shoe, index) => {
    const isCurrent = shoe.id === currentShoe().id;
    const accuracy = shoe.accuracy === null ? '—' : percent(shoe.accuracy);
    return `<div class="shoe-row ${isCurrent ? 'current' : ''}"><b>${escapeHtml(shoe.name)} ${isCurrent ? '<span class="shoe-status">· ปัจจุบัน</span>' : ''}</b><span>${shoe.hands} มือ</span><span>${shoe.decisive} ตัดสิน</span><span>${shoe.ties} Tie</span><span>WF ${accuracy}${shoe.evaluated ? ` (${shoe.evaluated})` : ''}</span></div>`;
  }).join('') || '<p class="muted">ยังไม่มีประวัติชู</p>';
}

function renderBeadPlate(beadPlate) {
  const board = $('beadBoard');
  if (!beadPlate.count) {
    board.className = 'bead-board empty-board';
    board.innerHTML = '<p>ยังไม่มีผลบันทึก</p>';
    return;
  }
  board.className = 'bead-board';
  const html = [];
  for (let col = 0; col < beadPlate.columns.length; col += 1) {
    for (let row = 0; row < 6; row += 1) {
      const result = beadPlate.columns[col][row];
      html.push(result
        ? `<div class="bead-cell filled ${result}" title="มือที่ ${col * 6 + row + 1}: ${sideLabel(result)}">${result}</div>`
        : '<div class="bead-cell" aria-hidden="true"></div>');
    }
  }
  board.innerHTML = html.join('');
}

function renderBigRoad(bigRoad) {
  const board = $('bigRoad');
  if (!bigRoad.cells.length && !bigRoad.pendingTies) {
    board.className = 'big-road empty-board';
    board.innerHTML = '<p>ยังไม่มีผล P/B สำหรับสร้าง Big Road</p>';
    setText('bigRoadFootnote', 'Tie จะไม่สร้างคอลัมน์ใน Big Road และไม่เปลี่ยนทางของผลก่อนหน้า');
    return;
  }
  const maxCol = Math.max(bigRoad.maxCol, bigRoad.pendingTies > 0 ? 0 : -1);
  board.className = 'big-road';
  const html = [];
  for (let col = 0; col <= maxCol; col += 1) {
    for (let row = 0; row < 6; row += 1) {
      const cell = bigRoad.occupied[row]?.[col] ?? null;
      if (!cell && bigRoad.pendingTies && !bigRoad.cells.length && row === 0 && col === 0) {
        html.push(`<div class="big-cell"><span style="color:var(--tie);font-size:.55rem">T×${bigRoad.pendingTies}</span></div>`);
      } else if (!cell) html.push('<div class="big-cell" aria-hidden="true"></div>');
      else {
        const tieMark = cell.tieCount > 0 ? `<span class="tie-mark">${cell.tieCount > 1 ? cell.tieCount : 'T'}</span><span class="tie-slash"></span>` : '';
        html.push(`<div class="big-cell filled ${cell.side}" title="มือที่ ${cell.handIndex + 1}: ${sideLabel(cell.side)}${cell.tieCount ? ` · Tie ${cell.tieCount} ครั้ง` : ''}">${cell.side}${tieMark}</div>`);
      }
    }
  }
  board.innerHTML = html.join('');
  const pendingNote = bigRoad.pendingTies ? ` · Tie ก่อนผลแรกที่รอผูก: ${bigRoad.pendingTies}` : '';
  setText('bigRoadFootnote', `จำนวน streak ${bigRoad.columns.length} คอลัมน์ · Tie ทั้งหมด ${bigRoad.totalTies}${pendingNote}`);
}

function renderDerivedRoads(derivedRoads) {
  $('derivedRoads').innerHTML = derivedRoads.map((road) => {
    const html = [];
    if (!road.marks.length) html.push('<div class="empty-board"><p>ยังไม่ถึงจุดเริ่มของถนนนี้</p></div>');
    else {
      for (let col = 0; col <= road.maxCol; col += 1) {
        for (let row = 0; row < 6; row += 1) {
          const cell = road.occupied[row]?.[col] ?? null;
          if (!cell) html.push('<div class="road-cell" aria-hidden="true"></div>');
          else {
            const symbol = road.key === 'cockroach' ? '<span class="slash-symbol">／</span>' : road.key === 'small' ? '<span class="solid-symbol"></span>' : '<span class="hollow-symbol"></span>';
            html.push(`<div class="road-cell filled ${cell.color}" title="${cell.color === 'R' ? 'แดง · รูปแบบซ้ำ' : 'น้ำเงิน · รูปแบบต่าง'}">${symbol}</div>`);
          }
        }
      }
    }
    const red = road.marks.filter((mark) => mark.color === 'R').length;
    const blue = road.marks.length - red;
    return `<article class="derived-card"><div class="derived-head"><div><strong>${road.name}</strong><div class="derived-sub">${road.description}</div></div><span class="road-count">${road.marks.length} MARKS</span></div><div class="road-grid">${html.join('')}</div><div class="derived-sub">แดง ${red} · น้ำเงิน ${blue}</div></article>`;
  }).join('');
}

function renderRecentSequence(results) {
  const decisive = results.filter((result) => result !== 'T').slice(-12);
  setText('recentCount', `${decisive.length} ผล`);
  $('recentSequence').innerHTML = decisive.length
    ? decisive.map((result) => `<span class="sequence-token ${result}" title="${sideLabel(result)}">${result}</span>`).join('')
    : '<span class="muted">ยังไม่มีข้อมูล</span>';
}

function renderPatternCards(pattern, patternScan) {
  const activeKeys = new Set((patternScan?.detections ?? []).map((item) => item.key));
  $('patternCards').innerHTML = PATTERNS.map((item, index) => {
    const active = activeKeys.has(item.key);
    return `<div class="pattern-item ${active ? 'active' : ''}"><span class="pattern-index">${String(index + 1).padStart(2, '0')}</span><span class="pattern-name">${item.name}</span><span class="pattern-desc">${item.description}</span><span class="pattern-status">${active ? 'ตรวจพบ' : 'ไม่ตรงเกณฑ์'}</span></div>`;
  }).join('');
}

function renderForecast(forecast) {
  const token = $('forecastToken');
  const side = forecast.side;
  token.className = `forecast-token ${side === 'B' ? 'banker' : side === 'P' ? 'player' : 'neutral'}`;
  token.textContent = side ?? '—';
  setText('forecastTitle', side ? `ทิศทางที่ผ่านเกณฑ์ย้อนหลัง: ${sideLabel(side)}` : `งดชี้ฝั่ง · ${forecast.status}`);
  setText('forecastDescription', forecast.statusDetail);
  setText('forecastMeta', 'คะแนนโมเดลเป็นค่าประเมินจากประวัติ ไม่ใช่โอกาสชนะจริงหรือคำแนะนำให้ลงเดิมพัน');
  setText('forecastPattern', `PATTERN: ${forecast.pattern.type.toUpperCase()}`);
  setText('forecastEvidence', `${forecast.observationsLearned} ผลเรียนรู้ · ทดสอบ ${forecast.evaluation.samples} ตา · ${forecast.evaluation.evaluatedShoes} ชู`);
  setText('forecastDisagreement', `ระยะห่างความเห็นผู้เชี่ยวชาญ ${(forecast.disagreement * 100).toFixed(1)} จุด %`);
  const stateChip = $('signalState');
  const cautionStatuses = ['ยังไม่ผ่านฐาน', 'โมเดลเห็นต่างกัน', 'ผลงานช่วงล่าสุดอ่อน'];
  stateChip.className = `state-chip ${side ? 'state-good' : cautionStatuses.includes(forecast.status) ? 'state-caution' : 'state-learning'}`;
  stateChip.textContent = forecast.status;
  setText('scoreB', percent(forecast.pB));
  setText('scoreP', percent(forecast.pP));
  $('scoreBBar').style.width = `${forecast.pB * 100}%`;
  $('scorePBar').style.width = `${forecast.pP * 100}%`;
}

function renderPatternMetrics(scan) {
  const stats = scan?.stats ?? {};
  const current = stats.currentStreak
    ? `${sideLabel(stats.currentStreak.side)} ${stats.currentStreak.length} ตา`
    : 'ยังไม่มี';
  const switchText = stats.switchRate === null || stats.switchRate === undefined
    ? '—'
    : `${(stats.switchRate * 100).toFixed(0)}% (${stats.switchCount}/${Math.max(0, stats.window - 1)})`;
  const html = [
    [`B / P · ${stats.window ?? 0} ตา`, `${stats.banker ?? 0} / ${stats.player ?? 0}`],
    ['อัตราสลับฝั่ง', switchText],
    ['สตรีกล่าสุด', current],
    ['ทางยาวสุดในหน้าต่าง', `${stats.longestRun ?? 0} ตา`]
  ].map(([label, value]) => `<div class="pattern-metric"><span>${label}</span><b>${escapeHtml(value)}</b></div>`).join('');
  $('patternMetrics').innerHTML = html;
  setText('patternInterpretation', `${stats.rhythm ?? 'รอข้อมูล'} · วิเคราะห์จาก ${stats.window ?? 0} ผลตัดสินล่าสุด; เป็นคำอธิบายรูปแบบย้อนหลัง ไม่ใช่ตัวบอกผลถัดไป`);
}

function renderValidation(forecast, metrics) {
  const evaluation = forecast.evaluation;
  setText('walkAccuracy', evaluation.accuracy === null ? '—' : percent(evaluation.accuracy));
  setText('walkSamples', `${evaluation.samples} ตัวอย่าง · ${evaluation.evaluatedShoes} ชู`);
  setText('walkBrier', evaluation.brier === null ? '—' : evaluation.brier.toFixed(3));
  setText('baseBrier', evaluation.baselineBrier === null ? '0.250' : evaluation.baselineBrier.toFixed(3));
  setText('brierSkill', evaluation.brierSkillScore === null ? '—' : `${(evaluation.brierSkillScore * 100).toFixed(1)}%`);
  const chip = $('validationState');
  chip.className = `state-chip ${evaluation.beatsBaseline && evaluation.recentStable ? 'state-good' : evaluation.samples >= 100 && evaluation.evaluatedShoes >= 5 ? 'state-caution' : 'state-learning'}`;
  chip.textContent = evaluation.beatsBaseline
    ? evaluation.recentStable ? 'ผ่านฐาน + ช่วงล่าสุด' : 'สะสมผ่าน · ล่าสุดอ่อน'
    : evaluation.samples >= 100 && evaluation.evaluatedShoes >= 5 ? 'ยังไม่ผ่านฐาน' : 'รอตัวอย่าง / หลายชู';
  const brierLower = evaluation.brierImprovement?.lower95;
  const logLower = evaluation.logLossImprovement?.lower95;
  setText('brierLower95', brierLower === null || brierLower === undefined ? '—' : brierLower.toFixed(4));
  setText('logLower95', logLower === null || logLower === undefined ? '—' : logLower.toFixed(4));
  const note = evaluation.samples < 100 || evaluation.evaluatedShoes < 5
    ? `มี ${evaluation.samples}/100 ตัวอย่าง และ ${evaluation.evaluatedShoes}/5 ชูที่ผ่านการประเมิน · ระบบจึงงดชี้ฝั่ง`
    : evaluation.beatsBaseline && evaluation.recentStable
      ? `ค่าเฉลี่ยรายชูมีขอบล่าง 95% เป็นบวกทั้ง Brier และ Log-loss และ 30 ตาล่าสุดยังดีกว่าฐาน · ไม่ยืนยันกำไรจริง`
      : evaluation.beatsBaseline
        ? `ผลสะสมผ่านเกณฑ์ แต่ 30 ตาล่าสุดไม่ผ่านทั้ง Brier และ Log-loss · ระบบจึงงดชี้ฝั่ง`
        : `จาก ${evaluation.samples} ตัวอย่าง ช่วงความเชื่อมั่นรายชูยังไม่ยืนยันว่าเหนือฐาน 50/50 · งดใช้เป็นสัญญาณเดิมพัน`;
  setText('validationNote', note);
  const recentText = evaluation.recent?.brier === null || evaluation.recent?.brier === undefined
    ? 'ยังไม่มี'
    : `ล่าสุด Brier ${evaluation.recent.brier.toFixed(3)}`;
  setText('currentEvaluation', evaluation.accuracy === null ? 'ยังไม่มี' : `${percent(evaluation.accuracy)} · n=${evaluation.samples} · ${recentText}`);
}

function renderExperts(forecast) {
  const pattern = forecast.patternMemory;
  setText('contextPattern', forecast.pattern.name);
  setText('contextMemory', `บริบท: ${pattern.key}`);
  setText('patternMemoryCount', `${pattern.samples} ตัวอย่าง`);
  setText('patternMemorySplit', pattern.samples
    ? `B ${percent(pattern.bankerRate)} · P ${percent(pattern.playerRate)}`
    : 'ยังไม่มีสถิติจากบริบทนี้');
  const experts = forecast.experts;
  const top = experts[0];
  setText('topExpert', top?.label ?? '—');
  setText('topExpertWeight', top ? `น้ำหนัก ${(top.weight * 100).toFixed(1)}% · ${top.samples} ตัวอย่าง` : 'ยังไม่ปรับน้ำหนัก');
  $('expertRows').innerHTML = experts.map((expert) => {
    const weight = expert.weight * 100;
    const accuracy = expert.accuracy === null ? '—' : percent(expert.accuracy);
    return `<tr><td>${escapeHtml(expert.label)}</td><td><div class="weight-cell"><span>${weight.toFixed(1)}%</span><span class="weight-track"><i style="width:${Math.max(0, Math.min(100, weight))}%"></i></span></div></td><td>${expert.samples}</td><td>${accuracy}</td><td>${percent(expert.currentProbabilityB)}</td></tr>`;
  }).join('') || '<tr><td colspan="5" class="empty-table">เริ่มบันทึกผลเพื่อให้โมเดลย่อยเรียนรู้</td></tr>';
  setText('currentPattern', forecast.pattern.name);
  setText('currentPatternSamples', pattern.samples);
  setText('currentProjection', forecast.side ? sideLabel(forecast.side) : 'งดชี้ฝั่ง');
}

function render() {
  const shoe = currentShoe();
  const roads = buildAllRoads(shoe.results);
  const analysis = getAnalysis();
  renderStats();
  renderWorkspace(analysis);
  renderBeadPlate(roads.beadPlate);
  renderBigRoad(roads.bigRoad);
  renderDerivedRoads(roads.derivedRoads);
  renderRecentSequence(shoe.results);
  renderPatternCards(analysis.forecast.pattern, analysis.forecast.patternScan);
  renderPatternMetrics(analysis.forecast.patternScan);
  renderForecast(analysis.forecast);
  renderValidation(analysis.forecast, analysis.metrics);
  renderExperts(analysis.forecast);
  saveState();
}

function addResult(side) {
  const normalized = normalizeResult(side);
  currentShoe().results.push(normalized);
  appendLearningResult(state.learningSession, normalized);
  state.redoStack = [];
  invalidateAnalysis();
  render();
  showToast(`บันทึก ${sideLabel(side)} แล้ว · อัปเดตความจำแล้ว`);
}

function undo() {
  const results = currentShoe().results;
  if (!results.length) return;
  state.redoStack.push(results.pop());
  rebuildLearningSession();
  render();
  showToast('ย้อนผลแล้ว · คำนวณความจำใหม่เรียบร้อย');
}

function redo() {
  if (!state.redoStack.length) return;
  const result = state.redoStack.pop();
  currentShoe().results.push(result);
  appendLearningResult(state.learningSession, result);
  invalidateAnalysis();
  render();
  showToast('ทำผลซ้ำแล้ว · อัปเดตการเรียนรู้ใหม่');
}

function newShoe() {
  if (currentShoe().results.length === 0) {
    showToast('ชูปัจจุบันว่างอยู่แล้ว สามารถเริ่มบันทึกได้เลย');
    return;
  }
  const number = state.shoes.length + 1;
  const id = `shoe-${Date.now()}-${number}`;
  const shoe = { id, name: `ชู ${number}`, results: [] };
  state.shoes.push(shoe);
  state.activeShoeId = id;
  startLearningShoe(state.learningSession, shoe);
  state.redoStack = [];
  invalidateAnalysis();
  render();
  showToast(`เริ่ม ${shoe.name} แล้ว · ความจำจาก ${number - 1} ชูก่อนหน้ายังคงอยู่`);
}

function renameShoe() {
  const shoe = currentShoe();
  const nextName = window.prompt('ตั้งชื่อชูปัจจุบัน', shoe.name);
  if (nextName === null) return;
  const name = String(nextName).trim().slice(0, 48);
  if (!name) { showToast('ชื่อชูต้องไม่เป็นค่าว่าง'); return; }
  shoe.name = name;
  if (state.learningSession?.activeStats) state.learningSession.activeStats.name = name;
  invalidateAnalysis();
  render();
  showToast('เปลี่ยนชื่อชูแล้ว');
}

function editShoe() {
  const shoe = currentShoe();
  if (!shoe.results.length) return;
  const input = window.prompt('แก้ไขประวัติทั้งชู โดยคั่นผลด้วยช่องว่างหรือจุลภาค (รองรับ P, B, T)', shoe.results.join(' '));
  if (input === null) return;
  try {
    const tokens = String(input).trim() ? String(input).trim().split(/[\s,;]+/) : [];
    shoe.results = validateResults(tokens);
    state.redoStack = [];
    rebuildLearningSession();
    render();
    showToast('แก้ไขประวัติแล้ว · สร้างความจำและน้ำหนักโมเดลใหม่');
  } catch (error) {
    showToast(`แก้ไขไม่สำเร็จ: ${error.message}`);
  }
}

function resetShoe() {
  const shoe = currentShoe();
  if (!shoe.results.length) return;
  if (!window.confirm(`ต้องการล้างผล ${shoe.name} จำนวน ${shoe.results.length} มือหรือไม่? ชูอื่นจะยังอยู่และใช้เรียนรู้ต่อ`)) return;
  shoe.results = [];
  state.redoStack = [];
  rebuildLearningSession();
  render();
  showToast('ล้างเฉพาะชูปัจจุบันแล้ว');
}

function clearMemory() {
  if (!window.confirm('ต้องการล้างประวัติทุกชูและเริ่มความจำโมเดลใหม่ทั้งหมดหรือไม่? ควรส่งออก JSON สำรองก่อน')) return;
  state.shoes = [{ id: `shoe-${Date.now()}`, name: 'ชู 1', results: [] }];
  state.activeShoeId = state.shoes[0].id;
  state.redoStack = [];
  rebuildLearningSession();
  render();
  setText('dataStatus', 'ล้างประวัติทุกชูแล้ว · โมเดลเริ่มเรียนรู้ใหม่');
  showToast('ล้างความจำทั้งหมดแล้ว');
}

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, (character) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[character]);
}

function downloadFile(filename, content, mimeType) {
  const blob = new Blob([content], { type: `${mimeType};charset=utf-8` });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = filename;
  document.body.append(anchor);
  anchor.click();
  anchor.remove();
  URL.revokeObjectURL(url);
}

function timestampName(extension) {
  const now = new Date();
  const pad = (number) => String(number).padStart(2, '0');
  const stamp = `${now.getFullYear()}${pad(now.getMonth() + 1)}${pad(now.getDate())}-${pad(now.getHours())}${pad(now.getMinutes())}`;
  return `baccarat-atlas-ai-${stamp}.${extension}`;
}

function exportJson() {
  downloadFile(timestampName('json'), JSON.stringify(exportWorkspace(state.shoes), null, 2), 'application/json');
  setText('dataStatus', `ส่งออกแล้ว ${state.shoes.length} ชู · ใช้ไฟล์นี้เพื่อฝึกโมเดลต่อบนอุปกรณ์อื่น`);
  showToast('ส่งออกความจำทุกชูเป็น JSON แล้ว');
}

function exportCsvFile() {
  downloadFile(timestampName('csv'), exportWorkspaceCsv(state.shoes), 'text/csv');
  setText('dataStatus', 'ส่งออก CSV แล้ว · มีคอลัมน์ชู ลำดับมือ และผล P/B/T');
  showToast('ส่งออก CSV ทุกชูแล้ว');
}

async function importFile(file) {
  if (!file) return;
  try {
    const content = await file.text();
    const isCsv = file.name.toLowerCase().endsWith('.csv') || file.type.includes('csv');
    const imported = isCsv ? parseWorkspaceCsv(content) : normalizeWorkspace(content);
    const oldTotal = state.shoes.reduce((total, shoe) => total + shoe.results.length, 0);
    const newTotal = imported.reduce((total, shoe) => total + shoe.results.length, 0);
    if (oldTotal && !window.confirm(`นำเข้า ${imported.length} ชู / ${newTotal} มือ และแทนที่ประวัติเดิม ${state.shoes.length} ชู / ${oldTotal} มือ ใช่หรือไม่?`)) return;
    state.shoes = imported.map((shoe, index) => ({
      id: `import-${Date.now()}-${index}`,
      name: shoe.name || `ชู ${index + 1}`,
      results: validateResults(shoe.results)
    }));
    if (!state.shoes.length) state.shoes = [{ id: `shoe-${Date.now()}`, name: 'ชู 1', results: [] }];
    state.activeShoeId = state.shoes.at(-1).id;
    state.redoStack = [];
    rebuildLearningSession();
    render();
    setText('dataStatus', `นำเข้าสำเร็จ ${state.shoes.length} ชู / ${newTotal} มือจาก ${file.name}`);
    showToast('นำเข้าประวัติแล้ว · สร้างความจำโมเดลใหม่จากข้อมูลทั้งหมด');
  } catch (error) {
    setText('dataStatus', `นำเข้าไม่สำเร็จ: ${error.message}`);
    showToast(`ไฟล์ไม่ถูกต้อง: ${error.message}`);
  } finally {
    $('importFile').value = '';
  }
}

function handleKeyboard(event) {
  const active = document.activeElement;
  const editing = active && (['INPUT', 'TEXTAREA', 'SELECT'].includes(active.tagName) || active.isContentEditable);
  if (editing || event.altKey || event.metaKey) return;
  const key = event.key.toLowerCase();
  if ((event.ctrlKey || event.shiftKey) && key === 'z') {
    event.preventDefault();
    if (event.shiftKey) redo(); else undo();
  } else if ((event.ctrlKey || event.metaKey) && key === 'y') {
    event.preventDefault(); redo();
  } else if (!event.ctrlKey && !event.shiftKey) {
    if (key === 'p') addResult('P');
    else if (key === 'b') addResult('B');
    else if (key === 't') addResult('T');
  }
}

function bindEvents() {
  $('addP').addEventListener('click', () => addResult('P'));
  $('addB').addEventListener('click', () => addResult('B'));
  $('addT').addEventListener('click', () => addResult('T'));
  $('undo').addEventListener('click', undo);
  $('redo').addEventListener('click', redo);
  $('editShoe').addEventListener('click', editShoe);
  $('resetShoe').addEventListener('click', resetShoe);
  $('newShoe').addEventListener('click', newShoe);
  $('renameShoe').addEventListener('click', renameShoe);
  $('clearMemory').addEventListener('click', clearMemory);
  $('exportJson').addEventListener('click', exportJson);
  $('exportCsv').addEventListener('click', exportCsvFile);
  $('importButton').addEventListener('click', () => $('importFile').click());
  $('importFile').addEventListener('change', (event) => importFile(event.target.files?.[0]));
  document.addEventListener('keydown', handleKeyboard);
}

loadState();
bindEvents();
rebuildLearningSession();
render();
