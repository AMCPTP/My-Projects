/**
 * Baccarat Atlas — deterministic roadmap engine.
 *
 * Important model boundary:
 * - P/B/T are historical outcomes, not predictive features with causal power.
 * - Ties are recorded on the Bead Plate and attached to the latest Big Road bead.
 * - A Tie does not change the Big Road streak or feed the derived roads.
 * - Derived-road colors describe Big Road geometry; they are not Banker/Player.
 */

export const APP_NAME = 'Baccarat Atlas';
export const DATA_VERSION = 1;
export const SIDES = Object.freeze(['P', 'B', 'T']);
export const ROAD_DEFINITIONS = Object.freeze([
  { key: 'bigEye', name: 'Big Eye Boy', offset: 1, symbol: '○', description: 'เปรียบเทียบกับคอลัมน์ก่อนหน้า 1 คอลัมน์' },
  { key: 'small', name: 'Small Road', offset: 2, symbol: '●', description: 'เปรียบเทียบโดยข้ามไป 1 คอลัมน์' },
  { key: 'cockroach', name: 'Cockroach Pig', offset: 3, symbol: '／', description: 'เปรียบเทียบโดยข้ามไป 2 คอลัมน์' }
]);

export function validateResults(value) {
  if (!Array.isArray(value)) throw new TypeError('ข้อมูลผลต้องเป็น array');
  return value.map((item, index) => {
    try {
      return normalizeResult(typeof item === 'string' ? item : item?.result);
    } catch {
      throw new TypeError(`ผลลำดับที่ ${index + 1} ไม่ถูกต้อง (รองรับ P, B, T)`);
    }
  });
}

export function normalizeResult(value) {
  const raw = String(value ?? '').trim().toUpperCase();
  const aliases = new Map([
    ['P', 'P'], ['PLAYER', 'P'], ['PLAYER WIN', 'P'], ['ผู้เล่น', 'P'],
    ['B', 'B'], ['BANKER', 'B'], ['BANKER WIN', 'B'], ['เจ้ามือ', 'B'],
    ['T', 'T'], ['TIE', 'T'], ['DRAW', 'T'], ['เสมอ', 'T']
  ]);
  const normalized = aliases.get(raw);
  if (!normalized) throw new TypeError(`ไม่รู้จักผล "${raw}" (รองรับ P, B, T)`);
  return normalized;
}

export function buildBeadPlate(results) {
  const normalized = validateResults(results);
  const columns = [];
  for (let i = 0; i < normalized.length; i += 6) columns.push(normalized.slice(i, i + 6));
  return {
    columns,
    count: normalized.length,
    rows: 6,
    lastIndex: normalized.length - 1
  };
}

function cellKey(row, col) { return `${row}:${col}`; }

/**
 * Build a six-row visual Big Road while retaining logical streak columns.
 * Logical run lengths (not the visual dragon-tail cells) feed derived roads.
 */
export function buildBigRoad(results) {
  const normalized = validateResults(results);
  const grid = new Map();
  const columns = [];
  const cells = [];
  let lastCell = null;
  let currentRun = null;
  let pendingTies = 0;
  let totalTies = 0;

  const isOccupied = (row, col) => grid.has(cellKey(row, col));
  const place = (cell) => {
    grid.set(cellKey(cell.row, cell.col), cell);
    cells.push(cell);
  };

  for (let handIndex = 0; handIndex < normalized.length; handIndex += 1) {
    const result = normalized[handIndex];
    if (result === 'T') {
      totalTies += 1;
      if (lastCell) {
        lastCell.tieCount += 1;
      } else {
        pendingTies += 1;
      }
      continue;
    }

    let row;
    let col;
    const startsNewRun = !currentRun || currentRun.side !== result;

    if (startsNewRun) {
      // Every logical streak begins in the next available top-row cell.
      const startFrom = currentRun ? currentRun.visualStartCol + 1 : 0;
      col = startFrom;
      while (isOccupied(0, col)) col += 1;
      row = 0;
      currentRun = {
        index: columns.length,
        side: result,
        startCol: columns.length,
        visualStartCol: col,
        logicalLength: 0,
        cells: []
      };
      columns.push(currentRun);
    } else {
      const previous = lastCell;
      if (previous.row < 5 && !isOccupied(previous.row + 1, previous.col)) {
        row = previous.row + 1;
        col = previous.col;
      } else {
        // Dragon tail / blocked-cell turn: extend right on the current row.
        row = previous.row;
        col = previous.col + 1;
        while (isOccupied(row, col)) col += 1;
      }
    }

    const cell = {
      side: result,
      row,
      col,
      runIndex: currentRun.index,
      logicalRow: currentRun.logicalLength,
      handIndex,
      tieCount: pendingTies
    };
    pendingTies = 0;
    currentRun.logicalLength += 1;
    currentRun.cells.push(cell);
    place(cell);
    lastCell = cell;
  }

  const maxCol = cells.reduce((max, cell) => Math.max(max, cell.col), -1);
  const occupied = Array.from({ length: 6 }, (_, row) =>
    Array.from({ length: maxCol + 1 }, (_, col) => grid.get(cellKey(row, col)) ?? null)
  );

  return {
    rows: 6,
    columns,
    cells,
    occupied,
    totalTies,
    pendingTies,
    maxCol,
    lastCell
  };
}

function buildDerivedGrid(marks) {
  const grid = new Map();
  const cells = [];
  let last = null;
  let currentVisualStartCol = -1;
  const occupied = (row, col) => grid.has(cellKey(row, col));

  for (const mark of marks) {
    let row;
    let col;
    if (!last) {
      row = 0; col = 0; currentVisualStartCol = 0;
    } else if (last.color === mark.color) {
      if (last.row < 5 && !occupied(last.row + 1, last.col)) {
        row = last.row + 1; col = last.col;
      } else {
        row = last.row; col = last.col + 1;
        while (occupied(row, col)) col += 1;
      }
    } else {
      row = 0; col = currentVisualStartCol + 1;
      while (occupied(row, col)) col += 1;
      currentVisualStartCol = col;
    }
    const cell = { ...mark, row, col };
    grid.set(cellKey(row, col), cell);
    cells.push(cell);
    last = cell;
  }

  const maxCol = cells.reduce((max, cell) => Math.max(max, cell.col), -1);
  return {
    cells,
    occupied: Array.from({ length: 6 }, (_, row) =>
      Array.from({ length: maxCol + 1 }, (_, col) => grid.get(cellKey(row, col)) ?? null)
    ),
    maxCol
  };
}

/**
 * The standard derived-road comparison:
 * offset 1 = Big Eye Boy, 2 = Small Road, 3 = Cockroach Pig.
 * New logical column: compare lengths of (current-1) and (current-1-offset).
 * Continuation: compare occupied status at rows r and r-1 in (current-offset).
 */
export function buildDerivedRoad(bigRoad, offset) {
  if (![1, 2, 3].includes(offset)) throw new RangeError('offset ต้องเป็น 1, 2 หรือ 3');
  const columns = bigRoad.columns;
  const marks = [];

  for (let c = 0; c < columns.length; c += 1) {
    const run = columns[c];
    for (let r = 0; r < run.logicalLength; r += 1) {
      let shouldStart = false;
      let isRed = null;

      if (r === 0) {
        if (c >= offset + 1) {
          shouldStart = true;
          const leftLength = columns[c - 1].logicalLength;
          const compareLength = columns[c - 1 - offset].logicalLength;
          isRed = leftLength === compareLength;
        }
      } else if (c >= offset) {
        shouldStart = true;
        const comparisonRun = columns[c - offset];
        const atCurrentRow = r < comparisonRun.logicalLength;
        const oneAbove = (r - 1) < comparisonRun.logicalLength;
        isRed = atCurrentRow === oneAbove;
      }

      if (shouldStart) {
        const sourceCell = run.cells[r];
        marks.push({
          color: isRed ? 'R' : 'B',
          sourceColumn: c,
          sourceRow: r,
          handIndex: sourceCell?.handIndex ?? null
        });
      }
    }
  }

  return { offset, marks, ...buildDerivedGrid(marks) };
}

export function buildAllRoads(results) {
  const beadPlate = buildBeadPlate(results);
  const bigRoad = buildBigRoad(results);
  const derivedRoads = ROAD_DEFINITIONS.map((definition) => ({
    ...definition,
    ...buildDerivedRoad(bigRoad, definition.offset)
  }));
  return { beadPlate, bigRoad, derivedRoads };
}

export function classifyPattern(results) {
  const sequence = validateResults(results).filter((result) => result !== 'T');
  const last = sequence.slice(-8);
  if (!sequence.length) return { key: 'empty', name: 'รอข้อมูล', description: 'ยังไม่มีผลที่ตัดสินเป็น P หรือ B', prediction: null, sample: '' };

  const isAlternating = (items) => items.length >= 6 && items.every((value, index) => index === 0 || value !== items[index - 1]);
  const repeatsPeriod = (items, period) => items.length >= period * 2 && items.slice(-period).every((value, index) => value === items[items.length - period * 2 + index]);
  const recent6 = sequence.slice(-6);
  const recent8 = sequence.slice(-8);

  if (isAlternating(recent6)) {
    const prediction = sequence.at(-1) === 'B' ? 'P' : 'B';
    return { key: 'pingpong', name: 'ปิงปอง / สลับฝั่ง', description: '6 ผลล่าสุดสลับ P/B ทุกตา', prediction, sample: recent6.join(' ') };
  }

  if (recent6.length === 6 && repeatsPeriod(recent6, 3)) {
    const [a, b, c] = recent6.slice(0, 3);
    if (a === b && b !== c) {
      return { key: 'two-one', name: 'สองตัวหนึ่ง (2–1)', description: 'รูปแบบ 2 ฝั่งเดียว แล้วเปลี่ยน 1 ฝั่ง วนซ้ำครบ 2 รอบ', prediction: a, sample: recent6.join(' ') };
    }
    if (a !== b && b === c) {
      return { key: 'one-two', name: 'หนึ่งตัวสอง (1–2)', description: 'รูปแบบ 1 ฝั่ง แล้วเปลี่ยนไปอีกฝั่ง 2 ครั้ง วนซ้ำครบ 2 รอบ', prediction: a, sample: recent6.join(' ') };
    }
  }

  if (recent8.length === 8 && repeatsPeriod(recent8, 4)) {
    const [a, b, c, d] = recent8.slice(0, 4);
    if (a === b && c === d && a !== c) {
      return { key: 'two-two', name: 'สองต่อสอง (2–2)', description: 'รูปแบบสองฝั่งแรก / สองฝั่งตรงข้าม วนซ้ำครบ 2 รอบ', prediction: a, sample: recent8.join(' ') };
    }
  }

  let streak = 1;
  for (let i = sequence.length - 1; i > 0 && sequence[i] === sequence[i - 1]; i -= 1) streak += 1;
  if (streak >= 3) {
    const prediction = sequence.at(-1);
    return { key: 'dragon', name: 'มังกร / ทางยาว', description: `ฝั่ง ${prediction} ต่อเนื่อง ${streak} ตา`, prediction, sample: sequence.slice(-Math.min(streak, 8)).join(' ') };
  }

  return { key: 'random', name: 'กระจัดกระจาย / ยังไม่พบรูปแบบ', description: 'ข้อมูลล่าสุดไม่เข้าเกณฑ์รูปแบบที่กำหนด', prediction: null, sample: last.join(' ') };
}

export function forecastFromPattern(results) {
  const pattern = classifyPattern(results);
  return {
    ...pattern,
    type: pattern.prediction ? 'pattern-projection' : 'no-signal',
    label: pattern.prediction === 'B' ? 'BANKER · B' : pattern.prediction === 'P' ? 'PLAYER · P' : 'ยังไม่มีสัญญาณ P/B'
  };
}

export function backtestPatternForecast(results) {
  const sequence = validateResults(results).filter((result) => result !== 'T');
  let signals = 0;
  let correct = 0;
  let bankerSignals = 0;
  let playerSignals = 0;
  const records = [];

  for (let nextIndex = 1; nextIndex < sequence.length; nextIndex += 1) {
    const history = sequence.slice(0, nextIndex);
    const forecast = forecastFromPattern(history);
    if (!forecast.prediction) continue;
    const actual = sequence[nextIndex];
    const isCorrect = forecast.prediction === actual;
    signals += 1;
    if (isCorrect) correct += 1;
    if (forecast.prediction === 'B') bankerSignals += 1;
    else playerSignals += 1;
    records.push({ handNumber: nextIndex + 1, prediction: forecast.prediction, actual, correct: isCorrect, pattern: forecast.key });
  }

  return {
    signals,
    correct,
    incorrect: signals - correct,
    accuracy: signals ? (correct / signals) * 100 : null,
    bankerSignals,
    playerSignals,
    records
  };
}

/** Calculate the next derived-road marker under a hypothetical P or B outcome. */
export function previewNextDerived(results, candidateSide) {
  if (!['P', 'B'].includes(candidateSide)) throw new TypeError('candidateSide ต้องเป็น P หรือ B');
  const before = buildAllRoads(results).derivedRoads;
  const after = buildAllRoads([...validateResults(results), candidateSide]).derivedRoads;
  return after.map((road, index) => {
    const previousCount = before[index].marks.length;
    const nextMark = road.marks.length > previousCount ? road.marks.at(-1) : null;
    return { key: road.key, name: road.name, color: nextMark?.color ?? null };
  });
}

export function summarizeResults(results) {
  const normalized = validateResults(results);
  const counts = { P: 0, B: 0, T: 0 };
  for (const result of normalized) counts[result] += 1;
  const decisive = normalized.filter((result) => result !== 'T');
  let streak = 0;
  let streakSide = null;
  for (let i = decisive.length - 1; i >= 0; i -= 1) {
    if (streakSide === null) streakSide = decisive[i];
    if (decisive[i] !== streakSide) break;
    streak += 1;
  }
  const recent = decisive.slice(-12);
  const recentCounts = { P: recent.filter((x) => x === 'P').length, B: recent.filter((x) => x === 'B').length };
  return {
    total: normalized.length,
    decisive: decisive.length,
    counts,
    rates: Object.fromEntries(['P', 'B', 'T'].map((side) => [side, normalized.length ? (counts[side] / normalized.length) * 100 : 0])),
    lastResult: normalized.at(-1) ?? null,
    currentStreak: streak ? { side: streakSide, length: streak } : null,
    recentCounts,
    recentTotal: recent.length
  };
}

export function exportSession(results) {
  return {
    app: APP_NAME,
    version: DATA_VERSION,
    exportedAt: new Date().toISOString(),
    results: validateResults(results)
  };
}

export function importSession(data) {
  let parsed = data;
  if (typeof data === 'string') parsed = JSON.parse(data);
  const results = Array.isArray(parsed) ? parsed : parsed?.results;
  return validateResults(results);
}

export function parseCsvResults(csvText) {
  if (typeof csvText !== 'string') throw new TypeError('ไฟล์ CSV ต้องเป็นข้อความ');
  const results = [];
  const lines = csvText.replace(/^\uFEFF/, '').split(/\r?\n/).map((line) => line.trim()).filter(Boolean);

  for (let lineIndex = 0; lineIndex < lines.length; lineIndex += 1) {
    const line = lines[lineIndex];
    const fields = line.split(/[,;\t]/).map((field) => field.trim().replace(/^"|"$/g, '')).filter(Boolean);
    if (!fields.length) continue;
    if (fields.some((field) => /^(result|ผล|hand|ลำดับ)$/i.test(field))) continue;

    // Supports both one-column files (P/B/T per row) and this app's hand,result format.
    const candidates = fields.length > 1 && /^\d+$/.test(fields[0]) ? fields.slice(1) : fields;
    for (const token of candidates) {
      try {
        results.push(normalizeResult(token));
      } catch {
        throw new TypeError(`CSV: อ่านค่า "${token}" ไม่ได้ (บรรทัด ${lineIndex + 1})`);
      }
    }
  }
  return results;
}

export function exportCsv(results) {
  const normalized = validateResults(results);
  return ['hand,result', ...normalized.map((result, index) => `${index + 1},${result}`)].join('\n');
}
