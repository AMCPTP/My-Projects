import test from 'node:test';
import assert from 'node:assert/strict';
import { buildAllRoads } from '../src/engine.js';
import {
  learnFromShoes,
  detectLearningPattern,
  scanLearningPatterns,
  normalizeWorkspace,
  exportWorkspace,
  exportWorkspaceCsv,
  parseWorkspaceCsv
} from '../src/learning.js';

const makeShoe = (id, results) => ({ id, name: id, results: results.split('') });

test('cold start waits for evidence rather than fabricating a directional signal', () => {
  const output = learnFromShoes([makeShoe('short', 'BPBPPBBP')]);
  assert.equal(output.forecast.observationsLearned, 8);
  assert.equal(output.forecast.side, null);
  assert.equal(output.metrics.evaluated, 0);
});

test('online learner evaluates prequentially after the 12-observation warm-up', () => {
  const output = learnFromShoes([makeShoe('long', 'BPBPPBBPBPBPBPPBBPBPBBPPBPPB')]);
  assert.equal(output.metrics.totalDecisive, 28);
  assert.equal(output.metrics.evaluated, 16);
  assert.equal(output.forecast.side, null);
  assert.equal(output.forecast.status, 'หลักฐานยังไม่พอ');
  assert.ok(output.forecast.pB >= 0.02 && output.forecast.pB <= 0.98);
  assert.ok(Math.abs(output.forecast.pB + output.forecast.pP - 1) < 1e-10);
});

test('learning memory crosses shoe boundaries but road sequence resets at each new shoe', () => {
  const output = learnFromShoes([
    makeShoe('shoe-1', 'BBBBPPPPBBBBPPPP'),
    makeShoe('shoe-2', 'BPBPB')
  ]);
  assert.equal(output.metrics.shoes, 2);
  assert.equal(output.metrics.totalDecisive, 21);
  assert.deepEqual(output.active.sequence, ['B', 'P', 'B', 'P', 'B']);
  assert.equal(output.forecast.observationsLearned, 21);
});

test('selected historical shoe replay excludes later shoes to prevent future leakage', () => {
  const first = makeShoe('shoe-1', 'BBBBPPPPBBBBPPPPBPBPBP');
  const laterA = makeShoe('shoe-2', 'BBBBBBBBBBBBBBBB');
  const laterB = makeShoe('shoe-2', 'PPPPPPPPPPPPPPPP');
  const a = learnFromShoes([first, laterA], 0);
  const b = learnFromShoes([first, laterB], 0);
  assert.equal(a.forecast.pB, b.forecast.pB);
  assert.equal(a.forecast.observationsLearned, b.forecast.observationsLearned);
  assert.deepEqual(a.active.sequence, b.active.sequence);
});

test('Tie is stored in hands but excluded from decisive learning observations', () => {
  const output = learnFromShoes([makeShoe('ties', 'TTBPPTBTTB')]);
  assert.equal(output.metrics.totalHands, 10);
  assert.equal(output.metrics.totalTies, 5);
  assert.equal(output.metrics.totalDecisive, 5);
  assert.equal(output.forecast.observationsLearned, 5);
  assert.deepEqual(output.active.sequence, ['B', 'P', 'P', 'B', 'B']);
});

test('expert weights remain normalized and expose historical diagnostics', () => {
  const output = learnFromShoes([makeShoe('a', 'BBPPBPBBPPBBPBPBPBPPBBPPBPPB')]);
  const sum = output.forecast.experts.reduce((total, expert) => total + expert.weight, 0);
  assert.ok(Math.abs(sum - 1) < 1e-10);
  assert.ok(output.forecast.experts.length >= 10);
  for (const expert of output.forecast.experts) {
    assert.ok(expert.weight >= 0 && expert.weight <= 1);
    assert.ok(expert.samples >= 0);
    assert.ok(expert.currentProbabilityB >= 0 && expert.currentProbabilityB <= 1);
  }
});

test('pattern memory generalizes alternating sequences by current phase', () => {
  const one = detectLearningPattern('BPBPBP'.split(''));
  const two = detectLearningPattern('PBPBPB'.split(''));
  assert.equal(one.type, 'pingpong');
  assert.equal(two.type, 'pingpong');
  assert.equal(one.key, 'pingpong:P');
  assert.equal(two.key, 'pingpong:B');
});



test('multi-angle pattern scan reports rhythm, balance, streak, and descriptive pattern', () => {
  const scan = scanLearningPatterns('BPBPBP'.split(''));
  assert.equal(scan.detections[0].key, 'pingpong');
  assert.equal(scan.stats.window, 6);
  assert.equal(scan.stats.banker, 3);
  assert.equal(scan.stats.player, 3);
  assert.equal(scan.stats.switchCount, 5);
  assert.equal(scan.stats.rhythm, 'สลับฝั่งถี่');
  assert.equal(scan.stats.currentStreak.length, 1);
});



test('scanner can flag overlapping structure and arbitrary repeated motifs', () => {
  const longSide = scanLearningPatterns('BBBBBBBBBBBB'.split(''));
  const longKeys = new Set(longSide.detections.map((item) => item.key));
  assert.ok(longKeys.has('dragon'));
  assert.ok(longKeys.has('stick-heavy'));
  assert.ok(longKeys.has('dominant'));

  const genericCycle = scanLearningPatterns('BPPBPBPPBPBPPBP'.split(''));
  assert.ok(genericCycle.detections.some((item) => item.key === 'cycle'));
});

test('direction is withheld when validation spans fewer than five independent shoes', () => {
  const sequence = 'BBPPBP'.repeat(45);
  const output = learnFromShoes([makeShoe('only-one-shoe', sequence)]);
  assert.ok(output.forecast.evaluation.samples >= 100);
  assert.equal(output.forecast.evaluation.evaluatedShoes, 1);
  assert.equal(output.forecast.side, null);
  assert.equal(output.forecast.status, 'หลักฐานยังไม่พอ');
  assert.ok(output.forecast.evaluation.brierImprovement.clusters === 1);
});



test('clustered validation exposes shoe-level confidence bounds for multi-shoe histories', () => {
  const shoes = Array.from({ length: 5 }, (_, index) => {
    let seed = 12345 + (index * 98765);
    const results = Array.from({ length: 180 }, () => {
      seed = ((1664525 * seed) + 1013904223) >>> 0;
      return (seed & 0x80000000) ? 'B' : 'P';
    });
    return { id: `shoe-${index + 1}`, name: `shoe-${index + 1}`, results };
  });
  const output = learnFromShoes(shoes);
  assert.ok(output.forecast.evaluation.samples >= 100);
  assert.equal(output.forecast.evaluation.evaluatedShoes, 5);
  assert.equal(output.forecast.evaluation.brierImprovement.clusters, 5);
  assert.equal(output.forecast.evaluation.logLossImprovement.clusters, 5);
  assert.equal(output.forecast.side, null);
});

test('all shoe formats export and import as a reusable training workspace', () => {
  const original = [makeShoe('a', 'BBPPTT'), makeShoe('b', 'PPBBTTBP')];
  const json = exportWorkspace(original);
  const restored = normalizeWorkspace(JSON.stringify(json));
  assert.deepEqual(restored.map((shoe) => shoe.results), original.map((shoe) => shoe.results));
  const csv = exportWorkspaceCsv(original);
  const csvRestored = parseWorkspaceCsv(csv);
  assert.deepEqual(csvRestored.map((shoe) => shoe.results), original.map((shoe) => shoe.results));
});

test('legacy v1 result exports migrate into one training shoe', () => {
  const migrated = normalizeWorkspace({ version: 1, results: ['B', 'P', 'T'] });
  assert.equal(migrated.length, 1);
  assert.deepEqual(migrated[0].results, ['B', 'P', 'T']);
});

test('per-shoe learning diagnostics report evaluated samples only after warm-up', () => {
  const output = learnFromShoes([
    makeShoe('first', 'BBBBBBBBBBBBBBBB'),
    makeShoe('second', 'PPPPPPPPPPPPPPPP')
  ]);
  assert.equal(output.perShoe[0].evaluated, 4);
  assert.equal(output.perShoe[1].evaluated, 16);
  assert.ok(output.perShoe[0].accuracy !== null);
});

test('incremental appends match a clean chronological replay, including a new shoe boundary', async () => {
  const {
    createLearningSession,
    appendLearningResult,
    startLearningShoe,
    snapshotLearningSession
  } = await import('../src/learning.js');
  const firstResults = 'BBPPBPBBPPBBPBPB'.split('');
  const secondResults = 'PBPBBPPBPB'.split('');
  const session = createLearningSession([{ id: 'a', name: 'a', results: firstResults }]);
  startLearningShoe(session, { id: 'b', name: 'b', results: [] });
  for (const result of secondResults) appendLearningResult(session, result);
  const incremental = snapshotLearningSession(session);
  const replay = learnFromShoes([
    { id: 'a', name: 'a', results: firstResults },
    { id: 'b', name: 'b', results: secondResults }
  ]);
  assert.equal(incremental.forecast.pB, replay.forecast.pB);
  assert.equal(incremental.metrics.brier, replay.metrics.brier);
  assert.equal(incremental.metrics.accuracy, replay.metrics.accuracy);
  assert.deepEqual(incremental.active.sequence, replay.active.sequence);
});

test('incremental updates handle a large sequence without rebuilding history per result', async () => {
  const { createLearningSession, appendLearningResult, snapshotLearningSession } = await import('../src/learning.js');
  const session = createLearningSession([{ id: 'large', results: [] }]);
  for (let i = 0; i < 2000; i += 1) appendLearningResult(session, i % 3 === 0 ? 'B' : 'P');
  const output = snapshotLearningSession(session);
  assert.equal(output.metrics.totalDecisive, 2000);
  assert.equal(output.forecast.observationsLearned, 2000);
  assert.equal(output.active.sequence.length, 2000);
});


test('incremental derived-road features match roadmap-engine colors across mixed results', () => {
  const results = Array.from({ length: 240 }, (_, index) => {
    const value = (index * 17 + Math.floor(index / 7) * 3) % 11;
    return value === 0 ? 'T' : value < 5 ? 'B' : 'P';
  });
  const reference = buildAllRoads(results);
  const learned = learnFromShoes([{ id: 'geometry', results }]);
  const expected = {
    1: reference.derivedRoads[0].marks.map((mark) => mark.color),
    2: reference.derivedRoads[1].marks.map((mark) => mark.color),
    3: reference.derivedRoads[2].marks.map((mark) => mark.color)
  };
  assert.deepEqual(learned.active.roadMarks, expected);
});
