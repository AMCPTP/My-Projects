import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const htmlPath = path.join(root, 'index.html');
let html = await fs.readFile(htmlPath, 'utf8');
const [css, engine, app] = await Promise.all([
  fs.readFile(path.join(root, 'styles.css'), 'utf8'),
  fs.readFile(path.join(root, 'src/engine.js'), 'utf8'),
  fs.readFile(path.join(root, 'src/app.js'), 'utf8')
]);
html = html.replace('<link rel="stylesheet" href="./styles.css">', `<style>\n${css}\n</style>`);
html = html.replace('<script src="./src/engine.js"></script>\n<script src="./src/app.js"></script>', `<script>\n${engine}\n</script>\n<script>\n${app}\n</script>`);
const outDir = path.join(root, 'dist');
await fs.mkdir(outDir, { recursive: true });
const out = path.join(outDir, 'Baccarat-Atlas-Neural-Lab-4.0.1.html');
await fs.writeFile(out, html, 'utf8');
console.log(`Built ${path.relative(root, out)} (${(Buffer.byteLength(html)/1024).toFixed(1)} KB)`);
