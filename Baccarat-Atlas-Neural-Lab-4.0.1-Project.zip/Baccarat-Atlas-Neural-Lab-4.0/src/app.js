'use strict';
(() => {
  const E = window.AtlasEngine;
  const $ = (id) => document.getElementById(id);
  const STORAGE = 'baccaratAtlas.neural-lab.workspace.v4';
  const PREVIOUS = ['baccaratAtlas.evidence.workspace.v3', 'baccaratAtlas.ai.workspace.v2', 'baccaratAtlas.session.v1'];
  const DEFAULT_BASE = 0.506825;
  const state = { baseB: DEFAULT_BASE, shoes: [{id:'shoe-1',name:'ชู 1',results:[]}], session:null, redo:[], saving:false, persistenceReady:true, storageError:'' };
  let toastTimer = null;

  function esc(v) { return String(v).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
  function pct(v, d=1) { return v == null || !Number.isFinite(v) ? '—' : `${(v*100).toFixed(d)}%`; }
  function set(id, value) { $(id).textContent = value; }
  function currentShoe() { return state.shoes[state.shoes.length-1]; }
  function toast(msg) { const t=$('toast');t.textContent=msg;t.classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>t.classList.remove('show'),2300); }

  function normalizeShoes(shoes) {
    return shoes.map((s,i)=>({id:String(s.id??`shoe-${i+1}`),name:String(s.name??`ชู ${i+1}`),results:E.validateResults(s.results??[])}));
  }
  function rebuild() {
    state.shoes=normalizeShoes(state.shoes);
    if (!state.shoes.length) state.shoes=[{id:'shoe-1',name:'ชู 1',results:[]}];
    state.session=E.createSession(state.shoes,state.baseB);
    state.shoes=state.session.shoes;
    save();
  }
  function load() {
    let raw=null;
    try { raw=localStorage.getItem(STORAGE); }
    catch(error) {
      state.persistenceReady=false;
      state.storageError=`เบราว์เซอร์ไม่อนุญาตให้อ่านพื้นที่เก็บข้อมูล (${error?.name||'StorageError'})`;
    }
    if (state.persistenceReady && raw!==null) {
      try {
        const x=JSON.parse(raw);
        if (!x || typeof x!=='object' || !Array.isArray(x.shoes)) throw new TypeError('รูปแบบ workspace ไม่ถูกต้อง');
        state.baseB=Number.isFinite(x.baseB)&&x.baseB>=0.4&&x.baseB<=0.6?x.baseB:DEFAULT_BASE;
        state.shoes=normalizeShoes(x.shoes);
      } catch(error) {
        // Never overwrite a corrupt workspace automatically; preserve it for recovery.
        state.persistenceReady=false;
        state.storageError=`พบข้อมูลเดิมที่อ่านไม่ได้ (${error.message}) · ระบบจะไม่เขียนทับข้อมูลเดิม`;
      }
    } else if (state.persistenceReady) {
      try {
        let oldKey=null, old=null;
        for (const key of PREVIOUS) {
          const candidate=localStorage.getItem(key);
          if (candidate!==null) { oldKey=key; old=candidate; break; }
        }
        if(old!==null){
          const x=JSON.parse(old);
          state.shoes=normalizeShoes(x.shoes??(x.results?[{name:'ชูเดิม',results:x.results}]:[]));
          state.baseB=Number.isFinite(x.baseB)&&x.baseB>=0.4&&x.baseB<=0.6?x.baseB:DEFAULT_BASE;
          set('saveLabel',`พบข้อมูลเดิมจาก ${oldKey} · กำลังย้ายเป็น v4`);
        }
      } catch(error) {
        state.persistenceReady=false;
        state.storageError=`ย้ายข้อมูลเดิมไม่สำเร็จ (${error.message}) · ข้อมูลต้นฉบับยังไม่ถูกลบ`;
      }
    }
    $('baseRate').value=(state.baseB*100).toFixed(2);
    if (!state.persistenceReady && state.storageError) set('saveLabel',state.storageError);
    rebuild();
  }
  function save() {
    if (!state.persistenceReady) { set('saveLabel',state.storageError || 'บันทึกอัตโนมัติไม่พร้อม · กรุณาส่งออก JSON'); return false; }
    try {
      localStorage.setItem(STORAGE,JSON.stringify({version:4,baseB:state.baseB,shoes:state.shoes}));
      set('saveLabel','บันทึกในอุปกรณ์แล้ว');
      return true;
    } catch(error) {
      state.persistenceReady=false;
      state.storageError=`บันทึกอัตโนมัติไม่ได้ (${error?.name||'StorageError'}) · ส่งออก JSON สำรอง`;
      set('saveLabel',state.storageError);
      return false;
    }
  }
  function download(name, content, type) {
    const blob=new Blob([content],{type:`${type};charset=utf-8`});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=name;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);
  }
  function stamp(){return new Date().toISOString().replace(/[:.]/g,'-').slice(0,19);}

  function add(side) {
    E.appendResult(state.session,side);state.shoes=state.session.shoes;state.redo=[];render();toast(`บันทึก ${side} แล้ว · อัปเดตโมเดลจากผลจริง`);
  }
  function undo() {
    const shoe=currentShoe();if(!shoe.results.length)return;
    state.redo.push(shoe.results.pop());rebuild();render();toast('ย้อนกลับแล้ว · สร้างความจำใหม่จากประวัติที่เหลือ');
  }
  function redo() {
    if(!state.redo.length)return;const v=state.redo.pop();E.appendResult(state.session,v);state.shoes=state.session.shoes;render();toast('ทำซ้ำแล้ว · อัปเดตโมเดลใหม่');
  }
  function newShoe() {
    if(!currentShoe().results.length){toast('ชูปัจจุบันว่างอยู่แล้ว');return;}
    E.startNewShoe(state.session,`ชู ${state.shoes.length+1}`);state.shoes=state.session.shoes;state.redo=[];render();toast('เริ่มชูใหม่แล้ว · ความจำจากชูก่อนยังอยู่');
  }
  function editShoe() {
    const shoe=currentShoe();const input=prompt('แก้ผลของชูนี้ คั่นด้วยช่องว่างหรือจุลภาค (P/B/T)',shoe.results.join(' '));if(input===null)return;
    try{shoe.results=String(input).trim()?String(input).trim().split(/[\s,;]+/).map(E.normalizeResult):[];state.redo=[];rebuild();render();toast('แก้ไขแล้ว · replay การเรียนรู้ใหม่ตามลำดับ');}
    catch(e){toast(`แก้ไขไม่ได้: ${e.message}`);}
  }
  function resetShoe() {
    const shoe=currentShoe();if(!shoe.results.length)return;
    if(!confirm(`ล้างผลทั้งหมด ${shoe.name} (${shoe.results.length} มือ) หรือไม่? ชูอื่นยังเก็บอยู่`))return;
    shoe.results=[];state.redo=[];rebuild();render();toast('ล้างชูปัจจุบันแล้ว');
  }
  function clearAll() {
    if(!confirm('ล้างประวัติทุกชูและความจำทั้งหมดหรือไม่? ควรส่งออก JSON ก่อน'))return;
    state.persistenceReady=true;state.storageError='';
    state.shoes=[{id:`shoe-${Date.now()}`,name:'ชู 1',results:[]}];state.redo=[];rebuild();render();toast('ล้างความจำทั้งหมดแล้ว');
  }
  function changeBase() {
    const v=Number($('baseRate').value)/100;
    if(!Number.isFinite(v)||v<0.4||v>0.6){toast('ค่าฐานต้องอยู่ระหว่าง 40.00–60.00%');$('baseRate').value=(state.baseB*100).toFixed(2);return;}
    state.baseB=v;rebuild();render();toast('เปลี่ยนฐานอ้างอิงแล้ว · โมเดลถูกคำนวณใหม่');
  }

  function renderBead(results) {
    const board=$('beadBoard');if(!results.length){board.innerHTML='<p class="empty">ยังไม่มีผล</p>';return;}
    const cols=E.buildBeadPlate(results),html=[];
    cols.forEach((col,c)=>{for(let r=0;r<6;r++){const x=col[r];html.push(`<div class="bead ${x||''}" title="มือ ${c*6+r+1}">${x||''}</div>`);}});
    board.innerHTML=html.join('');
  }
  function renderBig(results) {
    const road=E.buildBigRoad(results),board=$('bigRoad');
    if(!road.cells.length){board.innerHTML=road.pendingTies?`<div class="big-cell">T×${road.pendingTies}</div>`:'<p class="empty">รอผล B/P</p>';return;}
    const html=[];for(let c=0;c<=road.maxCol;c++)for(let r=0;r<6;r++){const cell=road.occupied[r]?.[c];if(!cell)html.push('<div class="big-cell"></div>');else html.push(`<div class="big-cell ${cell.side}" title="มือ ${cell.handIndex+1} · ${cell.tieCount} Tie">${cell.side}${cell.tieCount?`<i>${cell.tieCount}</i>`:''}</div>`);}
    board.innerHTML=html.join('');set('bigFoot',`Streak ${road.columns.length} คอลัมน์ · Tie ${road.ties}${road.pendingTies?` · Tie รอผูก ${road.pendingTies}`:''}`);
  }
  function renderDerived(local) {
    const info=[['Big Eye Boy',1],['Small Road',2],['Cockroach Pig',3]];
    $('derivedRoads').innerHTML=info.map(([name,off])=>{
      const marks=local.roads[off]||[];const cells=marks.slice(-90).map(x=>`<span class="road-mark ${x}"></span>`).join('');
      return `<div class="road-card"><b>${name}</b><small>แดง = โครงสร้างซ้ำ · น้ำเงิน = ต่าง</small><div class="mark-list">${cells||'<em>ข้อมูลยังไม่ถึงจุดเริ่ม</em>'}</div><small>${marks.length} marks · แดง ${marks.filter(x=>x==='R').length} · น้ำเงิน ${marks.filter(x=>x==='B').length}</small></div>`;
    }).join('');
  }
  function renderExperts(f) {
    $('expertRows').innerHTML=f.experts.map(e=>{
      const stat=e.usable&&e.lowerBound>0&&e.n>=E.constants.MIN_EXPERT_EVAL?'ผ่านเกณฑ์':e.n>=E.constants.MIN_EXPERT_EVAL?'ยังไม่เหนือฐาน':`รอข้อมูล (${e.n}/${E.constants.MIN_EXPERT_EVAL})`;
      return `<tr><td>${esc(e.label)}</td><td>${e.support}${e.usable?'':' · ยังน้อย'}</td><td>${e.n}</td><td>${e.improvement?e.improvement.toFixed(4):'0.0000'}</td><td>${e.weight?(e.weight*100).toFixed(1)+'%':'—'}</td><td>${stat}</td></tr>`;
    }).join('');
    set('patternName',f.pattern.label);set('patternMemory',`${f.patternMemory.samples} ตัวอย่างตรงบริบท · B ${f.patternMemory.B} / P ${f.patternMemory.P}`);
  }
  function renderForecastHistory(rows) {
    const body=$('forecastRows');
    if(!rows?.length){body.innerHTML='<tr><td colspan="8" class="empty-cell">ยังไม่มีประวัติคำประเมิน · บันทึกผลจริงเพื่อเริ่มสะสม</td></tr>';return;}
    body.innerHTML=rows.map(row=>{
      const actualClass=row.actual==='B'?'B':row.actual==='P'?'P':'T';
      const signal=row.signal?`<span class="pill pass">${row.signal}</span>`:'<span class="pill pending">ยังไม่ผ่าน</span>';
      const lean=row.lean || '—';
      const evaluated=row.evaluated?'ประเมินแล้ว':row.actual==='T'?'Tie · ไม่ฝึก P/B':'ช่วงเรียนรู้เริ่มต้น';
      return `<tr><td>${esc(row.shoeName)} · ${row.handNumber??'—'}</td><td>${esc(row.pattern)}</td><td>${pct(row.pB)} / ${pct(row.pP)}</td><td><b>${lean}</b></td><td><span class="result ${actualClass}">${row.actual}</span></td><td>${signal}</td><td>${evaluated}</td><td>${row.contextSupport} · ${row.evaluationShoesBeforeHand} ชู</td></tr>`;
    }).join('');
  }

  function render() {
    const s=E.snapshot(state.session),f=s.forecast,shoe=currentShoe(),v=f.validation;
    set('shoeName',shoe.name);set('shoeCount',s.shoes);set('handCount',shoe.results.length);set('allHands',s.totalHands);set('decisiveCount',s.totalDecisive);set('tieCount',s.totalTies);
    $('undo').disabled=!shoe.results.length;$('redo').disabled=!state.redo.length;$('edit').disabled=!shoe.results.length;$('reset').disabled=!shoe.results.length;
    renderBead(shoe.results);renderBig(shoe.results);renderDerived(s.local);renderExperts(f);renderForecastHistory(f.forecastHistory);
    const badge=$('signalBadge'),token=$('forecastToken');
    badge.textContent=f.status;badge.className='badge '+(f.side?'good':v.n>=100?'warn':'neutral');
    const displayedSide=f.side||f.lean;
    token.textContent=displayedSide||'—';token.className='token '+(displayedSide==='B'?'B':displayedSide==='P'?'P':'none');
    set('forecastTitle',f.side?`สัญญาณผ่านเกณฑ์: ${f.side==='B'?'Banker':'Player'}`:f.lean?`คะแนนเอนทาง ${f.lean==='B'?'Banker':'Player'} · ยังไม่ผ่านเกณฑ์`:'รอผลจริงเพื่อเริ่มเรียนรู้');
    set('forecastDetail',f.detail);
    set('modelB',pct(f.pB));set('modelP',pct(f.pP));set('baseBText',pct(f.baseB,2));
    $('modelBarB').style.width=`${f.pB*100}%`;$('baseMarker').style.left=`${f.baseB*100}%`;
    set('edgeText',`${f.edge>=0?'+':''}${(f.edge*100).toFixed(2)} จุดเปอร์เซ็นต์จากฐาน`);
    set('validationN',v.n);set('validationCoverage',`${v.shoes} ชูในชุดประเมิน`);set('validationAccuracy',pct(v.accuracy));set('modelBrier',v.brier?.toFixed(4)??'—');set('baselineBrier',v.baseBrier?.toFixed(4)??'—');set('modelLogLoss',v.logLoss?.toFixed(4)??'—');set('baselineLogLoss',v.baseLogLoss?.toFixed(4)??'—');set('skillText',v.brierSkill==null?'—':`${(v.brierSkill*100).toFixed(2)}%`);set('lossCI',v.n?`${v.meanDiff.toFixed(4)} (ขอบล่างเข้มงวด ${v.lowerBound.toFixed(4)})`:'—');
    set('activeExpertCount',f.activeExperts.length);set('activeSupport',f.currentSupport);
    set('driftStatus',f.drift.status);
    set('driftDetail',f.drift.ready?`Log-loss ล่าสุด ${f.drift.recentLogLoss.toFixed(4)} เทียบช่วงก่อน ${f.drift.priorLogLoss.toFixed(4)} · Brier เปลี่ยน ${(f.drift.brierDelta>=0?'+':'')+f.drift.brierDelta.toFixed(4)}`:`ต้องมีข้อมูลประเมินอย่างน้อย ${E.constants.DRIFT_WINDOW*2} ตัวอย่าง (ขณะนี้ ${f.validation.n})`);
    set('shoeRows',s.perShoe.slice().reverse().map(x=>`<tr><td>${esc(x.name)}</td><td>${x.hands}</td><td>${x.decisive}</td><td>${x.ties}</td><td>${x.evaluated}</td><td>${x.evaluated?pct(x.correct/x.evaluated):'—'}</td></tr>`).join(''));
    save();
  }

  function exportJson() {
    const data=E.exportWorkspace(state.shoes,state.baseB);download(`baccarat-atlas-neural-lab-${stamp()}.json`,JSON.stringify(data,null,2),'application/json');set('dataStatus',`ส่งออก ${state.shoes.length} ชูแล้ว`);toast('ส่งออกข้อมูลทุกชูแล้ว');
  }
  function exportCsv() {
    const csv=E.exportWorkspaceCsv(state.shoes);
    download(`baccarat-atlas-neural-lab-${stamp()}.csv`,csv,'text/csv');toast('ส่งออก CSV แล้ว · เก็บชื่อชูและลำดับมือ');
  }
  async function importFile(file) {
    if(!file)return;try{
      const content=await file.text();let shoes, importedBase=state.baseB;
      if(file.name.toLowerCase().endsWith('.csv')) shoes=E.importCsvWorkspace(content);
      else {
        const parsed=JSON.parse(content);
        shoes=E.importWorkspace(parsed);
        if(Number.isFinite(parsed?.baseB)&&parsed.baseB>=0.4&&parsed.baseB<=0.6) importedBase=parsed.baseB;
      }
      const hands=shoes.reduce((n,s)=>n+s.results.length,0);
      if(!confirm(`นำเข้า ${shoes.length} ชู / ${hands} มือ และแทนที่ข้อมูลปัจจุบันหรือไม่?`))return;
      // Commit only after confirmation; parsing or cancellation must not mutate settings.
      state.baseB=importedBase;
      $('baseRate').value=(state.baseB*100).toFixed(2);
      state.persistenceReady=true;state.storageError='';
      state.shoes=shoes;state.redo=[];rebuild();render();set('dataStatus',`นำเข้าสำเร็จ ${shoes.length} ชู / ${hands} มือ`);toast('นำเข้าประวัติแล้ว · replay โมเดลใหม่');
    }catch(e){set('dataStatus',`นำเข้าไม่สำเร็จ: ${e.message}`);toast(`ไฟล์ไม่ถูกต้อง: ${e.message}`);}finally{$('importFile').value='';}
  }

  function keydown(e) {
    const t=document.activeElement;if(t&&(t.tagName==='INPUT'||t.tagName==='TEXTAREA'||t.isContentEditable))return;
    if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='z'){e.preventDefault();undo();return;}
    if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='y'){e.preventDefault();redo();return;}
    if(e.ctrlKey||e.metaKey||e.altKey)return;
    const k=e.key.toLowerCase();if(k==='p')add('P');else if(k==='b')add('B');else if(k==='t')add('T');
  }

  $('addP').addEventListener('click',()=>add('P'));$('addB').addEventListener('click',()=>add('B'));$('addT').addEventListener('click',()=>add('T'));
  $('undo').addEventListener('click',undo);$('redo').addEventListener('click',redo);$('newShoe').addEventListener('click',newShoe);$('edit').addEventListener('click',editShoe);$('reset').addEventListener('click',resetShoe);$('clearAll').addEventListener('click',clearAll);
  $('baseRate').addEventListener('change',changeBase);$('exportJson').addEventListener('click',exportJson);$('exportCsv').addEventListener('click',exportCsv);$('importBtn').addEventListener('click',()=>$('importFile').click());$('importFile').addEventListener('change',e=>importFile(e.target.files?.[0]));document.addEventListener('keydown',keydown);
  load();render();
})();

