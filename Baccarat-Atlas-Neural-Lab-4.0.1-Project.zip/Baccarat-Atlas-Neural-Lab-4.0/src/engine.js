
/* Baccarat Atlas Neural Lab 4.0.1 — prequential, context-aware evaluator.
 * This engine learns only from outcomes explicitly entered/imported by the user.
 * It never assumes that a historical road causes the next result.
 */
(function (root) {
  'use strict';

  const SIDE = Object.freeze(['B', 'P']);
  const ROAD_OFFSETS = Object.freeze([1, 2, 3]);
  const WARMUP = 24;
  const MIN_EXPERT_EVAL = 80;
  const MIN_CONTEXT_SUPPORT = 10;
  const MIN_ENSEMBLE_EVAL = 100;
  const MIN_CONTEXTUAL_EXPERTS = 1;
  const MIN_SIGNAL_EDGE = 0.015;
  const MAX_HISTORY = 400;
  const FORECAST_HISTORY_LIMIT = 1200;
  const DRIFT_WINDOW = 40;
  const MARKOV_DEPTH = 10;
  const HAC_MAX_LAG = 8;
  const EPS = 1e-9;

  function normalizeResult(value) {
    const raw = String(value ?? '').trim().toUpperCase();
    const map = {
      P: 'P', PLAYER: 'P', 'PLAYER WIN': 'P', 'ผู้เล่น': 'P',
      B: 'B', BANKER: 'B', 'BANKER WIN': 'B', 'เจ้ามือ': 'B',
      T: 'T', TIE: 'T', DRAW: 'T', 'เสมอ': 'T'
    };
    if (!map[raw]) throw new TypeError(`ผลไม่ถูกต้อง: ${raw || '(ว่าง)'} — รองรับ P/B/T`);
    return map[raw];
  }

  function validateResults(results) {
    if (!Array.isArray(results)) throw new TypeError('ผลลัพธ์ต้องเป็นรายการ');
    return results.map(normalizeResult);
  }

  function clampRate(value) {
    const numeric = Number(value);
    if (!Number.isFinite(numeric)) return 0.506825;
    return Math.max(0.01, Math.min(0.99, numeric));
  }

  function validateBaseRate(value) {
    const numeric = Number(value);
    if (!Number.isFinite(numeric) || numeric < 0.4 || numeric > 0.6) {
      throw new RangeError('ฐานอ้างอิง Banker ต้องอยู่ระหว่าง 40% ถึง 60%');
    }
    return numeric;
  }

  function countsOf(sequence) {
    let B = 0, P = 0;
    for (const side of sequence) side === 'B' ? B++ : P++;
    return { B, P };
  }

  function betaRate(counts, prior, strength) {
    const n = counts ? counts.B + counts.P : 0;
    return (prior * strength + (counts?.B ?? 0)) / (strength + n);
  }

  function getCounts(map, key) {
    return key ? map.get(key) ?? { B: 0, P: 0 } : { B: 0, P: 0 };
  }

  function getN(counts) { return counts.B + counts.P; }

  function streakOf(sequence) {
    if (!sequence.length) return null;
    const side = sequence[sequence.length - 1];
    let length = 0;
    for (let i = sequence.length - 1; i >= 0 && sequence[i] === side; i--) length++;
    return { side, length };
  }

  function detectPattern(sequence) {
    if (!sequence.length) return { type: 'empty', label: 'รอข้อมูล', key: 'empty' };
    const tail = sequence.slice(-8);
    const last6 = sequence.slice(-6);
    const isAlt = last6.length === 6 && last6.every((x, i) => i === 0 || x !== last6[i - 1]);
    if (isAlt) return { type: 'pingpong', label: 'ปิงปอง 6 ตา', key: `pingpong:${last6.join('')}` };
    if (tail.length >= 6 && tail.slice(-3).join('') === tail.slice(-6, -3).join('')) {
      const [a, b, c] = tail.slice(-3);
      if (a === b && b !== c) return { type: 'two-one', label: 'สองตัวหนึ่ง', key: `two-one:${tail.slice(-6).join('')}` };
      if (a !== b && b === c) return { type: 'one-two', label: 'หนึ่งตัวสอง', key: `one-two:${tail.slice(-6).join('')}` };
    }
    if (tail.length === 8 && tail.slice(-4).join('') === tail.slice(-8, -4).join('')) {
      const [a, b, c, d] = tail.slice(-4);
      if (a === b && c === d && a !== c) return { type: 'two-two', label: 'สองต่อสอง', key: `two-two:${tail.join('')}` };
    }
    // Discover repeated cycles beyond the hand-coded 2-1 / 1-2 / 2-2 motifs.
    // A candidate must repeat three complete times; evidence is still required
    // before it can influence a validated signal.
    for (let period = 3; period <= 5; period++) {
      if (sequence.length < period * 3) continue;
      const cycle = sequence.slice(-period);
      const repeated = sequence.slice(-period * 3);
      if (repeated.every((side, i) => side === cycle[i % period])) {
        return { type: 'cycle', label: `วงรอบ ${period} ตา`, key: `cycle:${period}:${cycle.join('')}` };
      }
    }
    const streak = streakOf(sequence);
    if (streak && streak.length >= 3) {
      const bucket = Math.min(streak.length, 6);
      return { type: 'dragon', label: `มังกร ${streak.side} ×${streak.length}`, key: `dragon:${streak.side}:${bucket}` };
    }
    return { type: 'mixed', label: 'ผสม / ไม่ชัดเจน', key: `mixed:${sequence.slice(-3).join('')}` };
  }

  function newLocal() {
    return { sequence: [], runs: [], roads: { 1: [], 2: [], 3: [] }, ties: 0, bead: [] };
  }

  function derivedUpdate(local, side) {
    const previous = local.runs[local.runs.length - 1];
    if (!previous || previous.side !== side) {
      const col = local.runs.length;
      for (const offset of ROAD_OFFSETS) {
        if (col >= offset + 1) {
          const same = local.runs[col - 1].length === local.runs[col - 1 - offset].length;
          local.roads[offset].push(same ? 'R' : 'B');
        }
      }
      local.runs.push({ side, length: 1 });
    } else {
      const col = local.runs.length - 1;
      const row = previous.length;
      for (const offset of ROAD_OFFSETS) {
        if (row > 0 && col >= offset) {
          const comparison = local.runs[col - offset].length;
          const same = (row < comparison) === ((row - 1) < comparison);
          local.roads[offset].push(same ? 'R' : 'B');
        }
      }
      previous.length++;
    }
    local.sequence.push(side);
  }

  function getFeatures(local) {
    const seq = local.sequence;
    const streak = streakOf(seq);
    const pattern = detectPattern(seq);
    const ngrams = {};
    for (let n = 1; n <= MARKOV_DEPTH; n++) ngrams[n] = seq.length >= n ? seq.slice(-n).join('') : null;
    const roadKeys = {};
    for (const offset of ROAD_OFFSETS) {
      const marks = local.roads[offset];
      roadKeys[offset] = marks.length >= 2 ? marks.slice(-3).join('') : null;
    }
    return {
      ngrams,
      streakKey: streak ? `${streak.side}:${Math.min(streak.length, 6)}` : null,
      pattern,
      roadKeys,
      recent8: seq.slice(-8),
      recent16: seq.slice(-16),
      recent32: seq.slice(-32)
    };
  }

  function expertDefinitions() {
    return [
      { id: 'global', label: 'สถิติรวมทุกชู', type: 'global', min: 30 },
      { id: 'globalRecent64', label: 'Recent 64 · ข้ามชู', type: 'globalRecent', size: 64, min: 32 },
      { id: 'globalRecent128', label: 'Recent 128 · ข้ามชู', type: 'globalRecent', size: 128, min: 48 },
      { id: 'recent8', label: 'Recent 8', type: 'recent', size: 8, min: 8 },
      { id: 'recent16', label: 'Recent 16', type: 'recent', size: 16, min: 16 },
      { id: 'recent32', label: 'Recent 32', type: 'recent', size: 32, min: 24 },
      ...Array.from({ length: MARKOV_DEPTH }, (_, i) => i + 1).map(n => ({ id: `markov${n}`, label: `Sequence ${n}`, type: 'ngram', n, min: n <= 6 ? 10 : 18 })),
      { id: 'streak', label: 'Streak', type: 'streak', min: 10 },
      { id: 'pattern', label: 'Pattern Memory', type: 'pattern', min: 10 },
      { id: 'bigEye', label: 'Big Eye Boy', type: 'road', offset: 1, min: 10 },
      { id: 'smallRoad', label: 'Small Road', type: 'road', offset: 2, min: 10 },
      { id: 'cockroach', label: 'Cockroach Pig', type: 'road', offset: 3, min: 10 }
    ];
  }
  const EXPERTS = expertDefinitions();

  function createExpertStats() {
    return Object.fromEntries(EXPERTS.map(e => [e.id, { n: 0, diffs: [], correct: 0, brier: 0, sumLogLoss: 0 }]));
  }

  function newModel(baseB = 0.506825) {
    return {
      baseB: validateBaseRate(baseB), observations: 0,
      global: { B: 0, P: 0 },
      ngram: Array.from({ length: MARKOV_DEPTH }, () => new Map()),
      streak: new Map(), pattern: new Map(), road: { 1: new Map(), 2: new Map(), 3: new Map() },
      expertStats: createExpertStats(), evalHistory: [], forecastHistory: [], recentOutcomes: [], shoesSeen: 0
    };
  }

  function readExpert(model, local, features, expert) {
    const globalPrior = betaRate(model.global, model.baseB, 24);
    let counts = { B: 0, P: 0 }, support = 0, pB = model.baseB;
    if (expert.type === 'global') {
      counts = model.global; support = getN(counts); pB = betaRate(counts, model.baseB, 24);
    } else if (expert.type === 'recent') {
      const list = features[`recent${expert.size}`];
      counts = countsOf(list); support = list.length; pB = betaRate(counts, globalPrior, 8);
    } else if (expert.type === 'globalRecent') {
      const list = model.recentOutcomes.slice(-expert.size);
      counts = countsOf(list); support = list.length; pB = betaRate(counts, globalPrior, 12);
    } else if (expert.type === 'ngram') {
      const key = features.ngrams[expert.n];
      counts = getCounts(model.ngram[expert.n - 1], key);
      support = getN(counts); pB = betaRate(counts, globalPrior, 12);
    } else if (expert.type === 'streak') {
      counts = getCounts(model.streak, features.streakKey);
      support = getN(counts); pB = betaRate(counts, globalPrior, 14);
    } else if (expert.type === 'pattern') {
      counts = getCounts(model.pattern, features.pattern.key);
      support = getN(counts); pB = betaRate(counts, globalPrior, 16);
    } else if (expert.type === 'road') {
      const key = features.roadKeys[expert.offset];
      counts = getCounts(model.road[expert.offset], key);
      support = getN(counts); pB = betaRate(counts, globalPrior, 16);
    }
    return { pB: clampRate(pB), support, minSupport: expert.min, usable: support >= expert.min };
  }

  // Newey-West/HAC standard error: less optimistic than an IID standard
  // error when consecutive baccarat outcomes and forecast errors are clustered.
  // The lower bound is a conservative screening statistic, not a formal proof.
  function summarizeDiffs(diffs) {
    const n = diffs.length;
    if (!n) return { n: 0, mean: 0, se: Infinity, lowerBound: -Infinity };
    const mean = diffs.reduce((a,b) => a+b, 0) / n;
    if (n < 2) return { n, mean, se: Infinity, lowerBound: -Infinity };
    const centered = diffs.map(x => x - mean);
    const gamma0 = centered.reduce((sum, x) => sum + x*x, 0) / n;
    const maxLag = Math.min(HAC_MAX_LAG, n - 1);
    let longRunVariance = gamma0;
    for (let lag = 1; lag <= maxLag; lag++) {
      let covariance = 0;
      for (let i = lag; i < n; i++) covariance += centered[i] * centered[i-lag];
      covariance /= n;
      const weight = 1 - lag / (maxLag + 1); // Bartlett kernel
      longRunVariance += 2 * weight * covariance;
    }
    const se = Math.sqrt(Math.max(0, longRunVariance) / n);
    return { n, mean, se, lowerBound: mean - 2.8 * se };
  }

  // An always-on exploratory score prevents the dashboard from displaying a
  // frozen baseline until a specialist passes the evidence gate. Experts are
  // combined by family so ten correlated sequence depths cannot outvote every
  // other information family. Bayesian shrinkage in readExpert plus a second
  // sample-size shrinkage keeps very small samples close to the prior.
  function exploratoryEstimate(model, parts) {
    const families = [
      { id:'global', members:['global','globalRecent64','globalRecent128'] },
      { id:'recent', members:['recent8','recent16','recent32'] },
      { id:'sequence', members:Array.from({length:MARKOV_DEPTH},(_,i)=>`markov${i+1}`) },
      { id:'pattern', members:['streak','pattern'] },
      { id:'roads', members:['bigEye','smallRoad','cockroach'] }
    ];
    const estimates = [];
    for (const family of families) {
      const members = family.members.map(id => ({ id, part:parts[id], expert:EXPERTS.find(x=>x.id===id) }))
        .filter(x => x.part && x.part.support > 0);
      if (!members.length) continue;
      const weighted = members.map(x => {
        const priorStrength = x.expert.type === 'global' ? 24 :
          x.expert.type === 'recent' ? 8 : x.expert.type === 'globalRecent' ? 12 :
          x.expert.type === 'ngram' ? 12 : x.expert.type === 'streak' ? 14 : 16;
        const weight = x.part.support / (x.part.support + priorStrength);
        return { pB:x.part.pB, weight };
      });
      const weightSum = weighted.reduce((sum,x)=>sum+x.weight,0);
      if (!weightSum) continue;
      const pB = weighted.reduce((sum,x)=>sum+x.pB*x.weight,0)/weightSum;
      const credibility = Math.sqrt(weighted.reduce((sum,x)=>sum+x.weight,0)/members.length);
      estimates.push({ id:family.id, pB, weight:credibility });
    }
    if (!estimates.length) return { pB:model.baseB, rawPB:model.baseB, families:[] };
    const total = estimates.reduce((sum,x)=>sum+x.weight,0);
    const rawPB = estimates.reduce((sum,x)=>sum+x.pB*x.weight,0)/total;
    const shrink = Math.min(0.75, 0.75 * model.observations / (model.observations + 30));
    return { pB:clampRate(model.baseB + shrink*(rawPB-model.baseB)), rawPB, families:estimates };
  }

  function selectWeights(model, parts) {
    const candidates = [];
    for (const expert of EXPERTS) {
      const part = parts[expert.id];
      const stats = model.expertStats[expert.id];
      if (!part.usable || stats.diffs.length < MIN_EXPERT_EVAL) continue;
      const score = summarizeDiffs(stats.diffs);
      if (score.lowerBound > 0) {
        const evidenceFactor = part.support / (part.support + 35);
        const reliability = Math.max(0, score.lowerBound);
        candidates.push({ id: expert.id, label: expert.label, pB: part.pB, support: part.support,
          validationN: score.n, improvement: score.mean, lowerBound: score.lowerBound,
          rawWeight: reliability * evidenceFactor });
      }
    }
    const total = candidates.reduce((s,x) => s + x.rawWeight, 0);
    const exploration = exploratoryEstimate(model, parts);
    if (!total) {
      return { pB:exploration.pB, candidates:[], evidenceWeight:0,
        exploratoryPB:exploration.pB, rawExploratoryPB:exploration.rawPB, families:exploration.families };
    }
    const normalized = candidates.map(x => ({ ...x, weight: x.rawWeight / total }));
    const specialistP = normalized.reduce((s,x) => s + x.weight * x.pB, 0);
    // Once specialists demonstrate prequential value, blend their forecast
    // with the always-on exploratory estimate; retain an explicit prior anchor.
    const validatedP = 0.35 * model.baseB + 0.65 * specialistP;
    const pB = 0.5 * validatedP + 0.5 * exploration.pB;
    return { pB:clampRate(pB), candidates:normalized, evidenceWeight:0.325,
      validatedPB:validatedP, exploratoryPB:exploration.pB,
      rawExploratoryPB:exploration.rawPB, families:exploration.families };
  }

  function assessSignal(model, features, parts, ensemble, validation) {
    const enough = validation.n >= MIN_ENSEMBLE_EVAL && validation.shoes >= 2;
    const beatsBaseline = enough && validation.lowerBound > 0 && validation.brierSkill > 0;
    const contextualIds = new Set(['streak', 'pattern', 'bigEye', 'smallRoad', 'cockroach',
      ...Array.from({ length: MARKOV_DEPTH }, (_, i) => `markov${i + 1}`)]);
    const contextualExperts = ensemble.candidates.filter(x => contextualIds.has(x.id));
    const currentSupport = contextualExperts.reduce((m,x) => Math.max(m, x.support), 0);
    const edge = ensemble.pB - model.baseB;
    const hasContextualEvidence = contextualExperts.length >= MIN_CONTEXTUAL_EXPERTS;
    const side = beatsBaseline && hasContextualEvidence && currentSupport >= MIN_CONTEXT_SUPPORT &&
      Math.abs(edge) >= MIN_SIGNAL_EDGE ? (edge > 0 ? 'B' : 'P') : null;
    let status = 'ยังไม่มีหลักฐานพอ';
    let detail = `ผลประเมิน ${validation.n}/${MIN_ENSEMBLE_EVAL} ตัวอย่าง จาก ${validation.shoes} ชู · ต้องมีข้อมูลประเมินจากอย่างน้อย 2 ชู โมเดลบริบทที่ผ่านเกณฑ์ และผลทดสอบเหนือฐานก่อนแสดงสัญญาณ`;
    if (validation.n >= MIN_ENSEMBLE_EVAL && !beatsBaseline) {
      status = 'ยังไม่พบข้อได้เปรียบ';
      detail = `ยังพิสูจน์ไม่ได้ว่าโมเดลดีกว่าฐานอ้างอิง · ค่าเฉลี่ยความต่าง log-loss ${validation.meanDiff.toFixed(4)} (ขอบล่างแบบเข้มงวด ${validation.lowerBound.toFixed(4)})`;
    } else if (beatsBaseline && !side) {
      status = 'โมเดลดีขึ้น แต่สัญญาณอ่อน';
      detail = !hasContextualEvidence || currentSupport < MIN_CONTEXT_SUPPORT
        ? 'ผลทดสอบรวมดีกว่าฐาน แต่บริบทปัจจุบันยังไม่มีตัวอย่างเฉพาะทางเพียงพอ'
        : 'ผลทดสอบย้อนหลังดีกว่าฐาน แต่ส่วนต่างจากฐานในบริบทนี้ยังไม่ถึงเกณฑ์';
    } else if (side) {
      status = 'ผ่านเกณฑ์เชิงหลักฐาน';
      detail = `ผ่าน walk-forward ${validation.n} ตัวอย่างจาก ${validation.shoes} ชูในชุดประเมิน · ยังคงเป็นการประเมินเชิงสถิติ ไม่ใช่คำรับประกัน`;
    }
    return { side, status, detail, currentSupport, edge, beatsBaseline };
  }

  function summarizeDrift(history, baseB, windowSize = DRIFT_WINDOW) {
    if (history.length < windowSize * 2) {
      return { ready:false, windowSize, recentN:Math.min(history.length, windowSize), priorN:Math.max(0, history.length-windowSize), brierDelta:null, logLossDelta:null, status:'ข้อมูลยังไม่พอ' };
    }
    const prior = summarizeEvaluation(history.slice(-(windowSize * 2), -windowSize), baseB);
    const recent = summarizeEvaluation(history.slice(-windowSize), baseB);
    const logLossDelta = recent.logLoss - prior.logLoss;
    const brierDelta = recent.brier - prior.brier;
    const status = logLossDelta > 0.03 && brierDelta > 0.005 ? 'ประสิทธิภาพลดลง' :
      logLossDelta < -0.03 && brierDelta < -0.005 ? 'ประสิทธิภาพดีขึ้น' : 'ค่อนข้างคงที่';
    return { ready:true, windowSize, priorN:prior.n, recentN:recent.n, priorLogLoss:prior.logLoss,
      recentLogLoss:recent.logLoss, priorBrier:prior.brier, recentBrier:recent.brier,
      brierDelta, logLossDelta, status };
  }

  function recordForecast(model, local, shoeStats, actual, evaluated = false, prepared = null) {
    const features = prepared?.features ?? getFeatures(local);
    const parts = prepared?.parts ?? Object.fromEntries(EXPERTS.map(e => [e.id, readExpert(model, local, features, e)]));
    const ensemble = prepared?.ensemble ?? selectWeights(model, parts);
    const validation = summarizeEvaluation(model.evalHistory, model.baseB);
    const gate = assessSignal(model, features, parts, ensemble, validation);
    const row = {
      shoeId: shoeStats?.id ?? null,
      shoeName: shoeStats?.name ?? 'ชู',
      handNumber: shoeStats?.hands ?? null,
      actual,
      pB: ensemble.pB,
      pP: 1 - ensemble.pB,
      lean: model.observations > 0 ? (ensemble.pB >= 0.5 ? 'B' : 'P') : null,
      signal: gate.side,
      status: gate.status,
      pattern: features.pattern.label,
      evaluated: Boolean(evaluated && actual !== 'T'),
      contextSupport: gate.currentSupport,
      evaluationShoesBeforeHand: validation.shoes
    };
    model.forecastHistory.push(row);
    if (model.forecastHistory.length > FORECAST_HISTORY_LIMIT) model.forecastHistory.shift();
  }

  function predict(model, local) {
    const features = getFeatures(local);
    const parts = Object.fromEntries(EXPERTS.map(e => [e.id, readExpert(model, local, features, e)]));
    const ensemble = selectWeights(model, parts);
    const history = model.evalHistory;
    const validation = summarizeEvaluation(history, model.baseB);
    const gate = assessSignal(model, features, parts, ensemble, validation);
    const { side, status, detail, currentSupport, edge } = gate;
    const drift = summarizeDrift(history, model.baseB);
    const expertRows = EXPERTS.map(e => {
      const part = parts[e.id], stats = model.expertStats[e.id], diff = summarizeDiffs(stats.diffs);
      return { id:e.id, label:e.label, pB:part.pB, support:part.support, minSupport:e.min,
        usable:part.usable, n:diff.n, improvement:diff.mean, lowerBound:diff.lowerBound,
        accuracy:stats.n ? stats.correct/stats.n : null,
        weight:ensemble.candidates.find(x => x.id === e.id)?.weight ?? 0 };
    }).sort((a,b) => b.weight - a.weight || b.support - a.support);
    const patternCount = getCounts(model.pattern, features.pattern.key);
    return {
      side, lean: model.observations > 0 ? (ensemble.pB >= 0.5 ? 'B' : 'P') : null, pB: ensemble.pB, pP: 1 - ensemble.pB, baseB: model.baseB,
      edge, status, detail, pattern: features.pattern, experts: expertRows,
      activeExperts: ensemble.candidates, currentSupport, drift,
      patternMemory: { key:features.pattern.key, samples:getN(patternCount), B:patternCount.B, P:patternCount.P },
      validation, forecastHistory: model.forecastHistory.slice(-80).reverse()
    };
  }

  function logLoss(p, y) {
    const q = Math.max(EPS, Math.min(1-EPS, p));
    return -(y * Math.log(q) + (1-y) * Math.log(1-q));
  }

  function summarizeEvaluation(history, baseB) {
    const n = history.length;
    const shoes = new Set(history.map(row=>row.shoeId).filter(Boolean)).size;
    if (!n) return { n:0, shoes:0, accuracy:null, brier:null, baseBrier:null, logLoss:null, baseLogLoss:null, meanDiff:0, se:Infinity, lowerBound:-Infinity, brierSkill:0 };
    let correct=0, brier=0, baseBrier=0, loss=0, baseLoss=0;
    const diffs=[];
    for (const row of history) {
      const y = row.actual === 'B' ? 1 : 0;
      if ((row.pB >= 0.5 ? 'B' : 'P') === row.actual) correct++;
      brier += (row.pB-y)**2;
      baseBrier += (baseB-y)**2;
      const modelLoss=logLoss(row.pB,y), baselineLoss=logLoss(baseB,y);
      loss += modelLoss; baseLoss += baselineLoss; diffs.push(baselineLoss-modelLoss);
    }
    const diff = summarizeDiffs(diffs);
    return { n, shoes, accuracy:correct/n, brier:brier/n, baseBrier:baseBrier/n,
      logLoss:loss/n, baseLogLoss:baseLoss/n, meanDiff:diff.mean, se:diff.se,
      lowerBound:diff.lowerBound, brierSkill:baseBrier ? 1-(brier/baseBrier) : 0 };
  }

  function updateCount(map, key, actual) {
    if (!key) return;
    const counts = map.get(key) ?? { B:0, P:0 };
    counts[actual]++;
    map.set(key, counts);
  }

  function updateModel(model, local, actual, shoeStats) {
    const features = getFeatures(local);
    const parts = Object.fromEntries(EXPERTS.map(e => [e.id, readExpert(model, local, features, e)]));
    const ensemble = selectWeights(model, parts);
    const pB = ensemble.pB;
    const y = actual === 'B' ? 1 : 0;
    const evalThis = model.observations >= WARMUP;
    recordForecast(model, local, shoeStats, actual, evalThis, { features, parts, ensemble });

    // Learn which specialists help only when they had real context support.
    for (const expert of EXPERTS) {
      const part = parts[expert.id];
      if (!part.usable) continue;
      const stats = model.expertStats[expert.id];
      const diff = logLoss(model.baseB,y) - logLoss(part.pB,y);
      stats.n++;
      stats.diffs.push(diff);
      if (stats.diffs.length > MAX_HISTORY) stats.diffs.shift();
      if ((part.pB >= 0.5 ? 'B':'P') === actual) stats.correct++;
      stats.brier += (part.pB-y)**2;
      stats.sumLogLoss += logLoss(part.pB,y);
    }

    if (evalThis) {
      const row = { pB, predictedSide:pB >= 0.5 ? 'B':'P', actual, shoeId:shoeStats?.id ?? null };
      model.evalHistory.push(row);
      if (model.evalHistory.length > MAX_HISTORY) model.evalHistory.shift();
      if (shoeStats) {
        shoeStats.evaluated++;
        if (row.predictedSide === actual) shoeStats.correct++;
      }
    }

    model.global[actual]++;
    for (let n=1;n<=MARKOV_DEPTH;n++) updateCount(model.ngram[n-1], features.ngrams[n], actual);
    model.recentOutcomes.push(actual);
    if (model.recentOutcomes.length > 128) model.recentOutcomes.shift();
    updateCount(model.streak, getFeaturesStreakKey(features), actual);
    updateCount(model.pattern, features.pattern.key, actual);
    for (const offset of ROAD_OFFSETS) updateCount(model.road[offset], features.roadKeys[offset], actual);
    model.observations++;
    if (shoeStats) shoeStats.decisive++;
  }

  function getFeaturesStreakKey(features) { return features.streakKey; }

  function createSession(shoes, baseB = 0.506825) {
    if (!Array.isArray(shoes)) throw new TypeError('shoes ต้องเป็น array');
    const model = newModel(baseB);
    // Imported IDs are external data: make them unique before using them as
    // validation-group keys, otherwise duplicate IDs can fake multi-shoe evidence.
    const usedIds = new Set();
    const normalized = shoes.map((s,i) => {
      const baseId = String(s?.id ?? `shoe-${i+1}`).trim() || `shoe-${i+1}`;
      let id = baseId, suffix = 2;
      while (usedIds.has(id)) id = `${baseId}~${suffix++}`;
      usedIds.add(id);
      return { id, name:String(s?.name ?? `ชู ${i+1}`), results:validateResults(s?.results ?? []) };
    });
    const perShoe=[];
    let currentLocal=newLocal();
    for (const shoe of normalized) {
      currentLocal=newLocal();
      const shoeStats={ id:shoe.id,name:shoe.name,hands:0,decisive:0,ties:0,evaluated:0,correct:0 };
      for (const result of shoe.results) {
        shoeStats.hands++;
        if (result === 'T') {
          shoeStats.ties++; recordForecast(model, currentLocal, shoeStats, 'T', false);
          currentLocal.bead.push(result); currentLocal.ties++; continue;
        }
        const firstDecisiveInShoe = shoeStats.decisive === 0;
        currentLocal.bead.push(result);
        updateModel(model,currentLocal,result,shoeStats);
        if (firstDecisiveInShoe) model.shoesSeen++;
        derivedUpdate(currentLocal,result);
      }
      perShoe.push(shoeStats);
    }
    if (!normalized.length) {
      const empty = {id:'shoe-1',name:'ชู 1',results:[]};
      normalized.push(empty);
      perShoe.push({id:empty.id,name:empty.name,hands:0,decisive:0,ties:0,evaluated:0,correct:0});
      model.shoesSeen=0;
    }
    return { model, shoes:normalized, activeShoeId:normalized[normalized.length-1].id, perShoe, local:currentLocal };
  }

  function appendResult(session, result) {
    const side=normalizeResult(result);
    const shoe=session.shoes[session.shoes.length-1];
    if (!shoe) throw new Error('ไม่พบชูปัจจุบัน');
    shoe.results.push(side);
    const stats=session.perShoe[session.perShoe.length-1];
    stats.hands++;
    if (side==='T') { recordForecast(session.model, session.local, stats, 'T', false); session.local.bead.push(side); stats.ties++; session.local.ties++; return side; }
    const firstDecisiveInShoe = stats.decisive === 0;
    session.local.bead.push(side);
    updateModel(session.model,session.local,side,stats);
    if (firstDecisiveInShoe) session.model.shoesSeen++;
    derivedUpdate(session.local,side);
    return side;
  }

  function startNewShoe(session, name) {
    const n=session.shoes.length+1;
    const shoe={id:`shoe-${Date.now()}-${n}`,name:name || `ชู ${n}`,results:[]};
    session.shoes.push(shoe);
    session.perShoe.push({id:shoe.id,name:shoe.name,hands:0,decisive:0,ties:0,evaluated:0,correct:0});
    session.local=newLocal();
    session.activeShoeId=shoe.id;
    return shoe;
  }

  function snapshot(session) {
    const forecast=predict(session.model,session.local);
    return { forecast, local:session.local, perShoe:session.perShoe,
      totalHands:session.shoes.reduce((a,s)=>a+s.results.length,0),
      totalDecisive:session.model.observations,
      totalTies:session.shoes.reduce((a,s)=>a+s.results.filter(x=>x==='T').length,0),
      shoes:session.shoes.length };
  }

  function buildBeadPlate(results) {
    const columns=[];
    for(let i=0;i<results.length;i+=6) columns.push(results.slice(i,i+6));
    return columns;
  }

  function buildBigRoad(results) {
    const grid=new Map(), columns=[], cells=[]; let last=null, run=null, pendingTies=0, ties=0;
    const occupied=(r,c)=>grid.has(`${r}:${c}`);
    for(let i=0;i<results.length;i++){
      const side=results[i];
      if(side==='T'){ties++; if(last)last.tieCount++; else pendingTies++; continue;}
      let row=0,col=0;
      if(!run || run.side!==side){col=run?run.visualStartCol+1:0;while(occupied(0,col))col++;
        run={index:columns.length,side,visualStartCol:col,length:0,cells:[]};columns.push(run);row=0;
      } else if(last.row<5 && !occupied(last.row+1,last.col)){row=last.row+1;col=last.col;}
      else {row=last.row;col=last.col+1;while(occupied(row,col))col++;}
      const cell={side,row,col,handIndex:i,tieCount:pendingTies,runIndex:run.index};pendingTies=0;
      run.length++;run.cells.push(cell);cells.push(cell);grid.set(`${row}:${col}`,cell);last=cell;
    }
    const maxCol=cells.reduce((m,c)=>Math.max(m,c.col),-1);
    const occupiedGrid=Array.from({length:6},(_,r)=>Array.from({length:maxCol+1},(_,c)=>grid.get(`${r}:${c}`)||null));
    return {columns,cells,occupied:occupiedGrid,maxCol,ties,pendingTies};
  }

  function importWorkspace(data) {
    const parsed=typeof data==='string'?JSON.parse(data):data;
    if(Array.isArray(parsed)) return [{id:'shoe-1',name:'ชู 1',results:validateResults(parsed)}];
    if(Array.isArray(parsed?.shoes)) {
      if (!parsed.shoes.length) throw new TypeError('workspace ไม่มีข้อมูลชู');
      return parsed.shoes.map((s,i)=>({id:String(s?.id??`shoe-${i+1}`),name:String(s?.name??`ชู ${i+1}`),results:validateResults(s?.results??[])}));
    }
    if(Array.isArray(parsed?.results)) return [{id:'shoe-1',name:'ชู 1 (นำเข้าจากเวอร์ชันเดิม)',results:validateResults(parsed.results)}];
    throw new TypeError('ไม่พบ shoes หรือ results ในไฟล์');
  }

  function parseCsvRows(text) {
    const source = String(text ?? '').replace(/^\uFEFF/, '');
    const first = source.split(/\r?\n/,1)[0] ?? '';
    let delimiter = ',';
    let best = -1;
    for (const candidate of [',',';','\t']) {
      let count=0, quoted=false;
      for (let i=0;i<first.length;i++) {
        if (first[i] === '"') {
          if (quoted && first[i+1] === '"') i++;
          else quoted=!quoted;
        } else if (!quoted && first[i]===candidate) count++;
      }
      if (count>best) { best=count; delimiter=candidate; }
    }
    const rows=[]; let row=[], field='', quoted=false;
    for (let i=0;i<source.length;i++) {
      const ch=source[i];
      if (ch==='"') {
        if (quoted && source[i+1]==='"') { field+='"'; i++; }
        else quoted=!quoted;
      } else if (!quoted && ch===delimiter) { row.push(field.trim()); field=''; }
      else if (!quoted && (ch==='\n'||ch==='\r')) {
        if (ch==='\r' && source[i+1]==='\n') i++;
        row.push(field.trim()); field='';
        if (row.some(cell=>cell!=='')) rows.push(row);
        row=[];
      } else field+=ch;
    }
    if (quoted) throw new TypeError('CSV มีเครื่องหมายอัญประกาศไม่ครบคู่');
    row.push(field.trim());
    if (row.some(cell=>cell!=='')) rows.push(row);
    return rows;
  }

  function importCsvWorkspace(csvText) {
    const rows=parseCsvRows(csvText);
    if (!rows.length) throw new TypeError('ไฟล์ CSV ไม่มีข้อมูล');
    const tokenOk = value => {
      try { normalizeResult(value); return true; } catch { return false; }
    };
    const header = rows[0].map(value=>value.trim().toLowerCase());
    const findCol = names => header.findIndex(value=>names.includes(value));
    const resultCol = findCol(['result','outcome','winner','side','ผล','ผลลัพธ์']);
    const shoeCol = findCol(['shoe','shoe_no','shoeno','table_shoe','ชู']);
    const shoeNameCol = findCol(['shoe_name','shoename','table_name','ชื่อชู','ชื่อโต๊ะ']);
    const handCol = findCol(['hand','hand_no','handno','round','ลำดับ','มือ']);
    const hasHeader = resultCol >= 0;
    const dataRows = hasHeader ? rows.slice(1) : rows;
    const groups = new Map();
    const add = (shoeKey, shoeName, handOrder, token, lineNo) => {
      if (!tokenOk(token)) throw new TypeError(`CSV บรรทัด ${lineNo}: ผลไม่ถูกต้อง "${token}"`);
      const key=String(shoeKey ?? shoeName ?? 1);
      if (!groups.has(key)) groups.set(key, { name:String(shoeName || `ชู ${key}`), items:[] });
      const group=groups.get(key);
      if (shoeName) group.name=String(shoeName);
      group.items.push({ handOrder:handOrder!==null && handOrder!==undefined && String(handOrder).trim()!=='' && Number.isFinite(Number(handOrder))?Number(handOrder):null, result:normalizeResult(token), lineNo });
    };
    if (hasHeader) {
      dataRows.forEach((r,i)=>{
        if (resultCol >= r.length) throw new TypeError(`CSV บรรทัด ${i+2}: ไม่มีคอลัมน์ผล`);
        add(shoeCol>=0?r[shoeCol]:(shoeNameCol>=0?r[shoeNameCol]:1), shoeNameCol>=0?r[shoeNameCol]:null, handCol>=0?r[handCol]:null, r[resultCol], i+2);
      });
    } else {
      const allTokens = dataRows.every(r=>r.every(tokenOk));
      if (allTokens) {
        for (let i=0;i<dataRows.length;i++) for (const token of dataRows[i]) add(1,null,null,token,i+1);
      } else {
        dataRows.forEach((r,i)=>{
          const token=r[r.length-1];
          const multiShoe=r.length>=3 && /^\d+$/.test(r[0]);
          const handOrder=r.length>=3?r[1]:null;
          add(multiShoe?r[0]:1,null,handOrder,token,i+1);
        });
      }
    }
    if (!groups.size) throw new TypeError('CSV ไม่มีผล P/B/T ที่นำเข้าได้');
    const entries=[...groups.entries()];
    return entries.map(([key,group],index)=>{
      const items=group.items;
      const allOrdered=items.every(item=>item.handOrder!==null);
      if (allOrdered) items.sort((a,b)=>a.handOrder-b.handOrder || a.lineNo-b.lineNo);
      return {id:`shoe-${index+1}`,name:group.name || `ชู ${key}`,results:items.map(item=>item.result)};
    });
  }

  function csvCell(value) {
    const text = String(value ?? '');
    return /[\",\r\n]/.test(text) ? `\"${text.replace(/\"/g,'\"\"')}\"` : text;
  }

  function exportWorkspaceCsv(shoes) {
    if (!Array.isArray(shoes)) throw new TypeError('shoes ต้องเป็น array');
    const rows = ['shoe,shoe_name,hand,result'];
    shoes.forEach((shoe, shoeIndex) => {
      const results = validateResults(shoe?.results ?? []);
      results.forEach((result, handIndex) => rows.push([
        shoeIndex + 1, csvCell(shoe?.name ?? `ชู ${shoeIndex+1}`), handIndex + 1, result
      ].join(',')));
    });
    return rows.join('\n');
  }

  function exportWorkspace(shoes, baseB) {
    if (!Array.isArray(shoes)) throw new TypeError('shoes ต้องเป็น array');
    return {app:'Baccarat Atlas Neural Lab',version:4,baseB:validateBaseRate(baseB),exportedAt:new Date().toISOString(),shoes:shoes.map(s=>({id:s.id,name:s.name,results:validateResults(s.results)}))};
  }

  const api={normalizeResult,validateResults,newLocal,newModel,createSession,appendResult,startNewShoe,snapshot,
    buildBeadPlate,buildBigRoad,detectPattern,importWorkspace,importCsvWorkspace,exportWorkspace,exportWorkspaceCsv,EXPERTS,summarizeDiffs,summarizeEvaluation,summarizeDrift,
    constants:{WARMUP,MIN_EXPERT_EVAL,MIN_CONTEXT_SUPPORT,MIN_ENSEMBLE_EVAL,MIN_CONTEXTUAL_EXPERTS,MIN_SIGNAL_EDGE,MAX_HISTORY,FORECAST_HISTORY_LIMIT,DRIFT_WINDOW,MARKOV_DEPTH,HAC_MAX_LAG}};
  root.AtlasEngine=api;
  if (typeof module!=='undefined' && module.exports) module.exports=api;
})(typeof globalThis!=='undefined'?globalThis:this);

