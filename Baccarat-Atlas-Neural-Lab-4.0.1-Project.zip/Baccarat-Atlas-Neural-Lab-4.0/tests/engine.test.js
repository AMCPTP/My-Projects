'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const E = require('../src/engine.js');

test('normalizes P/B/T and rejects invalid outcomes', () => {
  assert.deepEqual(E.validateResults(['player','B','tie']), ['P','B','T']);
  assert.throws(() => E.validateResults(['X']), /ผลไม่ถูกต้อง/);
});

test('records a pre-result score for every hand, including Tie, without training on Tie', () => {
  const session = E.createSession([{id:'s1',name:'ชูทดสอบ',results:[]}]);
  E.appendResult(session, 'B');
  E.appendResult(session, 'T');
  E.appendResult(session, 'P');
  assert.equal(session.model.forecastHistory.length, 3);
  assert.equal(session.model.forecastHistory[0].pB, 0.506825, 'first forecast must use prior only');
  assert.equal(session.model.forecastHistory[0].actual, 'B');
  assert.equal(session.model.forecastHistory[1].actual, 'T');
  assert.equal(session.model.forecastHistory[1].evaluated, false);
  assert.equal(session.model.observations, 2, 'Tie must not increment decisive learning count');
});

test('supports ten-hand sequence contexts and cross-shoe recent memory', () => {
  const model = E.newModel();
  assert.equal(model.ngram.length, 10);
  assert.equal(E.EXPERTS.length, 21);
  const session = E.createSession([
    {id:'s1',name:'ชู 1',results:['B','P','B','P','B','P']},
    {id:'s2',name:'ชู 2',results:['P','B','P','B','P','B']}
  ]);
  assert.equal(session.model.shoesSeen, 2);
  assert.equal(session.model.recentOutcomes.length, 12);
  assert.ok(E.EXPERTS.some(x => x.id === 'globalRecent64'));
  assert.ok(E.EXPERTS.some(x => x.id === 'markov10'));
});

test('detects a repeated three-hand cycle not covered by the fixed motifs', () => {
  const pattern = E.detectPattern(['B','P','B','B','P','B','B','P','B']);
  assert.equal(pattern.type, 'cycle');
  assert.equal(pattern.key, 'cycle:3:BPB');
});


test('accuracy uses the true 50% most-likely-side threshold, not the Banker baseline', () => {
  const metric = E.summarizeEvaluation([
    {pB:0.505, actual:'B'},
    {pB:0.495, actual:'P'}
  ], 0.506825);
  assert.equal(metric.accuracy, 1);
});

test('walk-forward validation and drift diagnostics are finite on generated data', () => {
  const shoes = [];
  let seed = 17;
  for (let s = 0; s < 3; s++) {
    const results = [];
    for (let i = 0; i < 100; i++) {
      seed = (seed * 48271) % 2147483647;
      results.push(seed % 2 ? 'B' : 'P');
    }
    shoes.push({id:`s${s}`,name:`ชู ${s+1}`,results});
  }
  const session = E.createSession(shoes);
  const forecast = E.snapshot(session).forecast;
  assert.equal(forecast.validation.n, 300 - E.constants.WARMUP);
  assert.equal(forecast.forecastHistory.length, 80);
  assert.equal(forecast.drift.ready, true);
  assert.ok(Number.isFinite(forecast.pB));
  assert.ok(Math.abs(forecast.pB + forecast.pP - 1) < 1e-12);
});

test('import accepts the prior Atlas AI 2.x multi-shoe export and replays chronologically', () => {
  const imported = E.importWorkspace({app:'Baccarat Atlas AI',version:2,shoes:[
    {id:'old-1',name:'โต๊ะ A',results:['B','P','T']},
    {id:'old-2',name:'โต๊ะ B',results:['P','B']}
  ]});
  assert.equal(imported.length, 2);
  assert.deepEqual(imported[0].results, ['B','P','T']);
  const session = E.createSession(imported);
  assert.equal(session.model.observations, 4);
  assert.equal(session.model.forecastHistory.length, 5);
});


test('does not let a later shoe influence forecasts made in an earlier shoe', () => {
  const first = Array.from({length:160}, (_,i) => i % 2 ? 'P':'B');
  const second = ['B','P','B'];
  const session = E.createSession([
    {id:'early',name:'ชูเก่า',results:first},
    {id:'later',name:'ชูใหม่',results:second}
  ]);
  const earlyRows = session.model.forecastHistory.filter(row => row.shoeId === 'early');
  assert.equal(earlyRows.length, 160);
  assert.ok(earlyRows.every(row => row.signal === null), 'one-shoe history cannot pass the two-shoe evidence gate');
  assert.equal(session.model.shoesSeen, 2);
});

test('incremental updates and chronological replay produce the same final next-hand score', () => {
  const shoes = [
    {id:'s1',name:'A',results:['B','P','B','B','P','T','P','B','P','B']},
    {id:'s2',name:'B',results:['P','P','B','P','B','T','B','P','B']}
  ];
  const replay = E.createSession(shoes);
  const incremental = E.createSession([{id:'s1',name:'A',results:[]}]);
  for (const x of shoes[0].results) E.appendResult(incremental, x);
  E.startNewShoe(incremental, 'B');
  for (const x of shoes[1].results) E.appendResult(incremental, x);
  const a = E.snapshot(replay).forecast;
  const b = E.snapshot(incremental).forecast;
  assert.ok(Math.abs(a.pB - b.pB) < 1e-12);
  assert.equal(a.validation.n, b.validation.n);
  assert.equal(replay.model.forecastHistory.length, incremental.model.forecastHistory.length);
});

test('forecast history is capped to prevent unbounded local storage growth', () => {
  const outcomes = Array.from({length: E.constants.FORECAST_HISTORY_LIMIT + 30}, (_,i) => i % 2 ? 'B':'P');
  const session = E.createSession([{id:'long',name:'long',results:outcomes}]);
  assert.equal(session.model.forecastHistory.length, E.constants.FORECAST_HISTORY_LIMIT);
});

test('exploratory scores learn immediately instead of staying frozen at the base rate', () => {
  const base = 0.506825;
  const banker = E.createSession([{id:'b',name:'B',results:['B']}]);
  const player = E.createSession([{id:'p',name:'P',results:['P']}]);
  const bScore = E.snapshot(banker).forecast.pB;
  const pScore = E.snapshot(player).forecast.pB;
  assert.ok(bScore > base, `one B should move the exploratory score above base, got ${bScore}`);
  assert.ok(pScore < base, `one P should move the exploratory score below base, got ${pScore}`);
  assert.ok(Math.abs(bScore-base) < 0.02, 'one observation must remain strongly shrunk toward the prior');
  assert.ok(Math.abs(pScore-base) < 0.02, 'one observation must remain strongly shrunk toward the prior');
  assert.equal(E.snapshot(banker).forecast.side, null, 'exploratory lean must not be mislabeled as a validated signal');
});

test('counts only shoes with decisive B/P outcomes, not Tie-only shoes', () => {
  const session = E.createSession([
    {id:'tie-only',name:'Tie only',results:['T','T']},
    {id:'with-bp',name:'With result',results:['T','B','P']},
    {id:'empty',name:'Empty',results:[]}
  ]);
  assert.equal(session.model.shoesSeen, 1);
  assert.equal(E.snapshot(session).forecast.validation.shoes, 0, 'no validation examples should exist before warm-up');
  assert.equal(session.perShoe.length, 3);
});

test('the first hand of a new shoe cannot use that shoe to satisfy the two-shoe evidence gate', () => {
  const first = Array.from({length:150}, (_,i)=>i%2?'P':'B');
  const session = E.createSession([
    {id:'old',name:'ชูเก่า',results:first},
    {id:'new',name:'ชูใหม่',results:['B','P']}
  ]);
  const newRows = session.model.forecastHistory.filter(row=>row.shoeId==='new');
  assert.equal(newRows[0].evaluationShoesBeforeHand, 1);
  assert.equal(newRows[1].evaluationShoesBeforeHand, 2);
  assert.equal(session.model.shoesSeen, 2);
});

test('an empty workspace creates a matching empty shoe and per-shoe stats row', () => {
  const session=E.createSession([]);
  assert.equal(session.shoes.length,1);
  assert.equal(session.perShoe.length,1);
  assert.equal(session.perShoe[0].hands,0);
});

test('CSV importer supports native multi-shoe, old hand/result, sequence rows and semicolon files', () => {
  const native=E.importCsvWorkspace('shoe,hand,result\n1,2,B\n1,1,P\n2,1,T');
  assert.equal(native.length,2);
  assert.deepEqual(native[0].results,['P','B'],'hand number should restore chronological order');
  assert.deepEqual(native[1].results,['T']);
  const old=E.importCsvWorkspace('hand,result\n1,B\n2,P\n3,T');
  assert.deepEqual(old[0].results,['B','P','T']);
  const sequence=E.importCsvWorkspace('P,B,T,P');
  assert.deepEqual(sequence[0].results,['P','B','T','P']);
  const semicolon=E.importCsvWorkspace('shoe;hand;result\n1;1;ผู้เล่น\n1;2;เจ้ามือ');
  assert.deepEqual(semicolon[0].results,['P','B']);
});

test('base-rate input is validated rather than allowing NaN to poison the model', () => {
  assert.throws(()=>E.newModel(NaN),/ฐานอ้างอิง Banker/);
  assert.throws(()=>E.createSession([{results:[]}],0.75),/ฐานอ้างอิง Banker/);
  assert.equal(E.newModel(0.52).baseB,0.52);
});

test('a genuine repeating sequence can pass the evidence pipeline while independent random data cannot', () => {
  const cycle='BBBBBBPPPPPP';
  const patterned=Array.from({length:3},(_,s)=>({id:`pattern-${s}`,name:`Pattern ${s}`,results:Array.from({length:300},(_,i)=>cycle[i%cycle.length])}));
  const patternForecast=E.snapshot(E.createSession(patterned)).forecast;
  assert.equal(patternForecast.validation.shoes,2,'rolling validation must include two independent shoes');
  assert.equal(patternForecast.side,'B','the controlled serial-dependence fixture should be detectable');
  assert.ok(patternForecast.validation.brierSkill>0.1);

  let seed=17;
  const random=Array.from({length:3},(_,s)=>({id:`random-${s}`,name:`Random ${s}`,results:Array.from({length:300},()=>{
    seed=(seed*48271)%2147483647;
    return seed>1073741823?'B':'P';
  })}));
  const randomForecast=E.snapshot(E.createSession(random)).forecast;
  assert.equal(randomForecast.validation.shoes,2);
  assert.equal(randomForecast.side,null,'random fixture must not be promoted to a validated signal');
  assert.ok(randomForecast.validation.brierSkill<0.02);
});

test('CSV import preserves quoted shoe names and restores hand order', () => {
  const csv='shoe,shoe_name,hand,result\n1,"โต๊ะ, ห้อง A",2,B\n1,"โต๊ะ, ห้อง A",1,P\n2,"โต๊ะ ""สำรอง""",1,T';
  const shoes=E.importCsvWorkspace(csv);
  assert.equal(shoes[0].name,'โต๊ะ, ห้อง A');
  assert.deepEqual(shoes[0].results,['P','B']);
  assert.equal(shoes[1].name,'โต๊ะ "สำรอง"');
  assert.deepEqual(shoes[1].results,['T']);
});

test('Bead Plate and Big Road preserve six-row layout and Tie attachment', () => {
  assert.deepEqual(E.buildBeadPlate(['B','P','T','B','P','B','T']),[
    ['B','P','T','B','P','B'],['T']
  ]);
  const road=E.buildBigRoad(['T','B','T','B','P','P','B','B','B','B','B','B','B']);
  assert.equal(road.cells[0].tieCount,2,'leading and attached Tie should be shown on first Big Road bead');
  assert.equal(road.cells[0].row,0);
  assert.equal(road.cells[4].side,'B');
  assert.equal(road.cells[4].row,0);
  assert.equal(road.cells[9].row,5);
  assert.equal(road.cells[10].row,5);
  assert.equal(road.cells[10].col,3,'the seventh same-side bead should turn onto the Dragon Tail');
});


test('duplicate imported shoe IDs are repaired before they can fake multi-shoe evidence', () => {
  const session=E.createSession([
    {id:'duplicate',name:'First',results:Array.from({length:150},(_,i)=>i%2?'P':'B')},
    {id:'duplicate',name:'Second',results:Array.from({length:150},(_,i)=>i%2?'B':'P')}
  ]);
  assert.notEqual(session.shoes[0].id,session.shoes[1].id);
  assert.equal(session.model.shoesSeen,2);
  assert.equal(E.snapshot(session).forecast.validation.shoes,2);
});

test('CSV export and import round-trip preserves shoe grouping, names, order and Tie', () => {
  const source=[
    {id:'a',name:'โต๊ะ, ห้อง A',results:['B','T','P']},
    {id:'b',name:'โต๊ะ \"สำรอง\"',results:['P','B']}
  ];
  const csv=E.exportWorkspaceCsv(source);
  const restored=E.importCsvWorkspace(csv);
  assert.equal(restored.length,2);
  assert.equal(restored[0].name,'โต๊ะ, ห้อง A');
  assert.deepEqual(restored[0].results,['B','T','P']);
  assert.equal(restored[1].name,'โต๊ะ \"สำรอง\"');
  assert.deepEqual(restored[1].results,['P','B']);
});

test('Big Road generated geometry never overlaps and preserves every decisive outcome', () => {
  let seed=12345;
  for(let trial=0;trial<30;trial++) {
    const results=Array.from({length:400},()=>{
      seed=(seed*48271)%2147483647;
      return seed%11===0?'T':seed%2?'B':'P';
    });
    const road=E.buildBigRoad(results);
    const positions=new Set();
    for(const cell of road.cells) {
      const key=`${cell.row}:${cell.col}`;
      assert.ok(cell.row>=0&&cell.row<6);
      assert.ok(cell.col>=0);
      assert.ok(!positions.has(key),`overlap at ${key}`);
      positions.add(key);
    }
    assert.equal(road.cells.length,results.filter(x=>x!=='T').length);
    assert.equal(road.ties,results.filter(x=>x==='T').length);
  }
});

test('CSV parser rejects an unterminated quoted field instead of silently shifting columns', () => {
  assert.throws(()=>E.importCsvWorkspace('shoe,shoe_name,hand,result\n1,"table,1,1,B'),/อัญประกาศไม่ครบคู่/);
});

test('an empty shoe starts neutral instead of showing a Banker or Player lean from the prior alone', () => {
  const forecast=E.snapshot(E.createSession([{id:'empty',name:'ชูว่าง',results:[]}])).forecast;
  assert.equal(forecast.lean,null);
  assert.equal(forecast.side,null);
  assert.equal(forecast.pB,0.506825);
  assert.equal(forecast.pP,1-0.506825);
});

test('JSON import rejects an empty shoes workspace instead of silently creating a blank shoe', () => {
  assert.throws(()=>E.importWorkspace({app:'Baccarat Atlas',version:4,shoes:[]}),/ไม่มีข้อมูลชู/);
});
