'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
const app = fs.readFileSync(path.join(root, 'src/app.js'), 'utf8');

test('all app DOM ids exist in the HTML', () => {
  const used = [...app.matchAll(/\$\('([^']+)'\)/g), ...app.matchAll(/set\('([^']+)'/g)].map(m => m[1]);
  const ids = new Set([...html.matchAll(/\bid="([^"]+)"/g)].map(m => m[1]));
  const missing = [...new Set(used)].filter(id => !ids.has(id));
  assert.deepEqual(missing, []);
});

test('UI has both manual entry and JSON/CSV import/export controls', () => {
  for (const id of ['addP','addB','addT','importBtn','exportJson','exportCsv','forecastRows','signalBadge','modelB','modelP','driftStatus']) {
    assert.match(html, new RegExp(`id="${id}"`));
  }
});

test('app migrates previous storage keys and uses a new v4 key', () => {
  assert.match(app, /baccaratAtlas\.neural-lab\.workspace\.v4/);
  assert.match(app, /baccaratAtlas\.ai\.workspace\.v2/);
  assert.match(app, /baccaratAtlas\.evidence\.workspace\.v3/);
});

test('application bootstraps without a browser using a minimal DOM contract', () => {
  const vm = require('node:vm');
  const E = require('../src/engine.js');
  const elements = new Map();
  const makeElement = id => ({
    id, textContent:'', innerHTML:'', value:'', disabled:false, className:'', style:{},
    classList:{ add(){}, remove(){}, toggle(){} },
    listeners:{}, addEventListener(type,handler){ this.listeners[type]=handler; }, click(){ this.listeners.click?.(); }, append(){}, remove(){},
    files:[]
  });
  const document = {
    getElementById(id){ if(!elements.has(id)) elements.set(id, makeElement(id)); return elements.get(id); },
    addEventListener(){},
    activeElement:null,
    body:makeElement('body')
  };
  const memory = new Map();
  const localStorage = { getItem:k=>memory.get(k)??null, setItem:(k,v)=>memory.set(k,String(v)) };
  const context = { window:{AtlasEngine:E}, document, localStorage, console,
    setTimeout:()=>0, clearTimeout(){}, URL, Blob, Date, JSON, Number, Math, Map, Set, Array, String, RegExp, Error, TypeError };
  vm.runInNewContext(app, context, {timeout:2000});
  assert.equal(elements.get('modelB').textContent, '50.7%');
  assert.equal(elements.get('modelP').textContent, '49.3%');
  assert.match(elements.get('signalBadge').textContent, /หลักฐาน/);
  assert.equal(memory.has('baccaratAtlas.neural-lab.workspace.v4'), true);
  elements.get('addP').click();
  assert.equal(String(elements.get('handCount').textContent), '1');
  assert.match(elements.get('forecastRows').innerHTML, /PLAYER|P/);
  elements.get('addT').click();
  assert.equal(String(elements.get('allHands').textContent), '2');
  assert.match(elements.get('forecastRows').innerHTML, />T</);
  elements.get('undo').click();
  assert.equal(String(elements.get('handCount').textContent), '1');
  elements.get('redo').click();
  assert.equal(String(elements.get('handCount').textContent), '2');
  elements.get('newShoe').click();
  assert.equal(String(elements.get('shoeCount').textContent), '2');
  assert.equal(String(elements.get('handCount').textContent), '0');
  assert.equal(String(elements.get('allHands').textContent), '2');
});

test('corrupt local storage is not silently overwritten during startup', () => {
  const vm = require('node:vm');
  const E = require('../src/engine.js');
  const elements = new Map();
  const makeElement = id => ({
    id,textContent:'',innerHTML:'',value:'',disabled:false,className:'',style:{},
    classList:{add(){},remove(){},toggle(){}},listeners:{},
    addEventListener(type,handler){this.listeners[type]=handler;},click(){this.listeners.click?.();},append(){},remove(){},files:[]
  });
  const document={getElementById(id){if(!elements.has(id))elements.set(id,makeElement(id));return elements.get(id);},addEventListener(){},activeElement:null,body:makeElement('body')};
  const writes=[];
  const localStorage={getItem(k){return k==='baccaratAtlas.neural-lab.workspace.v4'?'not-json':null;},setItem(k,v){writes.push([k,v]);}};
  const context={window:{AtlasEngine:E},document,localStorage,console,setTimeout:()=>0,clearTimeout(){},URL,Blob,Date,JSON,Number,Math,Map,Set,Array,String,RegExp,Error,TypeError};
  vm.runInNewContext(app,context,{timeout:2000});
  assert.equal(writes.length,0,'must not replace the original corrupt backup automatically');
  assert.match(elements.get('saveLabel').textContent,/ไม่เขียนทับข้อมูลเดิม/);
});

test('app remains usable when browser storage is unavailable and reports the condition', () => {
  const vm = require('node:vm');
  const E = require('../src/engine.js');
  const elements = new Map();
  const makeElement = id => ({
    id,textContent:'',innerHTML:'',value:'',disabled:false,className:'',style:{},
    classList:{add(){},remove(){},toggle(){}},listeners:{},
    addEventListener(type,handler){this.listeners[type]=handler;},click(){this.listeners.click?.();},append(){},remove(){},files:[]
  });
  const document={getElementById(id){if(!elements.has(id))elements.set(id,makeElement(id));return elements.get(id);},addEventListener(){},activeElement:null,body:makeElement('body')};
  const localStorage={getItem(){throw new Error('blocked');},setItem(){throw new Error('blocked');}};
  const context={window:{AtlasEngine:E},document,localStorage,console,setTimeout:()=>0,clearTimeout(){},URL,Blob,Date,JSON,Number,Math,Map,Set,Array,String,RegExp,Error,TypeError};
  vm.runInNewContext(app,context,{timeout:2000});
  assert.match(elements.get('saveLabel').textContent,/ไม่อนุญาตให้อ่าน/);
  elements.get('addB').click();
  assert.equal(String(elements.get('handCount').textContent),'1');
  assert.match(elements.get('saveLabel').textContent,/ไม่อนุญาตให้อ่าน/);
});

test('HTML table headers are structurally valid and DOM IDs are unique', () => {
  const headers=[...html.matchAll(/<thead>([\s\S]*?)<\/thead>/g)].map(m=>m[1]);
  assert.ok(headers.length>=3,'expected expert, ledger and shoe tables');
  for(const header of headers) {
    const row=[...header.matchAll(/<tr>([\s\S]*?)<\/tr>/g)][0]?.[1] ?? '';
    const stripped=row.replace(/<th(?:\s[^>]*)?>[\s\S]*?<\/th>/g,'').trim();
    assert.equal(stripped,'','thead rows must contain only complete th cells');
  }
  const allIds=[...html.matchAll(/\bid="([^"]+)"/g)].map(m=>m[1]);
  assert.equal(new Set(allIds).size,allIds.length,'HTML ids must be unique');
});

test('validated signal side takes visual priority over the separate probability lean', () => {
  assert.match(app, /const displayedSide=f\.side\|\|f\.lean/);
  assert.match(app, /token\.textContent=displayedSide\|\|'—'/);
});
