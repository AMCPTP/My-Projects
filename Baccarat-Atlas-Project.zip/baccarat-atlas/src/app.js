import {
  APP_NAME,
  buildAllRoads,
  forecastFromPattern,
  backtestPatternForecast,
  previewNextDerived,
  summarizeResults,
  exportSession,
  importSession,
  parseCsvResults,
  exportCsv,
  normalizeResult,
  validateResults
} from './engine.js';

const STORAGE_KEY = 'baccaratAtlas.session.v1';
const state = { results: [], redoStack: [], storageAvailable: true };
const $ = (id) => document.getElementById(id);
let toastTimer = null;

const PATTERNS = [
  { key: 'dragon', name: 'มังกร / ทางยาว', description: 'ฝั่งเดิมต่อเนื่องอย่างน้อย 3 ตา' },
  { key: 'pingpong', name: 'ปิงปอง', description: '6 ตาล่าสุดสลับ P/B ทุกตา' },
  { key: 'two-one', name: 'สองตัวหนึ่ง (2–1)', description: 'รูปแบบสองซ้ำหนึ่งเปลี่ยน วน 2 รอบ' },
  { key: 'one-two', name: 'หนึ่งตัวสอง (1–2)', description: 'หนึ่งฝั่งแล้วอีกฝั่งซ้ำ 2 ครั้ง วน 2 รอบ' },
  { key: 'two-two', name: 'สองต่อสอง (2–2)', description: 'รูปแบบสองต่อสอง วน 2 รอบ' },
  { key: 'random', name: 'กระจัดกระจาย', description: 'ไม่เข้าเกณฑ์รูปแบบข้างต้น' }
];

function showToast(message) {
  const node = $('toast');
  node.textContent = message;
  node.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => node.classList.remove('show'), 2400);
}

function saveState() {
  const status = $('saveStatus');
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify({ version: 1, results: state.results, redoStack: state.redoStack }));
    state.storageAvailable = true;
    status.innerHTML = '<span class="status-dot"></span> บันทึกอัตโนมัติแล้ว';
  } catch (error) {
    state.storageAvailable = false;
    status.textContent = 'ไม่สามารถบันทึกอัตโนมัติได้ — ส่งออก JSON เพื่อสำรองข้อมูล';
  }
}

function loadState() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return;
    const saved = JSON.parse(raw);
    if (saved?.version !== 1) throw new Error('unsupported saved version');
    state.results = validateResults(saved.results ?? []);
    state.redoStack = validateResults(saved.redoStack ?? []);
  } catch {
    state.results = [];
    state.redoStack = [];
    state.storageAvailable = false;
    try { localStorage.removeItem(STORAGE_KEY); } catch { /* storage can be blocked */ }
    $('saveStatus').textContent = 'ข้อมูลเดิมอ่านไม่ได้ จึงเริ่มชุดใหม่';
  }
}

function setText(id, value) {
  $(id).textContent = value;
}

function percent(value) {
  return `${value.toFixed(1)}%`;
}

function sideLabel(side) {
  return side === 'B' ? 'Banker · B' : side === 'P' ? 'Player · P' : side === 'T' ? 'Tie · T' : '—';
}

function renderStats() {
  const summary = summarizeResults(state.results);
  setText('statTotal', summary.total);
  setText('statP', summary.counts.P);
  setText('statB', summary.counts.B);
  setText('statT', summary.counts.T);
  setText('rateP', percent(summary.rates.P));
  setText('rateB', percent(summary.rates.B));
  setText('rateT', percent(summary.rates.T));
  setText('lastResult', summary.lastResult ? sideLabel(summary.lastResult) : '—');
  setText('streakValue', summary.currentStreak ? `${sideLabel(summary.currentStreak.side)} × ${summary.currentStreak.length}` : '—');
  setText('entryCount', `${summary.total} HAND${summary.total === 1 ? '' : 'S'}`);
  $('undo').disabled = state.results.length === 0;
  $('redo').disabled = state.redoStack.length === 0;
  $('reset').disabled = state.results.length === 0 && state.redoStack.length === 0;
}

function renderBeadPlate(beadPlate) {
  const board = $('beadBoard');
  if (!beadPlate.count) {
    board.className = 'bead-board empty-board';
    board.innerHTML = '<p>ยังไม่มีผลบันทึก</p>';
    return;
  }
  board.className = 'bead-board';
  const html = [];
  for (let col = 0; col < beadPlate.columns.length; col += 1) {
    for (let row = 0; row < 6; row += 1) {
      const result = beadPlate.columns[col][row];
      if (result) html.push(`<div class="bead-cell filled ${result}" title="ตาที่ ${col * 6 + row + 1}: ${sideLabel(result)}">${result}</div>`);
      else html.push('<div class="bead-cell" aria-hidden="true"></div>');
    }
  }
  board.innerHTML = html.join('');
}

function renderBigRoad(bigRoad) {
  const board = $('bigRoad');
  if (!bigRoad.cells.length && !bigRoad.pendingTies) {
    board.className = 'big-road empty-board';
    board.innerHTML = '<p>ยังไม่มีผล P/B สำหรับสร้าง Big Road</p>';
    setText('bigRoadFootnote', 'Tie จะไม่สร้างคอลัมน์ใน Big Road และจะไม่เปลี่ยนทางของผลก่อนหน้า');
    return;
  }

  const maxCol = Math.max(bigRoad.maxCol, bigRoad.pendingTies > 0 ? 0 : -1);
  board.className = 'big-road';
  const html = [];
  for (let col = 0; col <= maxCol; col += 1) {
    for (let row = 0; row < 6; row += 1) {
      const cell = bigRoad.occupied[row]?.[col] ?? null;
      if (!cell && bigRoad.pendingTies && !bigRoad.cells.length && row === 0 && col === 0) {
        html.push(`<div class="big-cell" title="Tie ก่อนผลตัดสิน ${bigRoad.pendingTies} ครั้ง"><span style="color:var(--tie);font-size:.55rem">T×${bigRoad.pendingTies}</span></div>`);
      } else if (!cell) {
        html.push('<div class="big-cell" aria-hidden="true"></div>');
      } else {
        const tieMark = cell.tieCount > 0 ? `<span class="tie-mark">${cell.tieCount > 1 ? cell.tieCount : 'T'}</span><span class="tie-slash"></span>` : '';
        html.push(`<div class="big-cell filled ${cell.side}" title="ตาที่ ${cell.handIndex + 1}: ${sideLabel(cell.side)}${cell.tieCount ? ` · Tie ${cell.tieCount} ครั้ง` : ''}">${cell.side}${tieMark}</div>`);
      }
    }
  }
  board.innerHTML = html.join('');
  const pendingNote = bigRoad.pendingTies ? ` · Tie ก่อนผลแรกที่รอผูก: ${bigRoad.pendingTies}` : '';
  setText('bigRoadFootnote', `จำนวน streak ${bigRoad.columns.length} คอลัมน์ · Tie ทั้งหมด ${bigRoad.totalTies} · Tie ไม่ถูกนับเป็นผลชี้ขาดในถนนอนุพันธ์${pendingNote}`);
}

function renderDerivedRoads(derivedRoads) {
  const target = $('derivedRoads');
  target.innerHTML = derivedRoads.map((road) => {
    const html = [];
    if (!road.marks.length) {
      html.push('<div class="empty-board"><p>ยังไม่ถึงจุดเริ่มของถนนนี้</p></div>');
    } else {
      for (let col = 0; col <= road.maxCol; col += 1) {
        for (let row = 0; row < 6; row += 1) {
          const cell = road.occupied[row]?.[col] ?? null;
          if (!cell) html.push('<div class="road-cell" aria-hidden="true"></div>');
          else {
            const symbol = road.key === 'cockroach' ? '<span class="slash-symbol">／</span>' : road.key === 'small' ? '<span class="solid-symbol"></span>' : '<span class="hollow-symbol"></span>';
            html.push(`<div class="road-cell filled ${cell.color}" title="${cell.color === 'R' ? 'แดง · รูปแบบซ้ำ' : 'น้ำเงิน · รูปแบบต่าง'}">${symbol}</div>`);
          }
        }
      }
    }
    const red = road.marks.filter((mark) => mark.color === 'R').length;
    const blue = road.marks.length - red;
    return `<article class="derived-card"><div class="derived-head"><div><strong>${road.name}</strong><div class="derived-sub">${road.description}</div></div><span class="road-count">${road.marks.length} MARKS</span></div><div class="road-grid">${html.join('')}</div><div class="derived-sub">แดง ${red} · น้ำเงิน ${blue}</div></article>`;
  }).join('');
}

function renderScenarios(results) {
  const target = $('scenarioPreview');
  const scenarios = ['B', 'P'].map((side) => ({ side, marks: previewNextDerived(results, side) }));
  target.innerHTML = scenarios.map((scenario) => {
    const titleClass = scenario.side === 'B' ? 'banker' : 'player';
    const title = scenario.side === 'B' ? 'ถ้าผลถัดไป = BANKER (B)' : 'ถ้าผลถัดไป = PLAYER (P)';
    const marks = scenario.marks.map((mark) => `<span class="scenario-mark"><i class="${mark.color ?? 'none'}"></i>${mark.name}: ${mark.color === 'R' ? 'แดง' : mark.color === 'B' ? 'น้ำเงิน' : 'ยังไม่เริ่ม'}</span>`).join('');
    return `<div class="scenario-col"><div class="scenario-title ${titleClass}">${title}</div><div class="scenario-marks">${marks}</div></div>`;
  }).join('');
}

function renderPattern(forecast) {
  const token = $('forecastToken');
  token.className = `forecast-token ${forecast.prediction === 'B' ? 'banker' : forecast.prediction === 'P' ? 'player' : 'neutral'}`;
  token.textContent = forecast.prediction ?? '—';
  setText('forecastTitle', forecast.prediction ? `ระบบฉายรูปแบบไปทาง ${sideLabel(forecast.prediction)}` : 'ยังไม่มีสัญญาณ P/B');
  setText('forecastDescription', forecast.description);
  setText('forecastPattern', `PATTERN: ${forecast.key.toUpperCase()}`);
  setText('forecastMeta', forecast.prediction ? 'การต่อรูปแบบตามกฎ · ไม่ใช่โอกาสชนะจริง' : 'ไม่บังคับเดาฝั่งเมื่อไม่พบรูปแบบ');
  const stateChip = $('signalState');
  stateChip.className = `state-chip ${forecast.prediction === 'B' ? 'state-banker' : forecast.prediction === 'P' ? 'state-player' : 'state-neutral'}`;
  stateChip.textContent = forecast.prediction ? 'พบรูปแบบ' : 'รอรูปแบบ';

  const cards = PATTERNS.map((item, index) => {
    const active = item.key === forecast.key;
    return `<div class="pattern-item ${active ? 'active' : ''}"><span class="pattern-index">0${index + 1}</span><span class="pattern-name">${item.name}</span><span class="pattern-desc">${item.description}</span><span class="pattern-status">${active ? 'ตรวจพบ' : 'ไม่ตรงเกณฑ์'}</span></div>`;
  }).join('');
  $('patternCards').innerHTML = cards;
  setText('currentPattern', forecast.name);
  setText('currentProjection', forecast.prediction ? sideLabel(forecast.prediction) : 'ไม่มี');
}

function renderSequence(results) {
  const decisive = results.filter((result) => result !== 'T').slice(-12);
  setText('recentCount', `${decisive.length} ผล`);
  $('recentSequence').innerHTML = decisive.length
    ? decisive.map((result) => `<span class="sequence-token ${result}" title="${sideLabel(result)}">${result}</span>`).join('')
    : '<span class="muted">ยังไม่มีข้อมูล</span>';
}

function renderBacktest(results) {
  const test = backtestPatternForecast(results);
  setText('backtestRate', test.accuracy === null ? '—' : percent(test.accuracy));
  setText('backtestSignals', test.signals);
  setText('backtestCorrect', test.correct);
  setText('backtestWrong', test.incorrect);
  if (test.signals === 0) setText('backtestNote', 'ยังไม่มีสัญญาณในอดีตเพียงพอสำหรับคำนวณค่า');
  else if (test.signals < 20) setText('backtestNote', `มีตัวอย่างเพียง ${test.signals} สัญญาณ · ค่านี้ผันผวนสูงและไม่ใช่ตัวแทนความน่าจะเป็นในอนาคต`);
  else setText('backtestNote', `ตรวจ ${test.signals} สัญญาณย้อนหลังแบบ walk-forward · ค่านี้เป็นผลเฉพาะชุดข้อมูล ไม่รับประกันผลรอบถัดไป`);

  const summary = summarizeResults(results);
  setText('recentBalance', `${summary.recentCounts.B} B / ${summary.recentCounts.P} P`);
}

function render() {
  const roads = buildAllRoads(state.results);
  const forecast = forecastFromPattern(state.results);
  renderStats();
  renderBeadPlate(roads.beadPlate);
  renderBigRoad(roads.bigRoad);
  renderDerivedRoads(roads.derivedRoads);
  renderScenarios(state.results);
  renderPattern(forecast);
  renderSequence(state.results);
  renderBacktest(state.results);
  saveState();
}

function addResult(side) {
  state.results.push(normalizeResult(side));
  state.redoStack = [];
  render();
  showToast(`บันทึก ${sideLabel(side)} แล้ว`);
}

function undo() {
  if (!state.results.length) return;
  state.redoStack.push(state.results.pop());
  render();
  showToast('ย้อนกลับผลล่าสุดแล้ว');
}

function redo() {
  if (!state.redoStack.length) return;
  state.results.push(state.redoStack.pop());
  render();
  showToast('ทำซ้ำผลที่ย้อนกลับแล้ว');
}

function reset() {
  if (!state.results.length && !state.redoStack.length) return;
  const confirmed = window.confirm('ต้องการรีเซ็ตประวัติทั้งหมดของชุดนี้หรือไม่? การกระทำนี้ไม่สามารถย้อนกลับได้');
  if (!confirmed) return;
  state.results = [];
  state.redoStack = [];
  render();
  showToast('รีเซ็ตชุดข้อมูลแล้ว');
}

function downloadFile(filename, content, mimeType) {
  const blob = new Blob([content], { type: `${mimeType};charset=utf-8` });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = filename;
  document.body.append(anchor);
  anchor.click();
  anchor.remove();
  URL.revokeObjectURL(url);
}

function timestampName(extension) {
  const now = new Date();
  const pad = (number) => String(number).padStart(2, '0');
  const stamp = `${now.getFullYear()}${pad(now.getMonth() + 1)}${pad(now.getDate())}-${pad(now.getHours())}${pad(now.getMinutes())}`;
  return `baccarat-atlas-${stamp}.${extension}`;
}

function exportJson() {
  downloadFile(timestampName('json'), JSON.stringify(exportSession(state.results), null, 2), 'application/json');
  showToast('ส่งออกไฟล์ JSON แล้ว');
}

function exportCsvFile() {
  downloadFile(timestampName('csv'), exportCsv(state.results), 'text/csv');
  showToast('ส่งออกไฟล์ CSV แล้ว');
}

async function importFile(file) {
  if (!file) return;
  try {
    const content = await file.text();
    const isCsv = file.name.toLowerCase().endsWith('.csv') || file.type.includes('csv');
    const imported = isCsv ? parseCsvResults(content) : importSession(content);
    if (state.results.length && !window.confirm(`นำเข้าข้อมูล ${imported.length} ตา และแทนที่ข้อมูลเดิม ${state.results.length} ตา ใช่หรือไม่?`)) return;
    state.results = imported;
    state.redoStack = [];
    render();
    setText('dataStatus', `นำเข้าสำเร็จ ${imported.length} ผลจาก ${file.name}`);
    showToast(`นำเข้าข้อมูล ${imported.length} ผลแล้ว`);
  } catch (error) {
    setText('dataStatus', `นำเข้าไม่สำเร็จ: ${error.message}`);
    showToast(`ไฟล์ไม่ถูกต้อง: ${error.message}`);
  } finally {
    $('importFile').value = '';
  }
}

function handleKeyboard(event) {
  const active = document.activeElement;
  const editing = active && (['INPUT', 'TEXTAREA', 'SELECT'].includes(active.tagName) || active.isContentEditable);
  if (editing || event.altKey || event.metaKey) return;
  const key = event.key.toLowerCase();
  if ((event.ctrlKey || event.shiftKey) && key === 'z') {
    event.preventDefault();
    if (event.shiftKey) redo(); else undo();
  } else if ((event.ctrlKey || event.metaKey) && key === 'y') {
    event.preventDefault(); redo();
  } else if (!event.ctrlKey && !event.shiftKey) {
    if (key === 'p') addResult('P');
    if (key === 'b') addResult('B');
    if (key === 't') addResult('T');
  }
}

function bindEvents() {
  $('addP').addEventListener('click', () => addResult('P'));
  $('addB').addEventListener('click', () => addResult('B'));
  $('addT').addEventListener('click', () => addResult('T'));
  $('undo').addEventListener('click', undo);
  $('redo').addEventListener('click', redo);
  $('reset').addEventListener('click', reset);
  $('exportJson').addEventListener('click', exportJson);
  $('exportCsv').addEventListener('click', exportCsvFile);
  $('importButton').addEventListener('click', () => $('importFile').click());
  $('importFile').addEventListener('change', (event) => importFile(event.target.files?.[0]));
  document.addEventListener('keydown', handleKeyboard);
}

loadState();
bindEvents();
render();
