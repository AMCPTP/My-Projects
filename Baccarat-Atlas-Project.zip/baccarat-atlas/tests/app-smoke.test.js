import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import vm from 'node:vm';
import * as engine from '../src/engine.js';

class FakeElement {
  constructor(id = '') {
    this.id = id;
    this._textContent = '';
    Object.defineProperty(this, 'textContent', { get: () => this._textContent, set: (value) => { this._textContent = String(value ?? ''); } });
    this.innerHTML = '';
    this.className = '';
    this.classList = { add: () => {}, remove: () => {} };
    this.disabled = false;
    this.value = '';
    this.files = [];
    this.listeners = new Map();
  }
  addEventListener(type, callback) {
    const entries = this.listeners.get(type) ?? [];
    entries.push(callback);
    this.listeners.set(type, entries);
  }
  dispatch(type, event = {}) {
    for (const callback of this.listeners.get(type) ?? []) callback({ target: this, preventDefault() {}, ...event });
  }
  click() { this.dispatch('click'); }
  remove() {}
  append() {}
}

async function mountApp() {
  const appSource = (await readFile(new URL('../src/app.js', import.meta.url), 'utf8'))
    .replace(/^import\s*\{[\s\S]*?\}\s*from\s*['"]\.\/engine\.js['"];\s*/m, '');
  const elements = new Map();
  const documentListeners = new Map();
  const storage = new Map();
  const document = {
    activeElement: null,
    body: new FakeElement('body'),
    getElementById(id) {
      if (!elements.has(id)) elements.set(id, new FakeElement(id));
      return elements.get(id);
    },
    createElement(tag) { return new FakeElement(tag); },
    addEventListener(type, callback) {
      const entries = documentListeners.get(type) ?? [];
      entries.push(callback);
      documentListeners.set(type, entries);
    },
    dispatch(type, event = {}) {
      for (const callback of documentListeners.get(type) ?? []) callback({ preventDefault() {}, ...event });
    }
  };
  const localStorage = {
    getItem(key) { return storage.has(key) ? storage.get(key) : null; },
    setItem(key, value) { storage.set(key, String(value)); },
    removeItem(key) { storage.delete(key); }
  };
  const context = {
    ...engine,
    document,
    localStorage,
    window: { confirm: () => true },
    setTimeout: () => 1,
    clearTimeout: () => {},
    console,
    Blob,
    URL: { createObjectURL: () => 'blob:test', revokeObjectURL: () => {} }
  };
  vm.runInNewContext(appSource, context, { filename: 'app.js' });
  return { elements, document, storage };
}

test('UI smoke test: buttons, undo, redo, keyboard shortcuts and reset update the view', async () => {
  const { elements, document, storage } = await mountApp();
  const el = (id) => elements.get(id);
  assert.equal(el('statTotal').textContent, '0');

  el('addP').click();
  el('addB').click();
  el('addT').click();
  assert.equal(el('statTotal').textContent, '3');
  assert.equal(el('statP').textContent, '1');
  assert.equal(el('statB').textContent, '1');
  assert.equal(el('statT').textContent, '1');
  assert.match(el('beadBoard').innerHTML, /P/);
  assert.match(el('beadBoard').innerHTML, /B/);
  assert.match(el('beadBoard').innerHTML, /T/);
  assert.ok(storage.size > 0, 'session was saved to localStorage');

  el('undo').click();
  assert.equal(el('statTotal').textContent, '2');
  el('redo').click();
  assert.equal(el('statTotal').textContent, '3');

  document.dispatch('keydown', { key: 'p', ctrlKey: false, shiftKey: false, altKey: false, metaKey: false });
  assert.equal(el('statTotal').textContent, '4');
  document.dispatch('keydown', { key: 'z', ctrlKey: true, shiftKey: false, altKey: false, metaKey: false });
  assert.equal(el('statTotal').textContent, '3');

  el('reset').click();
  assert.equal(el('statTotal').textContent, '0');
  assert.match(el('beadBoard').innerHTML, /ยังไม่มีผลบันทึก/);
});

test('standalone build boots without module imports and accepts a result', async () => {
  const standalone = await readFile(new URL('../dist/Baccarat-Atlas.html', import.meta.url), 'utf8');
  const script = standalone.match(/<script>([\s\S]*?)<\/script>/)?.[1];
  assert.ok(script, 'standalone HTML contains an inline application script');
  const elements = new Map();
  const storage = new Map();
  const document = {
    activeElement: null,
    body: new FakeElement('body'),
    getElementById(id) {
      if (!elements.has(id)) elements.set(id, new FakeElement(id));
      return elements.get(id);
    },
    createElement(tag) { return new FakeElement(tag); },
    addEventListener() {}
  };
  const localStorage = {
    getItem(key) { return storage.get(key) ?? null; },
    setItem(key, value) { storage.set(key, String(value)); },
    removeItem(key) { storage.delete(key); }
  };
  vm.runInNewContext(script, {
    document,
    localStorage,
    window: { confirm: () => true },
    setTimeout: () => 1,
    clearTimeout: () => {},
    console,
    Blob,
    URL: { createObjectURL: () => 'blob:test', revokeObjectURL: () => {} }
  }, { filename: 'Baccarat-Atlas.html' });
  elements.get('addB').click();
  assert.equal(elements.get('statTotal').textContent, '1');
  assert.match(elements.get('bigRoad').innerHTML, /filled B/);
  assert.ok(storage.size > 0);
});
