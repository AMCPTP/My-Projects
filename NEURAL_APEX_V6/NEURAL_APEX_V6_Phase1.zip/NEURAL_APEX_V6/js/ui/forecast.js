export function renderForecast(){}
