export function renderStatistics(){}
