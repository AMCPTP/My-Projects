NEXUS ARC V10.3.0 — Evidence-First Adaptive Intelligence
========================================================

WHAT V10.3 IS
-------------
V10.3 is the full release line built on the supplied V9 bundle. The legacy V5–V9 modules remain packaged for compatibility, while a separate V10.3 analysis and prospective-evidence workflow is now available in the main dashboard and server API.

Release milestones delivered:
- V10.0 FOUNDATION: dedicated Python analysis engine, strict P/B parsing, sequence fingerprints, context/window comparison, separate V10 data directory, server API routes.
- V10.1 INTELLIGENCE: base-rate, Markov-1, and support-shrunken suffix diagnostics; context disagreement and exploratory change-point scan. These are descriptive/experimental lenses, not independently validated experts.
- V10.2 VALIDATION: prefix-only chronological walk-forward comparison against uniform 0.5 baseline; Log Loss, Brier Score, directional coverage/accuracy, five-bin Expected Calibration Error (ECE), and explicitly retrospective reporting.
- V10.3 RELEASE GATE: integrated dashboard panel; server-side append-only SHA-256 hash-chained prospective ledger; idempotent freeze requests; session binding; exact-prefix-plus-one-outcome resolve rule; cancel-without-score; integrity/lifecycle write blocking; automatic promotion disabled.

WINDOWS INSTALL / RUN
---------------------
1. Extract the release ZIP to a folder where the current user can write files.
2. Install Python 3.11+.
3. In PowerShell or Command Prompt, run:
      py -3 -m pip install -r requirements.txt
4. Double-click start_nexus_arc_v10.bat.
5. The launcher checks BOTH /api/health version=10.3.0 and dashboard=NEXUS_ARC_V10_ANALYSIS_DESK.html before opening the browser. It does not kill a process that cannot be identified as a NEXUS server.

Command-line start:
      py -3 -m uvicorn nexus_arc_v9_server:app --host 127.0.0.1 --port 8787
Open http://127.0.0.1:8787/ . To use a custom port, set NEXUS_PORT in .env before starting with the launcher. Keep the service bound to localhost; do not expose it publicly without appropriate authentication and deployment controls.

HOW TO USE V10.3
----------------
1. Paste the latest complete P/B history into the existing P/B sequence field in the dashboard. Do not flatten Tie events into P or B; the V10 input schema is intentionally P/B-only.
2. Click “วิเคราะห์ V10.3”. Review windows, transitions, model disagreement, context flags and walk-forward metrics. All sequence-only estimates remain exploratory and uncalibrated.
3. For prospective evaluation, enter a stable Shoe/Session ID and click “ล็อกก่อนผลจริง (WAIT)” BEFORE recording the next outcome.
4. After exactly one new P/B outcome is appended to the original frozen prefix, click “Resolve ผลใหม่ 1 ผล”. Resolve is rejected for edited history, skipped outcomes, multiple new outcomes or a different session ID.
5. Use the ledger status / export report for auditing. Cancellation closes a pending record without scoring it. The server blocks new writes if the hash chain or forecast lifecycle is invalid.

V10.3 API
----------
- POST /api/v10/analysis                 Analyze a P/B sequence; default action is WAIT.
- GET  /api/v10/status                   Version, ledger integrity, counts and write gate.
- GET  /api/v10/ledger/verify            Verify the stored hash chain and lifecycle projection.
- GET  /api/v10/ledger                   Read events and a forecast projection.
- POST /api/v10/forecasts/freeze         Freeze a prefix before the claimed next outcome.
- POST /api/v10/forecasts/{id}/resolve   Resolve only prefix + exactly one P/B outcome.
- POST /api/v10/forecasts/{id}/cancel    Cancel a pending forecast without scoring.
- GET  /api/health and GET /api/meta     Release/health discovery; V10 endpoints are advertised.

DATA AND INTEGRITY
------------------
- V10 data is stored separately in ./nexus_v10_data (or NEXUS_V10_DATA_DIR). It is not mixed with ./nexus_v9_data. Existing V9/legacy data is not automatically migrated into V10.
- The V10 prospective ledger is an append-only event array with sequence, previous hash and SHA-256 event hash. Tampering with retained prior events causes verification to fail and write access to close. The application does not silently replace corrupted ledger contents.
- The hash chain does NOT independently attest the physical outcome, source truth, browser/operator identity or trusted wall-clock time. A human-entered result can still be wrong.
- Browser interface values are not the record of authority for V10 prospective forecasts; the server ledger is the source of event history. Export/backup the data directory using normal backup procedures.
- A request id makes freeze submissions idempotent when retried with the same ID and same payload. Use a unique client_event_id for every new intended forecast.

ANALYSIS LIMITATIONS
--------------------
- The estimate called exploratory_ensemble is a fixed diagnostic blend of smoothed base rate, first-order conditional frequency and a support-shrunken suffix estimate. It is NOT a calibrated next-hand probability.
- The change-point scanner chooses the largest difference among multiple possible split points; it does not calculate a corrected significance result and its flag is only a screening cue.
- Walk-forward validation is a chronological retrospective replay. Rows in a single shoe/sequence are dependent, so the report is not proof of prospective edge. The ECE bins can be noisy for small samples.
- V10 intentionally keeps live_action=WAIT, does not provide betting advice, does not claim expected value/profitability, and never auto-promotes a model.
- P/B-only history does not reveal remaining-card composition. Tie handling requires a distinct schema and explicit rules; this build rejects T rather than silently flattening it.
- Server timestamps and hash chaining improve auditability but do not replace independent outcome verification or trusted timestamping.

TESTS
-----
Windows quick suite:
      run_nexus_arc_v10_3_tests.bat
Manual tests:
      py -3 -m py_compile nexus_arc_v9_server.py nexus_arc_v10_intelligence.py
      py -3 -m unittest -v test_nexus_arc_v10_intelligence.py
      py -3 -m unittest -v test_nexus_arc_v9_server_regression.py
      node --check nexus_arc_v9_analysis_engine.js
      node test_nexus_arc_v10_ui_integration.js
      node test_nexus_arc_v9_analysis_engine.js
      node test_nexus_arc_v9_ui_integration.js
      node test_nexus_arc_v5_9_5_pattern_engine.js
      node test_nexus_arc_v5_10_1_rapid_analyst_engine.js
      node test_nexus_arc_v6_3_validation_engine.js
      node test_nexus_arc_v7_diagnostics_engine.js

The regression suite validates API behavior and simulated UI invariants. A successful automated run is not equivalent to testing in a real target Windows browser. Before operational use, verify the browser flow on the intended machine and run a prospective study over independent sessions. No such independent long-running study is included in this release.

FILE MAP
--------
- NEXUS_ARC_V10_ANALYSIS_DESK.html: active V10.3 dashboard.
- nexus_arc_v9_server.py: local FastAPI gateway; kept under its legacy module filename for safe compatibility with the prior launcher and imports.
- nexus_arc_v10_intelligence.py: V10.3 sequence analysis, metrics, hash chain and forecast projection.
- test_nexus_arc_v10_intelligence.py: V10-specific unit + API regression suite.
- launch_nexus_arc_v10.ps1 / start_nexus_arc_v10.bat: checked Windows launcher.
- Files named V5–V9 are retained legacy components, compatibility tests, or historical audit records. They are not all active V10 analytical models.

SECURITY
--------
- Never include secrets in screenshots, reports or archives. Do not distribute a real .env.
- Default server binding is localhost-only. Browser-changing API requests reject unexpected Host/Origin combinations.
- Keep the V10 data directory backed up and restrict it to the intended Windows user.
