NOTE: This is the historical V9 guide. For the current V10.3 release, follow README_NEXUS_ARC_V10_3.txt.

NEXUS ARC V9 — Adaptive Pattern Intelligence & Forecast Audit
============================================================

วัตถุประสงค์
------------
V9 เป็นรุ่นที่รวมการวิเคราะห์ลำดับ P/B 12 กลุ่ม การเปรียบเทียบย้อนหลังหลายขนาด การตรวจความเปราะบาง/ความขัดแย้ง การประเมินแบบ walk-forward และการบันทึก shadow forecast ก่อนเห็นผลจริงเข้าด้วยกัน โดยยึดหลักเดิมว่าให้ข้อมูลจริงเป็นตัวตัดสิน ไม่เลื่อนโมเดลอัตโนมัติ และไม่เรียกรูปแบบย้อนหลังว่าเป็นความสามารถทำนายจนกว่าจะมีหลักฐานอิสระ

การเริ่มใช้งานบน Windows
------------------------
1. แตกไฟล์ NEXUS_ARC_V9_RELEASE_BUNDLE.zip ลงในโฟลเดอร์ที่เขียนไฟล์ได้
2. ติดตั้ง Python 3.11 หรือใหม่กว่า และติดตั้ง dependencies:
      py -3 -m pip install -r requirements.txt
3. ตรวจ .env.example แล้วคัดลอกเป็น .env ได้หากต้องการตั้งค่า NEXUS_PORT หรือ NEXUS_DATA_DIR เอง
4. ดับเบิลคลิก start_nexus_arc_v9.bat
5. Launcher จะตรวจ /api/health ให้ตรงทั้ง version=9.0.1 และ dashboard=NEXUS_ARC_V9_ANALYSIS_DESK.html ก่อนเปิดเบราว์เซอร์ ถ้าพอร์ตถูกโปรแกรมที่ไม่ใช่ NEXUS ใช้งานอยู่ จะไม่ฆ่า process นั้นโดยอัตโนมัติ

เริ่มแบบ command line (Windows)
-------------------------------
    py -3 -m pip install -r requirements.txt
    py -3 nexus_arc_v9_server.py
เปิด http://127.0.0.1:8787/ (หรือพอร์ตที่ตั้งไว้) ห้ามเปิด gateway นี้ออกสู่อินเทอร์เน็ตสาธารณะโดยไม่มีระบบยืนยันตัวตนที่เหมาะสม

หลักการใช้งาน
-------------
- ป้อน P/B ตามลำดับจริง แล้วกด Run V9 Analysis
- อ่านทะเบียน 12 กลุ่มพร้อม evidence, counter-evidence, support และ limits; กลุ่มที่เกิดร่วมกันไม่จำเป็นต้องบังคับให้เหลือกลุ่มเดียว
- Shadow forecast เป็นผลทดลองเท่านั้น; live_action ถูกกำหนดให้ WAIT จนกว่าจะมีหลักฐาน prospective ที่ผ่านเกณฑ์
- สำหรับ continuous forecast: ระบุ session/shoe ID, ล็อก forecast ก่อนผลใหม่, เพิ่มผลจริงเพียงหนึ่งผล แล้ว Resolve
- ถ้าแก้/แทนประวัติระหว่างมี forecast ค้าง ระบบจะปฏิเสธการ resolve; ยกเลิก forecast ค้างได้โดยไม่คิดคะแนน
- Local browser ledger อยู่ใน localStorage และแก้ไขได้เอง จึงไม่ใช่หลักฐานที่ server ลงนามหรือหลักฐานอิสระ ให้ Export สำรองเป็นระยะ และใช้ V6.3 server evidence ledger สำหรับการตรวจสอบฝั่งเซิร์ฟเวอร์
- ตรวจ Brain JSON ในส่วน Brain Integrity ก่อนนำเข้า; ไฟล์ checksum ถูกต้องก็ยังอาจไม่สอดคล้องกันได้ หากพบ critical conflict ห้ามนำเข้าและห้ามแก้ไขเงียบ ๆ
- โฟลเดอร์เก็บข้อมูลใหม่คือ ./nexus_v9_data (หรือ NEXUS_DATA_DIR) แยกจากข้อมูลเวอร์ชันเก่า ป้องกันการนำ ledger เก่ามาใช้โดยไม่ตั้งใจ

ทดสอบ
-----
ต้องมี Node.js 20+ สำหรับชุด JavaScript tests และ Python dependencies ติดตั้งแล้วสำหรับ server regression.
Windows:
    run_v9_tests.bat
หรือเรียกคำสั่งแยก:
    node --check nexus_arc_v9_analysis_engine.js
    node test_nexus_arc_v9_analysis_engine.js
    node test_nexus_arc_v9_ui_integration.js
    node test_nexus_arc_v5_9_5_pattern_engine.js
    node test_nexus_arc_v5_10_1_rapid_analyst_engine.js
    node test_nexus_arc_v6_3_validation_engine.js
    node test_nexus_arc_v7_diagnostics_engine.js
    py -3 -m unittest -v test_nexus_arc_v9_server_regression.py

สิ่งที่รวมไว้ใน V9
-----------------
Phase 0: checksum + Brain case/history reconciliation, conflict blocking, duplicate prevention, token validation
Phase 1: 12-group multi-label pattern registry with evidence/counter-evidence/support/limits
Phase 2: conservative blend of smoothed base/transition/suffix signals with shrinkage and explicit support limits; the 12-pattern registry is diagnostic-only and does not yet route forecast weights; no automatic promotion
Phase 3: prefix-only walk-forward, baseline metrics, log loss/Brier, null-model checks, fragility diagnostics
Phase 4: pre-outcome forecast freeze, exact-one-result resolution, cancellation without score, session ID, exportable local ledger; strict schema/prefix validation blocks malformed data
Phase 5: server health/version guard, allowlisted assets, server-side V6.3 evidence APIs and integrity checks, regression/test gates

สิ่งที่ตัดออกจาก workflow หลัก
-----------------------------
- ไม่แจกจ่าย dashboard HTML ซ้ำหลายรุ่น V5–V8 ใน package V9
- ไม่เสิร์ฟ JS asset เก่าที่ dashboard ปัจจุบันไม่ได้โหลด (เช่น V6.0/V6.2 engines); allowlist เหลือเฉพาะ assets ที่ใช้งานจริง
- ซ่อนแผงที่ซ้ำซ้อน/นอกขอบเขต: V5.9.5 duplicate pattern audit, V7 duplicate robustness panel, universal intelligence workspace, external event bus, old Baccarat Pro roadmap desk และ bankroll-risk panel
- คง legacy engine modules ที่ยังจำเป็นสำหรับหน้าจอหลัก, migration และ V6.3 server evidence/learning routes แต่ซ่อน UI ที่ไม่จำเป็นแทนการลบ API ที่อาจยังใช้ตรวจสอบย้อนหลัง

ข้อจำกัดที่ต้องเข้าใจ
--------------------
- V9 ไม่พิสูจน์ว่ามี predictive edge หรือรับรองผลกำไรในบาคาร่า
- ข้อมูลสั้นหรือหลาย pattern ซ้อนกันจะแสดงความไม่แน่นอนและอาจสรุปเป็น WAIT
- Forecasts ต้องลงทะเบียนก่อนเห็นผลจริงและประเมินจากหลาย session อิสระ; retrospective replay อย่างเดียวไม่พอ
- การทดสอบอัตโนมัติผ่านไม่เท่ากับการทดสอบบน Windows ทุกสภาพแวดล้อม; ตรวจ browser/launcher บนเครื่องเป้าหมายก่อนใช้งานจริง
- ห้ามนำไฟล์ .env ที่มี credential ไปแจกจ่าย

ไฟล์ใน `test_support/` ใช้เฉพาะทดสอบ compatibility ของ V7 diagnostics และไม่ได้อยู่ใน static asset allowlist ของ server.

V9.0.1 corrective integrity update: malformed local V9 ledgers now fail closed and can be exported for recovery without resetting stored content; changing Brain-import history prompts cancellation of any pending V9 forecast.

ดู NEXUS_ARC_V9_AUDIT_REPORT.md, NEXUS_ARC_V9_INTEGRATION_AUDIT_REPORT.md และ NEXUS_ARC_V9_TEST_REPORT.txt สำหรับรายละเอียดจุดแก้ไขและหลักฐานทดสอบ
