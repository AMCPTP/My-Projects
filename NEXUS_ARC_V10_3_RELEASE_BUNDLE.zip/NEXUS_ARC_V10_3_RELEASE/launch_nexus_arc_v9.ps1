# Backward-compatible launcher alias; always launches the current V10.3 release.
$ErrorActionPreference = 'Stop'
& (Join-Path $PSScriptRoot 'launch_nexus_arc_v10.ps1')
exit $LASTEXITCODE
