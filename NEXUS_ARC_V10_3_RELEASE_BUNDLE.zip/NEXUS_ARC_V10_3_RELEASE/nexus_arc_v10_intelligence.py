"""NEXUS ARC V10.3 evidence-first sequence analysis and append-only forecast ledger.

This module intentionally distinguishes descriptive sequence properties from calibrated
probabilities. P/B-only history cannot establish baccarat edge or remaining-card state.
"""
from __future__ import annotations
import hashlib
import json
import math
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

VERSION = "10.3.0"
ANALYSIS_SCHEMA = "nexus-arc-v10-analysis-v1"
LEDGER_SCHEMA = "nexus-arc-v10-prospective-ledger-v1"
MAX_SEQUENCE = 2000
MIN_ANALYSIS = 8
MIN_FREEZE = 20
EPS = 1e-12


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")


def canonical(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)


def sha256(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def parse_sequence(value: Any) -> str:
    if not isinstance(value, str):
        raise ValueError("sequence must be text containing P/B outcomes")
    upper = value.upper()
    if any(ch not in "PB \t\r\n,;|/._-" for ch in upper):
        raise ValueError("sequence accepts only P/B outcomes and common separators; Ties are not silently flattened")
    sequence = "".join(ch for ch in upper if ch in "PB")
    if len(sequence) > MAX_SEQUENCE:
        raise ValueError(f"sequence exceeds {MAX_SEQUENCE} outcomes")
    return sequence


def counts(sequence: str) -> dict[str, Any]:
    p = sequence.count("P"); b = len(sequence) - p; n = len(sequence)
    return {"n": n, "P": p, "B": b, "p_share": p / n if n else None, "b_share": b / n if n else None}


def run_profile(sequence: str) -> dict[str, Any]:
    if not sequence:
        return {"current_side": None, "current_length": 0, "max_run": 0, "run_count": 0, "mean_run_length": None, "runs": []}
    runs: list[dict[str, Any]] = []
    start = 0
    for i in range(1, len(sequence) + 1):
        if i == len(sequence) or sequence[i] != sequence[start]:
            runs.append({"side": sequence[start], "length": i-start, "start_index": start, "end_index_exclusive": i})
            start = i
    return {"current_side": runs[-1]["side"], "current_length": runs[-1]["length"], "max_run": max(r["length"] for r in runs), "run_count": len(runs), "mean_run_length": len(sequence)/len(runs), "runs": runs[-50:]}


def transition_profile(sequence: str) -> dict[str, Any]:
    matrix = {a: {"P": 0, "B": 0, "total": 0} for a in "PB"}
    for a, b in zip(sequence, sequence[1:]):
        matrix[a][b] += 1; matrix[a]["total"] += 1
    for a in "PB":
        for b in "PB":
            matrix[a][b + "_share"] = matrix[a][b] / matrix[a]["total"] if matrix[a]["total"] else None
    return matrix


def _base_probability(sequence: str) -> float:
    # Jeffreys prior Beta(1/2,1/2); smoothing reduces extreme estimates in short samples.
    return (sequence.count("P") + 0.5) / (len(sequence) + 1.0)


def _markov_probability(sequence: str) -> tuple[float, int]:
    if len(sequence) < 2:
        return _base_probability(sequence), 0
    last = sequence[-1]
    following = [sequence[i+1] for i in range(len(sequence)-1) if sequence[i] == last]
    if not following:
        return _base_probability(sequence), 0
    return (following.count("P") + 0.5) / (len(following) + 1.0), len(following)


def _suffix_probability(sequence: str) -> tuple[float, int, int | None, str | None]:
    base = _base_probability(sequence)
    for k in range(min(5, len(sequence)-1), 1, -1):
        suffix = sequence[-k:]
        following = [sequence[i+k] for i in range(0, len(sequence)-k) if sequence[i:i+k] == suffix]
        if len(following) >= 3:
            raw = (following.count("P") + 0.5) / (len(following) + 1.0)
            weight = len(following) / (len(following) + 8.0)
            return weight*raw + (1-weight)*base, len(following), k, suffix
    return base, 0, None, None


def model_probabilities(sequence: str) -> dict[str, Any]:
    base = _base_probability(sequence)
    markov, markov_support = _markov_probability(sequence)
    suffix_prob, suffix_support, suffix_len, suffix = _suffix_probability(sequence)
    # Fixed conservative mixture is a diagnostic candidate, not a learned or calibrated forecast.
    mixture = 0.45*base + 0.30*markov + 0.25*suffix_prob
    values = {"base_rate": base, "markov_1": markov, "suffix_shrunken": suffix_prob, "exploratory_ensemble": mixture}
    vals = list(values.values())
    return {
        "prob_P": {k: round(v, 8) for k, v in values.items()},
        "prob_B": {k: round(1-v, 8) for k, v in values.items()},
        "support": {"base_n": len(sequence), "markov_context_n": markov_support, "suffix_context_n": suffix_support, "suffix_length": suffix_len, "suffix": suffix},
        "disagreement_range": round(max(vals)-min(vals), 8),
        "calibrated": False,
        "status": "EXPLORATORY_UNCALIBRATED",
        "note": "Sequence-conditioned estimates are experimental diagnostics. Historical sequence alone does not establish predictive edge or expected value."
    }


def window_profile(sequence: str, windows: tuple[int, ...] = (4, 8, 12, 20, 40)) -> list[dict[str, Any]]:
    rows = []
    for width in windows:
        part = sequence[-width:]
        c = counts(part)
        alt = sum(a != b for a, b in zip(part, part[1:]))
        alt_rate = alt/(len(part)-1) if len(part) > 1 else None
        majority = "BALANCED" if c["p_share"] is not None and abs(c["p_share"]-0.5) < .1 else ("P_HEAVY" if c["p_share"] is not None and c["p_share"] > .5 else ("B_HEAVY" if c["p_share"] is not None else "EMPTY"))
        rhythm = "ALTERNATING" if alt_rate is not None and alt_rate >= .7 else ("CLUSTERED" if alt_rate is not None and alt_rate <= .3 else "MIXED")
        rows.append({"window": width, "n": len(part), "P": c["P"], "B": c["B"], "p_share": round(c["p_share"], 6) if c["p_share"] is not None else None, "alternations": alt, "alternation_rate": round(alt_rate, 6) if alt_rate is not None else None, "max_run": run_profile(part)["max_run"], "classification": majority + " · " + rhythm, "completeness": "FULL" if len(part)==width else "PARTIAL"})
    return rows


def change_point_scan(sequence: str, max_n: int = 40) -> dict[str, Any]:
    s = sequence[-max_n:]
    min_segment = 8
    if len(s) < min_segment*2:
        return {"status": "INSUFFICIENT_DATA", "n": len(s), "min_segment": min_segment, "note": "At least 16 recent outcomes are required for this exploratory scan."}
    best = None
    for i in range(min_segment, len(s)-min_segment+1):
        left, right = s[:i], s[i:]
        delta = abs(left.count("P")/len(left) - right.count("P")/len(right))
        candidate = {"split_after_recent_index": i, "left_n": len(left), "right_n": len(right), "left_p_share": left.count("P")/len(left), "right_p_share": right.count("P")/len(right), "absolute_delta": delta}
        if best is None or delta > best["absolute_delta"]:
            best = candidate
    status = "POSSIBLE_SHIFT_BY_EXPLORATORY_RULE" if best and best["absolute_delta"] >= .25 else "NO_LARGE_SHIFT_BY_RULE"
    return {"status": status, "n": len(s), "best_split": best, "threshold": .25, "p_value": None, "note": "Maximum split is selected from multiple candidates; this is a screening flag, not a corrected significance test or proof of a regime change."}


def historical_suffixes(sequence: str) -> list[dict[str, Any]]:
    out = []
    for k in range(2, min(5, len(sequence)-1)+1):
        if len(sequence) <= k: continue
        suffix = sequence[-k:]
        following = [sequence[i+k] for i in range(len(sequence)-k) if sequence[i:i+k] == suffix]
        out.append({"suffix": suffix, "length": k, "support": len(following), "following_P": following.count("P"), "following_B": following.count("B"), "raw_p_share": following.count("P")/len(following) if following else None, "interpretation": "historical conditional frequency only; not validated next-outcome probability"})
    return out


def _scores(p: float, actual: str) -> tuple[float, float]:
    p = min(1-EPS, max(EPS, p))
    y = 1.0 if actual == "P" else 0.0
    return -(y*math.log(p)+(1-y)*math.log(1-p)), (p-y)**2


def _metrics(rows: list[tuple[float, str]]) -> dict[str, Any]:
    if not rows: return {"n": 0, "mean_log_loss": None, "mean_brier": None, "directional_accuracy": None, "calibration_bins": [], "ece": None}
    losses=[]; briers=[]; hits=0; directional_n=0; bins=[[] for _ in range(5)]
    for p, actual in rows:
        ll, br = _scores(p, actual); losses.append(ll); briers.append(br)
        if abs(p - .5) > 1e-12:
            directional_n += 1
            hits += int((p > .5 and actual == "P") or (p < .5 and actual == "B"))
        idx=min(4, int(min(.999999, max(0, p))*5)); bins[idx].append((p, 1.0 if actual == "P" else 0.0))
    calibration=[]; ece_sum=0.0
    for i, group in enumerate(bins):
        if not group: calibration.append({"bin": f"{i/5:.1f}-{(i+1)/5:.1f}", "n": 0, "mean_predicted_P": None, "observed_P": None}); continue
        mp=sum(x for x,_ in group)/len(group); op=sum(y for _,y in group)/len(group); ece_sum += len(group)/len(rows)*abs(mp-op)
        calibration.append({"bin": f"{i/5:.1f}-{(i+1)/5:.1f}", "n": len(group), "mean_predicted_P": round(mp,6), "observed_P": round(op,6)})
    return {"n":len(rows), "mean_log_loss":sum(losses)/len(rows), "mean_brier":sum(briers)/len(rows), "directional_n":directional_n, "directional_coverage":directional_n/len(rows), "directional_accuracy":hits/directional_n if directional_n else None, "calibration_bins": calibration, "ece": ece_sum}


def walk_forward(sequence: str, seed: int = 20, max_rows: int = 1200) -> dict[str, Any]:
    start=max(seed, len(sequence)-max_rows)
    model_rows={"uniform_baseline":[], "base_rate":[], "markov_1":[], "exploratory_ensemble":[]}
    rows_n=0
    for i in range(start, len(sequence)):
        prefix=sequence[:i]; actual=sequence[i]
        models=model_probabilities(prefix)["prob_P"]
        model_rows["uniform_baseline"].append((0.5,actual))
        model_rows["base_rate"].append((models["base_rate"],actual))
        model_rows["markov_1"].append((models["markov_1"],actual))
        model_rows["exploratory_ensemble"].append((models["exploratory_ensemble"],actual))
        rows_n += 1
    model_metrics={k:_metrics(v) for k,v in model_rows.items()}
    baseline=model_metrics["uniform_baseline"]
    comparisons={}
    for k,m in model_metrics.items():
        comparisons[k]={"delta_log_loss_vs_uniform": (m["mean_log_loss"]-baseline["mean_log_loss"]) if m["mean_log_loss"] is not None else None, "delta_brier_vs_uniform": (m["mean_brier"]-baseline["mean_brier"]) if m["mean_brier"] is not None else None}
    return {"available": rows_n>0, "scored_n": rows_n, "seed_history": seed, "models": model_metrics, "vs_uniform_baseline": comparisons, "method": "chronological prefix-only retrospective walk-forward; no prospective proof; rows in a sequence are dependent", "status": "EXPLORATORY_ONLY" if rows_n else "INSUFFICIENT_HISTORY"}


def analyze_sequence(value: Any, include_walk_forward_audit: bool = True) -> dict[str, Any]:
    s=parse_sequence(value); c=counts(s); run=run_profile(s); windows=window_profile(s); models=model_probabilities(s); trans=transition_profile(s)
    flags=[]
    if len(s) < MIN_ANALYSIS: flags.append("ข้อมูลสั้นเกินไปสำหรับการอ่านรูปแบบพื้นฐานที่มั่นคง")
    if c["P"] < 5 or c["B"] < 5: flags.append("ตัวอย่างของอย่างน้อยหนึ่งฝั่งมีน้อยกว่า 5 ผล")
    usable=[w for w in windows if w["n"] >= 4]
    short=next((w for w in usable if w["window"]==8), usable[0] if usable else None)
    broad=next((w for w in usable if w["window"]==40), usable[-1] if usable else None)
    context={"status":"INSUFFICIENT_DATA","flags":[]}
    if short and broad and short["n"]>=4 and broad["n"]>=8:
        sp=short["p_share"]; bp=broad["p_share"]
        context_flags=[{"id":"SHORT_VS_BROAD_BALANCE","status":"DIFFERENT" if abs(sp-bp)>=.2 else "SIMILAR_BY_RULE","delta_p_share":round(abs(sp-bp),6),"note":"Descriptive comparison only."}]
        sa=short["alternation_rate"]; ba=broad["alternation_rate"]
        if sa is not None and ba is not None:
            context_flags.append({"id":"RHYTHM_DIFFERENCE","status":"DIFFERENT" if abs(sa-ba)>=.25 else "SIMILAR_BY_RULE","delta_alternation_rate":round(abs(sa-ba),6)})
        context={"status":"MIXED_CONTEXT" if any(x["status"]=="DIFFERENT" for x in context_flags) else "NO_LARGE_DIFFERENCE_BY_RULE","flags":context_flags}
    shift=change_point_scan(s)
    if models["disagreement_range"]>=.15: flags.append("โมเดลวิเคราะห์ต่างกันมากกว่าที่ควรมองข้าม")
    if shift["status"]=="POSSIBLE_SHIFT_BY_EXPLORATORY_RULE": flags.append("พบจุดแบ่งที่ควรตรวจต่อ แต่ยังไม่ใช่หลักฐานยืนยัน regime shift")
    wf=walk_forward(s) if include_walk_forward_audit and len(s)>=MIN_FREEZE+1 else {"available":False,"status":"INSUFFICIENT_HISTORY","reason":f"ต้องมีอย่างน้อย {MIN_FREEZE+1} ผลจึงเริ่ม walk-forward ได้","models":{}}
    return {
        "schema":ANALYSIS_SCHEMA,"version":VERSION,"created_at":utc_now(),
        "input":{"n":len(s),"sequence":s,"fingerprint_sha256":sha256(s),"counts":c},
        "readiness":{"basic_patterns_ready":len(s)>=MIN_ANALYSIS,"prospective_freeze_ready":len(s)>=MIN_FREEZE,"minimum_freeze_n":MIN_FREEZE},
        "sequence_profile":{"run":run,"alternations":sum(a!=b for a,b in zip(s,s[1:])),"alternation_rate":sum(a!=b for a,b in zip(s,s[1:]))/(len(s)-1) if len(s)>1 else None,"binary_entropy_bits":(-(c['p_share']*math.log2(c['p_share']) if c['p_share'] not in (None,0) else 0)-((1-c['p_share'])*math.log2(1-c['p_share']) if c['p_share'] not in (None,1) else 0)) if c['p_share'] is not None else None},
        "windows":windows,"transition_matrix":trans,"historical_suffix_evidence":historical_suffixes(s),"context_comparison":context,"change_point_scan":shift,
        "model_diagnostics":models,"walk_forward":wf,
        "decision":{"action":"WAIT","directional_call":"WAIT","live_action":"WAIT","calibrated":False,"reason":"V10.3 remains in evidence collection mode. Sequence-only exploratory estimates are not sufficient to authorize a live decision."},
        "quality_flags":flags,
        "guardrails":["Patterns describe the supplied history and can appear by chance.","Pattern groups are correlated and must not be counted as independent evidence.","Walk-forward on one sequence is retrospective, not prospective proof.","No live decision or model promotion is authorized by this report.","P/B-only history does not reveal remaining-card composition or establish profitability."]
    }


def _event_hash(event: dict[str, Any]) -> str:
    body = {k:v for k,v in event.items() if k != "event_hash"}
    return sha256(canonical(body))


def verify_ledger(events: Any) -> dict[str, Any]:
    if not isinstance(events, list): return {"valid":False,"checked":0,"bad_index":0,"reason":"ledger root must be an array"}
    previous="0"*64
    seen_ids=set()
    for i,event in enumerate(events):
        if not isinstance(event,dict): return {"valid":False,"checked":i,"bad_index":i,"reason":"event is not an object"}
        if event.get("schema") != LEDGER_SCHEMA or event.get("event_type") not in {"forecast_frozen", "forecast_resolved", "forecast_cancelled"} or not isinstance(event.get("payload"), dict):
            return {"valid":False,"checked":i,"bad_index":i,"reason":"unsupported event schema/type or malformed payload"}
        event_id=event.get("event_id")
        if not isinstance(event_id,str) or not event_id or event_id in seen_ids:
            return {"valid":False,"checked":i,"bad_index":i,"reason":"missing or duplicate event_id"}
        seen_ids.add(event_id)
        if not isinstance(event.get("created_at"),str) or not event.get("created_at"):
            return {"valid":False,"checked":i,"bad_index":i,"reason":"missing event timestamp"}
        payload=event["payload"]
        kind=event["event_type"]
        if kind=="forecast_frozen":
            prefix=payload.get("prefix_sequence")
            probability=payload.get("prob_P")
            if (not isinstance(payload.get("forecast_id"),str) or not payload.get("forecast_id") or
                not isinstance(prefix,str) or not prefix or len(prefix)<MIN_FREEZE or any(ch not in "PB" for ch in prefix) or
                payload.get("prefix_n")!=len(prefix) or payload.get("prefix_sha256")!=sha256(prefix) or
                not isinstance(probability,(int,float)) or isinstance(probability,bool) or not math.isfinite(probability) or not 0<probability<1 or
                payload.get("live_action")!="WAIT" or not isinstance(payload.get("session_id"),str) or not payload.get("session_id")):
                return {"valid":False,"checked":i,"bad_index":i,"reason":"malformed frozen forecast payload"}
        elif kind=="forecast_resolved":
            if (not isinstance(payload.get("forecast_id"),str) or payload.get("actual") not in {"P","B"} or
                not isinstance(payload.get("log_loss"),(int,float)) or not math.isfinite(payload["log_loss"]) or payload["log_loss"]<0 or
                not isinstance(payload.get("brier"),(int,float)) or not math.isfinite(payload["brier"]) or not 0<=payload["brier"]<=1):
                return {"valid":False,"checked":i,"bad_index":i,"reason":"malformed forecast resolution payload"}
        elif kind=="forecast_cancelled":
            if not isinstance(payload.get("forecast_id"),str) or not payload.get("forecast_id"):
                return {"valid":False,"checked":i,"bad_index":i,"reason":"malformed forecast cancellation payload"}
        try:
            computed=_event_hash(event)
        except (TypeError, ValueError, OverflowError):
            return {"valid":False,"checked":i,"bad_index":i,"reason":"event contains non-canonical or non-finite JSON data"}
        if event.get("sequence") != i+1 or event.get("prev_hash") != previous or not isinstance(event.get("event_hash"),str) or computed != event.get("event_hash"):
            return {"valid":False,"checked":i,"bad_index":i,"reason":"sequence, prev_hash or event_hash mismatch"}
        previous=event["event_hash"]
    return {"valid":True,"checked":len(events),"bad_index":None,"reason":"hash chain is internally consistent; timestamps and operator-entered outcomes are not independently attested","last_hash":previous}


def append_event(events: list[dict[str, Any]], event_type: str, payload: dict[str, Any], created_at: str | None = None) -> dict[str, Any]:
    integrity=verify_ledger(events)
    if not integrity["valid"]: raise ValueError("V10 ledger integrity failure; writes blocked")
    event={"schema":LEDGER_SCHEMA,"sequence":len(events)+1,"event_id":uuid.uuid4().hex,"created_at":created_at or utc_now(),"event_type":event_type,"payload":payload,"prev_hash":integrity.get("last_hash","0"*64)}
    event["event_hash"]=_event_hash(event); events.append(event); return event


def project_ledger(events: list[dict[str, Any]]) -> dict[str, Any]:
    forecasts: dict[str, dict[str, Any]]={}
    lifecycle_errors=[]
    for event in events:
        kind=event.get("event_type"); p=event.get("payload",{})
        fid=p.get("forecast_id")
        if kind=="forecast_frozen":
            if not fid or fid in forecasts: lifecycle_errors.append({"sequence":event.get("sequence"),"reason":"missing or duplicate forecast_id"}); continue
            forecasts[fid]={**p,"status":"PENDING","frozen_event_sequence":event.get("sequence"),"resolved_event_sequence":None}
        elif kind in {"forecast_resolved","forecast_cancelled"}:
            row=forecasts.get(fid)
            if not row or row["status"]!="PENDING": lifecycle_errors.append({"sequence":event.get("sequence"),"reason":"lifecycle transition requires a pending forecast"}); continue
            if kind=="forecast_resolved": row.update({k:v for k,v in p.items() if k!="forecast_id"}); row["status"]="RESOLVED"; row["resolved_event_sequence"]=event.get("sequence")
            else: row.update({"status":"CANCELLED","cancel_reason":p.get("cancel_reason","operator_cancelled"),"resolved_event_sequence":event.get("sequence")})
    resolved=[f for f in forecasts.values() if f["status"]=="RESOLVED"]
    predicted=[f for f in resolved if f.get("shadow_call") in {"P","B"}]
    return {"schema":LEDGER_SCHEMA,"forecast_count":len(forecasts),"pending_count":sum(f["status"]=="PENDING" for f in forecasts.values()),"resolved_count":len(resolved),"cancelled_count":sum(f["status"]=="CANCELLED" for f in forecasts.values()),"directional_n":len(predicted),"directional_accuracy":sum(f.get("hit") is True for f in predicted)/len(predicted) if predicted else None,"mean_log_loss":sum(float(f["log_loss"]) for f in resolved)/len(resolved) if resolved else None,"mean_brier":sum(float(f["brier"]) for f in resolved)/len(resolved) if resolved else None,"lifecycle_errors":lifecycle_errors,"auto_promotion":False,"forecasts":forecasts}


def freeze_payload(sequence_value: Any, session_id: str) -> dict[str, Any]:
    s=parse_sequence(sequence_value)
    if len(s)<MIN_FREEZE: raise ValueError(f"at least {MIN_FREEZE} P/B outcomes are required to freeze a V10 prospective forecast")
    sid=str(session_id or "").strip()
    if not sid or len(sid)>120: raise ValueError("session_id is required and must be at most 120 characters")
    analysis=analyze_sequence(s,include_walk_forward_audit=False)
    probs=analysis["model_diagnostics"]["prob_P"]["exploratory_ensemble"]
    # Because the ensemble has no prospective calibration, do not choose a directional side.
    return {"forecast_id":"v10-"+uuid.uuid4().hex,"session_id":sid,"prefix_n":len(s),"prefix_sequence":s,"prefix_sha256":sha256(s),"engine_version":VERSION,"prob_P":probs,"prob_B":round(1-probs,8),"shadow_call":"WAIT","live_action":"WAIT","calibrated":False,"forecast_status":"SHADOW_ONLY","created_at":utc_now(),"actual":None,"hit":None,"log_loss":None,"brier":None,"note":"Server-recorded before the claimed outcome; server hash chain does not independently attest the user's sequence or wall clock."}


def resolve_payload(forecast: dict[str, Any], sequence_value: Any, session_id: str) -> dict[str, Any]:
    s=parse_sequence(sequence_value)
    if str(session_id or "").strip()!=forecast.get("session_id"): raise ValueError("session_id must match the frozen forecast")
    prefix=forecast.get("prefix_sequence","")
    if len(s)!=len(prefix)+1 or not s.startswith(prefix): raise ValueError("resolve blocked: history must equal the frozen prefix plus exactly one new P/B result")
    actual=s[-1]; p=min(1-EPS,max(EPS,float(forecast["prob_P"]))); y=1.0 if actual=="P" else 0.0
    return {"forecast_id":forecast["forecast_id"],"actual":actual,"hit":None,"log_loss":-(y*math.log(p)+(1-y)*math.log(1-p)),"brier":(p-y)**2,"resolved_at":utc_now(),"outcome_source":"operator_entered_unverified","note":"Outcome is operator-entered and not independently verified."}
