NEXUS ARC V10.3 runtime storage.

The server creates v10_prospective_ledger.json here on first write. Keep this directory writable and separate from nexus_v9_data. Release bundles intentionally ship without live ledger data. Back up this folder before maintenance.
