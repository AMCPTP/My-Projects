@echo off
setlocal
cd /d "%~dp0"
echo === V10.3 Python syntax ===
py -3 -m py_compile nexus_arc_v9_server.py nexus_arc_v10_intelligence.py || goto :fail
echo === V10.3 analysis + server API tests ===
py -3 -m unittest -v test_nexus_arc_v10_intelligence.py || goto :fail
echo === Legacy/V9 compatibility regression ===
py -3 -m unittest -v test_nexus_arc_v9_server_regression.py || goto :fail
echo === V10.3 UI/API integration scenarios ===
node test_nexus_arc_v10_ui_integration.js || goto :fail
echo === Legacy JavaScript syntax and compatibility tests ===
node --check nexus_arc_v9_analysis_engine.js || goto :fail
node test_nexus_arc_v9_analysis_engine.js || goto :fail
node test_nexus_arc_v9_ui_integration.js || goto :fail
node test_nexus_arc_v5_9_5_pattern_engine.js || goto :fail
node test_nexus_arc_v5_10_1_rapid_analyst_engine.js || goto :fail
node test_nexus_arc_v6_3_validation_engine.js || goto :fail
node test_nexus_arc_v7_diagnostics_engine.js || goto :fail
echo.
echo All included V10.3 and legacy compatibility validation suites passed.
exit /b 0
:fail
echo.
echo Test suite failed. See output above.
exit /b 1
