@echo off
setlocal
cd /d "%~dp0"
call "%~dp0run_nexus_arc_v10_3_tests.bat"
exit /b %errorlevel%
