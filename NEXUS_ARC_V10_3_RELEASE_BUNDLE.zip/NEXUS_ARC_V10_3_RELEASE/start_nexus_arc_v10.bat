@echo off
setlocal
cd /d "%~dp0"
if not exist ".env" copy ".env.example" ".env" >nul
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0launch_nexus_arc_v10.ps1"
if errorlevel 1 (
  echo.
  echo NEXUS ARC V10.3 launcher stopped safely. Review the message above.
  pause
)
endlocal
