@echo off
setlocal
cd /d "%~dp0"
call "%~dp0start_nexus_arc_v10.bat"
endlocal
