import math
import tempfile
import unittest
from pathlib import Path
from fastapi.testclient import TestClient
import nexus_arc_v10_intelligence as v10

SEQUENCE = "PBPBBPPBBPBPBPBPBBPB" * 2


class V10AnalysisTests(unittest.TestCase):
    def test_parser_is_strict_and_bounds_length(self):
        self.assertEqual(v10.parse_sequence("P B,P;B|P"), "PBPBP")
        with self.assertRaisesRegex(ValueError, "Ties are not silently flattened"):
            v10.parse_sequence("PBTB")
        with self.assertRaisesRegex(ValueError, "exceeds"):
            v10.parse_sequence("P" * 2001)

    def test_output_schema_and_decision_stay_wait(self):
        report = v10.analyze_sequence(SEQUENCE)
        self.assertEqual(report["version"], "10.3.0")
        self.assertEqual(report["input"]["n"], 40)
        self.assertEqual(report["decision"]["action"], "WAIT")
        self.assertFalse(report["model_diagnostics"]["calibrated"])
        self.assertEqual(set(report["model_diagnostics"]["prob_P"]), {"base_rate", "markov_1", "suffix_shrunken", "exploratory_ensemble"})
        for name, p in report["model_diagnostics"]["prob_P"].items():
            self.assertTrue(0 < p < 1, (name, p))
            self.assertAlmostEqual(p + report["model_diagnostics"]["prob_B"][name], 1.0, places=7)

    def test_empty_and_short_sequences_return_safe_report(self):
        report = v10.analyze_sequence("")
        self.assertEqual(report["decision"]["live_action"], "WAIT")
        self.assertFalse(report["readiness"]["basic_patterns_ready"])
        short = v10.analyze_sequence("PBP")
        self.assertEqual(short["input"]["n"], 3)
        self.assertEqual(short["walk_forward"]["status"], "INSUFFICIENT_HISTORY")

    def test_windows_and_transitions_are_count_consistent(self):
        report = v10.analyze_sequence("PPBBPB")
        self.assertEqual(report["input"]["counts"]["P"] + report["input"]["counts"]["B"], 6)
        self.assertEqual(sum(report["transition_matrix"][x]["total"] for x in "PB"), 5)
        self.assertEqual([w["window"] for w in report["windows"]], [4, 8, 12, 20, 40])

    def test_prefix_only_walk_forward_and_metrics_are_finite(self):
        report = v10.analyze_sequence(SEQUENCE)
        wf = report["walk_forward"]
        self.assertEqual(wf["status"], "EXPLORATORY_ONLY")
        self.assertEqual(wf["scored_n"], 20)
        for model in wf["models"].values():
            for key in ("mean_log_loss", "mean_brier", "ece"):
                self.assertTrue(math.isfinite(model[key]), (key, model))
            if model["directional_accuracy"] is not None:
                self.assertGreaterEqual(model["directional_accuracy"], 0)
                self.assertLessEqual(model["directional_accuracy"], 1)
            self.assertGreaterEqual(model["directional_coverage"], 0)
            self.assertLessEqual(model["directional_coverage"], 1)

    def test_change_point_is_screening_not_significance(self):
        sequence = "P" * 20 + "B" * 20
        result = v10.change_point_scan(sequence)
        self.assertEqual(result["status"], "POSSIBLE_SHIFT_BY_EXPLORATORY_RULE")
        self.assertIsNone(result["p_value"])
        self.assertIn("not a corrected significance test", result["note"])

    def test_ledger_hash_chain_detects_tampering(self):
        events = []
        frozen = v10.freeze_payload(SEQUENCE, "shoe-1")
        v10.append_event(events, "forecast_frozen", frozen)
        self.assertTrue(v10.verify_ledger(events)["valid"])
        events[0]["payload"]["prob_P"] = 0.99
        self.assertFalse(v10.verify_ledger(events)["valid"])

    def test_freeze_requires_minimum_and_resolve_requires_exactly_one_outcome(self):
        with self.assertRaisesRegex(ValueError, "at least 20"):
            v10.freeze_payload("PBPB", "shoe-1")
        frozen = v10.freeze_payload(SEQUENCE, "shoe-1")
        with self.assertRaisesRegex(ValueError, "exactly one new"):
            v10.resolve_payload(frozen, SEQUENCE + "BB", "shoe-1")
        with self.assertRaisesRegex(ValueError, "session_id must match"):
            v10.resolve_payload(frozen, SEQUENCE + "B", "other-shoe")
        resolved = v10.resolve_payload(frozen, SEQUENCE + "B", "shoe-1")
        self.assertEqual(resolved["actual"], "B")
        self.assertTrue(math.isfinite(resolved["log_loss"]))
        self.assertTrue(math.isfinite(resolved["brier"]))


class V10ServerApiTests(unittest.TestCase):
    def setUp(self):
        import nexus_arc_v9_server as server
        self.server = server
        self.previous_events = list(server.v10_ledger_events)
        self.previous_path = server.V10_LEDGER_PATH
        self.previous_error = server.V10_LEDGER_LOAD_ERROR
        self.tmp = tempfile.TemporaryDirectory()
        server.V10_LEDGER_PATH = Path(self.tmp.name) / "v10_ledger.json"
        server.v10_ledger_events.clear()
        server.V10_LEDGER_LOAD_ERROR = None
        self.client = TestClient(server.app, base_url="http://127.0.0.1")

    def tearDown(self):
        self.client.close()
        self.server.v10_ledger_events.clear()
        self.server.v10_ledger_events.extend(self.previous_events)
        self.server.V10_LEDGER_PATH = self.previous_path
        self.server.V10_LEDGER_LOAD_ERROR = self.previous_error
        self.tmp.cleanup()

    def test_health_and_api_discover_v10_release(self):
        health = self.client.get("/api/health").json()
        self.assertEqual(health["version"], "10.3.0")
        self.assertEqual(health["dashboard"], "NEXUS_ARC_V10_ANALYSIS_DESK.html")
        meta = self.client.get("/api/meta").json()
        self.assertEqual(meta["server_version"], "10.3.0")
        self.assertEqual(meta["v10_analysis_url"], "/api/v10/analysis")

    def test_analysis_endpoint_is_wait_gated_and_rejects_ties(self):
        response = self.client.post("/api/v10/analysis", json={"sequence": SEQUENCE})
        self.assertEqual(response.status_code, 200, response.text)
        self.assertEqual(response.json()["decision"]["live_action"], "WAIT")
        response = self.client.post("/api/v10/analysis", json={"sequence": "PBTB"})
        self.assertEqual(response.status_code, 422)

    def test_freeze_idempotency_exact_resolve_and_hash_chain(self):
        payload = {"sequence": SEQUENCE, "session_id": "shoe-api-1", "client_event_id": "v10-api-freeze-0001"}
        first = self.client.post("/api/v10/forecasts/freeze", json=payload)
        self.assertEqual(first.status_code, 200, first.text)
        second = self.client.post("/api/v10/forecasts/freeze", json=payload)
        self.assertEqual(second.status_code, 200, second.text)
        self.assertTrue(second.json()["duplicate"])
        reused = {**payload, "sequence": SEQUENCE[:-1] + ("B" if SEQUENCE[-1] == "P" else "P")}
        conflict = self.client.post("/api/v10/forecasts/freeze", json=reused)
        self.assertEqual(conflict.status_code, 409)
        fid = first.json()["forecast"]["forecast_id"]
        invalid = self.client.post(f"/api/v10/forecasts/{fid}/resolve", json={"sequence": SEQUENCE + "BB", "session_id": "shoe-api-1"})
        self.assertEqual(invalid.status_code, 409)
        resolved = self.client.post(f"/api/v10/forecasts/{fid}/resolve", json={"sequence": SEQUENCE + "P", "session_id": "shoe-api-1"})
        self.assertEqual(resolved.status_code, 200, resolved.text)
        self.assertEqual(resolved.json()["forecast"]["status"], "RESOLVED")
        self.assertEqual(resolved.json()["forecast"]["actual"], "P")
        verify = self.client.get("/api/v10/ledger/verify").json()
        self.assertTrue(verify["integrity"]["valid"])
        self.assertEqual(verify["resolved_count"], 1)

    def test_same_session_pending_is_blocked_and_cancel_does_not_score(self):
        payload = {"sequence": SEQUENCE, "session_id": "shoe-api-2", "client_event_id": "v10-api-freeze-0002"}
        first = self.client.post("/api/v10/forecasts/freeze", json=payload)
        self.assertEqual(first.status_code, 200, first.text)
        other = {**payload, "client_event_id": "v10-api-freeze-0003"}
        denied = self.client.post("/api/v10/forecasts/freeze", json=other)
        self.assertEqual(denied.status_code, 409)
        fid = first.json()["forecast"]["forecast_id"]
        cancelled = self.client.post(f"/api/v10/forecasts/{fid}/cancel", json={"reason": "test"})
        self.assertEqual(cancelled.status_code, 200, cancelled.text)
        projection = self.client.get("/api/v10/ledger").json()["projection"]
        self.assertEqual(projection["cancelled_count"], 1)
        self.assertEqual(projection["resolved_count"], 0)

    def test_corrupted_ledger_closes_write_gate(self):
        self.server.v10_ledger_events.append({"sequence": 1, "prev_hash": "bad", "event_hash": "bad"})
        status = self.client.get("/api/v10/status").json()
        self.assertEqual(status["write_gate"], "BLOCKED")
        response = self.client.post("/api/v10/forecasts/freeze", json={"sequence": SEQUENCE, "session_id": "shoe-3", "client_event_id": "v10-api-freeze-0004"})
        self.assertEqual(response.status_code, 409)


if __name__ == "__main__":
    unittest.main(verbosity=2)
