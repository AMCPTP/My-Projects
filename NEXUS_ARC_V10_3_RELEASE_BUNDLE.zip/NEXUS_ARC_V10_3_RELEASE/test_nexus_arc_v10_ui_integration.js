'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const html = fs.readFileSync('NEXUS_ARC_V10_ANALYSIS_DESK.html', 'utf8');
const match = html.match(/<script id="nexusArcV103Controller">([\s\S]*?)<\/script>/);
assert.ok(match, 'V10.3 dashboard controller exists');
for (const id of ['v10Run','v10Freeze','v10Resolve','v10Cancel','v10Refresh','v10Export','v10ModelRows','v10WalkRows','v10ForecastRows','v10ServerStatus']) {
  assert.ok(html.includes(`id="${id}"`), `dashboard has #${id}`);
}
const sequence = 'PBPBBPPBBPBPBPBPBBPB'.repeat(2);
const elements = new Map();
function elem(id) {
  if (!elements.has(id)) elements.set(id, { id, value: '', textContent: '', innerHTML: '', disabled: false, handlers: {},
    addEventListener(name, fn) { this.handlers[name] = fn; } });
  return elements.get(id);
}
elem('arSequence').value = sequence;
elem('v10SessionId').value = 'shoe-ui-1';
const report = {
  version:'10.3.0', input:{n:40,sequence,counts:{n:40,P:20,B:20,p_share:.5,b_share:.5}},
  sequence_profile:{run:{current_side:'B',current_length:3,max_run:4,run_count:12},alternations:20,alternation_rate:.51,binary_entropy_bits:1},
  model_diagnostics:{prob_P:{base_rate:.5,markov_1:.51,suffix_shrunken:.49,exploratory_ensemble:.5},prob_B:{base_rate:.5,markov_1:.49,suffix_shrunken:.51,exploratory_ensemble:.5},support:{base_n:40,markov_context_n:19,suffix_context_n:4,suffix_length:2},disagreement_range:.02,calibrated:false},
  windows:[4,8,12,20,40].map(window=>({window,n:Math.min(window,40),P:window/2,B:window/2,p_share:.5,alternation_rate:.5,classification:'BALANCED · MIXED',completeness:'FULL',max_run:3})),
  context_comparison:{status:'NO_LARGE_DIFFERENCE_BY_RULE',flags:[]},
  change_point_scan:{status:'NO_LARGE_SHIFT_BY_RULE',best_split:{absolute_delta:.05,left_n:20,right_n:20},note:'screening only'},
  walk_forward:{available:true,status:'EXPLORATORY_ONLY',scored_n:20,method:'prefix only',models:{},vs_uniform_baseline:{}},
  decision:{action:'WAIT',live_action:'WAIT',reason:'test safety gate'},quality_flags:[],guardrails:['descriptive only']
};
for (const name of ['uniform_baseline','base_rate','markov_1','exploratory_ensemble']) {
  report.walk_forward.models[name]={n:20,mean_log_loss:.69,mean_brier:.25,directional_accuracy:.5,ece:.01};
  report.walk_forward.vs_uniform_baseline[name]={delta_log_loss_vs_uniform:0,delta_brier_vs_uniform:0};
}
const calls=[];let storedForecast=null;let eventCount=0;
function statusBody(){return {version:'10.3.0',forecast_count:storedForecast?1:0,pending_count:storedForecast?.status==='PENDING'?1:0,resolved_count:storedForecast?.status==='RESOLVED'?1:0,cancelled_count:storedForecast?.status==='CANCELLED'?1:0,event_count:eventCount,write_gate:'OPEN',integrity:{valid:true,checked:eventCount,reason:'test chain valid'},note:'test chain'};}
async function fetchMock(path, options={}) {
  const method=options.method||'GET'; calls.push({path,method,body:options.body?JSON.parse(options.body):null});
  if (path==='/api/v10/status') return response(statusBody());
  if (path.startsWith('/api/v10/ledger?')) return response({projection:{forecasts:storedForecast?{[storedForecast.forecast_id]:storedForecast}:{}}});
  if (path==='/api/v10/analysis'&&method==='POST') return response(report);
  if (path==='/api/v10/forecasts/freeze'&&method==='POST') {
    storedForecast={forecast_id:'v10-ui-forecast-1',session_id:JSON.parse(options.body).session_id,status:'PENDING',created_at:'2026-10-18T00:00:00Z',prob_P:.5,prob_B:.5,actual:null,log_loss:null,brier:null};eventCount++;
    return response({ok:true,duplicate:false,forecast:{...storedForecast,prefix_n:sequence.length}});
  }
  if (path.endsWith('/resolve')&&method==='POST') {
    storedForecast={...storedForecast,status:'RESOLVED',actual:JSON.parse(options.body).sequence.slice(-1),log_loss:.6931,brier:.25};eventCount++;
    return response({ok:true,forecast:storedForecast});
  }
  if (path.endsWith('/cancel')&&method==='POST') {
    storedForecast={...storedForecast,status:'CANCELLED'};eventCount++;
    return response({ok:true});
  }
  throw new Error(`Unexpected mock API call ${method} ${path}`);
}
function response(body, status=200){return {ok:status>=200&&status<300,status,json:async()=>body};}
const context={document:{readyState:'complete',getElementById:elem,addEventListener(){}},fetch:fetchMock,console,Date,Math,JSON,Promise,URL,Blob,setTimeout,clearTimeout};
vm.runInNewContext(match[1],context,{filename:'nexusArcV103Controller.js'});
const tick=()=>new Promise(resolve=>setTimeout(resolve,0));
(async()=>{
  await tick(); await tick();
  assert.ok(calls.some(c=>c.path==='/api/v10/analysis'&&c.method==='POST'),'dashboard calls server analysis');
  assert.match(elem('v10DataState').textContent,/40 outcomes/,'analysis renders sequence counts');
  await elem('v10Freeze').handlers.click();
  assert.ok(calls.some(c=>c.path==='/api/v10/forecasts/freeze'),'dashboard freezes a prospective forecast');
  assert.match(elem('v10LedgerCounts').textContent,/1 forecasts/,'ledger counts render');
  elem('arSequence').value=sequence+'P';
  await elem('v10Resolve').handlers.click();
  assert.ok(calls.some(c=>c.path.endsWith('/resolve')&&c.method==='POST'),'dashboard resolves the next outcome through server API');
  assert.match(elem('v10ForecastRows').innerHTML,/RESOLVED/,'resolved forecast renders in table');
  assert.equal(elem('v10Resolve').disabled,true,'resolved forecast is no longer available to resolve');
  console.log('PASS V10.3 UI calls server analysis and renders diagnostics');
  console.log('PASS V10.3 UI freeze -> server ledger -> exact-next-outcome resolve flow');
  console.log('PASS V10.3 resolved forecasts disappear from pending actions');
})().catch(err=>{console.error(err);process.exitCode=1;});
