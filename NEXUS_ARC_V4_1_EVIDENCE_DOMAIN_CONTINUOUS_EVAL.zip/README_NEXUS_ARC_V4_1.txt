NEXUS ARC V4.1 — EVIDENCE, DOMAIN INTELLIGENCE & CONTINUOUS EVALUATION
=====================================================================

WHAT'S INCLUDED
---------------
- NEXUS_ARC_V4_1_UNIVERSAL_INTELLIGENCE.html : Dashboard and local P/B/T engine
- nexus_arc_v4_1_server.py                   : Local backend, web-search analysis, feed monitor, evidence audit, evaluation API
- requirements_nexus_v4_1.txt                : Python dependencies
- test_nexus_arc_v4_1.py                     : Automated regression/unit tests
- NEXUS_ARC_V4_1_TEST_REPORT.txt              : Test results and explicit limitations

FEATURES ADDED IN V4.1
----------------------
1) LIVE INTELLIGENCE
   - Server-side polling of explicitly configured public RSS, Atom and JSON feeds.
   - Default poll interval 60 seconds; configurable from 30 to 3600 seconds using NEXUS_POLL_SECONDS.
   - Feed health exposes last poll age, last success age, source-item age, freshness status and errors.
   - Exact duplicate IDs are deduplicated. Exact normalized stories from another publisher are grouped as one event while independent source references are retained as corroboration.
   - Only configured feeds are monitored. This is not exhaustive monitoring of the internet or world events.

2) DOMAIN INTELLIGENCE
   - Domain-specific checklists for general research, news, sports, finance, weather/travel, science, technology, business, coding/engineering, creative work and P/B/T sequence analysis.
   - Checklist results are explicitly marked as model-reported, not independently proven.

3) EVIDENCE VERIFICATION
   - Claim-level assessments use supported / contradicted / uncertain labels.
   - A claim's source links are retained only when the URL matches a citation annotation returned by the provider. Invented/unmatched links are rejected and counted.
   - Reports citation count, unique source domains, claim-linkage rate and warnings for missing citations or insufficient source diversity.
   - Provider citations and model assessments are not a guarantee that a claim is true. Users should open and evaluate the sources, especially for high-stakes decisions.

4) CONTINUOUS EVALUATION
   - Each successful analysis records evaluation metadata, source references, response quality checks, domain checklist, claim mappings, model and latency.
   - The raw task/context text is not persisted by the evaluation ledger; a one-way task fingerprint is stored. The generated claim checks and cited URLs are stored locally for review.
   - Users can label a response correct, partly correct, incorrect or not verifiable, with an optional note.
   - The dashboard reports metrics by domain and an integrity/contract benchmark. Human feedback is subjective; these metrics do not prove objective accuracy or universal intelligence.
   - Meaningful accuracy evaluation still requires independent gold-labelled datasets, sufficient samples and out-of-sample tests per domain.

INSTALLATION — WINDOWS POWERSHELL
---------------------------------
1. Extract the ZIP into a folder you can write to.
2. Open PowerShell in that folder and run:

   py -m venv .venv
   .\.venv\Scripts\Activate.ps1
   py -m pip install -r requirements_nexus_v4_1.txt
   $env:OPENAI_API_KEY = "YOUR_API_KEY"
   $env:NEXUS_MODEL = "YOUR_AVAILABLE_MODEL"
   $env:NEXUS_POLL_SECONDS = "60"
   py nexus_arc_v4_1_server.py

3. Open http://127.0.0.1:8787/ in your browser.
4. Click "ตรวจ Backend". Provider readiness is confirmed only after a request actually succeeds with the currently configured model/key.
5. In WORLD MONITOR, replace the empty feed list with public URLs you trust, save, then start monitoring or allow the server monitor to run.

INSTALLATION — LINUX / macOS
----------------------------
   python3 -m venv .venv
   source .venv/bin/activate
   python -m pip install -r requirements_nexus_v4_1.txt
   export OPENAI_API_KEY="YOUR_API_KEY"
   export NEXUS_MODEL="YOUR_AVAILABLE_MODEL"
   export NEXUS_POLL_SECONDS="60"
   python nexus_arc_v4_1_server.py

Then open http://127.0.0.1:8787/.

SECURITY / OPERATION NOTES
--------------------------
- API keys remain in server environment variables and must not be pasted into the HTML dashboard or feed URLs.
- The server binds to 127.0.0.1 by default. Do not expose it to a public network without authentication, authorization, HTTPS and operational hardening.
- Feed URLs are checked for local/private targets, unsafe schemes and redirects; feeds are fetched with time/size limits. Configure only public feeds you trust.
- Keep the backend running for server-side polling. Browser sync works only while the dashboard is open.
- Use a model available to your own API project. This package contains no user API key and does not preconfigure an external feed.
- The package is a local workbench; it does not promise to detect every event, to be correct in every domain, or to replace professional review.

EVALUATION API
--------------
GET  /api/health
GET  /api/events
GET  /api/feeds
POST /api/feeds
POST /api/monitor/poll-now
POST /api/analyze
GET  /api/evaluations
GET  /api/evaluations/summary
GET  /api/evaluations/benchmark
POST /api/evaluations/{evaluation_id}/feedback

The benchmark tests the integrity/completeness of saved response records and citation links. It is not a factual accuracy benchmark.
