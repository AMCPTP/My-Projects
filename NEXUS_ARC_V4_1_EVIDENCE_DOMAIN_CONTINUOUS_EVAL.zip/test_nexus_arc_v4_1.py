import json
import sys
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
import nexus_arc_v4_1_server as nexus


@pytest.fixture(autouse=True)
def isolate_local_state(tmp_path, monkeypatch):
    # Tests never read or mutate a real user's feed configuration or event history.
    monkeypatch.setattr(nexus, "FEEDS_PATH", tmp_path / "feed_sources.json")
    monkeypatch.setattr(nexus, "STATE_PATH", tmp_path / "world_state.json")
    monkeypatch.setattr(nexus, "EVAL_PATH", tmp_path / "evaluation_records.json")
    monkeypatch.setattr(nexus, "evaluation_records", [])
    fresh = {"events": [], "feed_status": {}, "last_poll_at": None, "poll_count": 0,
             "last_provider_success_at": None, "last_provider_error": None,
             "last_web_search_status": "NOT_TESTED", "last_provider_model": None, "last_provider_key_fingerprint": None}
    monkeypatch.setattr(nexus, "state", fresh)
    monkeypatch.setattr(nexus, "request_times", {})
    monkeypatch.setattr(nexus, "feed_sources", [])


def test_private_and_local_feed_urls_are_rejected():
    for url in [
        "http://127.0.0.1/feed.json",
        "http://localhost/feed.xml",
        "http://192.168.1.10/feed.json",
        "file:///etc/passwd",
        "http://user:pass@example.com/feed.xml",
    ]:
        with pytest.raises(ValueError):
            nexus.reject_private_url(url)


def test_public_http_urls_are_accepted_syntactically():
    assert nexus.reject_private_url("https://example.org/feed.xml").startswith("https://")


def test_json_feed_parsing_normalizes_items():
    raw = json.dumps({"items": [{"id": "a1", "title": "Release", "summary": "Version changed", "url": "https://example.org/a1", "publishedAt": "2026-10-09T00:00:00Z"}]}).encode()
    items = nexus.parse_json_feed(raw, "Unit Feed", "https://example.org/feed.json")
    assert len(items) == 1
    assert items[0]["title"] == "Release"
    assert items[0]["text"] == "Version changed"
    assert items[0]["url"] == "https://example.org/a1"
    assert len(items[0]["fingerprint"]) == 64


def test_rss_feed_parsing():
    xml = b'''<?xml version="1.0"?><rss version="2.0"><channel><item><title>Headline</title><description>Body</description><link>https://example.org/story</link><guid>story-1</guid><pubDate>Fri, 09 Oct 2026 00:00:00 GMT</pubDate></item></channel></rss>'''
    items = nexus.parse_xml_feed(xml, "Unit RSS", "https://example.org/feed.xml")
    assert len(items) == 1
    assert items[0]["title"] == "Headline"
    assert items[0]["url"] == "https://example.org/story"
    assert items[0]["text"] == "Body"


def test_health_and_static_dashboard_routes():
    with TestClient(nexus.app) as client:
        home = client.get("/")
        assert home.status_code == 200
        assert "NEXUS ARC V4" in home.text
        health = client.get("/api/health")
        assert health.status_code == 200
        info = health.json()
        assert info["version"] == "4.1.0"
        assert "live_status" in info
        assert "evaluation_records" in info
        assert info["live_status"] == "NOT_CONFIGURED"
        assert "coverage_note" in info
        events = client.get("/api/events")
        assert events.status_code == 200
        assert isinstance(events.json()["events"], list)


def test_feed_endpoint_blocks_loopback():
    with TestClient(nexus.app) as client:
        response = client.post("/api/feeds", json={"feeds": [{"name": "bad", "url": "http://127.0.0.1:8080/feed.json", "format": "json"}]})
        assert response.status_code == 400


def test_no_provider_credentials_never_returns_fake_analysis():
    if nexus.API_KEY and nexus.MODEL:
        pytest.skip("Live provider credentials are configured; avoids a real paid API request.")
    with TestClient(nexus.app) as client:
        response = client.post("/api/analyze", json={"domain": "general_research", "task": "Verify a fact"})
        assert response.status_code == 503
        assert "No analysis was generated" in response.json()["detail"] or "not configured" in response.json()["detail"]


def test_analysis_route_uses_mock_provider_and_returns_only_provider_citations(monkeypatch):
    from types import ModuleType, SimpleNamespace
    import sys

    class FakeResponses:
        async def create(self, **kwargs):
            assert kwargs["model"] == "unit-test-model"
            assert kwargs.get("tools") == [{"type": "web_search"}]
            structured = {
                "summary": "สรุปที่ได้จาก provider จำลอง",
                "verified_facts": ["ข้อเท็จจริงจำลอง"],
                "analysis_and_inference": ["ข้ออนุมานจำลอง"],
                "uncertainties": ["ยังต้องตรวจซ้ำ"],
                "missing_information": ["ข้อมูลต้นทางเพิ่มเติม"],
                "next_steps": ["เปิดอ่านแหล่งอ้างอิง"],
                "coverage_note": "ทดสอบด้วย provider จำลองเท่านั้น",
                "domain_checks": [
                    {"check_id": "scope", "status": "addressed", "note": "สรุปขอบเขตในการทดสอบ"},
                    {"check_id": "source_comparison", "status": "not_available", "note": "ตัวอย่าง mock มีแหล่งเดียว"},
                    {"check_id": "uncertainty", "status": "addressed", "note": "ระบุความไม่แน่นอนแล้ว"},
                ],
                "claim_checks": [
                    {"claim": "ข้อเท็จจริงจำลอง", "assessment": "supported", "explanation": "ตรวจจาก citation ของ mock", "source_urls": ["https://example.org/source"]},
                    {"claim": "ลิงก์ที่ไม่อยู่ใน citation", "assessment": "uncertain", "explanation": "ควรถูกตัดลิงก์ที่ไม่ผ่าน", "source_urls": ["https://fake.invalid/unsupported"]},
                ],
            }
            annotation = SimpleNamespace(type="url_citation", url="https://example.org/source", title="Example Source")
            content = SimpleNamespace(annotations=[annotation])
            return SimpleNamespace(
                output_text=json.dumps(structured, ensure_ascii=False),
                output=[SimpleNamespace(type="web_search_call"), SimpleNamespace(type="message", content=[content])],
                id="resp-unit-test",
            )

    class FakeClient:
        def __init__(self, **kwargs):
            self.responses = FakeResponses()

    monkeypatch.setattr(nexus, "API_KEY", "unit-test-key")
    monkeypatch.setattr(nexus, "MODEL", "unit-test-model")
    fake_module = ModuleType("openai")
    fake_module.AsyncOpenAI = FakeClient
    monkeypatch.setitem(sys.modules, "openai", fake_module)
    with TestClient(nexus.app) as client:
        response = client.post("/api/analyze", json={"domain": "general_research", "task": "ทดสอบ", "use_web_search": True})
        assert response.status_code == 200, response.text
        result = response.json()
        assert "สรุปที่ได้จาก provider จำลอง" in result["answer"]
        assert result["web_search_used"] is True
        assert result["sources"] == [{"title": "Example Source", "url": "https://example.org/source"}]
        assert "ยังต้องตรวจซ้ำ" in result["uncertainties"]
        assert result["evaluation_id"]
        assert result["evidence_audit"]["citation_count"] == 1
        assert result["claim_checks"][0]["sources"][0]["url"] == "https://example.org/source"
        assert result["claim_checks"][1]["sources"] == []
        assert result["evidence_audit"]["claim_assessment_count"] == 2
        assert len(nexus.evaluation_records) == 1


def test_geojson_nested_properties_and_epoch_timestamp():
    raw = json.dumps({"features": [{"id": "eq-1", "properties": {"title": "M4.2 earthquake", "place": "Near coast", "time": 1791504000000, "url": "https://example.org/quake/1"}}]}).encode()
    items = nexus.parse_json_feed(raw, "Geo Feed", "https://example.org/feed.geojson")
    assert len(items) == 1
    assert items[0]["title"] == "M4.2 earthquake"
    assert items[0]["text"] == "Near coast"
    assert items[0]["timestamp"].endswith("Z")
    assert items[0]["timestamp_kind"] == "source_epoch"


def test_invalid_source_timestamp_is_marked_as_observed_fallback():
    timestamp, kind, original = nexus.normalize_timestamp("not-a-time")
    assert timestamp.endswith("Z")
    assert kind == "observed_at_fallback"
    assert original == "not-a-time"



def test_domain_checklists_have_expected_coverage():
    assert {"event_time", "corroboration", "claim_status"}.issubset({x["id"] for x in nexus.DOMAIN_CHECKLISTS["news_events"]})
    assert {"instrument", "data_provenance", "risk_scenarios"}.issubset({x["id"] for x in nexus.DOMAIN_CHECKLISTS["finance"]})
    assert nexus.domain_checklist_payload("sequence_pbt")


def test_cross_source_duplicates_keep_corroboration_without_duplicate_event():
    nexus.state["events"] = []
    nexus.state["cross_source_duplicates"] = 0
    text = "A distinct alert with enough clear text to be normalized identically across two independent public data sources."
    content_fp = nexus.content_fingerprint("Important alert", text)
    base = {"title": "Important alert", "text": text, "timestamp": "2026-10-09T01:00:00Z", "timestamp_kind": "source_timestamp", "impact": .7, "type": "feed_event", "content_fingerprint": content_fp}
    one = {**base, "source": "Source A", "source_url": "https://a.example/feed", "url": "https://a.example/item", "fingerprint": "source-a-id"}
    two = {**base, "source": "Source B", "source_url": "https://b.example/feed", "url": "https://b.example/item", "fingerprint": "source-b-id"}
    assert nexus.merge_events([one]) == 1
    assert nexus.merge_events([two]) == 0
    rows = nexus.state["events"]
    assert len(rows) == 1
    assert rows[0]["corroboration_count"] == 2
    assert len(rows[0]["corroborating_sources"]) == 1
    assert nexus.state["cross_source_duplicates"] == 1


def test_evidence_audit_flags_missing_search_citations():
    audit = nexus.build_evidence_audit("news_events", [], [], nexus.sanitize_domain_checks("news_events", [])[0], True, False, 0, 0)
    assert audit["citation_count"] == 0
    assert any("No provider citation URLs" in warning for warning in audit["warnings"])


def test_claim_urls_without_provider_annotations_are_rejected():
    claims, rejected = nexus.sanitize_claim_checks([{"claim": "Claim", "assessment": "supported", "explanation": "x", "source_urls": ["https://evil.example/fake"]}], [{"title": "Real", "url": "https://real.example/source"}])
    assert claims[0]["sources"] == []
    assert rejected == 1


def test_evaluation_summary_and_benchmark_state_no_data():
    summary = nexus.evaluation_summary([])
    assert summary["total_analyses"] == 0
    benchmark = nexus.run_evaluation_benchmark([])
    assert benchmark["status"] == "NO_DATA"


def test_evaluation_feedback_endpoint_tracks_user_review(monkeypatch):
    row = {"evaluation_id": "eval-123", "domain": "general_research", "generated_at": nexus.utc_now(), "quality_checks": {}, "sources": [], "feedback": [], "elapsed_ms": 100, "source_count": 0, "web_search_requested": True, "web_search_used": False}
    nexus.evaluation_records = [row]
    with TestClient(nexus.app) as client:
        response = client.post("/api/evaluations/eval-123/feedback", json={"label": "partly_correct", "note": "checked manually"})
        assert response.status_code == 200, response.text
        assert response.json()["feedback"]["label"] == "partly_correct"
        summary = client.get("/api/evaluations/summary").json()
        assert summary["total_analyses"] == 1
        assert summary["overall"]["scored_reviews"] == 1
        bench = client.get("/api/evaluations/benchmark").json()
        assert bench["status"] in {"PASS", "REVIEW"}


def test_feedback_rejects_unknown_label():
    with TestClient(nexus.app) as client:
        response = client.post("/api/evaluations/missing/feedback", json={"label": "invented", "note": ""})
        assert response.status_code == 422



def test_same_host_repeat_does_not_count_as_independent_corroboration():
    nexus.state["events"] = []
    nexus.state["cross_source_duplicates"] = 0
    text = "Same publisher repeat with stable identical title and body used to exercise source independence logic."
    cf = nexus.content_fingerprint("Same story", text)
    first = {"title": "Same story", "text": text, "source": "Publisher", "source_url": "https://publisher.example/feed", "url": "https://publisher.example/story-1", "timestamp": "2026-10-09T01:00:00Z", "timestamp_kind": "source_timestamp", "content_fingerprint": cf, "fingerprint": "first-guid"}
    second = {**first, "url": "https://publisher.example/story-mirror", "fingerprint": "second-guid"}
    assert nexus.merge_events([first]) == 1
    assert nexus.merge_events([second]) == 0
    assert nexus.state["events"][0]["corroboration_count"] == 1
    assert nexus.state["cross_source_duplicates"] == 0


def test_provider_ready_is_not_inferred_from_stale_success_for_other_model(monkeypatch):
    monkeypatch.setattr(nexus, "API_KEY", "current-key")
    monkeypatch.setattr(nexus, "MODEL", "new-model")
    nexus.state["last_provider_success_at"] = nexus.utc_now()
    nexus.state["last_provider_model"] = "old-model"
    nexus.state["last_provider_key_fingerprint"] = nexus.digest("current-key")[:16]
    with TestClient(nexus.app) as client:
        info = client.get("/api/health").json()
        assert info["ai_ready"] is False
        assert info["provider_status"] == "CONFIGURED_NOT_YET_VERIFIED"



def test_dashboard_exposes_evidence_feedback_and_continuous_evaluation_controls():
    html = (ROOT / "NEXUS_ARC_V4_1_UNIVERSAL_INTELLIGENCE.html").read_text(encoding="utf-8")
    for expected in [
        'id="uiEvidenceAudit"', 'id="uiClaimChecks"', 'data-eval-feedback="correct"',
        'id="uiEvalBenchmark"', 'id="uiRefreshEval"', 'id="uiRunEvalBenchmark"',
        "uiRenderEvidenceAudit(data.evidence_audit)", "uiSubmitEvaluationFeedback", "live ${data.live_status||'UNKNOWN'}",
    ]:
        assert expected in html, expected


def test_response_audit_marks_model_claim_assessments_as_not_ground_truth():
    checks, _ = nexus.sanitize_domain_checks("science", [])
    audit = nexus.build_evidence_audit("science", [], [], checks, True, False, 0, 0)
    assert audit["claim_assessments_are_not_ground_truth"] is True
    assert audit["model_checklist_is_self_reported"] is True
    assert audit["domain_checks_total"] == len(nexus.DOMAIN_CHECKLISTS["science"])



def test_evaluation_benchmark_handles_malformed_ledger_entries_without_crashing():
    benchmark = nexus.run_evaluation_benchmark([
        {"evaluation_id": "ok", "domain": "news_events", "quality_checks": {}, "sources": [], "generated_at": nexus.utc_now(), "claim_checks": [], "domain_checks": []},
        {"evaluation_id": "bad", "domain": "news_events", "quality_checks": None, "sources": None, "generated_at": nexus.utc_now(), "claim_checks": "not-a-list", "domain_checks": None},
    ])
    assert benchmark["status"] == "REVIEW"
    assert benchmark["analyses_tested"] == 2
