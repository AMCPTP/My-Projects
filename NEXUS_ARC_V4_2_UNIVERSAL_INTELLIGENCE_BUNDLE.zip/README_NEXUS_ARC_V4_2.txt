NEXUS ARC V4.2 — UNIVERSAL INTELLIGENCE WORKBENCH
=================================================

ขอบเขต
------
V4.2 เป็น local-first dashboard + Python backend สำหรับการวิเคราะห์หลายโดเมน การตรวจสอบแหล่งอ้างอิง การติดตาม public feeds ที่ผู้ใช้ตั้งค่า และการประเมินผลจาก feedback/gold-labelled rubric

ระบบไม่อ้างว่าสามารถรับรู้ทุกเหตุการณ์ทั่วโลก และไม่ถือว่า citation มีอยู่แล้วแปลว่าข้อกล่าวอ้างได้รับการพิสูจน์ความจริงแล้ว

ไฟล์ในชุด
---------
- NEXUS_ARC_V4_2_UNIVERSAL_INTELLIGENCE.html : dashboard
- nexus_arc_v4_2_server.py                  : local API/backend + feed monitor
- requirements_nexus_v4_2.txt               : Python dependencies
- test_nexus_arc_v4_2.py                    : regression/unit tests
- NEXUS_ARC_V4_2_GOLD_SET_TEMPLATE.json     : ตัวอย่างโครงสร้าง gold rubric (ต้องแทนที่ placeholder)
- NEXUS_ARC_V4_2_TEST_REPORT.txt            : ผลทดสอบและข้อจำกัด

ติดตั้งบน Windows PowerShell
----------------------------
1. แตก ZIP ทั้งชุดไว้ในโฟลเดอร์เดียวกัน
2. เปิด PowerShell ในโฟลเดอร์นั้น แล้วรัน:

   py -m venv .venv
   .\.venv\Scripts\Activate.ps1
   py -m pip install -r requirements_nexus_v4_2.txt

3. ตั้งค่า API key และชื่อโมเดลที่บัญชี API ใช้งานได้จริง (อย่าใส่ API key ลงใน HTML):

   $env:OPENAI_API_KEY = "YOUR_API_KEY"
   $env:NEXUS_MODEL = "YOUR_AVAILABLE_MODEL"

4. เปิด backend:

   py nexus_arc_v4_2_server.py

5. เปิด browser ที่:

   http://127.0.0.1:8787/

Backend bind เฉพาะ 127.0.0.1 โดยค่าเริ่มต้น อย่าเปิดออกสู่ public network โดยไม่มี authentication, HTTPS และการ hardening ที่เหมาะสม

Live Intelligence
-----------------
- Feed monitor ทำงานเฉพาะขณะที่ backend ทำงาน
- ตั้ง polling ได้ด้วย NEXUS_POLL_SECONDS; ค่าจะถูกจำกัดไว้ที่ 30–3600 วินาที ค่าเริ่มต้น 60 วินาที
- รองรับ public RSS/Atom/XML/JSON feeds สูงสุด 40 feeds; จำกัด payload ต่อ feed 2 MiB และตรวจ redirect/DNS เพื่อลดความเสี่ยง SSRF
- เพิ่ม feeds ผ่านส่วน Monitor ใน dashboard; ไม่ได้มี feed สดที่ preconfigure มาให้
- Dashboard แสดง fetch freshness แยกจาก content freshness: endpoint อาจตอบสำเร็จแต่บทความล่าสุดอาจเก่าได้
- Browser notifications เป็น best-effort และต้องอนุญาตจาก browser; server feed monitor ไม่ได้พึ่งการเปิดหน้า dashboard แต่หยุดเมื่อ backend ถูกปิด
- การค้นเว็บทำตอนมีคำขอวิเคราะห์ตามโดเมน/ตัวเลือกที่เกี่ยวข้อง ไม่ใช่การสแกนเว็บทั้งโลกตลอดเวลา

Evidence Verification
---------------------
- Citation URLs ที่แสดงเป็นลิงก์จะมาจาก annotations ที่ provider ส่งกลับมาเท่านั้น
- หากโมเดลระบุ claim ว่า supported/contradicted แต่ไม่มี citation ที่ตรงกับ provider citation ระบบลด assessment เป็น uncertain
- สถานะ linkage หมายถึงตรวจการผูกลิงก์กับข้อมูลที่ provider คืนมา ไม่ได้หมายความว่าได้ตรวจพิสูจน์เนื้อหา source อย่างอิสระแล้ว
- Domain checklist เป็นการรายงานของโมเดล ไม่ใช่ผลตรวจอิสระ

Continuous Evaluation
--------------------
1. หลังวิเคราะห์ ระบบบันทึก evaluation ID, domain, model, latency, sources, checks และ output สำหรับ audit ในไฟล์ local `nexus_v4_2_data/evaluation_records.json` (เก็บข้อความ answer สูงสุด 60,000 ตัวอักษรต่อ record เพื่อเทียบกับ rubric)
2. กด feedback ต่อผลวิเคราะห์ตามตัวเลือกใน UI เพื่อบันทึกการตรวจทานโดยผู้ใช้
3. เปิด GOLD-LABELLED DOMAIN BENCHMARK และโหลด `NEXUS_ARC_V4_2_GOLD_SET_TEMPLATE.json` หรือสร้าง rubric เอง
4. แทนที่ placeholder ด้วยเกณฑ์ที่ได้จากแหล่งตรวจอิสระ แล้วบันทึกผ่าน UI
5. รันคำถามด้วย domain และข้อความ task ที่ตรงกับ gold case ทุกตัวอักษร จากนั้น Run Gold Benchmark
6. เกณฑ์ expected_contains/expected_not_contains/min_sources/use_web_search ตรวจ rubric ที่กำหนดเท่านั้น; มันไม่ใช่การตัดสินความจริงอัตโนมัติ ต้องใช้มนุษย์หรือ gold labels ที่เชื่อถือได้

การย้ายข้อมูล V4.1
-----------------
เมื่อเริ่ม V4.2 ระบบจะพยายามคัดลอก `feed_sources.json`, `world_state.json`, และ `evaluation_records.json` จาก `nexus_v4_1_data` ไปยัง `nexus_v4_2_data` เฉพาะเมื่อไฟล์ปลายทางยังไม่มีอยู่ การย้ายไม่เขียนทับข้อมูล V4.2 ที่มีอยู่ รายงาน migration ดูได้ที่ `/api/health` หรือ log/state ตามการตั้งค่า

ความเป็นส่วนตัวและข้อมูล
-----------------------
ไฟล์ state, feed config, evaluation ledger และ gold set อยู่ในโฟลเดอร์ `nexus_v4_2_data` ข้าง backend; หลีกเลี่ยงส่งข้อมูลลับ/ส่วนบุคคลไปวิเคราะห์หากไม่มีเหตุผลและสิทธิ์ที่เหมาะสม อย่าแชร์โฟลเดอร์ data หรือเปิด API ออกสู่เครือข่ายโดยไม่มีการควบคุมสิทธิ์

คำสั่งทดสอบ
-----------
   py -m pytest -q test_nexus_arc_v4_2.py

ข้อจำกัดสำคัญ
-------------
- ทดสอบด้วย mocked AI provider และ browser mock; ไม่มี live paid provider call หรือ API key ของผู้ใช้ในชุดทดสอบ
- ไม่มี feed ภายนอกที่ถูกยืนยันว่า ingest สำเร็จจริงใน build environment
- ความแม่นยำจริงต้องวัดแยกตามโดเมน ด้วย gold-labelled unseen cases และการ review ที่มีคุณภาพ
- ระบบติดตามได้เฉพาะ feed ที่ตั้งค่าและข้อมูลที่ provider ค้นได้เมื่อสั่งวิเคราะห์ ไม่สามารถรับประกัน exhaustive global awareness
