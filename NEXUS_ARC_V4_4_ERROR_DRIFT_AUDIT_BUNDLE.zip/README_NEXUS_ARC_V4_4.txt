NEXUS ARC V4.4 — ERROR & DRIFT AUDIT
===================================

WHAT THIS RELEASE ADDS
----------------------
1. Evidence-linked error hypotheses. A saved miss now carries the forecast probabilities, realized outcome, log loss/Brier score, relevant model/context indicators, and rule-based signals used to label the miss. These labels are hypotheses, not verified causal explanations.
2. Rolling performance diagnostics. The dashboard compares recent saved forecast cases to an earlier window, and shows Log Loss, Brier score, accuracy, average confidence, and the confidence-vs-accuracy gap.
3. Baseline comparison. The audit displays the 50/50 reference (log loss ln(2), Brier 0.5, accuracy reference 0.5) to avoid implying that a high accuracy alone proves useful forecasting.
4. Legacy Brain import. V4.4 accepts V4.2 and V4.3 Brain schemas; it checks the original exported checksum before migrating the data to the V4.4 schema.
5. Offline audit utility. `nexus_arc_v4_4_audit.py` reads a Brain JSON export and produces chronological segment summaries, baseline skill metrics, rolling drift warnings, confidence bins, and high-confidence error examples.

FILES
-----
- NEXUS_ARC_V4_4_ERROR_DRIFT_AUDIT.html: main dashboard; open in a browser.
- nexus_arc_v4_2_server.py: V4.2 backend included unchanged. It is not claimed to be newly upgraded or live-verified in this release.
- nexus_arc_v4_4_audit.py: standalone offline audit tool (Python standard library only).
- test_nexus_arc_v4_4_audit.py: automated unit tests for the offline audit tool.
- V4_4_CHANGELOG_AND_LIMITS.txt: change summary and limits.
- V4_4_REGRESSION_REPORT.txt: tests actually run for this release.

UPGRADE / SAFE MIGRATION
------------------------
1. Keep a backup of your existing Brain JSON before changing versions.
2. Open the V4.4 HTML file in your browser.
3. Click “Import Brain” and choose your existing V4.2 or V4.3 Brain JSON.
4. Confirm the status line reports successful migration to V4.4. If it reports checksum mismatch, do not edit the file to force an import; recover the original export.
5. Export a new V4.4 Brain after confirming the imported history.

RUN THE OFFLINE AUDIT (Windows)
-------------------------------
Open Command Prompt in the folder containing the script and your exported Brain JSON, then run:

  py nexus_arc_v4_4_audit.py "NEXUS_ARC_V4_4_Brain_....json" --out audit_report.json

If `py` is unavailable, use `python` instead. The generated `audit_report.json` is descriptive and can be inspected or shared for further analysis. It does NOT verify the export checksum; the dashboard's import path does that. It evaluates saved forecasts and saved outcomes only.

RUN THE OFFLINE AUDIT TESTS
---------------------------
  py -m unittest -v test_nexus_arc_v4_4_audit.py

INTERPRETING RESULTS
--------------------
- WARMING means insufficient scored outcomes for the configured comparison; it does not mean the model is good.
- DRIFT/HIGH are threshold-based warning flags, not statistical significance tests or proof of concept drift.
- Log-loss/Brier skill above zero is historical description, not proof of future edge.
- The 60/20/20 segments in the offline report are descriptive summaries of the currently saved cases. They are not guaranteed untouched holdouts and must not be treated as an unbiased final test after repeated inspection.
- The HTML still uses the existing heuristic sequence engines. This release does not establish that those heuristics predict future P/B outcomes better than chance.
- Configured feeds and optional backend/provider checks are unchanged; no global event awareness or always-live status is claimed.
