#!/usr/bin/env node
'use strict';
// Standard-library-only mock-DOM smoke test for the self-contained NEXUS ARC HTML.
// This tests application logic/initialization but is not a replacement for a real-browser visual test.
const fs = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const { webcrypto } = require('node:crypto');
const { performance } = require('node:perf_hooks');

const htmlPath = process.argv[2] || './NEXUS_ARC_V4_5_PREQUENTIAL_RELEASE_CANDIDATE.html';
const html = fs.readFileSync(htmlPath, 'utf8');
const matches = [...html.matchAll(/<script>([\s\S]*?)<\/script>/g)];
assert.equal(matches.length, 1, 'expected one inline application script');

class FakeElement {
  constructor(id = '') {
    this.id = id; this.textContent = ''; this.innerHTML = ''; this.value = '';
    this.checked = false; this.disabled = false; this.className = ''; this.dataset = {};
    this.files = []; this.children = []; this.style = {}; this.attributes = {}; this.listeners = {};
    this.classList = { add() {}, remove() {}, contains() { return false; }, toggle() {} };
  }
  addEventListener(type, fn) { (this.listeners[type] ||= []).push(fn); }
  removeEventListener() {}
  appendChild(child) { this.children.push(child); return child; }
  append(...children) { this.children.push(...children); }
  replaceChildren(...children) { this.children = [...children]; }
  remove() {}
  focus() {}
  click() { return this.dispatch('click', { target: this }); }
  async dispatch(type, event = { target: this }) {
    const results = [];
    for (const fn of this.listeners[type] || []) results.push(await fn(event));
    return results;
  }
  setAttribute(k, v) { this.attributes[k] = v; }
  getAttribute(k) { return this.attributes[k] ?? null; }
  closest() { return null; }
  querySelectorAll() { return []; }
  querySelector() { return new FakeElement(); }
  scrollIntoView() {}
  getBoundingClientRect() { return { width: 100, height: 20 }; }
}

const elements = new Map();
const storageMap = new Map();
const localStorage = {
  getItem: k => storageMap.has(k) ? storageMap.get(k) : null,
  setItem: (k, v) => storageMap.set(k, String(v)),
  removeItem: k => storageMap.delete(k),
  clear: () => storageMap.clear(),
};
const resultButtons = ['P', 'B', 'T'].map(result => {
  const button = new FakeElement(`result-${result}`);
  button.dataset.result = result;
  return button;
});
const document = {
  getElementById(id) { if (!elements.has(id)) elements.set(id, new FakeElement(id)); return elements.get(id); },
  querySelectorAll(selector) { return selector === '[data-result]' ? resultButtons : []; },
  createElement(tag) { return new FakeElement(tag); },
  createTextNode(text) { return { textContent: String(text) }; },
  addEventListener() {},
  body: new FakeElement('body'),
};
const window = { localStorage, NEXUS: null, location: { href: 'http://localhost/mock.html' }, addEventListener() {}, removeEventListener() {} };
const context = {
  window, document, crypto: webcrypto, performance, localStorage, console, Date, Math, JSON, Number, String,
  Object, Array, Map, Set, RegExp, Error, Promise, Uint8Array, TextEncoder, TextDecoder, URL, Blob,
  AbortController, setTimeout, clearTimeout, setInterval, clearInterval,
  fetch: async () => { throw new Error('network is intentionally disabled in mock test'); },
  Notification: function Notification() {}, navigator: {}, location: { href: 'http://localhost/mock.html' },
  structuredClone: global.structuredClone,
};
context.globalThis = context;

(async () => {
  const instrumentedScript = matches[0][1].replace(
    'window.NEXUS={makeForecast,render,deepSelfTest',
    'window.__TEST={importBrainFile,sha256,canonical,normalizeLearning};window.NEXUS={makeForecast,render,deepSelfTest'
  );
  assert.notEqual(instrumentedScript, matches[0][1], 'test-only hooks should be injected');
  vm.runInNewContext(instrumentedScript, context, { timeout: 15000, filename: 'nexus_arc_v4_5_inline.js' });
  assert.equal(window.NEXUS?.version, 'NEXUS-ARC-V4.5-PREQUENTIAL-SAFE-ADAPTATION');
  assert.equal(document.getElementById('champion').textContent, 'adaptive-v3');

  await window.NEXUS.deepSelfTest();
  const selfTest = document.getElementById('brainDetail').textContent;
  assert.match(document.getElementById('status').textContent, /Self-test PASS/);
  assert.match(selfTest, /6\/6 suites/);
  assert.match(selfTest, /100 deep checks/);

  const sequence = process.argv.includes('--long')
    ? Array.from({ length: 220 }, (_, i) => 'PBBPBPPB'[i % 8])
    : 'PBBPBPPBPPBPBBPBPBPPBPPBBPBPBPBBPBPBPPBBPBPPBPBPBPPBPPBBPBPPB';
  for (const result of sequence) await resultButtons.find(b => b.dataset.result === result).click();
  const learner = window.NEXUS.learner;
  const fresh = learner.cases.filter(c => c.engineVersion === window.NEXUS.version);
  const complete = fresh.filter(c => ['adaptive-v3', 'base-heavy', 'regime-heavy', 'memory-heavy', 'conservative']
    .every(name => c.shadowPredictions?.[name]?.prob && Number.isFinite(c.shadowPredictions[name].prob.P) && Number.isFinite(c.shadowPredictions[name].prob.B)));
  assert.ok(fresh.length > 0, 'interactions should create scored V4.5 cases');
  assert.equal(complete.length, fresh.length, 'every new scored case should include all five pre-outcome shadow forecasts');
  assert.ok(fresh.every(c => c.activeProfile && c.forecast?.prob), 'each scored case should store active policy and actual forecast');

  console.log('PASS — mock-DOM application initialization');
  console.log(`PASS — in-app Deep Self-Test: ${selfTest}`);
  console.log(`PASS — interaction replay: ${window.NEXUS.history.length} outcomes, ${fresh.length} V4.5 scored cases, ${complete.length} with all five shadow candidates; Champion=${learner.selection.champion}; trial=${learner.selection.trial ? `${learner.selection.trial.candidate} ${learner.selection.trial.rows.length}/${learner.selection.trial.target}` : 'none'}`);

  const brain = {
    schema: 'NEXUS-ARC-V4.4-ERROR-DRIFT-AUDIT',
    history: ['P','B','P','B','B','P','P','B','T','P','B','T'],
    learner: {
      version: 'NEXUS-ARC-V4.4-ERROR-DRIFT-AUDIT',
      selection: { champion: 'memory-heavy' },
      calibration: { temp: 1.25, rows: [{ prob: { P: .7, B: .3 }, actual: 'P', at: 1 }] },
      cases: [{ actual: 'P', at: 11, forecast: { prob: { P: .6, B: .4 } } }]
    },
    events: [], exportedAt: '2026-10-01T00:00:00Z'
  };
  brain.checksum = await window.__TEST.sha256(window.__TEST.canonical({
    schema: brain.schema, history: brain.history,
    learner: { ...brain.learner, integrity: {} }, events: brain.events
  }));
  await window.__TEST.importBrainFile({ text: async () => JSON.stringify(brain) });
  assert.equal(window.NEXUS.history.length, 12, 'V4.4 history should migrate');
  assert.equal(window.NEXUS.learner.selection.champion, 'memory-heavy', 'selected profile should be preserved');
  assert.equal(window.NEXUS.learner.calibration.temp, 1, 'cross-version calibration temperature must reset');
  assert.equal(window.NEXUS.learner.calibration.rows.length, 0, 'cross-version calibration rows must reset');
  assert.match(document.getElementById('status').textContent, /Import Brain สำเร็จ/);
  console.log('PASS — checksum-verified V4.4 Brain migration; history/profile preserved, cross-version calibration reset');

  const before = window.NEXUS.history.slice();
  const corrupted = { ...brain, history: ['B', ...brain.history.slice(1)] };
  await window.__TEST.importBrainFile({ text: async () => JSON.stringify(corrupted) });
  assert.match(document.getElementById('status').textContent, /checksum mismatch/);
  assert.deepEqual(window.NEXUS.history, before, 'corrupted Brain import must not mutate active history');
  console.log('PASS — corrupted Brain import rejected without mutating active history');
  console.log('LIMIT — mock DOM does not validate actual Chrome/Edge layout, external API credentials, or live source connectivity.');
})().catch(error => { console.error('FAIL —', error.stack || error); process.exitCode = 1; });
