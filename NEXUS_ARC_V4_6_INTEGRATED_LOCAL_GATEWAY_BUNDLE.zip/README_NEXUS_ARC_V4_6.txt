NEXUS ARC V4.6 — INTEGRATED LOCAL GATEWAY + PREQUENTIAL EVALUATION
Date: 10 October 2026

OVERVIEW
V4.6 closes the release packaging gap in V4.5: it now includes a version-matched server instead of shipping the unchanged V4.2 backend. It combines the V4.5 local P/B sequence-learning dashboard and prequential challenger evaluation with a hardened local domain-analysis/feed-monitor backend.

FILES
- NEXUS_ARC_V4_6_INTEGRATED_RELEASE_CANDIDATE.html : self-contained dashboard; served by the backend root route.
- nexus_arc_v4_6_server.py : local FastAPI server with analysis, configured RSS/Atom/JSON feeds, evaluation ledger, user-defined gold-rubric checks, health/meta endpoints, rate limits, and same-origin mutation checks.
- nexus_arc_v4_6_audit.py : offline Brain JSON audit, Python standard library only.
- test_nexus_arc_v4_6_audit.py : 9 unit tests for the offline auditor.
- test_nexus_arc_v4_6_server.py : 10 API/security/migration integration tests using temporary test storage; no external network or provider calls.
- test_nexus_arc_v4_6_mock.js : mock-DOM app initialization, self-test, replay, and Brain import checks. This is not a full real-browser visual test.
- requirements.txt : runtime dependencies.
- .env.example : blank configuration template; never place real secrets in a shared file.
- setup_windows.bat / run_windows.bat / run_tests_windows.bat : Windows convenience scripts.
- V4_6_REGRESSION_REPORT.txt : observed results and limitations.
- NEXUS_ARC_V4_6_CHANGELOG.txt : change record.
- SHA256SUMS / PACKAGE_SHA256 : integrity hashes.

WINDOWS QUICK START
1. Extract the bundle to a folder you control.
2. Run setup_windows.bat.
3. Edit .env; set OPENAI_API_KEY and NEXUS_MODEL to valid values. The key stays on the server. Do not share .env.
4. Run run_windows.bat.
5. Open http://127.0.0.1:8787 in your browser. Use the page served by the backend, not the HTML file opened as file://; browser-origin guards intentionally reject opaque/null-origin writes.
6. Click Check Backend. Configure public RSS/Atom/JSON feeds you trust. A feed being fetched freshly does not mean its content is recent or true.
7. For local P/B sequence evaluation, enter the prediction/round in the dashboard before entering that outcome. Do not retroactively label predictions as pre-outcome.

MANUAL START
Python 3.11+ recommended.
  python -m venv .venv
  .venv\Scripts\\python.exe -m pip install -r requirements.txt
  copy .env.example .env
Edit .env, then:
  .venv\Scripts\\python.exe nexus_arc_v4_6_server.py
Open http://127.0.0.1:8787

CONFIGURATION
- OPENAI_API_KEY: required for live domain analysis; keep private.
- NEXUS_MODEL: required; set the model name available to your API project.
- NEXUS_PORT: optional local port (default 8787).
- NEXUS_POLL_SECONDS: optional polling interval, clamped to 30–3600 seconds (default 60).
- NEXUS_DATA_DIR: optional persistent data folder. By default it uses ./nexus_v4_6_data.

MIGRATION AND DATA SAFETY
- Dashboard import supports Brain exports from V4.2, V4.3, V4.4, V4.5, and V4.6. On cross-version import, calibration rows/temperature and active in-progress trial are reset; compatible history/case records are retained after validation.
- Server startup uses its own V4.6 data folder. It attempts a non-destructive copy of known JSON files from ./nexus_v4_2_data and then ./nexus_v4_1_data when those folders are alongside the script. It does not overwrite any destination file. For safety, back up your previous data folders before migration. If your old data lives somewhere else, copy it manually only after making a backup.
- Run-time JSON is written atomically. Data is still local application state, not an authenticated audit vault; SHA-256 checksums detect accidental/casual corruption in Brain imports but are not signatures proving who created a file.

TESTS
  .venv\Scripts\\python.exe -m unittest -v test_nexus_arc_v4_6_audit.py test_nexus_arc_v4_6_server.py
  node test_nexus_arc_v4_6_mock.js NEXUS_ARC_V4_6_INTEGRATED_RELEASE_CANDIDATE.html
  node test_nexus_arc_v4_6_mock.js NEXUS_ARC_V4_6_INTEGRATED_RELEASE_CANDIDATE.html --long
A mock-DOM test is not a real Chrome/Edge visual test. API integration tests use TestClient and synthetic inputs, not live API credentials or real feeds.

OFFLINE AUDIT
  python nexus_arc_v4_6_audit.py "NEXUS_ARC_V4_6_Brain_export.json" --out audit_report.json

LIMITATIONS — READ BEFORE RELYING ON FORECASTS
- No live provider API or real feed connectivity was exercised by release tests; an API call may require correct credentials, a supported model, working network access, and billing/account permissions.
- No real-user Brain or future outcome cohort was evaluated. The challenger trial must complete on genuinely future outcomes; a synthetic replay is only a code-path check.
- P/B/T local sequence analysis treats P/B as binary outcomes and T separately. Historical sequence memory alone is not evidence of predictive advantage on an approximately random process.
- Feed monitoring covers configured public sources only; no system guarantees awareness of every event worldwide.
- Rule-based error causes are hypotheses, not proof of causation. User feedback and literal rubric checks are also not independent truth validation.
- The server binds to 127.0.0.1 by default. Same-origin checks are not user authentication. Do not expose this service to a LAN or the public Internet without a separate security review and authentication layer.
