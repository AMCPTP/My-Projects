@echo off
setlocal
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe (
  echo Virtual environment is missing. Run setup_windows.bat first.
  pause
  exit /b 1
)
.venv\Scripts\python.exe -m unittest -v test_nexus_arc_v4_6_audit.py test_nexus_arc_v4_6_server.py
if errorlevel 1 goto :failed
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js not found; skipping browser-mock test. Python tests passed.
  pause
  exit /b 0
)
node test_nexus_arc_v4_6_mock.js NEXUS_ARC_V4_6_INTEGRATED_RELEASE_CANDIDATE.html
if errorlevel 1 goto :failed
node test_nexus_arc_v4_6_mock.js NEXUS_ARC_V4_6_INTEGRATED_RELEASE_CANDIDATE.html --long
if errorlevel 1 goto :failed
echo All available local regression checks passed.
pause
exit /b 0
:failed
echo One or more tests failed.
pause
exit /b 1
