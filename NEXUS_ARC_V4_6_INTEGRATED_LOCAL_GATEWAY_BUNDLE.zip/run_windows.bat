@echo off
setlocal
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe (
  echo Virtual environment is missing. Run setup_windows.bat first.
  pause
  exit /b 1
)
if not exist .env copy .env.example .env >nul
.venv\Scripts\python.exe nexus_arc_v4_6_server.py
pause
