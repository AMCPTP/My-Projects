@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 (
  echo Python Launcher ^(py^) was not found. Install Python 3.11 or later first.
  pause
  exit /b 1
)
if not exist .venv\Scripts\python.exe py -3 -m venv .venv
if errorlevel 1 goto :failed
.venv\Scripts\python.exe -m pip install --upgrade pip
if errorlevel 1 goto :failed
.venv\Scripts\python.exe -m pip install -r requirements.txt
if errorlevel 1 goto :failed
if not exist .env copy .env.example .env >nul
echo.
echo Setup complete. Edit .env and set OPENAI_API_KEY and NEXUS_MODEL, then run run_windows.bat.
pause
exit /b 0
:failed
echo Setup failed. Review the error above.
pause
exit /b 1
