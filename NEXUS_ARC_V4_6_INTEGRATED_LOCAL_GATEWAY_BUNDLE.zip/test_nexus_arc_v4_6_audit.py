import unittest
from nexus_arc_v4_6_audit import build_report, metrics, valid_cases, drift_report, prequential_candidate_report, selection_trial_report, CANDIDATES


def case(actual, p, b, cause=None, diagnostic=None, at=0):
    return {"actual": actual, "at": at,
            "forecast": {"prob": {"P": p, "B": b}},
            "cause": cause, "diagnostic": diagnostic}

class AuditTests(unittest.TestCase):
    def test_perfect_forecasts_beat_50_50_baseline(self):
        rows, qc = valid_cases([case("P", .9, .1), case("B", .1, .9)])
        m = metrics(rows)
        self.assertEqual(m["n"], 2)
        self.assertEqual(m["accuracy"], 1.0)
        self.assertGreater(m["log_loss_skill_vs_50_50"], 0)

    def test_invalid_rows_are_not_scored(self):
        rows, qc = valid_cases([case("T", .5, .5), case("P", 1.2, .1), case("B", .2, .8)])
        self.assertEqual(len(rows), 1)
        self.assertEqual(qc["invalid_or_unscored_cases"], 2)

    def test_rolling_drift_detects_degradation(self):
        rows=[]
        for i in range(24):
            rows.append({"source_index": i, "actual": "P", "prob": {"P": .9, "B": .1}, "case": {}})
        for i in range(24, 48):
            rows.append({"source_index": i, "actual": "P", "prob": {"P": .1, "B": .9}, "case": {}})
        report = drift_report(rows)
        self.assertEqual(report["status"], "HIGH")
        self.assertGreater(report["delta"]["log_loss"], .12)

    def test_report_segments_and_limitations(self):
        cases=[]
        for i in range(100):
            # First 60 look useful; last 40 are noisy/misspecified.
            actual = "P" if i % 2 == 0 else "B"
            if i < 60:
                probs = ({"P": .8, "B": .2} if actual == "P" else {"P": .2, "B": .8})
            else:
                probs = ({"P": .8, "B": .2} if actual == "B" else {"P": .2, "B": .8})
            cases.append({"at": i, "actual": actual, "forecast": {"prob": probs}, "cause": "MODEL-MISS" if i >= 60 else None,
                          "diagnostic": {"primary": "MODEL-MISS", "signals": [{"label": "OVERCONFIDENCE"}] } if i >= 60 else None})
        doc={"schema":"NEXUS-ARC-V4.3-WALK-FORWARD-GATE", "history":["P","B"]*50,
             "learner":{"cases":cases,"errors":[]},"events":[],"checksum":"abc"}
        report=build_report(doc)
        self.assertEqual(report["overall"]["n"],100)
        self.assertEqual(report["chronological_segments"]["train_descriptive"]["n"],60)
        self.assertEqual(report["chronological_segments"]["validation_descriptive"]["n"],20)
        self.assertEqual(report["chronological_segments"]["audit_descriptive"]["n"],20)
        self.assertFalse(report["source"]["checksum_verified"])
        self.assertEqual(report["error_hypotheses"]["primary_cause_counts"].get("MODEL-MISS"),40)

    def test_warming_status_with_small_sample(self):
        rows=[{"source_index":i,"actual":"P","prob":{"P":.6,"B":.4},"case":{}} for i in range(39)]
        self.assertEqual(drift_report(rows)["status"], "WARMING")

    def test_prequential_candidate_metrics_from_shadow_forecasts(self):
        cases=[]
        for i in range(20):
            actual="P" if i%2==0 else "B"
            best={"P":.9,"B":.1} if actual=="P" else {"P":.1,"B":.9}
            worse={"P":.8,"B":.2} if actual=="B" else {"P":.8,"B":.2}
            shadow={name:{"prob":best if name=="base-heavy" else worse, "action":actual} for name in CANDIDATES}
            cases.append({"actual":actual,"at":i,"engineVersion":"NEXUS-ARC-V4.6-PREQUENTIAL-SAFE-ADAPTATION",
                          "activeProfile":"base-heavy","forecast":{"prob":best},"shadowPredictions":shadow})
        report=prequential_candidate_report(cases,"base-heavy")
        self.assertEqual(report["complete_pre_outcome_shadow_cases"],20)
        self.assertEqual(report["candidate_metrics"]["base-heavy"]["accuracy"],1.0)
        self.assertGreater(report["candidate_metrics"]["base-heavy"]["log_loss_skill_vs_50_50"],0)
        self.assertEqual(report["active_forecast_alignment"]["matches"],20)
        self.assertEqual(report["ranked_by_historical_log_loss"][0]["candidate"],"base-heavy")

    def test_incomplete_shadow_case_not_used_for_candidate_rank(self):
        case0={"actual":"P","forecast":{"prob":{"P":.7,"B":.3}},
               "shadowPredictions":{"adaptive-v3":{"prob":{"P":.7,"B":.3}}}}
        report=prequential_candidate_report([case0],"adaptive-v3")
        self.assertEqual(report["complete_pre_outcome_shadow_cases"],0)
        self.assertTrue(all(m["n"]==0 for m in report["candidate_metrics"].values()))

    def test_selection_trial_marks_partial_trial_not_passed(self):
        learner={"selection":{"champion":"adaptive-v3","trial":{"candidate":"base-heavy","champion":"adaptive-v3",
          "target":60,"startedAt":"2026-01-01T00:00:00Z","rows":[{"at":101},{"at":102}]},"trialHistory":[]}}
        report=selection_trial_report(learner)
        self.assertEqual(report["current_trial"]["status"],"RUNNING")
        self.assertEqual(report["current_trial"]["scored_cases"],2)
        self.assertIn("not decided",report["current_trial"]["decision"])

    def test_report_includes_shadow_and_selection_audit(self):
        shadow={name:{"prob":{"P":.55,"B":.45}} for name in CANDIDATES}
        cases=[{"actual":"P","at":i,"forecast":{"prob":{"P":.55,"B":.45}},"shadowPredictions":shadow,
                "activeProfile":"adaptive-v3","engineVersion":"NEXUS-ARC-V4.6-PREQUENTIAL-SAFE-ADAPTATION"} for i in range(5)]
        doc={"schema":"NEXUS-ARC-V4.6-PREQUENTIAL-SAFE-ADAPTATION","history":["P"]*5,
             "learner":{"cases":cases,"errors":[],"selection":{"champion":"adaptive-v3","trial":None}},"events":[]}
        report=build_report(doc)
        self.assertEqual(report["report_schema"],"NEXUS-ARC-V4.6-PREQUENTIAL-AUDIT-1")
        self.assertEqual(report["prequential_shadow_candidates"]["complete_pre_outcome_shadow_cases"],5)
        self.assertEqual(report["selection_trial"]["current_trial"]["status"],"NONE")

if __name__ == "__main__":
    unittest.main(verbosity=2)
