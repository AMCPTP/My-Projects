"""Integration/security smoke tests for the NEXUS ARC V4.6 local API.

Runs entirely locally with a temporary data directory and does not call a provider or live feed.
"""
from __future__ import annotations
import json
import os
import tempfile
import unittest
from pathlib import Path

WORK = Path(__file__).resolve().parent
TEST_DATA = tempfile.mkdtemp(prefix="nexus_arc_v4_6_test_")
os.environ["NEXUS_DATA_DIR"] = TEST_DATA
os.environ["NEXUS_DASHBOARD_PATH"] = str(WORK / "NEXUS_ARC_V4_6_INTEGRATED_RELEASE_CANDIDATE.html")
os.environ["NEXUS_POLL_SECONDS"] = "3600"

from fastapi.testclient import TestClient  # noqa: E402
import nexus_arc_v4_6_server as server  # noqa: E402


class V46ServerTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.client_context = TestClient(server.app)
        cls.client = cls.client_context.__enter__()

    @classmethod
    def tearDownClass(cls):
        cls.client_context.__exit__(None, None, None)

    def setUp(self):
        # Reset mutable test state between cases; no external feed is configured.
        server.feed_sources = []
        server.atomic_save(server.FEEDS_PATH, [])
        server.state["feed_status"] = {}
        server.atomic_save(server.STATE_PATH, server.state)

    def test_health_reports_v46_without_secrets(self):
        response = self.client.get("/api/health")
        self.assertEqual(response.status_code, 200)
        body = response.json()
        self.assertEqual(body["version"], "4.6.0")
        self.assertIn("dashboard", body)
        self.assertNotIn("OPENAI_API_KEY", response.text)
        self.assertEqual(response.headers.get("x-nexus-arc-version"), "4.6.0")
        self.assertEqual(response.headers.get("cache-control"), "no-store")

    def test_meta_exposes_bounded_capabilities_and_scope_limit(self):
        response = self.client.get("/api/meta")
        self.assertEqual(response.status_code, 200)
        body = response.json()
        self.assertEqual(body["server_version"], "4.6.0")
        self.assertIn("origin_guard", body["capabilities"])
        self.assertIn("cannot guarantee awareness of every event", body["coverage_note"])
        self.assertFalse(any("key" in key.lower() and key not in {"api_key_configured"} for key in body))

    def test_root_serves_v46_dashboard(self):
        response = self.client.get("/")
        self.assertEqual(response.status_code, 200)
        self.assertIn("NEXUS ARC V4.6", response.text)

    def test_cross_origin_mutation_is_blocked(self):
        response = self.client.post("/api/feeds", json={"feeds": []}, headers={"Origin": "https://evil.example"})
        self.assertEqual(response.status_code, 403)

    def test_null_origin_mutation_is_blocked(self):
        response = self.client.post("/api/evaluations/gold-set", json={"cases": []}, headers={"Origin": "null"})
        self.assertEqual(response.status_code, 403)

    def test_same_origin_mutation_is_allowed(self):
        response = self.client.post("/api/feeds", json={"feeds": []}, headers={"Origin": "http://testserver"})
        self.assertEqual(response.status_code, 200)
        self.assertTrue(response.json()["ok"])

    def test_local_and_private_feed_urls_are_rejected(self):
        for url in ("http://127.0.0.1/secret", "http://localhost/rss", "http://192.168.1.5/feed", "http://internal.local/rss"):
            with self.subTest(url=url):
                response = self.client.post("/api/feeds", json={"feeds": [{"name": "test", "url": url}]}, headers={"Origin": "http://testserver"})
                self.assertEqual(response.status_code, 400)

    def test_oversized_write_request_is_rejected(self):
        response = self.client.post("/api/feeds", content=b"{" + b" " * (1024 * 1024), headers={"Origin": "http://testserver", "Content-Length": str(1024 * 1024 + 1), "Content-Type": "application/json"})
        self.assertEqual(response.status_code, 413)

    def test_invalid_domain_is_rejected_before_provider_call(self):
        response = self.client.post("/api/analyze", json={"domain": "not-a-domain", "task": "hello"}, headers={"Origin": "http://testserver"})
        self.assertEqual(response.status_code, 422)

    def test_valid_analysis_fails_closed_when_credentials_are_missing(self):
        old_key, old_model = server.API_KEY, server.MODEL
        try:
            server.API_KEY = ""
            server.MODEL = ""
            response = self.client.post("/api/analyze", json={"domain": "general_research", "task": "ทดสอบ"}, headers={"Origin": "http://testserver"})
            self.assertEqual(response.status_code, 503)
            self.assertIn("No analysis was generated", response.json()["detail"])
        finally:
            server.API_KEY, server.MODEL = old_key, old_model

    def test_non_destructive_legacy_migration(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            v42, v41, target = root / "v42", root / "v41", root / "target"
            v42.mkdir(); v41.mkdir(); target.mkdir()
            (v42 / "feed_sources.json").write_text('[{"name":"old","url":"https://example.com/feed"}]', encoding="utf-8")
            (v41 / "feed_sources.json").write_text('[{"name":"older","url":"https://example.org/feed"}]', encoding="utf-8")
            (v42 / "world_state.json").write_text('{"events":[]}', encoding="utf-8")
            (v41 / "evaluation_records.json").write_text('[]', encoding="utf-8")
            (target / "feed_sources.json").write_text('[]', encoding="utf-8")
            report = server.migrate_legacy_data([v42, v41], target)
            self.assertEqual(report["status"], "MIGRATED")
            self.assertEqual(json.loads((target / "feed_sources.json").read_text(encoding="utf-8")), [])
            self.assertEqual(json.loads((target / "world_state.json").read_text(encoding="utf-8")), {"events": []})
            self.assertEqual(json.loads((target / "evaluation_records.json").read_text(encoding="utf-8")), [])


if __name__ == "__main__":
    unittest.main(verbosity=2)
