NEXUS ARC V4.7 — BACCARAT ROADMAP LAB
Date: 10 October 2026

WHAT CHANGED
- Adds a local-only Baccarat Roadmap Lab to the V4.6 dashboard.
- Parses B/P/T result sequences and summarizes Bead Plate, Big Road, run/streak, alternation/chop, 2-2 motifs, suffix recurrence, and ties.
- Shows derived-road comparison views named Big Eye Boy, Small Road, and Cockroach Pig. These are exploratory structural approximations; validate against the specific casino/table roadmap before treating them as an exact clone.
- No side-bet inference (pairs/naturals) from B/P/T alone.
- No API call is made by the Baccarat module; it runs in the browser.
- Adds a version-matched backend copy, version 4.7.0, serving the V4.7 dashboard. Existing V4.6 data remains untouched.

HOW TO USE
1. Install dependencies using the existing requirements.txt.
2. Configure a private .env with API credentials only if using the general-domain workspace.
3. Run: python nexus_arc_v4_7_server.py
4. Open http://127.0.0.1:8787 and use section “09 · Baccarat Roadmap Lab”.
5. Paste historical results in chronological order, e.g. B P B B P T P.

IMPORTANT LIMITATIONS
- Roadmaps are records/classifications of past results, not reliable predictors of the next hand.
- The derived-road drawings are simplified visual diagnostics and may differ from a casino's full official road logic in edge cases. Do not use them for operational reconciliation until independently verified.
- No real-world baccarat dataset, casino feed, or betting profitability test was run.
- Backtest any proposed predictive feature prospectively and compare against the proper base-rate baseline; don't promote it based on an in-sample streak.
- Avoid Martingale or any staking system that assumes a loss must be recovered.

TEST
node test_nexus_arc_v4_7_baccarat.js NEXUS_ARC_V4_7_BACCARAT_ROADMAP_LAB.html
