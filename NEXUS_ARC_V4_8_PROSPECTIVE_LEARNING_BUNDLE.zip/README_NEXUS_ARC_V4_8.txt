NEXUS ARC V4.8 — PROSPECTIVE LEARNING & EVIDENCE GATE
Release candidate: 4.8.0
Date: 11 October 2026

PURPOSE
V4.8 adds a prospective forecast ledger and evidence/coverage gates to the existing NEXUS ARC workspace. It is designed to make evaluation more auditable, not to claim universal intelligence or guaranteed prediction.

PACKAGE CONTENTS
- NEXUS_ARC_V4_8_PROSPECTIVE_LEARNING.html : self-contained dashboard, including V4.7 Baccarat Roadmap Lab and V4.8 learning panel
- nexus_arc_v4_8_server.py              : localhost FastAPI gateway
- nexus_arc_v4_8_learning.py            : standard-library learning/evaluation ledger core
- test_nexus_arc_v4_8_learning.py        : unit tests for validation, scoring, ledger integrity, and challenger gates
- test_nexus_arc_v4_8_api.py             : isolated API lifecycle and cross-origin mutation tests
- test_nexus_arc_v4_8_mock.js             : mock-DOM browser-logic smoke test
- requirements.txt                       : runtime/test dependencies
- start_nexus_arc_v4_8.bat                : Windows launcher
- V4_8_TEST_REPORT.txt                   : test evidence and limitations
- NEXUS_ARC_V4_8_SHA256SUMS.txt           : hashes of release files

WINDOWS QUICK START
1. Extract this ZIP to a folder you can write to.
2. Install Python 3.11+ (Python 3.12 recommended) if not already installed.
3. Open Command Prompt in the extracted folder and run:
   py -m pip install -r requirements.txt
4. Double-click start_nexus_arc_v4_8.bat, or run:
   py nexus_arc_v4_8_server.py
5. Open http://127.0.0.1:8787 in your browser.
6. In section 13, use Refresh + Verify. Create a forecast BEFORE the outcome is known; only later record the observed outcome.

LEARNING WORKFLOW
1. Create a forecast with an event key, model ID, probability distribution, baseline, rationale, and source/freshness metadata.
2. The server timestamps and appends the forecast to the learning ledger. Coverage or confidence problems can trigger ABSTAIN.
3. After the event occurs, record the outcome once for that event key.
4. Record a post-outcome error review as a human hypothesis. The review is not automatically a proven cause.
5. Verify the hash chain and inspect paired champion/challenger summaries. Promotion is never automatic.
6. Back up the data folder before upgrades. Default persistent data is stored in ./nexus_v4_8_data/ next to the server.

SECURITY / CONFIGURATION
- The server binds to 127.0.0.1 by default. Do not expose it to a public network without a separate security review.
- State-changing browser requests with a mismatched Origin are rejected; JSON request bodies are size-limited and API responses are marked no-store.
- Optional AI analysis needs OPENAI_API_KEY and NEXUS_MODEL configured as environment variables or in a private .env file. Do not share .env or API keys.
- External feeds are not automatically universal. Only configured sources and source checks for a given task are covered.
- The SHA-256 hash chain is tamper-evident for changes within the chain; it is not a digital signature, identity proof, or protection against an attacker who can rewrite the entire ledger and its hashes.

IMPORTANT LIMITATIONS
- This release has not been validated against all real-world domains, all browsers, live external feeds, or real casino roadmaps.
- The Baccarat Roadmap Lab summarizes historical P/B/T sequences. Derived roads are exploratory approximations and need comparison against the exact table/casino rules before operational use.
- Baccarat outcomes are not made predictable by streaks, chop, or derived-road patterns. No betting edge or profitability is claimed.
- Synthetic/mock tests are not evidence of live-world predictive accuracy.
- The server-side cross-domain challenger ledger does not auto-promote models. The pre-existing browser-local sequence learner has a separate gated profile-selection flow that can switch its active profile only after its prospective trial criteria; this is not model-weight learning and has not been shown to improve real-world baccarat outcomes.
- The prospective comparison gate is a review gate only. Passing it is not proof of generalization; evaluate sample size, paired confidence intervals, data leakage, multiple comparisons, and regime changes.

TROUBLESHOOTING
- If port 8787 is busy, set NEXUS_PORT to another local port before starting and open that port in the browser.
- If the dashboard says the API is unavailable, keep the terminal window running and confirm the URL is http://127.0.0.1:8787 rather than opening the HTML file with file://.
- The browser mock test intentionally disables network requests. It does not replace a real Chrome/Edge visual test.
