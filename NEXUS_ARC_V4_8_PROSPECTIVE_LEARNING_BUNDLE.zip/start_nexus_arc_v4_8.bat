@echo off
cd /d "%~dp0"
py nexus_arc_v4_8_server.py
pause
