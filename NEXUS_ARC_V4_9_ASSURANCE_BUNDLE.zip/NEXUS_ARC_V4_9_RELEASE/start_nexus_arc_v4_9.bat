@echo off
cd /d "%~dp0"
py nexus_arc_v4_9_server.py
pause
