import os, tempfile, unittest, sys
from pathlib import Path
# Isolate server-side state from the user's normal data directory before importing app.
TEMP_DATA = tempfile.mkdtemp(prefix='nexus_v49_api_test_')
os.environ['NEXUS_DATA_DIR'] = TEMP_DATA
os.environ['NEXUS_DASHBOARD_PATH'] = str(Path(__file__).with_name('NEXUS_ARC_V4_9_ASSURANCE_WORKSPACE.html'))
os.environ['NEXUS_PORT'] = '18787'
sys.path.insert(0, str(Path(__file__).parent))
from fastapi.testclient import TestClient
import nexus_arc_v4_9_server as server

class AssuranceAPITests(unittest.TestCase):
    def setUp(self):
        server.assurance_ledger.clear()
        server.learning_ledger.clear()
        server.evaluation_records.clear()
        server.state['events']=[]
        server.state['feed_status']={}
        server.state['last_poll_at']=None
        server.feed_sources=[]
        server.atomic_save(server.ASSURANCE_LEDGER_PATH, server.assurance_ledger)
        server.atomic_save(server.FEEDS_PATH, [])
        server.atomic_save(server.LEARNING_LEDGER_PATH, server.learning_ledger)
        server.atomic_save(server.EVAL_PATH, server.evaluation_records)
        self.client=TestClient(server.app)

    def test_status_and_integrity_empty_ledger(self):
        r=self.client.get('/api/assurance/status'); self.assertEqual(r.status_code,200)
        self.assertEqual(r.json()['coverage']['overall'],'NOT_CONFIGURED')
        self.assertTrue(r.json()['integrity']['valid'])
        self.assertEqual(self.client.get('/api/assurance/verify').json()['checked'],0)

    def test_configured_recent_feed_reports_monitor_down_without_task(self):
        from datetime import datetime, timezone
        recent=datetime.now(timezone.utc).isoformat().replace('+00:00','Z')
        url='https://feed.example/rss'
        server.feed_sources=[{'name':'Example feed','url':url,'format':'auto'}]
        server.atomic_save(server.FEEDS_PATH, server.feed_sources)
        server.state['feed_status']={url:{'last_check_at':recent,'last_success_at':recent,'latest_source_timestamp':recent,'items_seen':1,'new_items':0}}
        server.monitor_task=None
        r=self.client.get('/api/assurance/status')
        self.assertEqual(r.status_code,200)
        self.assertEqual(r.json()['coverage']['overall'],'MONITOR_DOWN')
        self.assertFalse(r.json()['coverage']['monitor_running'])

    def test_meta_and_health_publish_assurance_fields(self):
        meta=self.client.get('/api/meta').json()
        self.assertEqual(meta['server_version'],'4.9.0')
        self.assertEqual(meta['assurance_status_url'],'/api/assurance/status')
        health=self.client.get('/api/health').json()
        self.assertIn('assurance_ledger_integrity',health)
        self.assertIn('assurance_write_gate',health)

    def test_evidence_and_incident_flow(self):
        ev=self.client.post('/api/assurance/evidence',json={'domain':'technology','source_title':'Official release notes','source_url':'https://example.com/release','claim':'Version changed','excerpt':'operator-entered excerpt','source_kind':'official'})
        self.assertEqual(ev.status_code,200,ev.text)
        eid=ev.json()['evidence_id']
        inc=self.client.post('/api/assurance/incidents',json={'domain':'technology','category':'source_gap','symptom':'Missed update','hypothesis':'Feed was stale','corrective_action':'Add a release-note source','evidence_ids':[eid],'cause_status':'hypothesis'})
        self.assertEqual(inc.status_code,200,inc.text)
        stat=self.client.get('/api/assurance/status').json()
        self.assertEqual(stat['evidence_count'],1); self.assertEqual(stat['incident_count'],1)
        self.assertTrue(self.client.get('/api/assurance/verify').json()['valid'])

    def test_evidence_rejects_non_http_url(self):
        r=self.client.post('/api/assurance/evidence',json={'source_title':'bad','source_url':'javascript:alert(1)','claim':'x'})
        self.assertEqual(r.status_code,400)

    def test_experiment_preregister_results_and_no_auto_promotion(self):
        reg=self.client.post('/api/assurance/experiments',json={'domain':'coding_engineering','champion_id':'A','challenger_id':'B','metric_name':'error_rate','direction':'lower_better','holdout_description':'untouched final test set','minimum_effect':0.01,'hypothesis':'B reduces errors by at least one percent'})
        self.assertEqual(reg.status_code,200,reg.text); xid=reg.json()['experiment_id']
        payload={'pairs':[{'case_id':'c1','champion_score':1.0,'challenger_score':0.7},{'case_id':'c2','champion_score':0.9,'challenger_score':0.6}]}
        r=self.client.post(f'/api/assurance/experiments/{xid}/results',json=payload)
        self.assertEqual(r.status_code,200,r.text); self.assertEqual(r.json()['gate'],'INSUFFICIENT_EVIDENCE'); self.assertFalse(r.json()['auto_promotion'])
        r2=self.client.post(f'/api/assurance/experiments/{xid}/results',json=payload)
        self.assertEqual(r2.status_code,409)

    def test_duplicate_case_ids_rejected(self):
        reg=self.client.post('/api/assurance/experiments',json={'domain':'science','champion_id':'A','challenger_id':'B','metric_name':'score','direction':'higher_better','holdout_description':'independent holdout set','minimum_effect':0.01,'hypothesis':'B improves scoring'})
        xid=reg.json()['experiment_id']
        pairs=[{'case_id':'c1','champion_score':1,'challenger_score':2},{'case_id':'c1','champion_score':1,'challenger_score':2}]
        r=self.client.post(f'/api/assurance/experiments/{xid}/results',json={'pairs':pairs})
        self.assertEqual(r.status_code,400)

    def test_tampered_ledger_blocks_writes(self):
        self.client.post('/api/assurance/evidence',json={'domain':'technology','source_title':'ok','source_url':'https://example.com','claim':'x'})
        server.assurance_ledger[0]['payload']['claim']='tampered'
        r=self.client.post('/api/assurance/evidence',json={'domain':'technology','source_title':'second','source_url':'https://example.org','claim':'y'})
        self.assertEqual(r.status_code,409)

if __name__=='__main__': unittest.main(verbosity=2)
