NEXUS ARC V4 — UNIVERSAL INTELLIGENCE WORKBENCH
================================================

This package separates the browser UI from the model credentials and external feed monitor.
It does NOT claim complete awareness of every event in the world. It can search on demand and
monitor only the public RSS/Atom/JSON feeds you configure.

FILES
-----
NEXUS_ARC_V4_UNIVERSAL_INTELLIGENCE.html  Dashboard UI
nexus_arc_v4_server.py                    Local backend/API/feed monitor
requirements_nexus_v4.txt                 Python packages

REQUIREMENTS
------------
- Python 3.10+ (recommended 3.11+)
- An API account/key and a model name available to that API project for AI analysis.
- Public RSS/Atom/JSON feeds if you want continuous feed monitoring. No feeds are preconfigured.
- An internet connection for model/search/feed requests.

WINDOWS SETUP
-------------
1. Put the HTML, server script and requirements file in the same folder.
2. Open PowerShell in that folder.
3. Create a virtual environment and install packages:

   py -m venv .venv
   .\.venv\Scripts\Activate.ps1
   py -m pip install -r requirements_nexus_v4.txt

4. Set server-only credentials and model. Do NOT put an API key in the HTML:

   $env:OPENAI_API_KEY = "YOUR_API_KEY"
   $env:NEXUS_MODEL = "MODEL_NAME_AVAILABLE_TO_YOUR_API_PROJECT"

   Use the exact model identifier enabled for your account. There is intentionally no
   hard-coded model assumption. The value is not saved into the dashboard or browser storage.

5. Run the local service:

   py nexus_arc_v4_server.py

6. Open http://127.0.0.1:8787/ in the browser. Keep the server process running.
7. Click “ตรวจ Backend”. If AI is not ready, the status will say what is missing.
8. Add public feed URLs as a JSON array under WORLD MONITOR, then click “บันทึก Feed”.
   Supported formats: RSS, Atom and JSON. “auto” attempts to detect JSON versus XML.
9. Click “เริ่มติดตาม” to sync feed events into the dashboard. The backend polls feeds while
   the server process is running, even if the browser tab is closed; the browser dashboard
   itself syncs only while the page remains open.

FEED CONFIG EXAMPLE (replace with feeds you trust)
-------------------------------------------------
[
  {"name":"Example RSS feed","url":"https://public.example.org/feed.xml","format":"auto"},
  {"name":"Example JSON feed","url":"https://public.example.org/events.json","format":"json"}
]
These are placeholders, not real feeds. Replace them before use.

WHAT IT CAN / CANNOT DO
-----------------------
- On-demand analysis uses the configured model; web search is enabled for relevant domains
  except creative writing and local P/B/T sequence analysis.
- Automatic monitoring only covers feeds configured by the user and accessible over public HTTP(S).
- Source timestamps, feed failures, event duplicates and data freshness are exposed rather than hidden.
- The app cannot guarantee exhaustive global event awareness. Some events are paywalled, private,
  delayed, unavailable, not indexed, or not present in configured feeds.
- Domain labels are analysis instructions/adapters, not proof of expert-level accuracy. Validate
  each domain using independent benchmarks and fresh held-out data before operational reliance.
- No live fetch or AI inference is represented as successful until the backend returns a successful
  response. Backend API keys stay in environment variables and are not sent to the browser.
- The local server binds to 127.0.0.1 only. Do not change this to 0.0.0.0 without adding
  authentication, deployment hardening, TLS, logging controls and network access restrictions.
