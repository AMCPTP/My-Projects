import json
import sys
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
import nexus_arc_v4_server as nexus


@pytest.fixture(autouse=True)
def isolate_local_state(tmp_path, monkeypatch):
    # Tests never read or mutate a real user's feed configuration or event history.
    monkeypatch.setattr(nexus, "FEEDS_PATH", tmp_path / "feed_sources.json")
    monkeypatch.setattr(nexus, "STATE_PATH", tmp_path / "world_state.json")
    fresh = {"events": [], "feed_status": {}, "last_poll_at": None, "poll_count": 0,
             "last_provider_success_at": None, "last_provider_error": None,
             "last_web_search_status": "NOT_TESTED"}
    monkeypatch.setattr(nexus, "state", fresh)
    monkeypatch.setattr(nexus, "request_times", {})
    monkeypatch.setattr(nexus, "feed_sources", [])


def test_private_and_local_feed_urls_are_rejected():
    for url in [
        "http://127.0.0.1/feed.json",
        "http://localhost/feed.xml",
        "http://192.168.1.10/feed.json",
        "file:///etc/passwd",
        "http://user:pass@example.com/feed.xml",
    ]:
        with pytest.raises(ValueError):
            nexus.reject_private_url(url)


def test_public_http_urls_are_accepted_syntactically():
    assert nexus.reject_private_url("https://example.org/feed.xml").startswith("https://")


def test_json_feed_parsing_normalizes_items():
    raw = json.dumps({"items": [{"id": "a1", "title": "Release", "summary": "Version changed", "url": "https://example.org/a1", "publishedAt": "2026-10-09T00:00:00Z"}]}).encode()
    items = nexus.parse_json_feed(raw, "Unit Feed", "https://example.org/feed.json")
    assert len(items) == 1
    assert items[0]["title"] == "Release"
    assert items[0]["text"] == "Version changed"
    assert items[0]["url"] == "https://example.org/a1"
    assert len(items[0]["fingerprint"]) == 64


def test_rss_feed_parsing():
    xml = b'''<?xml version="1.0"?><rss version="2.0"><channel><item><title>Headline</title><description>Body</description><link>https://example.org/story</link><guid>story-1</guid><pubDate>Fri, 09 Oct 2026 00:00:00 GMT</pubDate></item></channel></rss>'''
    items = nexus.parse_xml_feed(xml, "Unit RSS", "https://example.org/feed.xml")
    assert len(items) == 1
    assert items[0]["title"] == "Headline"
    assert items[0]["url"] == "https://example.org/story"
    assert items[0]["text"] == "Body"


def test_health_and_static_dashboard_routes():
    with TestClient(nexus.app) as client:
        home = client.get("/")
        assert home.status_code == 200
        assert "NEXUS ARC V4" in home.text
        health = client.get("/api/health")
        assert health.status_code == 200
        info = health.json()
        assert info["version"] == "4.0.0"
        assert "coverage_note" in info
        events = client.get("/api/events")
        assert events.status_code == 200
        assert isinstance(events.json()["events"], list)


def test_feed_endpoint_blocks_loopback():
    with TestClient(nexus.app) as client:
        response = client.post("/api/feeds", json={"feeds": [{"name": "bad", "url": "http://127.0.0.1:8080/feed.json", "format": "json"}]})
        assert response.status_code == 400


def test_no_provider_credentials_never_returns_fake_analysis():
    if nexus.API_KEY and nexus.MODEL:
        pytest.skip("Live provider credentials are configured; avoids a real paid API request.")
    with TestClient(nexus.app) as client:
        response = client.post("/api/analyze", json={"domain": "general_research", "task": "Verify a fact"})
        assert response.status_code == 503
        assert "No analysis was generated" in response.json()["detail"] or "not configured" in response.json()["detail"]


def test_analysis_route_uses_mock_provider_and_returns_only_provider_citations(monkeypatch):
    from types import ModuleType, SimpleNamespace
    import sys

    class FakeResponses:
        async def create(self, **kwargs):
            assert kwargs["model"] == "unit-test-model"
            assert kwargs.get("tools") == [{"type": "web_search"}]
            structured = {
                "summary": "สรุปที่ได้จาก provider จำลอง",
                "verified_facts": ["ข้อเท็จจริงจำลอง"],
                "analysis_and_inference": ["ข้ออนุมานจำลอง"],
                "uncertainties": ["ยังต้องตรวจซ้ำ"],
                "missing_information": ["ข้อมูลต้นทางเพิ่มเติม"],
                "next_steps": ["เปิดอ่านแหล่งอ้างอิง"],
                "coverage_note": "ทดสอบด้วย provider จำลองเท่านั้น",
            }
            annotation = SimpleNamespace(type="url_citation", url="https://example.org/source", title="Example Source")
            content = SimpleNamespace(annotations=[annotation])
            return SimpleNamespace(
                output_text=json.dumps(structured, ensure_ascii=False),
                output=[SimpleNamespace(type="web_search_call"), SimpleNamespace(type="message", content=[content])],
                id="resp-unit-test",
            )

    class FakeClient:
        def __init__(self, **kwargs):
            self.responses = FakeResponses()

    monkeypatch.setattr(nexus, "API_KEY", "unit-test-key")
    monkeypatch.setattr(nexus, "MODEL", "unit-test-model")
    fake_module = ModuleType("openai")
    fake_module.AsyncOpenAI = FakeClient
    monkeypatch.setitem(sys.modules, "openai", fake_module)
    with TestClient(nexus.app) as client:
        response = client.post("/api/analyze", json={"domain": "general_research", "task": "ทดสอบ", "use_web_search": True})
        assert response.status_code == 200, response.text
        result = response.json()
        assert "สรุปที่ได้จาก provider จำลอง" in result["answer"]
        assert result["web_search_used"] is True
        assert result["sources"] == [{"title": "Example Source", "url": "https://example.org/source"}]
        assert "ยังต้องตรวจซ้ำ" in result["uncertainties"]


def test_geojson_nested_properties_and_epoch_timestamp():
    raw = json.dumps({"features": [{"id": "eq-1", "properties": {"title": "M4.2 earthquake", "place": "Near coast", "time": 1791504000000, "url": "https://example.org/quake/1"}}]}).encode()
    items = nexus.parse_json_feed(raw, "Geo Feed", "https://example.org/feed.geojson")
    assert len(items) == 1
    assert items[0]["title"] == "M4.2 earthquake"
    assert items[0]["text"] == "Near coast"
    assert items[0]["timestamp"].endswith("Z")
    assert items[0]["timestamp_kind"] == "source_epoch"


def test_invalid_source_timestamp_is_marked_as_observed_fallback():
    timestamp, kind, original = nexus.normalize_timestamp("not-a-time")
    assert timestamp.endswith("Z")
    assert kind == "observed_at_fallback"
    assert original == "not-a-time"
