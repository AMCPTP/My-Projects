# NEXUS ARC V5.10.0 — P/B-Only Analyst Audit

## Scope

This audit covers the P/B result-entry and analysis paths modified for V5.10.0: live history normalization, the rapid analyst, the historical pattern/roadmap parser, walk-forward audit input, and server/dashboard release wiring. Tie is not an outcome in these workflows. Unsupported tokens, including `T` and `TIE`, are ignored rather than converted into a P/B outcome. The separate payout/EV tools that model an explicit Tie side bet remain isolated and do not feed the P/B sequence analyzer.

## Changes that address the prior stress findings

1. **Short sequence:** the rapid analyst requires at least 12 accepted P/B results before it may describe historical tilt. Below 12 it returns `WAIT_INSUFFICIENT_DATA`, `lean=NEUTRAL`, `score=null`, `probability=null`, and `edge_claim=false`.
2. **Alternation:** detects 4/6-result alternation as a description only. It does not add points to either side.
3. **2-2 blocks:** detects PPBB/BBPP as a historical shape only. Balanced 2-2 examples remain neutral.
4. **Streaks:** run length is reported, but it never directly adds directional points. A long one-sided sample may show a historical P-share tilt only if its Wilson 95% interval falls outside the fixed reference; this is not a next-hand forecast.
5. **Shift candidate:** compares the most recent 12 accepted P/B results with the prior 12 and only runs when at least 24 P/B results exist. A shift is a candidate, not a verified new regime or forecast.
6. **Malformed / unsupported tokens:** rapid analyst and roadmap parser count ignored input tokens. Compact strings containing T are filtered to P/B, with the ignored count reported. Unknown tokens are not silently interpreted as results.
7. **Long alternation / transition trap:** transition counts and repeated suffixes are retained as descriptive context only; they cannot drive the reported direction. Long `PB` alternation remains neutral rather than receiving a transition-based P/B lean.

## Scenario examples from the V5.10.0 engine

| Scenario | Input | Engine output | Interpretation |
|---|---|---|---|
| 1. Insufficient sample | `PBPBPB` | `WAIT_INSUFFICIENT_DATA`, `NEUTRAL`, `score=null` | Six P/B results are enough to describe alternation, not enough to report historical tilt. |
| 2. Alternation | `PBPBPBPBPBPB` | `NEUTRAL`, `NO_CLEAR_TILT` | Pattern found; it does not imply the next result must alternate. |
| 3. 2-2 | `PPBBPPBBPPBB` | `NEUTRAL`, `NO_CLEAR_TILT` | The 2-2 pattern is found, but no direction is inferred from it. |
| 4. Long streak | `PPPPPPPPPPPP` | `P` historical tilt, `LIMITED_SAMPLE`, no probability | Wilson interval indicates the historical P-share differs from the reference in this sample. This is not a next-hand forecast and is not a bet signal. |
| 5. Regime shift | `BBBBBBBBBBBBPPPPPPPPPPPP` | `SHIFT_CANDIDATE`, overall `NEUTRAL` | Two contrasting 12-result windows are flagged for review; this does not prove a regime change. |
| 7. Long alternation | `PB` repeated 50 times (100 results) | `NEUTRAL`, `NO_CLEAR_TILT` | Transition/road shape does not add a directional score. |
| Tie removed | `PBTBPBTB` | 6 accepted P/B results, 2 ignored tokens, `WAIT_INSUFFICIENT_DATA` | Tie tokens are not recorded as outcomes in the P/B analysis path. |
| Malformed input | `P, X, B, ?` | 2 accepted P/B results, 2 ignored tokens | Input quality is made visible instead of silently claiming a clean sequence. |

## Verification results

- Python regression suite: **45 passed**.
- Pattern engine tests: **15 passed**.
- Brain import guard tests: **5 passed**.
- Rapid analyst engine tests: **13 passed**.
- Total regression/engine tests: **78 passed**. The separate roadmap parser suite adds **3/3 passed** checks.
- Rapid analyst invariant test enumerates every binary P/B sequence of lengths 0 through 10: **2,047 sequences checked**.
- Python compile check: passed.
- JavaScript syntax checks: passed for both engines and all 11 inline JavaScript blocks in the dashboard.
- Roadmap parser tests: 3/3 passed (compact Tie token, malformed tokens, and named P/B outcomes).
- FastAPI regression tests exercise health/meta, dashboard asset allowlist, version guard text, and existing learning/ledger invariants.

## Limits and honesty notes

- This build did **not** run a full end-to-end browser session on the user's Windows machine. Launch and verify `/api/health` locally after installation.
- Passing software tests shows that the implemented rules and invariants behave as tested. It does **not** show that baccarat outcomes can be predicted reliably, that the model beats a properly held-out baseline, or that a positive expected value exists.
- The Wilson interval here describes one historical P/B sequence and is not clustered by shoe/session. Dependence within a shoe and repeated pattern searching can make nominal intervals overconfident. Therefore the validation gate remains `WAIT`.
- P/B results alone do not identify the cards remaining in a shoe. No exact remaining-card or card-counting model is claimed.
- The prior Brain schema and pattern-ledger key are retained for migration compatibility. Old saved Tie entries are filtered from the live P/B history when loaded; a pending pattern forecast whose raw prefix no longer matches that normalized history is cancelled without scoring.
