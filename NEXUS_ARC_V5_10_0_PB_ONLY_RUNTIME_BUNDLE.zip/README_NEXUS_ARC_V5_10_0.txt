NEXUS ARC V5.10.0 — P/B-Only Evidence-First Analyst

PURPOSE
This release removes Tie from the main baccarat result-entry, roadmap, rapid analysis, and prospective pattern workflow. The analysis path accepts Player (P) and Banker (B) only. Unsupported tokens, including T/TIE, are ignored and reported in the rapid analyst and roadmap panels. Separate payout/EV calculators for an explicitly selected Tie side bet remain separate tools and do not feed the P/B pattern analysis.

CHANGES
- Main live result buttons now accept P/B only. Saved history and imported Brain history are normalized to P/B for the live sequence; existing learner schema remains compatible.
- Roadmap input, Big Road rendering, bead plate, derived roads, window statistics and uncertainty text now analyze P/B only. Unsupported tokens are counted rather than treated as outcomes.
- Rapid analyst requires at least 12 accepted P/B results before reporting a historical tilt. Under 12 results it returns WAIT, neutral lean, null score, and no probability.
- A historical tilt is reported only when the Wilson 95% interval for the observed P-share does not overlap the fixed fresh-shoe reference P-share. This is a descriptive historical comparison, not a next-hand forecast.
- Alternation, 2-2, streaks, transition counts, suffix matches, and shift candidates are context only; they do not add directional points. Shift comparison uses 12 recent vs 12 prior results and requires at least 24 P/B outcomes.
- Unknown tokens are reported; result schema is consistent between WAIT and historical-read states.
- The independent validation gate remains WAIT until prospective predictions, separated by session, beat suitable baselines and replicate independently.

WHAT THIS DOES NOT CLAIM
- Road patterns do not guarantee continuation or reversal.
- P/B history alone does not reveal the cards remaining in a shoe.
- A Wilson interval on one historical sequence is not a shoe-clustered interval and does not establish future predictability.
- No positive EV or betting edge is claimed. The app has not been tested end-to-end in the user's Windows browser by this build process.

SAFE UPGRADE (WINDOWS)
1. Back up the whole NEXUS folder, .env, nexus_v5_0_data (if present), and Brain exports.
2. Extract this ZIP into the existing installation folder and overwrite matching application files. Files are at the ZIP root. Do not delete .env or user data.
3. Run start_nexus_arc_v5_9.bat. It should confirm server version 5.10.0 and dashboard NEXUS_ARC_V5_10_0_PB_ONLY_ANALYST_DESK.html before opening a browser.
4. Verify http://127.0.0.1:8787/api/health reports version 5.10.0 and the exact dashboard filename.
5. Use only P/B in live result entry and roadmap input. Any unsupported tokens are ignored; the rapid analyst/roadmap panel reports how many were skipped.

REQUIREMENTS / TESTS
Python 3.11+ and dependencies in requirements.txt.
Run: py -3 -m pip install -r requirements.txt
Run: py -3 -m unittest -v test_nexus_arc_v5_10_0_regression.py
Run: node test_nexus_arc_v5_9_5_pattern_engine.js
Run: node test_nexus_arc_v5_10_0_brain_import_guard.js
Run: node test_nexus_arc_v5_10_0_rapid_analyst_engine.js
Run: node test_nexus_arc_v5_10_0_roadmap_parser.js

COMPATIBILITY
- Backend version: 5.10.0.
- Legacy Brain learner schema stays NEXUS-ARC-V5.9.2-CONTEXT-ISOLATION-INTEGRITY for migration compatibility. Imported and stored live result history is normalized to P/B only.
- The existing prospective pattern ledger key/schema is retained to avoid deleting prior local records. A pending forecast may be cancelled if its old prefix contains unsupported tokens and no longer matches the normalized P/B history.
- Separate EV calculators are not inputs to the pattern engine.

LIMITATIONS
The Linux build environment cannot execute Windows PowerShell process management or a full browser session on the user's computer. Regression and JavaScript tests run locally in this build environment; verify /api/health after launch. The previous Brain export audit and metrics CSV remain historical review artifacts and do not promote model weights.
