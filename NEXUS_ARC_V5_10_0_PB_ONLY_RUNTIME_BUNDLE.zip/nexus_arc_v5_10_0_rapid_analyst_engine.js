/* NEXUS ARC V5.10.0 Rapid Analyst Engine
 * P/B-only descriptive diagnostics. Patterns and transition rates are not next-hand predictions.
 * Tie is unsupported in this analysis workflow and is counted as an ignored input item.
 */
(function(root){
  'use strict';
  const VERSION='5.10.0';
  const BASELINE=Object.freeze({P:0.49317561922276104,B:0.5068243807772389});
  const MIN_ANALYSIS_PB=12;
  const WINDOWS=Object.freeze([6,12,20]);
  function token(v){const s=String(v==null?'':v).trim().toUpperCase();if(s==='P'||s==='PLAYER')return'P';if(s==='B'||s==='BANKER')return'B';return null;}
  function parse(input){
    const out=[];let ignored=0,rawCount=0;
    const accept=(v)=>{const s=String(v==null?'':v).trim().toUpperCase();if(!s)return;
      if(s==='P'||s==='PLAYER'){out.push('P');rawCount++;return;}
      if(s==='B'||s==='BANKER'){out.push('B');rawCount++;return;}
      // Tie is deliberately not part of this analysis. Report it as ignored, never as a result.
      rawCount++;ignored++;
    };
    if(Array.isArray(input)){for(const v of input)accept(v&&typeof v==='object'?(v.result??v.outcome??''):v);return{outcomes:out,raw_count:rawCount,ignored_count:ignored};}
    const s=String(input==null?'':input).trim().toUpperCase();if(!s)return{outcomes:[],raw_count:0,ignored_count:0};
    const compact=s.replace(/[\s,;|/\\._:-]+/g,'');
    if(/^[PBT]+$/.test(compact)){for(const ch of compact)accept(ch);return{outcomes:out,raw_count:rawCount,ignored_count:ignored};}
    const pieces=s.split(/[\s,;|/\\._:-]+/).filter(Boolean);
    for(const piece of pieces){if(/^[PBT]+$/.test(piece)){for(const ch of piece)accept(ch);continue;}const t=token(piece);if(t){out.push(t);rawCount++;}else{rawCount++;ignored++;}}
    return{outcomes:out,raw_count:rawCount,ignored_count:ignored};
  }
  function normalizeOutcomes(input){return parse(input).outcomes;}
  function pbOnly(input){return normalizeOutcomes(input);}
  function runsOf(seq){const runs=[];for(let i=0;i<seq.length;i++){const v=seq[i],last=runs[runs.length-1];if(last&&last.side===v){last.length++;last.end=i;}else runs.push({side:v,length:1,start:i,end:i});}return runs;}
  function pShare(seq){return seq.length?seq.filter(x=>x==='P').length/seq.length:null;}
  function rateCI(successes,n){if(!n)return null;const z=1.959963984540054,p=successes/n,z2=z*z,den=1+z2/n,center=(p+z2/(2*n))/den,half=z*Math.sqrt((p*(1-p)/n)+(z2/(4*n*n)))/den;return{low:Math.max(0,center-half),high:Math.min(1,center+half)};}
  function summarizeWindow(seq,n){const x=seq.slice(-n),runs=runsOf(x),flips=x.slice(1).filter((v,i)=>v!==x[i]).length,ps=pShare(x);return{window:n,n:x.length,P:x.filter(x=>x==='P').length,B:x.filter(x=>x==='B').length,p_share:ps,b_share:ps===null?null:1-ps,flip_count:flips,flip_rate:x.length>1?flips/(x.length-1):null,max_run:runs.reduce((m,r)=>Math.max(m,r.length),0),sequence:x.join('')};}
  function suffixRunPattern(lengths){const list=[
    {id:'RUN_SHAPE_1_2',seq:[1,2],label:'จังหวะ 1-2',meaning:'สอง run ท้ายยาว 1 แล้ว 2 ผล; เป็นรูปทรงย้อนหลัง ไม่ใช่ forecast'},
    {id:'RUN_SHAPE_1_3',seq:[1,3],label:'จังหวะ 1-3',meaning:'สอง run ท้ายยาว 1 แล้ว 3 ผล; เป็นรูปทรงย้อนหลัง ไม่ใช่ forecast'},
    {id:'RUN_SHAPE_2_1_2',seq:[2,1,2],label:'จังหวะ 2-1-2',meaning:'สาม run ท้ายยาว 2, 1, 2 ผล; เป็นรูปทรงย้อนหลัง ไม่ใช่ forecast'},
    {id:'RUN_SHAPE_3_1',seq:[3,1],label:'จังหวะ 3-1',meaning:'สอง run ท้ายยาว 3 แล้ว 1 ผล; เป็นรูปทรงย้อนหลัง ไม่ใช่ forecast'},
    {id:'RUN_SHAPE_2_2',seq:[2,2],label:'จังหวะ 2-2',meaning:'สอง run ท้ายยาว 2 ผล; เป็นรูปทรงย้อนหลัง ไม่ใช่ forecast'}];
    return list.filter(p=>lengths.length>=p.seq.length&&p.seq.every((v,i)=>lengths[lengths.length-p.seq.length+i]===v));}
  function classifyAll(seq,runs){const out=[];if(seq.length<4)out.push({id:'WARMUP',label:'ข้อมูลยังไม่พอ',meaning:'มีผล P/B น้อยกว่า 4 รายการ'});
    if(seq.length>=4){const t=seq.slice(-4),alt=t.every((v,i)=>i===0||v!==t[i-1]);if(alt)out.push({id:'ALTERNATION_4',label:'สลับฝั่ง 4 ผล',meaning:'สี่ผลท้ายสลับ P/B ทุกช่วง'});if(t[0]===t[1]&&t[2]===t[3]&&t[0]!==t[2])out.push({id:'TWO_BY_TWO',label:'กลุ่มละ 2 ผล',meaning:'สี่ผลท้ายเป็น PPBB หรือ BBPP'});}
    if(seq.length>=6){const t=seq.slice(-6);if(t.every((v,i)=>i===0||v!==t[i-1]))out.push({id:'ALTERNATION_6',label:'สลับฝั่ง 6 ผล',meaning:'หกผลท้ายสลับ P/B ทุกช่วง'});}
    const run=runs[runs.length-1]?.length||0;if(run>=2)out.push({id:'CURRENT_RUN',label:run>=5?'Streak ยาว ≥ 5':run>=3?'Streak ≥ 3':'คู่ซ้ำท้าย',meaning:`ผลฝั่ง ${seq[seq.length-1]||'—'} ต่อเนื่อง ${run} ครั้ง`,run_length:run});
    out.push(...suffixRunPattern(runs.map(r=>r.length)));if(!out.length)out.push({id:'MIXED',label:'รูปแบบผสม',meaning:'ยังไม่ตรงเกณฑ์เฉพาะที่กำหนด'});return out;}
  function transitionStats(seq){const c={P:{P:0,B:0},B:{P:0,B:0}};for(let i=1;i<seq.length;i++)c[seq[i-1]][seq[i]]++;return['P','B'].map(from=>{const n=c[from].P+c[from].B;return{from,n,to_P:c[from].P,to_B:c[from].B,p_to_P:n?c[from].P/n:null,p_to_B:n?c[from].B/n:null,ci_P:rateCI(c[from].P,n),ci_B:rateCI(c[from].B,n),use_for_direction:false};});}
  function entropy(seq){if(!seq.length)return null;const p=seq.filter(x=>x==='P').length/seq.length,b=1-p,h=v=>v>0?-v*Math.log2(v):0;return h(p)+h(b);}
  function suffixMatches(seq){const out=[],n=seq.length;for(const k of[2,3,4,5]){if(n<2*k+1)continue;const suffix=seq.slice(n-k).join(''),target=n-k;let p=0,b=0,occ=0;for(let i=0;i+k<target;i++)if(seq.slice(i,i+k).join('')===suffix){const next=seq[i+k];if(next==='P')p++;else b++;occ++;}out.push({length:k,suffix,occurrences:occ,following_P:p,following_B:b,p_share:occ?p/occ:null,decision:occ>=10?'DESCRIPTIVE_ONLY_SAMPLE_AVAILABLE':'TOO_FEW_MATCHES',use_for_direction:false});}return out;}
  function readObservedTilt(seq){const n=seq.length,pn=seq.filter(x=>x==='P').length,ps=n?pn/n:null,ci=rateCI(pn,n);if(n<MIN_ANALYSIS_PB)return{lean:'NEUTRAL',score:null,strength:'NONE',ci,observed_p_share:ps,evidence:'INSUFFICIENT_SAMPLE'};if(ci&&ci.low>BASELINE.P)return{lean:'P',score:Number((ps-BASELINE.P).toFixed(3)),strength:n>=40?'STRONGER_SAMPLE':'LIMITED_SAMPLE',ci,observed_p_share:ps,evidence:'HISTORICAL_P_SHARE_CI_ABOVE_REFERENCE'};if(ci&&ci.high<BASELINE.P)return{lean:'B',score:Number((ps-BASELINE.P).toFixed(3)),strength:n>=40?'STRONGER_SAMPLE':'LIMITED_SAMPLE',ci,observed_p_share:ps,evidence:'HISTORICAL_P_SHARE_CI_BELOW_REFERENCE'};return{lean:'NEUTRAL',score:Number((ps-BASELINE.P).toFixed(3)),strength:'NO_CLEAR_TILT',ci,observed_p_share:ps,evidence:'CI_OVERLAPS_REFERENCE'};}
  function analyze(input){const parsed=parse(input),pb=parsed.outcomes,n=pb.length,runs=runsOf(pb),run=runs[runs.length-1]||null,windows=WINDOWS.map(w=>summarizeWindow(pb,w)),pN=pb.filter(x=>x==='P').length,bN=pb.filter(x=>x==='B').length;
    const recent=n>=24?pb.slice(-12):[],prior=n>=24?pb.slice(-24,-12):[],prev=pShare(prior),curr=pShare(recent),delta=prev===null||curr===null?null:curr-prev,shiftStatus=delta===null?'INSUFFICIENT_DATA':Math.abs(delta)>=.25?'SHIFT_CANDIDATE':'NO_LARGE_SHIFT_DETECTED';
    const transitions=transitionStats(pb),h20=entropy(pb.slice(-20)),patterns=classifyAll(pb,runs),matches=suffixMatches(pb),observed=readObservedTilt(pb);
    const reasoning=[];if(n<MIN_ANALYSIS_PB)reasoning.push(`ข้อมูล P/B ${n} ผล; เกณฑ์ขั้นต่ำ ${MIN_ANALYSIS_PB} ผลสำหรับสรุป historical tilt ยังไม่ครบ`);else if(observed.lean==='NEUTRAL')reasoning.push('ช่วง Wilson 95% ของสัดส่วน P ย้อนหลังยังคร่อมค่าอ้างอิง; ไม่สรุปว่าเอนฝั่งอย่างมีหลักฐาน');else reasoning.push(`พบ historical ${observed.lean} tilt ในสัดส่วนย้อนหลังเมื่อเทียบค่าอ้างอิง; ไม่ใช่การทำนายผลถัดไป`);
    if(shiftStatus==='SHIFT_CANDIDATE')reasoning.push(`สัดส่วน P ใน 12 ผลล่าสุดต่างจาก 12 ผลก่อนหน้า ${(Math.abs(delta)*100).toFixed(1)} จุดเปอร์เซ็นต์; เป็น candidate เชิงพรรณนา ไม่ยืนยัน regime ใหม่`);else if(shiftStatus==='INSUFFICIENT_DATA')reasoning.push('ต้องมีอย่างน้อย 24 ผล P/B เพื่อเทียบ 12 ผลล่าสุดกับ 12 ผลก่อนหน้า');else reasoning.push('ไม่พบความต่างอย่างน้อย 25 จุดเปอร์เซ็นต์ระหว่าง 12 ผลล่าสุดกับ 12 ผลก่อนหน้า');
    if(run&&run.length>=3)reasoning.push(`พบ streak ${run.side} ยาว ${run.length}; ไม่ให้คะแนนตามหรือสวน streak`);if(parsed.ignored_count)reasoning.push(`มี ${parsed.ignored_count} token ที่ไม่รองรับ/ถูกข้าม รวมถึง Tie; ระบบนี้รับเฉพาะ P/B และไม่ตีความ token ที่ข้ามเป็นผล`);if(matches.some(x=>x.occurrences>0&&x.occurrences<10))reasoning.push('พบ suffix ที่เกิดซ้ำไม่มาก; อัตราตามหลังเป็นเพียงข้อมูลย้อนหลังและตัวอย่างอาจทับซ้อน');
    const enough=n>=MIN_ANALYSIS_PB;const quick={mode:enough?'OBSERVED_TILT_ONLY':'WAIT_INSUFFICIENT_DATA',lean:enough?observed.lean:'NEUTRAL',score:enough?observed.score:null,strength:enough?observed.strength:'NONE',factors:[`P/B sample=${n}; minimum=${MIN_ANALYSIS_PB}`,`P share=${pN}/${n||0}${observed.ci?`; Wilson 95% CI ${(observed.ci.low*100).toFixed(1)}%–${(observed.ci.high*100).toFixed(1)}%`:''}`,'Alternation, 2-2, streaks, transition rates, and suffixes are context only; they never add directional score.'],validated:false,probability:null,edge_claim:false,note:'ผลนี้อธิบายสัดส่วนย้อนหลังเทียบค่าอ้างอิงเท่านั้น ไม่ใช่ความน่าจะเป็นของมือถัดไป ไม่ใช่สัญญาณเดิมพัน และไม่ยืนยัน EV เป็นบวก'};
    return{schema:'nexus-arc-v5.10.0-pb-only-analyst-v1',version:VERSION,data_quality:{input_items:parsed.raw_count,accepted_outcomes:n,ignored_items:parsed.ignored_count,pb_n:n,player_n:pN,banker_n:bN,unsupported_tie_removed:true,has_session_ids:false,has_card_composition:false},current_state:{last_outcome:n?pb[n-1]:null,last_non_tie:n?pb[n-1]:null,current_run_side:run?run.side:null,current_run_length:run?run.length:0,run_count:runs.length,longest_run:runs.reduce((m,r)=>Math.max(m,r.length),0),mean_run_length:runs.length?runs.reduce((s,r)=>s+r.length,0)/runs.length:null,recent_entropy_20:h20,entropy_label:h20===null?'ไม่พอ':h20<.75?'สัดส่วนเอนเอียงไปข้างหนึ่ง':h20>.95?'สัดส่วน P/B ใกล้สมดุล':'ผสม'},patterns,windows,transition_stats:transitions,recent_vs_previous_12:{recent_n:recent.length,previous_n:prior.length,recent_player_share:curr,previous_player_share:prev,delta_player_share:delta,status:shiftStatus},historical_suffix_matches:matches,forecast_assessment:{decision:enough?'OBSERVED_TILT_ONLY':'WAIT',status:'WAIT_NO_VERIFIED_CROSS_SESSION_EDGE',quick_read:quick,validation_gate:'WAIT_NO_VERIFIED_CROSS_SESSION_EDGE',baseline_reference:BASELINE,baseline_note:'ค่าอ้างอิงสำหรับ shoe ใหม่มาตรฐาน 8 สำรับ โดยคิด P/B แบบมีเงื่อนไข ไม่ใช่ความน่าจะเป็นเฉพาะ shoe ปัจจุบัน',pattern_adjustment_applied:false,why_wait:['Roadmap และแพตเทิร์นเป็นคำอธิบายอดีต ไม่ได้พิสูจน์ว่ามือถัดไปต้องตามหรือสวน','สถิติ transition และ suffix ไม่ส่งผลต่อทิศทาง','ไม่มีองค์ประกอบไพ่คงเหลือ จึงคำนวณ odds เฉพาะ shoe ปัจจุบันไม่ได้','ยังไม่มี prospective validation และ independent replication']},reasoning,methodology:{rule_order:['parse and validate P/B-only input; report unsupported tokens','describe run lengths and pattern shapes without directional score','compare 6/12/20 descriptive windows','measure transition counts with sample sizes and Wilson intervals as context only','compare 12 recent vs prior 12 only when at least 24 P/B results exist','evaluate historical P share against reference with Wilson 95% interval','require independent prospective evidence before any prediction claim'],limits:['Tie is not an outcome in this workflow; it is ignored and reported.','Observed historical tilt is not next-result probability.','Within-sequence counts may be dependent and overlapping.','Wilson intervals are descriptive row-level intervals, not shoe-clustered intervals.','No card-counting or exact composition model is used.','Validation gate remains WAIT until prospective evidence and independent replication.']}};
  }
  const api={VERSION,BASELINE,MIN_ANALYSIS_PB,WINDOWS,parse,normalizeOutcomes,pbOnly,runsOf,classifyAll,transitionStats,suffixMatches,analyze};root.NexusAnalystReasoningV510=api;if(typeof module!=='undefined'&&module.exports)module.exports=api;
})(typeof window!=='undefined'?window:globalThis);
