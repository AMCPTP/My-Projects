"""Regression tests for NEXUS ARC V5.10.0 Brain import guard + V5.9.5 pattern audit + V5.9.4 cluster-aware evaluation and legacy learner invariants context isolation, evaluation integrity, and dashboard learner regression tests.

Run from this directory with: py -3 -m unittest -v test_nexus_arc_v5_10_0_regression.py
The tests use a fresh temporary data directory and never touch a user's existing ledger.
"""
from __future__ import annotations

import os
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent
os.environ["NEXUS_DATA_DIR"] = tempfile.mkdtemp(prefix="nexus-arc-v592-tests-")
os.environ.pop("OPENAI_API_KEY", None)
os.environ.pop("NEXUS_MODEL", None)
sys.path.insert(0, str(ROOT))

from fastapi.testclient import TestClient
from pydantic import ValidationError

import nexus_arc_v5_9_server as server
import nexus_arc_v5_learning as v5_learning
from nexus_arc_v4_9_assurance import append_event, verify_chain


class DomainIsolationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.client = TestClient(server.app, base_url="http://localhost")
        cls.client.__enter__()

    @classmethod
    def tearDownClass(cls):
        cls.client.__exit__(None, None, None)

    def setUp(self):
        server.assurance_ledger.clear()
        server.learning_ledger.clear()
        server.evaluation_records.clear()
        server.request_times.clear()
        server.ASSURANCE_LEDGER_LOAD_ERROR = None
        server.LEARNING_LEDGER_LOAD_ERROR = None

    @staticmethod
    def event(seq: int, kind: str, payload: dict, day: int = 1) -> dict:
        return {
            "seq": seq,
            "event_type": kind,
            "payload": payload,
            "created_at": f"2026-10-{day:02d}T00:00:00Z",
            "event_hash": f"fixture-{seq}",
        }

    def lesson_fixture(self, incident_id: str, domain: str, evidence_id: str, evidence_domain: str | None = None, cross_domain_reusable: bool = False):
        evidence_domain = evidence_domain or domain
        return [
            self.event(1, "evidence_added", {"evidence_id": evidence_id, "domain": evidence_domain}, 1),
            self.event(2, "incident_recorded", {
                "incident_id": incident_id,
                "domain": domain,
                "symptom": f"{domain} symptom",
                "hypothesis": f"{domain} hypothesis",
                "corrective_action": f"{domain} corrective action",
                "evidence_ids": [evidence_id],
                "cross_domain_reusable": cross_domain_reusable,
            }, 2),
            self.event(3, "lesson_reviewed", {
                "incident_id": incident_id,
                "decision": "approved",
                "note": "Reviewed with a linked evidence record.",
            }, 3),
        ]

    def register_experiment(self, label: str) -> str:
        response = self.client.post("/api/assurance/experiments", json={
            "domain": "general_research",
            "champion_id": "champion-v1",
            "challenger_id": f"challenger-{label}",
            "metric_name": "log_loss",
            "direction": "lower_better",
            "holdout_description": "Independently reserved set, not used in tuning.",
            "minimum_effect": 0.001,
            "hypothesis": "The challenger reduces prediction loss on unseen cases.",
        })
        self.assertEqual(response.status_code, 200, response.text)
        return response.json()["experiment_id"]

    def test_general_requests_do_not_receive_domain_specific_lessons(self):
        finance = self.lesson_fixture("fin-1", "finance", "ev-fin")
        sports = self.lesson_fixture("sport-1", "sports", "ev-sport")
        events = finance + [dict(e, seq=e["seq"] + 3, event_hash=f"fixture-{e['seq']+3}") for e in sports]
        general = v5_learning.retrieve_lessons(events, "general_research", 10)
        self.assertEqual(general["lessons"], [])
        finance_result = v5_learning.retrieve_lessons(events, "finance", 10)
        self.assertEqual({x["incident_id"] for x in finance_result["lessons"]}, {"fin-1"})
        sports_result = v5_learning.retrieve_lessons(events, "sports", 10)
        self.assertEqual({x["incident_id"] for x in sports_result["lessons"]}, {"sport-1"})

    def test_general_lesson_is_not_shared_across_domains_without_explicit_opt_in(self):
        events = self.lesson_fixture("general-1", "general_research", "ev-general")
        result = v5_learning.retrieve_lessons(events, "finance", 5)
        self.assertEqual(result["lessons"], [])
        self.assertEqual(result["scope_blocked_general_lesson_count"], 1)

    def test_general_lesson_can_be_reused_only_after_explicit_opt_in(self):
        events = self.lesson_fixture("general-2", "general_research", "ev-general-2", cross_domain_reusable=True)
        self.assertEqual(len(v5_learning.retrieve_lessons(events, "finance", 5)["lessons"]), 1)

    def test_unrelated_evidence_cannot_support_a_lesson(self):
        bad_events = self.lesson_fixture("fin-2", "finance", "ev-sport", evidence_domain="sports")
        self.assertEqual(v5_learning.retrieve_lessons(bad_events, "finance", 5)["lessons"], [])

    def test_two_harmful_reports_quarantine_lesson(self):
        events = self.lesson_fixture("fin-3", "finance", "ev-fin")
        events.extend([
            self.event(4, "lesson_effectiveness_reviewed", {"incident_id": "fin-3", "verdict": "harmful"}, 4),
            self.event(5, "lesson_effectiveness_reviewed", {"incident_id": "fin-3", "verdict": "harmful"}, 5),
        ])
        result = v5_learning.retrieve_lessons(events, "finance", 5)
        self.assertEqual(result["lessons"], [])
        self.assertEqual(result["quarantined_pending_review_count"], 1)

    def test_unknown_domain_is_rejected_by_all_memory_write_models(self):
        invalid_cases = [
            (server.LearningForecastRequest, {"event_key": "x", "domain": "made_up", "probabilities": {"yes": .5, "no": .5}}),
            (server.EvidenceRequest, {"domain": "made_up", "source_title": "x", "source_url": "https://example.com/x", "claim": "x"}),
            (server.IncidentRequest, {"domain": "made_up", "symptom": "x", "hypothesis": "x"}),
            (server.ExperimentRegisterRequest, {"domain": "made_up", "champion_id": "a", "challenger_id": "b", "metric_name": "x", "direction": "lower_better", "holdout_description": "a holdout that is not used in tuning", "hypothesis": "this tests a candidate"}),
        ]
        for model, payload in invalid_cases:
            with self.subTest(model=model.__name__), self.assertRaises(ValidationError):
                model.model_validate(payload)

    def test_source_key_normalizes_default_ports_and_fragments(self):
        self.assertEqual(server.source_key("https://EXAMPLE.com:443/a#one"), server.source_key("https://example.com/a#two"))
        self.assertEqual(server.source_key("http://example.com:80/a"), server.source_key("http://example.com/a"))

    def test_source_key_preserves_non_default_ports_and_query(self):
        self.assertNotEqual(server.source_key("https://example.com:8443/a"), server.source_key("https://example.com/a"))
        self.assertNotEqual(server.source_key("https://example.com/a?x=1"), server.source_key("https://example.com/a?x=2"))

    def test_evidence_cannot_link_to_evaluation_from_another_domain(self):
        server.evaluation_records.append({"evaluation_id": "ev-sports", "domain": "sports"})
        response = self.client.post("/api/assurance/evidence", json={
            "domain": "finance", "source_title": "Market notice", "source_url": "https://example.com/notice",
            "claim": "An example claim", "related_evaluation_id": "ev-sports",
        })
        self.assertEqual(response.status_code, 400, response.text)

    def test_incident_cannot_link_to_evaluation_from_another_domain(self):
        server.evaluation_records.append({"evaluation_id": "ev-sports", "domain": "sports"})
        response = self.client.post("/api/assurance/incidents", json={
            "domain": "finance", "evaluation_id": "ev-sports", "symptom": "Bad call",
            "hypothesis": "Source information was stale", "corrective_action": "Check timestamp first",
        })
        self.assertEqual(response.status_code, 400, response.text)

    def test_incident_cannot_link_to_evidence_from_unrelated_domain(self):
        evidence = self.client.post("/api/assurance/evidence", json={
            "domain": "finance", "source_title": "Market notice", "source_url": "https://example.com/notice",
            "claim": "An example claim",
        })
        self.assertEqual(evidence.status_code, 200, evidence.text)
        evidence_id = evidence.json()["evidence_id"]
        incident = self.client.post("/api/assurance/incidents", json={
            "domain": "sports", "symptom": "Wrong score", "hypothesis": "Feed stale",
            "corrective_action": "Check official score feed", "evidence_ids": [evidence_id],
        })
        self.assertEqual(incident.status_code, 400, incident.text)

    def test_incident_refuses_forecast_link_when_learning_ledger_integrity_is_broken(self):
        forecast = self.client.post("/api/learning/forecasts", json={
            "event_key": "sequence-test-001", "domain": "sequence_pbt", "model_id": "baseline-v1",
            "role": "standalone", "probabilities": {"B": 0.46, "P": 0.45, "T": 0.09},
            "coverage": {"sources": [], "missing_critical_inputs": []},
        })
        self.assertEqual(forecast.status_code, 200, forecast.text)
        server.learning_ledger[0]["payload"]["model_id"] = "tampered-after-write"
        incident = self.client.post("/api/assurance/incidents", json={
            "domain": "sequence_pbt", "forecast_id": forecast.json()["forecast_id"],
            "symptom": "A sequence forecast was incorrect", "hypothesis": "The model may be misspecified",
            "corrective_action": "Keep claims exploratory and evaluate prospectively",
        })
        self.assertEqual(incident.status_code, 409, incident.text)

    def test_effectiveness_feedback_cannot_be_borrowed_from_another_domain(self):
        incident = self.client.post("/api/assurance/incidents", json={
            "domain": "finance", "symptom": "Wrong call", "hypothesis": "Bad source",
            "corrective_action": "Require an official primary source first",
        })
        self.assertEqual(incident.status_code, 200, incident.text)
        server.evaluation_records.append({"evaluation_id": "ev-sports", "domain": "sports"})
        response = self.client.post("/api/v5/learning/lesson-use-review", json={
            "incident_id": incident.json()["incident_id"], "verdict": "harmful",
            "evaluation_id": "ev-sports", "note": "This review belongs to a different domain.",
        })
        self.assertEqual(response.status_code, 400, response.text)

    def test_experiment_cannot_reuse_case_ids_from_prior_experiment(self):
        first_id = self.register_experiment("one")
        first = self.client.post(f"/api/assurance/experiments/{first_id}/results", json={
            "pairs": [
                {"case_id": "holdout-001", "champion_score": 0.8, "challenger_score": 0.7},
                {"case_id": "holdout-002", "champion_score": 0.9, "challenger_score": 0.8},
            ]
        })
        self.assertEqual(first.status_code, 200, first.text)
        second_id = self.register_experiment("two")
        second = self.client.post(f"/api/assurance/experiments/{second_id}/results", json={
            "pairs": [
                {"case_id": "holdout-002", "champion_score": 0.9, "challenger_score": 0.85},
                {"case_id": "holdout-003", "champion_score": 0.7, "challenger_score": 0.6},
            ]
        })
        self.assertEqual(second.status_code, 409, second.text)

    def test_diagnostics_do_not_count_a_review_from_another_domain(self):
        events = [
            self.event(1, "evidence_added", {"evidence_id": "ev-fin", "domain": "finance"}, 1),
            self.event(2, "incident_recorded", {
                "incident_id": "inc-fin", "domain": "finance", "symptom": "x",
                "hypothesis": "y", "corrective_action": "z", "evidence_ids": ["ev-fin"],
            }, 2),
            self.event(3, "lesson_reviewed", {
                "incident_id": "inc-fin", "domain": "sports", "decision": "approved",
            }, 3),
        ]
        diagnostics = v5_learning.build_diagnostics(events, [], domain="finance")
        self.assertEqual(diagnostics["approved_lesson_count"], 0)
        self.assertEqual(diagnostics["pending_review_count"], 1)

    def test_cross_domain_reuse_flag_is_only_allowed_for_general_research(self):
        response = self.client.post("/api/assurance/incidents", json={
            "domain": "finance", "symptom": "Wrong call", "hypothesis": "Context mismatch",
            "cross_domain_reusable": True,
        })
        self.assertEqual(response.status_code, 400, response.text)

    def test_effectiveness_review_requires_evaluation_that_considered_the_lesson(self):
        evidence = self.client.post("/api/assurance/evidence", json={
            "domain": "finance", "source_title": "Market notice", "source_url": "https://example.com/notice",
            "claim": "An example claim",
        })
        self.assertEqual(evidence.status_code, 200, evidence.text)
        incident = self.client.post("/api/assurance/incidents", json={
            "domain": "finance", "symptom": "Wrong call", "hypothesis": "Bad source",
            "corrective_action": "Check primary source", "evidence_ids": [evidence.json()["evidence_id"]],
        })
        self.assertEqual(incident.status_code, 200, incident.text)
        iid = incident.json()["incident_id"]
        server.evaluation_records.append({"evaluation_id": "ev-finance-not-considered", "domain": "finance", "lesson_ids_considered": []})
        response = self.client.post("/api/v5/learning/lesson-use-review", json={
            "incident_id": iid, "verdict": "helpful", "evaluation_id": "ev-finance-not-considered",
            "note": "Lesson was not included in the linked evaluation.",
        })
        self.assertEqual(response.status_code, 400, response.text)

    def test_effectiveness_review_is_linked_and_cannot_be_duplicated(self):
        evidence = self.client.post("/api/assurance/evidence", json={
            "domain": "finance", "source_title": "Market notice", "source_url": "https://example.com/notice",
            "claim": "An example claim",
        })
        iid = self.client.post("/api/assurance/incidents", json={
            "domain": "finance", "symptom": "Wrong call", "hypothesis": "Bad source",
            "corrective_action": "Check primary source", "evidence_ids": [evidence.json()["evidence_id"]],
        }).json()["incident_id"]
        server.evaluation_records.append({"evaluation_id": "ev-finance-linked", "domain": "finance", "lesson_ids_considered": [iid]})
        payload = {"incident_id": iid, "verdict": "helpful", "evaluation_id": "ev-finance-linked", "note": "The lesson was present in context and appears useful."}
        first = self.client.post("/api/v5/learning/lesson-use-review", json=payload)
        self.assertEqual(first.status_code, 200, first.text)
        second = self.client.post("/api/v5/learning/lesson-use-review", json=payload)
        self.assertEqual(second.status_code, 409, second.text)



    def test_meta_reports_v5100_and_forecast_api_persists_cluster_id(self):
        meta = self.client.get("/api/meta")
        self.assertEqual(meta.status_code, 200, meta.text)
        self.assertEqual(str(meta.json().get("version", meta.json().get("server_version", ""))), "5.10.0")
        health = self.client.get("/api/health")
        self.assertEqual(health.status_code, 200, health.text)
        self.assertEqual(health.json()["version"], "5.10.0")
        self.assertEqual(health.json()["dashboard"], "NEXUS_ARC_V5_10_0_PB_ONLY_ANALYST_DESK.html")
        self.assertTrue(health.json()["dashboard_path"].endswith("NEXUS_ARC_V5_10_0_PB_ONLY_ANALYST_DESK.html"))
        dashboard = self.client.get("/?nocache=unit-test")
        self.assertEqual(dashboard.status_code, 200, dashboard.text[:500])
        self.assertIn("NEXUS ARC V5.10.0", dashboard.text)
        self.assertIn("no-store", dashboard.headers.get("cache-control", ""))
        self.assertEqual(dashboard.headers.get("x-nexus-arc-version"), "5.10.0")
        response = self.client.post("/api/learning/forecasts", json={
            "event_key": "api-shoe-1-hand-1", "domain": "sequence_pbt", "model_id": "api-model-v597",
            "role": "standalone", "cluster_id": "shoe-1",
            "probabilities": {"P": 0.45, "B": 0.45, "T": 0.10}, "coverage": {},
        })
        self.assertEqual(response.status_code, 200, response.text)
        forecasts = [e["payload"] for e in server.learning_ledger if e.get("event_type") == "forecast_created"]
        self.assertEqual(forecasts[-1]["cluster_id"], "shoe-1")

    def test_forecasts_for_same_event_must_share_cluster_id(self):
        import nexus_arc_v4_8_learning as learning
        ledger = []
        base = {
            "event_key": "shoe-1-hand-1", "domain": "sequence_pbt", "model_id": "champion",
            "role": "champion", "probabilities": {"P": 0.45, "B": 0.45, "T": 0.10},
            "cluster_id": "shoe-1", "coverage": {},
        }
        forecast = learning.validate_forecast_request(base, ledger)
        learning.append_event(ledger, "forecast_created", forecast)
        challenger = {**base, "model_id": "challenger", "role": "challenger", "cluster_id": "shoe-2"}
        with self.assertRaisesRegex(ValueError, "same cluster_id"):
            learning.validate_forecast_request(challenger, ledger)

    def test_cluster_bootstrap_resamples_whole_sessions(self):
        import nexus_arc_v4_8_learning as learning
        diffs = [-0.2, -0.1, 0.1, 0.2, -0.3, 0.3]
        clusters = ["shoe-a", "shoe-a", "shoe-b", "shoe-b", "shoe-c", "shoe-c"]
        result = learning._paired_ci(diffs, n_boot=200, cluster_ids=clusters)
        self.assertEqual(result["independent_cluster_count"], 3)
        self.assertIn("cluster percentile bootstrap", result["method"])


    def test_pbt_comparison_blocks_review_with_fewer_than_20_clusters(self):
        import nexus_arc_v4_8_learning as learning
        ledger = []
        for i in range(60):
            event_key = f"shoehand-{i:03d}"
            cluster_id = f"shoe-{i // 6:02d}"  # ten independent shoe/session labels
            common = {
                "event_key": event_key, "domain": "sequence_pbt", "cluster_id": cluster_id,
                "probabilities": {"P": 0.70, "B": 0.20, "T": 0.10},
                "baseline_probabilities": {"P": 0.34, "B": 0.45, "T": 0.21},
                "coverage": {"source_count": 0}, "gate_status": "ALLOW", "gate_reasons": [],
            }
            for model_id, role in (("champion", "champion"), ("challenger", "challenger")):
                learning.append_event(ledger, "forecast_created", {
                    **common, "forecast_id": f"{model_id}-{i}", "model_id": model_id, "role": role,
                }, now=f"2026-10-01T00:{i // 60:02d}:{i % 60:02d}Z")
        for i in range(60):
            learning.append_event(ledger, "outcome_recorded", {
                "event_key": f"shoehand-{i:03d}", "outcome": "P",
            }, now=f"2026-10-02T00:{i // 60:02d}:{i % 60:02d}Z")
        summary = learning.build_summary(ledger)
        comparison = summary["prospective_challenger_comparisons"][0]
        self.assertEqual(comparison["matched_n"], 60)
        self.assertEqual(comparison["independent_cluster_count"], 10)
        self.assertEqual(comparison["promotion_gate"], "NOT_ENOUGH_INDEPENDENT_CLUSTERS")

    def test_rowwise_interval_warns_about_dependence(self):
        import nexus_arc_v4_8_learning as learning
        result = learning._paired_ci([-0.2, 0.1, -0.1, 0.2], n_boot=100)
        self.assertIn("assumes independent rows", result["method"])

    def test_learning_ledger_rejects_malformed_timestamp_even_with_intact_chain_hash_shape(self):
        import nexus_arc_v4_8_learning as learning
        chain = []
        learning.append_event(chain, "forecast_created", {
            "forecast_id": "f-1", "event_key": "event-1", "domain": "sequence_pbt",
            "model_id": "m1", "probabilities": {"P": 0.5, "B": 0.5}, "gate_status": "ALLOW",
        })
        chain[0]["created_at"] = "not-a-date"
        result = learning.verify_chain(chain)
        self.assertFalse(result["valid"])
        self.assertIn("timestamp", result["reason"])

    def test_assurance_ledger_rejects_unknown_event_schema_before_projection(self):
        chain = []
        append_event(chain, "evidence_added", {"evidence_id": "e-1", "claim": "test"})
        chain[0]["event_type"] = "unknown_future_event"
        result = verify_chain(chain)
        self.assertFalse(result["valid"])
        self.assertIn("event_type", result["reason"])

    def test_streamed_request_body_limit_is_enforced_without_content_length(self):
        limit = server.MAX_REQUEST_BYTES
        chunks = iter([b"x" * (limit // 2), b"y" * (limit // 2 + 1)])
        response = self.client.post(
            "/api/assurance/evidence",
            content=chunks,
            headers={"content-type": "application/json"},
        )
        self.assertEqual(response.status_code, 413, response.text[:300])
        self.assertIn("1 MB", response.json().get("detail", ""))

    def test_hash_chain_detects_payload_mutation(self):
        chain = []
        append_event(chain, "evidence_added", {"evidence_id": "1", "claim": "true"})
        self.assertTrue(verify_chain(chain)["valid"])
        chain[0]["payload"]["claim"] = "changed"
        self.assertFalse(verify_chain(chain)["valid"])


    def test_mutation_rejects_dns_rebinding_style_host_even_with_matching_origin(self):
        response = self.client.post(
            "/api/learning/forecasts",
            headers={"host": "attacker.example", "origin": "http://attacker.example"},
            json={},
        )
        self.assertEqual(response.status_code, 403, response.text)

    def test_mutation_rejects_non_loopback_host_without_origin(self):
        response = self.client.post(
            "/api/learning/forecasts",
            headers={"host": "attacker.example"},
            json={},
        )
        self.assertEqual(response.status_code, 403, response.text)

    def test_mutation_accepts_loopback_host_and_reaches_payload_validation(self):
        response = self.client.post(
            "/api/learning/forecasts",
            headers={"host": "localhost", "origin": "http://localhost"},
            json={},
        )
        self.assertEqual(response.status_code, 422, response.text)


class DashboardLearningInvariantTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.html = (ROOT / "NEXUS_ARC_V5_10_0_PB_ONLY_ANALYST_DESK.html").read_text(encoding="utf-8")

    def test_calibration_is_fit_from_raw_precalibration_probabilities(self):
        self.assertIn("const rawProb=pbNorm(fused.prob),calibratedProb=calibrated(rawProb)", self.html)
        self.assertIn("prob:prev.forecast.rawProb||prev.forecast.prob", self.html)

    def test_calibration_schedule_uses_scored_count_not_capped_window_length(self):
        self.assertIn("function shouldFitCalibration(scoredN){return Number.isInteger(scoredN)&&scoredN>0&&scoredN%12===0}", self.html)
        self.assertIn("if(shouldFitCalibration(learner.global.n))fitCalibration()", self.html)
        self.assertNotIn("if(learner.calibration.rows.length%12===0)fitCalibration()", self.html)

    def test_correct_wait_is_not_labeled_missed_edge(self):
        self.assertNotIn("else if(prev.action==='WAIT'&&p[pred]>.60)", self.html)
        self.assertIn("correct WAIT forecast mislabeled as a miss", self.html)

    def test_previous_v59_brain_schema_remains_importable_for_migration(self):
        self.assertIn("'NEXUS-ARC-V5.9-CONTEXT-ISOLATION-INTEGRITY'", self.html)
        self.assertIn("const VERSION='NEXUS-ARC-V5.9.2-CONTEXT-ISOLATION-INTEGRITY';", self.html)

    def test_v595_pattern_audit_keeps_validation_wait_but_shows_rapid_read(self):
        self.assertIn('id="patternAuditV595"', self.html)
        self.assertIn('nexus_arc_v5_9_5_pattern_engine.js', self.html)
        self.assertIn('HISTORICAL READ · NEUTRAL', self.html)
        self.assertIn('VALIDATION WAIT · NO VERIFIED EDGE', self.html)
        self.assertIn('validation remains WAIT', self.html)
        self.assertIn('not a betting instruction', self.html)

    def test_brain_import_cancels_pending_pattern_forecast_before_history_switch(self):
        function = self.html.split("async function importBrainFile(file)", 1)[1].split("function openResetModal", 1)[0]
        self.assertIn("window.NexusPatternAuditV595Integration?.prepareBrainImport?.()", function)
        self.assertLess(function.index("prepareBrainImport"), function.index("history=safeHistory"))
        self.assertIn("patternImportTxn?.rollback?.()", function)
        self.assertIn("function prepareBrainImport()", self.html)
        self.assertIn("E.cancelPending(working,'brain_import_replaced_history'", self.html)
        self.assertIn("statusMsg('IMPORT ERROR", function)

    def test_brain_import_context_guard_preserves_pattern_ledger_schema(self):
        self.assertIn("nexus-arc-v5.9.5-pattern-audit-ledger-v1", self.html)
        self.assertIn("window.NexusPatternAuditV595Integration={prepareBrainImport}", self.html)
        self.assertIn("brain_import_replaced_history", self.html)

    def test_pb_only_entry_and_conservative_analyst_threshold(self):
        self.assertNotIn('data-result="T"', self.html)
        self.assertIn("const PB=['P','B'],OUT=['P','B']", self.html)
        engine = (ROOT / 'nexus_arc_v5_10_0_rapid_analyst_engine.js').read_text(encoding='utf-8')
        self.assertIn('const MIN_ANALYSIS_PB=12', engine)
        self.assertIn('WAIT_INSUFFICIENT_DATA', engine)
        self.assertIn('Wilson 95% CI', engine)
        self.assertIn('window.NEXUSBaccaratIgnored', self.html)

    def test_v5100_rapid_analyst_panel_is_integrated(self):
        self.assertIn('id="analystReasoningV5100"', self.html)
        self.assertIn('nexus_arc_v5_10_0_rapid_analyst_engine.js', self.html)
        self.assertIn('id="arTransitionRows"', self.html)
        self.assertIn('id="arSuffixRows"', self.html)
        self.assertIn("NexusAnalystReasoningV510", self.html)
        self.assertIn("validation_gate:'WAIT_NO_VERIFIED_CROSS_SESSION_EDGE'", (ROOT / 'nexus_arc_v5_10_0_rapid_analyst_engine.js').read_text(encoding='utf-8'))

    def test_pattern_ledger_is_separate_and_session_gated(self):
        self.assertIn("nexus-arc-v5.9.5-pattern-audit-ledger-v1", self.html)
        self.assertIn('test_nexus_arc_v5_9_5_pattern_engine.js', (ROOT / 'README_NEXUS_ARC_V5_10_0.txt').read_text(encoding='utf-8'))
        self.assertIn('test_nexus_arc_v5_10_0_rapid_analyst_engine.js', (ROOT / 'README_NEXUS_ARC_V5_10_0.txt').read_text(encoding='utf-8'))
        self.assertIn('WAIT_BASELINE_ONLY_INSUFFICIENT_CROSS_SESSION_PATTERN_EVIDENCE', (ROOT / 'nexus_arc_v5_9_5_pattern_engine.js').read_text(encoding='utf-8'))




class DashboardAssetServingTests(unittest.TestCase):
    def test_pattern_and_analyst_modules_are_served_by_allowlist(self):
        client = TestClient(server.app)
        for name, marker in [
            ("nexus_arc_v5_9_5_pattern_engine.js", "NexusPatternAuditV595"),
            ("nexus_arc_v5_10_0_rapid_analyst_engine.js", "NexusAnalystReasoningV510"),
        ]:
            response = client.get("/" + name)
            self.assertEqual(response.status_code, 200, response.text)
            self.assertIn(marker, response.text)
            self.assertIn("javascript", response.headers.get("content-type", ""))
            self.assertEqual(response.headers.get("x-nexus-arc-version"), "5.10.0")

    def test_unknown_root_asset_is_not_served(self):
        response = TestClient(server.app).get("/unlisted_asset.js")
        self.assertEqual(response.status_code, 404)

class StartupVersionGuardTests(unittest.TestCase):
    def test_health_and_dashboard_must_both_match_release(self):
        launcher = (ROOT / "launch_nexus_arc_v5_9.ps1").read_text(encoding="utf-8")
        self.assertIn("$ExpectedVersion = '5.10.0'", launcher)
        self.assertIn("$DashboardName = 'NEXUS_ARC_V5_10_0_PB_ONLY_ANALYST_DESK.html'", launcher)
        self.assertIn("$health.version -eq $ExpectedVersion", launcher)
        self.assertIn("$health.dashboard -eq $DashboardName", launcher)
        self.assertIn("/api/health", launcher)

    def test_launcher_does_not_kill_unknown_port_owner(self):
        launcher = (ROOT / "launch_nexus_arc_v5_9.ps1").read_text(encoding="utf-8")
        self.assertIn("nexus_arc_v5_9_server\\.py", launcher)
        self.assertIn("It was NOT stopped", launcher)
        self.assertIn("Stop-Process -Id", launcher)

    def test_batch_runs_checked_launcher_not_server_directly(self):
        bat = (ROOT / "start_nexus_arc_v5_9.bat").read_text(encoding="utf-8")
        self.assertIn("launch_nexus_arc_v5_9.ps1", bat)
        self.assertNotIn("py -3 nexus_arc_v5_9_server.py", bat)

if __name__ == "__main__":
    unittest.main(verbosity=2)
