'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
const html=fs.readFileSync(require('node:path').join(__dirname,'NEXUS_ARC_V5_10_0_PB_ONLY_ANALYST_DESK.html'),'utf8');
const start=html.indexOf('function parse(s){');
const end=html.indexOf('\nfunction bigRoad',start);
assert.ok(start>=0&&end>start,'roadmap parser source must exist');
const context={window:{}};vm.createContext(context);vm.runInContext(html.slice(start,end).trim()+';globalThis.testParse=parse;',context);
const cases=[
  {name:'compact PBTB ignores Tie',input:'PBTB',expected:['P','B','B'],ignored:1},
  {name:'malformed tokens are counted',input:'P, X, B, ?',expected:['P','B'],ignored:2},
  {name:'named outcomes remain supported',input:'PLAYER BANKER',expected:['P','B'],ignored:0},
];
for(const c of cases){assert.deepEqual(Array.from(context.testParse(c.input)),c.expected,c.name);assert.equal(context.window.NEXUSBaccaratIgnored,c.ignored,c.name+' ignored count');console.log('PASS '+c.name)}
console.log(`\n${cases.length} roadmap parser cases passed.`);
