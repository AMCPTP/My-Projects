NEXUS ARC V5.10.1 — RAPID MULTI-LENS READ, P/B ONLY

PURPOSE
Reduce the frustrating whole-system WAIT state by separating a fast, always-visible read from evidence validation. At 0-3 accepted P/B results, the panel shows BUILDING READ and the count remaining. At 4+ accepted results, it immediately displays a RAPID HEURISTIC READ (P lean, B lean, or neutral). The independent edge-validation gate deliberately remains WAIT until prospective, cross-session evidence has been scored and independently replicated.

WHAT CHANGED FROM V5.10.0
- Rapid Read starts at 4 P/B results; the user no longer needs 12 results before any directional read is visible.
- Rapid Read uses smoothed short/recent-6, recent-12, recent-20, and all-history lenses where available, plus a small 6-vs-prior-6 momentum term. This is a heuristic score, not a calibrated probability.
- Very short samples are labelled VERY_LOW_SUPPORT or LOW_SUPPORT. The application never outputs a next-hand probability or positive-EV claim from this heuristic.
- Repeating 2-2 patterns have a phase guard to avoid turning a transient last-six imbalance into a directional lean. Alternation, streak, transition, suffix and shift are described as context, not certainty.
- Main dashboard uses the dedicated O(n) rapidRead() path rather than running the full analyzer multiple times just to update the main status cards.
- Historical tilt stays separate and uses a Wilson 95% interval over the full supplied history with its own 12-result minimum.
- The P/B-only result flow from V5.10.0 remains. Tie and malformed tokens are ignored and counted, not converted into P/B outcomes.
- Brain compatibility, roadmap analysis, prospective forecast ledger, walk-forward audit, and risk-control panels remain present.

INTERPRETATION / LIMITS
A RAPID P/B LEAN is a low-cost hypothesis drawn from recent and historical outcome shares. It is NOT the probability of the next hand, is not calibrated, and is not a betting instruction. Road shapes cannot establish that the next result will continue or reverse. P/B history does not reveal the cards remaining in a shoe. The existing prospective ledger is the memory/audit mechanism: forecasts should be locked before outcomes and then scored by session. There is no automatic model-weight update based on a single result; that would invite overfitting. VALIDATION GATE stays WAIT until adequate prospective samples and independent replication are achieved.

SAFE UPGRADE (WINDOWS)
1. Back up the whole NEXUS folder, .env, nexus_v5_0_data (if present), and Brain exports.
2. Extract this ZIP into the existing installation folder and overwrite matching application files. Do not delete .env or user data.
3. Run start_nexus_arc_v5_9.bat. The launcher should confirm version 5.10.1 and dashboard NEXUS_ARC_V5_10_1_RAPID_READ_ANALYST_DESK.html before opening a browser.
4. Verify http://127.0.0.1:8787/api/health reports version 5.10.1 and the exact dashboard filename.
5. Enter only P/B in live result entry and roadmap input. Unknown and Tie tokens are skipped and counted.

TESTS
- py -3 -m unittest -v test_nexus_arc_v5_10_1_regression.py
- node test_nexus_arc_v5_9_5_pattern_engine.js
- node test_nexus_arc_v5_10_1_brain_import_guard.js
- node test_nexus_arc_v5_10_1_rapid_analyst_engine.js
- node test_nexus_arc_v5_10_1_roadmap_parser.js

LIMITATION
This package is regression-tested in the build environment. A live browser end-to-end test on the user's Windows computer has not been performed. Passing software tests do not establish baccarat prediction accuracy or positive EV.
