$ErrorActionPreference = 'Stop'
$Root = (Resolve-Path -LiteralPath $PSScriptRoot).Path
$ServerScript = Join-Path $Root 'nexus_arc_v5_9_server.py'
$DashboardName = 'NEXUS_ARC_V5_10_1_RAPID_READ_ANALYST_DESK.html'
$DashboardPath = Join-Path $Root $DashboardName
$ExpectedVersion = '5.10.1'

if (-not (Test-Path -LiteralPath $ServerScript)) { throw "Server script missing: $ServerScript" }
if (-not (Test-Path -LiteralPath $DashboardPath)) { throw "V5.10.1 dashboard missing: $DashboardPath" }

# Mirror python-dotenv's effective port precedence: process environment first, then .env, then 8787.
$Port = 8787
if ($env:NEXUS_PORT -match '^\d+$') { $Port = [int]$env:NEXUS_PORT }
elseif (Test-Path -LiteralPath (Join-Path $Root '.env')) {
    $line = Get-Content -LiteralPath (Join-Path $Root '.env') | Where-Object { $_ -match '^\s*NEXUS_PORT\s*=' } | Select-Object -Last 1
    if ($line -and $line -match '^\s*NEXUS_PORT\s*=\s*"?(\d+)"?\s*$') { $Port = [int]$Matches[1] }
}
if ($Port -lt 1 -or $Port -gt 65535) { throw "Invalid NEXUS_PORT: $Port" }
$env:NEXUS_PORT = [string]$Port
$env:NEXUS_DASHBOARD_PATH = $DashboardPath
$BaseUrl = "http://127.0.0.1:$Port"

function Get-NexusHealth {
    try { return Invoke-RestMethod -Uri "$BaseUrl/api/health" -Method Get -TimeoutSec 2 } catch { return $null }
}
function Get-ListenerPids {
    try {
        $found = @(Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction Stop | Select-Object -ExpandProperty OwningProcess -Unique)
        if ($found.Count -gt 0) { return $found }
    } catch { }
    # Fallback for systems where Get-NetTCPConnection is unavailable or blocked.
    $pattern = "(?i)^\s*TCP\s+\S+:$Port\s+\S+\s+LISTENING\s+(\d+)\s*$"
    $found = @()
    foreach ($line in (& netstat.exe -ano -p TCP 2>$null)) {
        if ($line -match $pattern) { $found += [int]$Matches[1] }
    }
    return @($found | Select-Object -Unique)
}
function Test-ExpectedRelease($health) {
    return ($null -ne $health -and [string]$health.version -eq $ExpectedVersion -and [string]$health.dashboard -eq $DashboardName)
}

# If the intended release is already serving this port, just open it.
$health = Get-NexusHealth
if (Test-ExpectedRelease $health) {
    Write-Host "NEXUS ARC $ExpectedVersion already active at $BaseUrl" -ForegroundColor Green
    Start-Process "$BaseUrl/?launchcheck=$([DateTimeOffset]::UtcNow.ToUnixTimeSeconds())"
    exit 0
}

# If a previous NEXUS version owns the port, stop only that known server process.
# Never terminate an unrelated process merely because it uses the same port.
$pids = Get-ListenerPids
foreach ($pidValue in $pids) {
    $proc = Get-CimInstance Win32_Process -Filter "ProcessId = $pidValue" -ErrorAction SilentlyContinue
    $cmd = [string]$proc.CommandLine
    if (-not $proc -or $cmd -notmatch '(?i)nexus_arc_v5_9_server\.py') {
        $detail = if ($cmd) { $cmd } else { 'command line unavailable' }
        throw "Port $Port is occupied by a process that does not identify as the NEXUS server (PID $pidValue). It was NOT stopped. Process: $detail. Stop it yourself or set NEXUS_PORT in .env."
    }
    Write-Host "Stopping old NEXUS server PID $pidValue (detected version: $([string]$health.version))..." -ForegroundColor Yellow
    Stop-Process -Id ([int]$pidValue) -Force
}

# Give the old listener time to release the socket.
for ($i = 0; $i -lt 10; $i++) {
    $remaining = @(Get-ListenerPids)
    if ($remaining.Count -eq 0) { break }
    Start-Sleep -Milliseconds 500
}
$remaining = @(Get-ListenerPids)
if ($remaining.Count -gt 0) { throw "Port $Port is still occupied after stopping the old NEXUS process." }

$py = Get-Command 'py.exe' -ErrorAction SilentlyContinue
if (-not $py) { $py = Get-Command 'py' -ErrorAction SilentlyContinue }
if (-not $py) { throw 'Python Launcher (py.exe) was not found. Install Python 3.11+ or run the server from a terminal.' }
Write-Host "Starting NEXUS ARC $ExpectedVersion from: $Root" -ForegroundColor Cyan
$proc = Start-Process -FilePath $py.Source -ArgumentList @('-3', ('"' + $ServerScript + '"')) -WorkingDirectory $Root -PassThru

# Do not open the URL until the expected backend AND its exact dashboard filename are confirmed.
$confirmed = $false
for ($i = 0; $i -lt 30; $i++) {
    Start-Sleep -Seconds 1
    $health = Get-NexusHealth
    if (Test-ExpectedRelease $health) { $confirmed = $true; break }
    if ($null -ne $health -and [string]$health.version -ne $ExpectedVersion) {
        throw "Unexpected service version $($health.version) is responding at $BaseUrl (dashboard $($health.dashboard)). Refusing to open the wrong release."
    }
}
if (-not $confirmed) { throw "V5.10.1 health check failed at $BaseUrl. The browser was not opened; inspect the server console." }
Write-Host "Verified API version $($health.version), dashboard $($health.dashboard)" -ForegroundColor Green
Start-Process "$BaseUrl/?launchcheck=$([DateTimeOffset]::UtcNow.ToUnixTimeSeconds())"
