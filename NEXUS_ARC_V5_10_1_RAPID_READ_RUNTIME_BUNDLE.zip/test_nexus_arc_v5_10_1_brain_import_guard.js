'use strict';
const fs = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const path = require('node:path');

const htmlPath = path.join(__dirname, 'NEXUS_ARC_V5_10_1_RAPID_READ_ANALYST_DESK.html');
const html = fs.readFileSync(htmlPath, 'utf8');
const start = html.indexOf('function prepareBrainImport(){');
const end = html.indexOf('function renderProspective(){', start);
assert.ok(start >= 0 && end > start, 'import guard helper should exist before renderer');
const helperSource = html.slice(start, end);

function harness(initialLedger) {
  let ledger = JSON.parse(JSON.stringify(initialLedger));
  let saveCount = 0;
  let renderCount = 0;
  let cancelCount = 0;
  let failLoad = false;
  let failSave = false;
  const E = {
    cancelPending(target, reason, now) {
      cancelCount++;
      if (!target.pending_id) return { changed: false, message: 'none' };
      const row = target.records.find(r => r.forecast_id === target.pending_id);
      assert.ok(row, 'pending_id must resolve to a record');
      row.status = 'CANCELLED';
      row.cancel_reason = reason;
      row.resolved_at = now;
      target.pending_id = null;
      return { changed: true, message: 'cancelled' };
    }
  };
  const context = {
    E,
    storageMode: 'LOCAL',
    window: {},
    safeLoad() { if (failLoad) throw new Error('corrupt ledger'); return JSON.parse(JSON.stringify(ledger)); },
    safeSave(value) { saveCount++; if (failSave) return false; ledger = JSON.parse(JSON.stringify(value)); return true; },
    renderProspective() { renderCount++; },
    getLedger() { return JSON.parse(JSON.stringify(ledger)); },
    stats() { return { saveCount, renderCount, cancelCount }; },
    setFailLoad(v) { failLoad = v; },
    setFailSave(v) { failSave = v; }
  };
  vm.runInNewContext(helperSource + '\nglobalThis.__api = window.NexusPatternAuditV595Integration;', context);
  return { api: context.__api, context };
}

let checks = 0;
function test(name, fn) { fn(); checks++; console.log('PASS ' + name); }

const empty = harness({ schema: 'nexus-arc-v5.9.5-pattern-audit-ledger-v1', pending_id: null, records: [] });
test('no pending forecast is a no-op', () => {
  const txn = empty.api.prepareBrainImport();
  assert.equal(txn.cancelled, false);
  assert.equal(empty.context.stats().saveCount, 0);
  assert.equal(empty.context.stats().cancelCount, 0);
  txn.commit(); txn.rollback();
  assert.equal(empty.context.getLedger().pending_id, null);
});

const h = () => harness({ schema: 'nexus-arc-v5.9.5-pattern-audit-ledger-v1', pending_id: 'f1', records: [{ forecast_id: 'f1', status: 'PENDING', session_id: 'shoe-a' }] });
test('pending forecast is cancelled without score before history swap', () => {
  const x = h(); const txn = x.api.prepareBrainImport(); const l = x.context.getLedger();
  assert.equal(txn.cancelled, true);
  assert.equal(l.pending_id, null);
  assert.equal(l.records[0].status, 'CANCELLED');
  assert.equal(l.records[0].cancel_reason, 'brain_import_replaced_history');
  assert.equal(Object.hasOwn(l.records[0], 'score'), false);
  assert.equal(x.context.stats().saveCount, 1);
});

test('failed Brain import can restore the previous pending ledger snapshot', () => {
  const x = h(); const txn = x.api.prepareBrainImport();
  assert.equal(x.context.getLedger().pending_id, null);
  txn.rollback();
  const l = x.context.getLedger();
  assert.equal(l.pending_id, 'f1');
  assert.equal(l.records[0].status, 'PENDING');
});

test('committed import does not resurrect the cancelled pending forecast', () => {
  const x = h(); const txn = x.api.prepareBrainImport();
  txn.commit(); txn.rollback();
  const l = x.context.getLedger();
  assert.equal(l.pending_id, null);
  assert.equal(l.records[0].status, 'CANCELLED');
});

test('corrupt ledger blocks the guard rather than silently overwriting state', () => {
  const x = h(); x.context.setFailLoad(true);
  assert.throws(() => x.api.prepareBrainImport(), /corrupt ledger/);
  assert.equal(x.context.stats().saveCount, 0);
});

console.log(`${checks} Brain import guard tests passed.`);
