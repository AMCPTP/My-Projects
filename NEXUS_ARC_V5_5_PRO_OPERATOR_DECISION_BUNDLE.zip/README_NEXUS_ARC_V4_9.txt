NEXUS ARC V4.9 — UNIFIED ASSURANCE / EVIDENCE / MEMORY
Release candidate: 4.9.0
Date: 11 October 2026

WHAT THIS RELEASE ADDS
- A separate unified assurance ledger that can cross-link completed domain analyses, operator-entered evidence records, incident/error notes, and preregistered paired experiments.
- A hash-linked append-only event history with sequence/previous-hash verification. This is tamper-evident, not a digital signature, identity proof, or truth verification.
- Feed coverage reporting that separates fetch freshness from source-content age; statuses include NOT_CONFIGURED, NOT_CHECKED, FETCH_FAILED, FETCH_STALE, FETCH_OK_CONTENT_OLD, FETCH_OK_CONTENT_TIME_UNKNOWN, and FRESH.
- Incident memory that explicitly stores cause explanations as hypotheses or operator assertions; it does not autonomously establish causal mechanisms.
- Preregistered Champion-vs-Challenger comparison with paired bootstrap intervals. A promising result is only flagged for independent review; no model is promoted automatically.
- Migration of recognized V4.8 and earlier local JSON state into the V4.9 data directory when no destination file already exists.
- Dashboard panel for ledger verification, feed coverage, adding evidence, recording incidents, and running preregistered paired comparisons.

CONTENTS
- NEXUS_ARC_V4_9_ASSURANCE_WORKSPACE.html
- nexus_arc_v4_9_server.py
- nexus_arc_v4_9_assurance.py
- nexus_arc_v4_8_learning.py (compatibility dependency for prospective forecast ledger)
- requirements.txt
- start_nexus_arc_v4_9.bat
- test_nexus_arc_v4_9_assurance.py
- test_nexus_arc_v4_9_api.py
- test_nexus_arc_v4_9_mock.js
- V4_9_TEST_REPORT.txt
- V4.4/V4.5 audit modules + V4.8 compatibility files, included only to reproduce the regression test command
- NEXUS_ARC_V4_9_CHANGELOG.txt
- NEXUS_ARC_V4_9_SHA256SUMS.txt

WINDOWS QUICK START
1. Extract the ZIP into a writable folder.
2. Install Python 3.11+ (Python 3.12 recommended).
3. Open Command Prompt in that folder and run: py -m pip install -r requirements.txt
4. Run start_nexus_arc_v4_9.bat, or run: py nexus_arc_v4_9_server.py
5. Open http://127.0.0.1:8787
6. In section 14, click “Refresh + Verify”. Configure public feed URLs in the World Monitor section if you want feed-based tracking.

OPTIONAL AI ANALYSIS
Set OPENAI_API_KEY and NEXUS_MODEL in the server environment (or in a private .env file kept out of shared bundles). No credentials are collected in the dashboard. Without valid credentials, the local evidence/assurance and learning APIs still operate, but /api/analyze will return a configuration error rather than fabricate an answer.

V4.9 ASSURANCE API
GET  /api/assurance/status
GET  /api/assurance/verify
GET  /api/assurance/ledger?limit=100&offset=0
POST /api/assurance/evidence
GET  /api/assurance/evidence
POST /api/assurance/incidents
GET  /api/assurance/incidents
POST /api/assurance/experiments
POST /api/assurance/experiments/{experiment_id}/results
GET  /api/assurance/experiments

EXPERIMENT WORKFLOW
1. Register the champion, challenger, metric/direction, practical effect threshold, hypothesis, and holdout plan before submitting result scores.
2. Once the planned evaluation finishes, submit paired case scores with unique case_id values.
3. The evaluator reports a deterministic paired percentile bootstrap 95% interval. Fewer than 100 pairs are always INSUFFICIENT_EVIDENCE under the current review heuristic.
4. “PROMISING_FOR_INDEPENDENT_REVIEW” means only that the submitted paired scores meet the pre-set screen. It is not proof of genuine holdout independence, causal benefit, safe deployment, or generalization. There is no auto-promotion.

EVIDENCE AND INCIDENT WORKFLOW
- Evidence records preserve title, URL, claim, excerpt, source type, timestamp, relation to an analysis, and a hash. The endpoint does not fetch the URL or verify the claim.
- Incident records can link to a completed analysis, prospective forecast, and evidence records. A human-supplied cause label is not independent proof that the cause is correct.
- The analysis API cross-links successful analysis metadata and provider-cited URLs to the assurance ledger when ledger writes succeed. If trace append fails, the analysis record includes an assurance_trace_warning.

COVERAGE INTERPRETATION
- “Fresh” means configured feed checks and timestamped source content pass simple age thresholds; it does not mean all world events are covered or source content is true.
- A successful fetch can contain old articles. The dashboard reports feed response age separately from source-content age.
- No feeds configured is reported as NOT_CONFIGURED, never as fresh/live global coverage.

SECURITY / OPERATING LIMITS
- Server binds to 127.0.0.1 by default. Do not expose the local gateway to the public network without a separate threat-model/security review.
- Mutating browser requests with a mismatched Origin are rejected; JSON request size is limited to 1 MB; feed fetches use bounded parsing and URL checks inherited from V4.8.
- Evidence URLs and excerpts are operator-supplied inputs. Evidence records do not trigger an outbound fetch.
- Hash chain protects against unnoticed individual record alteration relative to a retained later chain; it is not signed, externally anchored, or resistant to an actor who can rewrite the entire ledger and all hashes.
- User-local data should be backed up before upgrades. Default data directory: ./nexus_v4_9_data/ . The server copies recognized old JSON files only when the V4.9 destination file does not already exist.

VALIDATION LIMITATIONS
- Unit/API tests and mock-DOM tests are software tests, not proof of real-world predictive skill.
- No live production feed, real external AI request, independently labelled domain benchmark, or casino dataset was used in release validation.
- Baccarat roadmaps remain descriptive of past P/B/T sequences; no prediction advantage or profit is claimed.
