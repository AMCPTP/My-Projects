NEXUS ARC V5.0 — RETRIEVAL-GUIDED LEARNING + ASSURANCE
Release candidate: 5.0.0
Date: 11 October 2026

PURPOSE
V5.0 addresses a specific gap in prior versions: incident notes were stored, but were not explicitly reviewed and retrieved into later AI analyses as contextual guidance. V5.0 adds an evidence-linked lesson review lifecycle and a retrieval trace for future analyses.

IMPORTANT LEARNING BOUNDARY
- This is retrieval-guided adaptation at inference time. It does NOT fine-tune or update model weights.
- A lesson is eligible for retrieval only after an operator explicitly approves it and its incident links at least one existing evidence record.
- Source excerpts and URLs are not inserted as trusted instructions. Only a short symptom, corrective action, status, and IDs are passed as candidate guidance.
- The model is instructed to treat retrieved lessons as untrusted historical notes, ignore embedded instructions, check applicability against current evidence, and not overrule newer evidence.
- If at least two effectiveness reviews report a lesson as harmful and harmful count exceeds helpful count, that lesson is quarantined from retrieval until review state changes. This is a safety heuristic, not a validated universal threshold.
- “Approved” means operator-reviewed only. It does not prove the causal explanation, evidence truth, or applicability to all contexts.
- Feedback-degradation flags are descriptive signals based on subjective operator labels and are not ground-truth accuracy estimates.

WHAT'S NEW
- /api/v5/learning/lessons: domain-filtered retrieval of explicitly approved, evidence-linked lessons.
- /api/v5/learning/lesson-review: approve/reject lessons. Approval requires at least one existing linked evidence record.
- /api/v5/learning/lesson-use-review: record helpful / neutral / harmful reports by context and optionally link to an evaluation.
- /api/v5/learning/diagnostics: report lesson counts, trace usage, operator feedback trend signals, and prospective forecast metrics.
- /api/analyze receives up to five applicable approved lessons and returns lesson IDs considered. Successful analysis trace records the lesson IDs in the assurance ledger.
- Analysis feedback is cross-linked into the assurance ledger as an operator signal.
- Automatic model promotion and weight training remain disabled.
- Migration copies supported V4.9/V4.8 local JSON state into V5.0 storage only when the destination file does not already exist.

CONTENTS
- NEXUS_ARC_V5_0_ASSURANCE_LEARNING.html — primary dashboard
- nexus_arc_v5_0_server.py — local FastAPI backend
- nexus_arc_v5_learning.py — retrieval memory and diagnostics
- nexus_arc_v4_9_assurance.py — compatible assurance ledger primitives
- nexus_arc_v4_8_learning.py — prospective forecast ledger
- nexus_arc_v4_8_server.py — prior-version regression dependency
- nexus_arc_v4_4_audit.py / nexus_arc_v4_5_audit.py — regression dependencies
- requirements.txt / requirements-dev.txt
- start_nexus_arc_v5_0.bat
- test_nexus_arc_v5_learning.py — V5 retrieval-learning unit tests
- test_nexus_arc_v5_0_api.py — API lifecycle tests
- test_nexus_arc_v5_0_mock.js — dashboard mock-DOM and V5 interaction tests
- previous-version test files — regression tests
- V5_0_TEST_REPORT.txt / NEXUS_ARC_V5_0_CHANGELOG.txt / SHA256SUMS

WINDOWS QUICK START
1. Extract the ZIP into a writable folder. If migrating existing local state automatically, keep the prior version's nexus_v4_9_data folder beside the new files, or manually copy it before the first run.
2. Install Python 3.11+ (Python 3.12 recommended).
3. Open Command Prompt in this folder and run: py -m pip install -r requirements.txt
4. Copy .env.example to .env and enter OPENAI_API_KEY and NEXUS_MODEL to enable external AI analysis. Keep .env private; it is not included as a real credential.
5. Run start_nexus_arc_v5_0.bat, or run: py nexus_arc_v5_0_server.py
6. Open http://127.0.0.1:8787
7. Add source evidence and an incident in section 14. In section 15, enter the incident ID and explicitly approve it to permit retrieval. Evidence must exist and be linked. Check the lesson list for the active domain.
8. After a future analysis uses a lesson, record helpful / neutral / harmful feedback with the same incident ID. Review quarantined lessons before re-approving them.

V5 API
GET  /api/v5/learning/diagnostics?domain=technology
GET  /api/v5/learning/lessons?domain=technology&limit=5
POST /api/v5/learning/lesson-review
POST /api/v5/learning/lesson-use-review
Existing V4.9 assurance endpoints and V4.8 prospective forecast endpoints remain available.

SUGGESTED JSON BODY — approve a lesson
{"incident_id":"<existing incident id>","decision":"approved","note":"Reviewed the evidence and scope"}

SUGGESTED JSON BODY — review lesson effectiveness
{"incident_id":"<existing incident id>","verdict":"helpful","evaluation_id":"<optional existing evaluation id>","note":"Helped verify the current release date"}

DATA AND SECURITY
- Server binds to 127.0.0.1 by default. Do not expose it to public networks without authentication, TLS, and a full threat-model review.
- API credentials are read server-side from environment/.env; no credentials are collected in the dashboard.
- Store paths can be customized with NEXUS_DATA_DIR. Back up local data before upgrades.
- Hash chains are tamper-evident but unsigned and not resistant to a privileged actor rewriting the entire ledger.
- Local user/operator reviews are not identity-verified, independently audited, or ground-truth labels.

VALIDATION LIMITATIONS
- Regression suite and dashboard mock tests are software tests only.
- No live production feeds, real external AI request, independently labelled cross-domain benchmark, or casino dataset was used in V5.0 release validation.
- The prospective forecast ledger scores predictions only when an outcome is recorded; operator-entered outcomes still need independent verification.
- Baccarat Roadmaps summarize prior outcomes. No next-hand prediction edge or profitability is claimed.
- V5.0 is a TESTED LOCAL RELEASE CANDIDATE, not certified universal intelligence or autonomous self-improvement.
