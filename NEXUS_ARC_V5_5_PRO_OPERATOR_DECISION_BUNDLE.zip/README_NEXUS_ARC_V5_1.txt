NEXUS ARC V5.1 — BACCARAT PRO DECISION SUPPORT LAYER
Release candidate: 5.1.0 (add-on to V5.0 core)
Date: 11 October 2026

PURPOSE
Add a disciplined baccarat decision-support layer to the V5.0 dashboard. This does not claim to beat baccarat or predict the next hand. It prioritizes expected value, uncertainty, rules awareness, and stop limits over pattern-chasing.

WHAT'S NEW
- Existing roadmap analyzer retained: B/P/T history, streaks, switches, and road visualizations. Derived-road rendering remains a visualization aid; verify against the casino's exact rules before operational use.
- Standard 8-deck baseline EV cards: Banker assumes 5% commission; Player 1:1; Tie pays 8:1; ties push Banker/Player. Table-specific rules can change these values.
- Wilson 95% interval for the observed Banker share among decisive (non-Tie) outcomes. This describes historical sample uncertainty and is NOT a next-hand probability.
- User-configured bankroll/session guard with stop-loss alerts. It is a reminder, not a bet recommendation.
- Local snapshot storage (browser localStorage) and JSON export. Data stays in that browser unless the user exports it or separately shares it.
- Python helper module with testable EV, parsing, summary, confidence interval, and guard functions.

KEY PROFESSIONAL RULE
If the only evidence is a B/P/T roadmap, the decision gate returns PASS_NO_DEMONSTRATED_EDGE_FROM_ROADS_ALONE. Road patterns describe past results; they do not demonstrate an advantage on the next hand. Do not chase losses or use Martingale as a repair strategy.

QUICK START (WINDOWS)
1. Extract this ZIP to a writable folder.
2. Install Python 3.11+ and dependencies: py -m pip install -r requirements.txt
3. Start with start_nexus_arc_v5_0.bat (the assurance/learning backend remains V5.0; V5.1 adds the Baccarat decision-support layer).
4. Open http://127.0.0.1:8787.
5. Enter historical B/P/T results in section 09, analyze roads, then review Pro Decision Gate.
6. Set bankroll and stop-loss before session. Snapshot and JSON export are local browser actions.

TESTING
Run: py -m pip install -r requirements-dev.txt
Then: py -m pytest -q test_nexus_arc_v5_1_baccarat.py
Dashboard JS syntax is checked with Node if installed. Mock-DOM testing is not a substitute for a real browser visual/accessibility test.

LIMITATIONS
- No live casino connection or actual remaining-card composition tracking. B/P/T-only history cannot reveal exact remaining cards, pairs, naturals, or side-bet information.
- No independent casino dataset, live provider, or profitability benchmark was used.
- Baseline probabilities are standard approximate 8-deck references; table rules and deck composition may differ.
- User-entered history and session P/L are not independently verified.
- V5.1 does not train model weights or automatically choose a bet.
- Browser snapshots are local to that browser profile and can be cleared by the browser.
- This is a decision-support aid, not financial advice or a promise of winnings.
