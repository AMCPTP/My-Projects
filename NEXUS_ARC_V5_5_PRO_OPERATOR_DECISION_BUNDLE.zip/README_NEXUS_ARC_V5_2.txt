NEXUS ARC V5.2 — ADAPTIVE AUDIT & PROSPECTIVE EVALUATION
Release: 5.2.0 add-on to V5.0/V5.1
Date: 12 October 2026

PURPOSE
V5.2 strengthens evidence discipline. It does not claim universal intelligence, casino advantage, or reliable prediction of the next baccarat hand. It adds a prospective forecast ledger so a candidate probability model can be measured against a fixed 8-deck baseline on outcomes recorded only after forecasts are registered.

WHAT'S NEW
- V5.1 dashboard retained as the main desk, with a visible Baccarat Safety Override: sequence-engine scores/action gates are software diagnostics, not bet signals.
- Prospective B/P/T evaluation panel. User provides probabilities; the panel does not generate a road-based betting pick.
- Only one unresolved forecast at a time. User registers probability distribution first, then resolves it after the observed outcome. A second registration is blocked until the first is resolved.
- Paired multiclass Brier score and log loss versus fixed 8-deck baseline, plus approximate 95% intervals of paired score differences.
- Minimum-sample gates: below 100 results is WARMING; 100–299 is EVALUATING / NO PROMOTION; 300+ can only reach a provisional review state if both score comparisons improve with intervals fully below zero. This is not automated promotion.
- Rolling degradation signal compares recent 50 outcomes with the preceding 50. It prompts review; it does not infer why performance changed.
- Calibration summary, local browser storage, export to JSON, corrupted-ledger fail-closed behavior, duplicate ID checks, timestamp ordering, and maximum 2,000 records without silent truncation.
- Python evaluation module for reproducible scoring and audit summaries.

HOW TO USE
1. Install dependencies once: `py -m pip install -r requirements.txt`.
2. Run `start_nexus_arc_v5_2.bat`, then open http://127.0.0.1:8787. The launcher sets the server to serve the V5.2 dashboard while retaining the V5.0 assurance/learning API. The prospective audit panel works locally in the browser; no casino API is connected.
3. In section 10, enter a candidate model's B/P/T probability percentages. The default values are a baseline demonstration, not a prediction from Roadmaps.
4. Before seeing the next outcome, click "ลงทะเบียน Forecast".
5. After the result is known, select B, P, or T and click "ปิด Forecast ด้วยผลจริง".
6. Repeat in sequence. Export JSON regularly for backup and further audit.
7. Do not enter predictions retrospectively. Doing so invalidates prospective test claims.

SCORE INTERPRETATION
- Multiclass Brier score ranges from 0 to 2; lower is better.
- Log loss is lower when more probability is assigned to the outcome that actually occurred; a zero-probability miss receives a large capped penalty for numerical safety.
- Paired deltas are candidate minus baseline; negative means candidate score was better on that metric.
- Intervals use a normal approximation and do not account for serial dependence among consecutive hands. Treat them as diagnostics only.
- An improved score does not establish profit, causality, or a reliable advantage in future hands.

TESTING
From the release folder:
  py -m pip install -r requirements-dev.txt
  py -m pytest -q
  node test_nexus_arc_v5_0_mock.js ./NEXUS_ARC_V5_2_ADAPTIVE_AUDIT_DESK.html
The mock DOM validates initialization and scripted interactions. It is not a substitute for real Chrome/Edge layout, keyboard/accessibility checks, or testing on a real casino data feed.

LIMITATIONS / TRUST MODEL
- No live casino integration, physical shoe/card-composition tracking, side-bet analysis, external labeled dataset, or profitability study was used.
- Browser-local JSON can be edited by the user and is not signed, tamper-proof, or independently time-verified. The UI blocks accidental out-of-order use but cannot prove the human saw the forecast before the result.
- The baseline assumes approximate standard 8-deck outcome probabilities. Rules and shoe conditions may differ.
- A shift/degradation detector is a signal for human review, not automatic root-cause discovery or a repair algorithm.
- V5.2 does not train model weights, does not auto-promote a model, does not choose a bet, and does not claim to beat baccarat.
- A real prospective study would require independently timestamped forecasts, verified outcomes, sufficient sample size, pre-registered protocol, and an independent replication cohort.

CORE RULE
If the only support is the B/P/T Roadmap or a sequence pattern, return PASS / NO DEMONSTRATED EDGE. Do not chase losses, increase stakes to recover, or use Martingale as a repair strategy.
