NEXUS ARC V5.3 — ADVERSARIAL AUDIT & REGIME-AWARE EVALUATION
Release: 5.3.0
Date: 12 October 2026

PURPOSE
V5.3 tightens the prospective evaluation workflow around baccarat outcome probabilities. It does NOT create a reliable next-hand predictor from Roadmaps, recommend wagers, train model weights automatically, or certify profitability. The core V5.0 assurance/learning API and earlier roadmap visualizations remain available.

WHAT CHANGED FROM V5.2
- Replaced normal-approximation intervals in the new V5.3 audit panel with a deterministic moving-block bootstrap (1,000 replicates, default block length 5) for paired Brier/log-loss differences. This approximately preserves short-range ordering; it is not a cure for non-stationarity or all dependence.
- Added strict frozen model/candidate identity, a reported count of variants tried, and a required change note. A single cohort may not mix model IDs or silently change its experimental setup.
- Added first-half / second-half stability gate. An aggregate result cannot qualify for provisional review when either half fails to beat the baseline on both scores.
- Added an archive-and-new-cohort workflow: closed cohorts are snapshotted in browser storage with their summary, model ID, variant count, and change note; the next model version starts with a separate active ledger. Up to 20 archived cohorts are kept in browser storage; export archive JSON regularly.
- Tightened JavaScript ledger validation: unique IDs, strict B/P/T distribution, status, fractional-time ordering, no overlap with the prior resolved outcome, single pending item at the end, and frozen cohort/model identity.
- Python audit module preserves timestamp fractional seconds. The prior implementation normalized timestamps to whole seconds, which could hide order violations inside the same second.
- Added exploratory-only gate when more than one candidate/setting has been tried, plus tests for unstable second-half performance, mixed model IDs, invalid sequence order, digest comparison, and insufficient samples.
- Existing V5.2 localStorage data is not deleted. V5.3 uses a separate localStorage key intentionally; open the V5.2 page to review its former ledger. Do not copy old records into a confirmatory cohort as if they were recorded by V5.3.

INSTALL / RUN ON WINDOWS
1. Unzip the release folder to a writable directory.
2. Install Python dependencies once if needed: `py -m pip install -r requirements.txt`.
3. Start the service by double-clicking `start_nexus_arc_v5_3.bat`.
4. Open http://127.0.0.1:8787 if it does not open automatically. The local service retains the V5.0 assurance/learning API and serves the V5.3 dashboard; no casino API is connected.
5. In section 10, enter the exact model/candidate ID, number of variants actually tried, and a short change note before the first forecast. This configuration locks when the first forecast is registered.
6. Enter the model's B/P/T probabilities, click register BEFORE the result is known, then record B/P/T after the observed outcome. Only one pending forecast is allowed.
7. After a cohort is complete and no forecast remains pending, archive it before starting the next model/version. Archived cohorts are stored in browser localStorage, which is editable; export JSON for an offline copy.
8. Export both the active audit and archived cohorts regularly. The browser cannot independently prove that forecast timestamps preceded outcomes.

EVALUATION / GATES
- Multiclass Brier score and log loss: lower is better.
- Paired candidate-minus-baseline score differences: negative is better.
- Moving-block bootstrap: 95% interval, 1,000 replicates, block length 5 by default in the UI. Python helper exposes these as configurable parameters.
- Fewer than 100 resolved outcomes: WARMING / insufficient sample.
- 100–299: evaluate only; no promotion.
- At 300+, only a provisional research state is possible if both score intervals lie below zero, both halves beat the baseline on both metrics, no recent degradation gate fires, and only one candidate trial is declared. More than one tried candidate blocks promotion in the same cohort.
- Every apparent improvement still requires a newly frozen, independent confirmation cohort before it should be trusted. The variant count is self-reported, not independently verified.

PYTHON MODULE
`nexus_arc_v5_3_adversarial_audit.py` provides:
- strict B/P/T probability validation;
- prequential forecast create/resolve lifecycle;
- fractional-second timestamp ordering checks;
- moving-block bootstrap confidence intervals;
- mixed-model and invalid-ledger rejection;
- two-half stability and rolling degradation gates;
- calibration summary, candidate-search gate, and externally comparable SHA-256 digest helpers.

TESTS
From this folder:
  py -m pip install -r requirements-dev.txt
  py -m pytest -q
  node test_nexus_arc_v5_0_mock.js ./NEXUS_ARC_V5_3_ADVERSARIAL_AUDIT_DESK.html

TEST LIMITS
Python and mock-DOM tests validate software logic and scripted interaction only. They do not validate actual Chrome/Edge layout/accessibility, protect localStorage from a user/editor, authenticate a real forecast clock, connect to live casino feeds, infer shoe/card composition, prove causality, or show betting profitability. The SHA-256 helper is a comparison digest, not a digital signature; someone able to alter the data can recompute it.

CORE RULE
Roadmap shapes/streaks are descriptive evidence about prior results, not a demonstrated edge on the next baccarat hand. If prospective, independent evidence is absent, the supported status is PASS / NO DEMONSTRATED EDGE. The dashboard never authorizes a wager or stake increase.
