NEXUS ARC V5.4 — PROFIT REALITY & BANKROLL RISK LAB
Release date: 12 October 2026

PURPOSE
V5.4 extends the V5.3 assurance/roadmap workspace with an explicit Expected Value (EV) calculator, a bounded Monte Carlo comparison of flat betting versus Martingale, and an actual-session ledger that compares recorded P/L with the EV implied by the recorded table rules.

This is a decision-support and risk-audit tool. It does NOT predict the next baccarat hand, does NOT infer remaining shoe composition from roadmaps, does NOT select wagers automatically, and does NOT promise or certify profit. The intended default is PASS unless a positive edge has been independently demonstrated under exact rules and relevant conditions.

KEY ADDITIONS
1. Expected value under entered rules for Banker, Player, and Tie. Rules can be configured for Banker commission, net payout on Player, and net payout on Tie.
2. Break-even estimates: maximum commission for Banker, minimum net odds for Player, and minimum net odds for Tie, based on the rounded reference probabilities.
3. Session-risk Monte Carlo compares fixed flat stake against Martingale (double after a loss, reset after a win; Banker/Player tie pushes leave the stake unchanged). Both use the same bankroll, base stake, stop-loss, profit target, hand cap, and table maximum.
4. Simulation metrics include target-hit rate with Wilson 95% interval, stop-loss-hit rate with Wilson interval, table/bankroll-limit rate, hand-cap rate, mean and median P/L, 5th/95th P/L percentiles, average turnover, average maximum stake, average hands, and EV multiplied by average turnover.
5. Actual-session memory stores session label, strategy, side, hands, turnover, P/L, entered payout rules, theoretical EV, and notes in browser localStorage. It provides totals and grouping by strategy/side, plus JSON export. Corrupted ledgers are blocked instead of silently overwritten.
6. Seeded simulation can be repeated with the same inputs. Browser workload is bounded to trials × max hands <= 1,000,000.

REFERENCE BASELINE AND ASSUMPTIONS
The default baseline is a common 8-deck punto banco game, approximately:
- Banker result: 45.8597%
- Player result: 44.6247%
- Tie result: 9.5156%
- Banker win pays net 0.95 per unit with 5% commission; Tie pushes Banker/Player bets.
- Player pays net 1.00 per unit; Tie pays net 8.00 per unit.
Approximate EV per unit initially wagered: Banker -1.058%; Player -1.235%; Tie -14.360%. These values are rule-specific reference values rounded from published standard-game calculations. Different rules, payout exceptions, number of decks, or exact shoe composition can change results. Reference: https://wizardofodds.com/games/baccarat/basics/

The Monte Carlo uses these rounded outcome probabilities as independent per-hand draws. It does not simulate the cards left in the shoe, cut-card position, table-specific rule variants, promotions, rebates, taxes, or other fees. Simulation numbers describe assumed scenarios, not future results.

HOW TO USE
Standalone HTML:
- Open NEXUS_ARC_V5_4_RISK_LAB_DESK.html in a modern desktop browser. If a local browser restricts local file storage, use the local service launch method below.
- Scroll to section 11: V5.4 Profit Reality & Bankroll Risk Lab.
- Set bankroll, base stake, stop-loss, profit target, maximum hands, table maximum, trials, bet side and exact table payout rules.
- Click Calculate EV + Simulate Risk. Check EV first, then read target and stop-loss rates together with the P/L distribution and constraint-hit rates.
- The actual-session memory section lets you record real sessions after they end. Set actual total turnover and final net P/L. The EV saved with each session uses the rule inputs available at the time of logging. Export the ledger JSON regularly for backup.

Windows local service:
1. Unzip the entire release folder into a writable directory.
2. Install dependencies if needed: `py -m pip install -r requirements.txt`.
3. Double-click `start_nexus_arc_v5_4.bat`.
4. Open the localhost URL printed by the retained V5.0 server, usually http://127.0.0.1:8787.
5. The server still provides the prior V5.0 assurance/learning endpoints; V5.4 is the configured dashboard. No casino feed is connected.

HOW TO INTERPRET THE RESULTS
- Expected value (EV) is the average net result per unit staked under the entered payout rules and outcome assumptions. Negative EV is not cured by a staking progression.
- Banker/Player ties push. Tie bets lose on Banker and Player outcomes and receive the entered net payout on a Tie.
- A session stop rule changes when a session ends and can change the distribution of P/L; it does not change the per-unit EV.
- Martingale can hit small profit targets frequently in some settings but can also create very large stakes and stop at the bankroll/table limit. Evaluate loss and constraint rates, lower-tail P/L, and average max stake—not target-hit rate alone.
- A short-run positive P/L is not proof of a profitable edge or a causal effect from a betting strategy.
- If an adjusted payout appears to create positive EV, independently verify the exact rule, all restrictions, and exact probabilities before drawing conclusions. The rounded baseline is unsuitable for deciding an extremely narrow edge.
- Browser localStorage is editable and not independently timestamped. A digest is not a digital signature. Exported files preserve records but do not prove the timestamps or original data were genuine.

TEST COMMANDS
From this release directory:
  py -m pip install -r requirements-dev.txt
  py -m pytest -q
  node test_nexus_arc_v5_0_mock.js ./NEXUS_ARC_V5_4_RISK_LAB_DESK.html
  node test_nexus_arc_v5_4_dashboard.js ./NEXUS_ARC_V5_4_RISK_LAB_DESK.html

LIMITATIONS
- No live casino connection, no shoe/card-composition tracker, and no independently attested pre-outcome timestamp.
- Probabilities are rounded reference values and assumptions are not a real-time per-shoe model.
- Simulations are not forecasts or profitability benchmarks; Monte Carlo error and model assumptions apply.
- Session data are user-entered and can be edited; strategy group comparisons are descriptive, not causal.
- Actual rendered browser layout/accessibility was not verified in this build environment because Chromium's navigation to local/localhost pages was blocked by environment policy. JavaScript syntax, mock-DOM regression, and an isolated simulation/ledger interaction test were run.
