NEXUS ARC V5.5 — PRO OPERATOR DECISION GATE
Release date: 12 October 2026

PURPOSE
V5.5 adds a conservative decision gate for the baccarat dashboard. It forces the operator to separate (1) EV calculated from stated probabilities and entered table rules, (2) evidence that an edge held up in a preregistered untouched sample, and (3) session bankroll/risk controls. It is an audit tool, not a next-hand predictor or betting signal.

FILES
- NEXUS_ARC_V5_5_PRO_OPERATOR_DECISION_DESK.html: integrated dashboard. Retains V5.4 Risk Lab and prior dashboard panels and adds section 12.
- nexus_arc_v5_5_pro_operator.py: independently testable decision-gate implementation.
- test_nexus_arc_v5_5_pro_operator.py: Python unit tests for probability validation, EV, evidence gates, session stops, drift and review-only status.
- test_nexus_arc_v5_5_dashboard.js: isolated browser-script/mock-DOM test of the V5.5 gate.
- test_nexus_arc_v5_4_dashboard.js: V5.4 interaction regression test.
- test_nexus_arc_v5_0_mock.js: prior dashboard mock-DOM regression test.
- nexus_arc_v5_4_risk_lab.py and prior tests/modules: carried forward from V5.4.
- start_nexus_arc_v5_5.bat: starts the local backend with V5.5 dashboard selected.

USAGE
1. Unzip the package into a new folder. Do not merge it over an older release.
2. Install Python dependencies only if needed, from requirements.txt.
3. On Windows, run start_nexus_arc_v5_5.bat. Or open the HTML directly for offline dashboard portions; server-backed assurance/memory panels need the local backend.
4. In section 12, the model probabilities must be frozen model outputs, not raw historical B/P/T frequencies repackaged as the next-hand probability. The default probabilities are rounded common 8-deck reference values.
5. Confirm exact payout/commission rules in section 11. The decision gate uses those current settings.
6. Enter the out-of-sample sample size, 95% lower bound of EV per unit, and a report ID, then review all evidence boxes against source records. The browser cannot authenticate evidence merely because a box is checked.
7. Export the Gate Report JSON for manual/independent review.

DECISION STATES
- PASS_NO_POSITIVE_MODELLED_EV: supplied probabilities/rules do not show positive EV for the selected side.
- HOLD_*: rules/evidence/risk conditions are not adequate or a drift alert is active.
- STOP_SESSION_*: a predeclared stop condition is reached, stake exceeds a limit, or chasing/emotional state is flagged.
- REVIEW_ONLY_EDGE_CANDIDATE: all user-entered gate conditions pass. This is not an authorization to bet, and not certification of profitability.

THE PRO OPERATOR LOOP
Observe -> verify table rules -> state probabilities and uncertainty -> calculate EV -> lock model before outcomes -> test on untouched prospective data -> compare to baseline and calibration -> check stability/drift and bankroll limits -> PASS/HOLD/STOP/REVIEW -> record actual session -> review discrepancies before changing the next model version.

LIMITATIONS
- No live casino feed, no exact shoe composition/card-count engine, no validated next-hand advantage and no automatic wager recommendation.
- 1,000 out-of-sample observations is only a minimum guardrail, not universally sufficient. Validity depends on effect size, serial dependence, sampling, calibration, confidence-interval method, table rules and multiple-model selection.
- Holdout size, confidence bound, checks and report IDs are operator-entered; no cryptographic signature, timestamp authority or external reviewer is connected. The local browser ledger is editable.
- A positive EV result based on assumed probabilities does not prove those probabilities are accurate for the current shoe/table.
- Stake/stop controls alter risk exposure, not the game's per-unit house edge.

TESTING
From this release folder:
  python -m pytest -q
  node test_nexus_arc_v5_5_dashboard.js ./NEXUS_ARC_V5_5_PRO_OPERATOR_DECISION_DESK.html
  node test_nexus_arc_v5_4_dashboard.js ./NEXUS_ARC_V5_5_PRO_OPERATOR_DECISION_DESK.html
  node test_nexus_arc_v5_0_mock.js ./NEXUS_ARC_V5_5_PRO_OPERATOR_DECISION_DESK.html

Do not use this tool to chase losses. If control is difficult, stop the session and do not add funds to recover losses.
