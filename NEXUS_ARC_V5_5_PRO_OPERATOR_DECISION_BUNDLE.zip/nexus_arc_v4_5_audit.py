#!/usr/bin/env python3
"""Offline auditor for NEXUS ARC V4.5 Brain exports. Python standard library only.

Audits active forecasts and all five pre-outcome shadow candidates when present.
It cannot independently prove forecast chronology, outcome truth, or future edge.
"""
from __future__ import annotations
import argparse
import json
import math
import sys
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

OUTCOMES = {"P", "B"}
EPS = 1e-6
BASELINE_LL = math.log(2.0)
BASELINE_BRIER = 0.5
CANDIDATES = ("adaptive-v3", "base-heavy", "regime-heavy", "memory-heavy", "conservative")
V45_SCHEMA = "NEXUS-ARC-V4.5-PREQUENTIAL-SAFE-ADAPTATION"


def finite_number(v: Any) -> bool:
    return isinstance(v, (int, float)) and not isinstance(v, bool) and math.isfinite(float(v))


def read_prob(case: dict[str, Any]) -> dict[str, float] | None:
    p = ((case.get("forecast") or {}).get("prob") or {})
    if not isinstance(p, dict) or not finite_number(p.get("P")) or not finite_number(p.get("B")):
        return None
    pp, pb = float(p["P"]), float(p["B"])
    if pp < 0 or pb < 0 or pp > 1 or pb > 1 or pp + pb <= 0:
        return None
    z = pp + pb
    return {"P": pp / z, "B": pb / z}


def valid_cases(raw_cases: Any) -> tuple[list[dict[str, Any]], dict[str, int]]:
    counts = Counter()
    rows: list[dict[str, Any]] = []
    if not isinstance(raw_cases, list):
        return [], {"total_cases": 0, "invalid_shape": 1}
    counts["total_cases"] = len(raw_cases)
    for i, c in enumerate(raw_cases):
        if not isinstance(c, dict):
            counts["invalid_case_shape"] += 1
            continue
        y = c.get("actual")
        if y not in OUTCOMES:
            counts["non_binary_or_invalid_outcome"] += 1
            continue
        p = read_prob(c)
        if p is None:
            counts["missing_or_invalid_probabilities"] += 1
            continue
        rows.append({"source_index": i, "case": c, "actual": y, "prob": p})
    counts["valid_scored_cases"] = len(rows)
    counts["invalid_or_unscored_cases"] = len(raw_cases) - len(rows)
    return rows, dict(counts)


def metrics(rows: list[dict[str, Any]]) -> dict[str, Any]:
    n = len(rows)
    if not n:
        return {"n": 0, "log_loss": None, "brier": None, "accuracy": None,
                "mean_confidence": None, "calibration_gap": None,
                "log_loss_skill_vs_50_50": None, "brier_skill_vs_50_50": None}
    losses, briers, correct, confidence = [], [], [], []
    for r in rows:
        p, y = r["prob"], r["actual"]
        pred = "P" if p["P"] >= p["B"] else "B"
        chosen_p = max(p["P"], p["B"])
        losses.append(-math.log(max(EPS, min(1.0, p[y]))))
        briers.append((p["P"] - (1.0 if y == "P" else 0.0)) ** 2 +
                      (p["B"] - (1.0 if y == "B" else 0.0)) ** 2)
        correct.append(1.0 if pred == y else 0.0)
        confidence.append(chosen_p)
    ll, br, acc, mc = sum(losses)/n, sum(briers)/n, sum(correct)/n, sum(confidence)/n
    return {"n": n, "log_loss": round(ll, 6), "brier": round(br, 6),
            "accuracy": round(acc, 6), "mean_confidence": round(mc, 6),
            "calibration_gap": round(mc - acc, 6),
            "log_loss_skill_vs_50_50": round(1.0 - ll / BASELINE_LL, 6),
            "brier_skill_vs_50_50": round(1.0 - br / BASELINE_BRIER, 6)}


def confidence_bins(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    bounds = [(0.50, 0.60), (0.60, 0.70), (0.70, 0.80), (0.80, 0.90), (0.90, 1.0000001)]
    labels = ["50–59%", "60–69%", "70–79%", "80–89%", "90–100%"]
    out = []
    for (lo, hi), label in zip(bounds, labels):
        part = []
        for r in rows:
            conf = max(r["prob"]["P"], r["prob"]["B"])
            if lo <= conf < hi:
                part.append(r)
        m = metrics(part)
        out.append({"bin": label, "n": m["n"], "mean_confidence": m["mean_confidence"],
                    "accuracy": m["accuracy"], "interpretation": "small sample; do not interpret" if m["n"] < 10 else "descriptive only"})
    return out


def drift_report(rows: list[dict[str, Any]]) -> dict[str, Any]:
    tail = rows[-60:]
    if len(tail) < 40:
        return {"status": "WARMING", "n": len(tail), "prior": metrics([]), "recent": metrics([]),
                "reason": "ต้องมีผลจริง 40 เคสในหน้าต่างเปรียบเทียบอย่างน้อย 20 เคสต่อช่วง"}
    cut = len(tail) // 2
    prior, recent = metrics(tail[:cut]), metrics(tail[cut:])
    ll_shift = recent["log_loss"] - prior["log_loss"]
    brier_shift = recent["brier"] - prior["brier"]
    acc_shift = recent["accuracy"] - prior["accuracy"]
    gap = abs(recent["calibration_gap"] or 0.0)
    reasons = []
    if ll_shift >= 0.12: reasons.append("Log Loss increased by >= 0.12")
    if brier_shift >= 0.06: reasons.append("Brier score increased by >= 0.06")
    if acc_shift <= -0.15: reasons.append("Accuracy fell by >= 15 percentage points")
    if gap >= 0.10: reasons.append("Recent confidence-accuracy gap >= 10 percentage points")
    status = "HIGH" if ll_shift >= 0.12 or brier_shift >= 0.06 or acc_shift <= -0.15 else (
        "DRIFT" if ll_shift >= 0.035 or brier_shift >= 0.025 or acc_shift <= -0.08 or gap >= 0.10 else "STABLE")
    if not reasons: reasons = ["No configured degradation threshold triggered"]
    return {"status": status, "n": len(tail), "prior": prior, "recent": recent,
            "delta": {"log_loss": round(ll_shift, 6), "brier": round(brier_shift, 6), "accuracy": round(acc_shift, 6)},
            "reason": "; ".join(reasons),
            "important_limit": "heuristic warning only; not a statistical significance test"}


def hypothesis_summary(rows: list[dict[str, Any]], errors: Any) -> dict[str, Any]:
    primary = Counter()
    labels = Counter()
    case_diagnostics = [r["case"].get("diagnostic") for r in rows if isinstance(r["case"].get("diagnostic"), dict)]
    iterable = errors if isinstance(errors, list) else []
    # Prefer the per-case diagnostic ledger when present. Fall back to learner.errors
    # for older Brain exports, avoiding counting the same error twice.
    if case_diagnostics:
        for r in rows:
            c = r["case"]
            d = c.get("diagnostic")
            if not isinstance(d, dict):
                if c.get("cause"):
                    primary[str(c["cause"])] += 1
                    labels[str(c["cause"])] += 1
                continue
            cause = d.get("primary") or c.get("cause") or "UNLABELED"
            primary[str(cause)] += 1
            signal_names = set()
            for sig in d.get("signals", []):
                if isinstance(sig, dict) and sig.get("label"):
                    signal_names.add(str(sig["label"]))
            labels.update(signal_names)
            if str(cause) not in signal_names:
                labels[str(cause)] += 1
        source_used = "saved case diagnostics"
    else:
        for e in iterable[-500:]:
            if not isinstance(e, dict):
                continue
            if e.get("cause"):
                primary[str(e["cause"])] += 1
            causes = e.get("causes") if isinstance(e.get("causes"), list) else [e.get("cause")]
            d = e.get("diagnosis")
            signal_names = set()
            if isinstance(d, dict):
                for sig in d.get("signals", []):
                    if isinstance(sig, dict) and sig.get("label"):
                        signal_names.add(str(sig["label"]))
            labels.update(signal_names)
            for c in causes:
                if c and str(c) not in signal_names:
                    labels[str(c)] += 1
        source_used = "learner.errors fallback"
    return {"source_used": source_used, "error_records_scanned": min(len(iterable), 500),
            "records_with_diagnostic_object": len(case_diagnostics),
            "primary_cause_counts": dict(primary.most_common()), "cause_and_signal_counts": dict(labels.most_common()),
            "interpretation": "labels are rule-based hypotheses, not causal proof"}



def read_candidate_prob(case: dict[str, Any], name: str) -> dict[str, float] | None:
    predictions = case.get("shadowPredictions")
    if not isinstance(predictions, dict):
        predictions = case.get("candidates")
    item = predictions.get(name) if isinstance(predictions, dict) else None
    p = item.get("prob") if isinstance(item, dict) else None
    if not isinstance(p, dict) or not finite_number(p.get("P")) or not finite_number(p.get("B")):
        return None
    pp, pb = float(p["P"]), float(p["B"])
    if pp < 0 or pb < 0 or pp > 1 or pb > 1 or pp + pb <= 0:
        return None
    z = pp + pb
    return {"P": pp / z, "B": pb / z}


def prequential_candidate_report(raw_cases: Any, active_champion: Any) -> dict[str, Any]:
    cases = raw_cases if isinstance(raw_cases, list) else []
    shadow_rows: dict[str, list[dict[str, Any]]] = {name: [] for name in CANDIDATES}
    complete_indices: list[int] = []
    alignment_checked = alignment_matches = 0
    v45_case_count = 0
    for i, case in enumerate(cases):
        if not isinstance(case, dict) or case.get("actual") not in OUTCOMES:
            continue
        if case.get("engineVersion") == V45_SCHEMA:
            v45_case_count += 1
        probs = {name: read_candidate_prob(case, name) for name in CANDIDATES}
        if all(probs[name] is not None for name in CANDIDATES):
            complete_indices.append(i)
            for name in CANDIDATES:
                shadow_rows[name].append({"source_index": i, "case": case, "actual": case["actual"], "prob": probs[name]})
            active = case.get("activeProfile")
            main_prob = read_prob(case)
            if active in CANDIDATES and main_prob is not None and probs.get(active) is not None:
                alignment_checked += 1
                if abs(main_prob["P"] - probs[active]["P"]) <= 1e-12 and abs(main_prob["B"] - probs[active]["B"]) <= 1e-12:
                    alignment_matches += 1
    metrics_by_candidate = {name: metrics(shadow_rows[name]) for name in CANDIDATES}
    rankable = [(name, report["log_loss"]) for name, report in metrics_by_candidate.items()
                if report["n"] > 0 and report["log_loss"] is not None]
    rankable.sort(key=lambda item: item[1])
    return {
        "candidate_names": list(CANDIDATES),
        "complete_pre_outcome_shadow_cases": len(complete_indices),
        "v4_5_scored_cases": v45_case_count,
        "active_champion": active_champion if active_champion in CANDIDATES else None,
        "candidate_metrics": metrics_by_candidate,
        "ranked_by_historical_log_loss": [{"candidate": name, "log_loss": ll} for name, ll in rankable],
        "active_forecast_alignment": {"checked": alignment_checked, "matches": alignment_matches,
            "note": "comparison only possible when each case stores activeProfile; this checks internal consistency, not truth"},
        "selection_use": "historical candidate metrics are descriptive only; V4.5 promotion uses a separate prospective fixed-size trial",
        "chronology_limit": "the offline auditor can inspect saved fields but cannot independently prove these forecasts were created before outcomes"
    }


def selection_trial_report(learner: dict[str, Any]) -> dict[str, Any]:
    selection = learner.get("selection") if isinstance(learner.get("selection"), dict) else {}
    trial = selection.get("trial") if isinstance(selection.get("trial"), dict) else None
    last = selection.get("lastTrial") if isinstance(selection.get("lastTrial"), dict) else None
    if trial:
        rows = trial.get("rows") if isinstance(trial.get("rows"), list) else []
        active = {"status": "RUNNING", "candidate": trial.get("candidate"), "champion": trial.get("champion"),
                  "scored_cases": len(rows), "target_cases": trial.get("target", 60),
                  "started_at": trial.get("startedAt"),
                  "decision": "not decided; trial is incomplete and must not be interpreted as a pass"}
    else:
        active = {"status": "NONE", "decision": "no currently running prospective trial"}
    return {"current_trial": active,
            "last_completed_trial": last,
            "trial_history_count": len(selection.get("trialHistory", [])) if isinstance(selection.get("trialHistory"), list) else 0,
            "promotion_record": selection.get("lastPromotion"),
            "important_limit": "the paired confidence bound is an approximate normal interval; real data, independent review, and repeated-use monitoring remain necessary"}

def build_report(doc: dict[str, Any]) -> dict[str, Any]:
    learner = doc.get("learner") if isinstance(doc.get("learner"), dict) else {}
    raw = learner.get("cases", [])
    rows, qc = valid_cases(raw)
    n = len(rows)
    # Chronological partitions are descriptive summaries only. Candidate selection is not performed here.
    n_train = int(n * 0.60)
    n_valid = int(n * 0.20)
    train = rows[:n_train]
    validation = rows[n_train:n_train+n_valid]
    audit = rows[n_train+n_valid:]
    all_metrics = metrics(rows)
    wrong = []
    for r in rows:
        p, y = r["prob"], r["actual"]
        pred = "P" if p["P"] >= p["B"] else "B"
        if pred != y and max(p.values()) >= 0.70:
            wrong.append({"case_order": r["source_index"], "at": r["case"].get("at"),
                          "predicted": pred, "actual": y, "confidence": round(max(p.values()), 6),
                          "log_loss": round(-math.log(max(EPS, p[y])), 6),
                          "cause_label": r["case"].get("cause"),
                          "diagnostic": r["case"].get("diagnostic")})
    history = doc.get("history") if isinstance(doc.get("history"), list) else []
    return {
        "report_schema": "NEXUS-ARC-V4.5-PREQUENTIAL-AUDIT-1",
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "source": {"schema": doc.get("schema"), "exported_at": doc.get("exportedAt"),
                   "history_entries": len(history), "learner_case_entries": len(raw) if isinstance(raw, list) else 0,
                   "events_entries": len(doc.get("events", [])) if isinstance(doc.get("events", []), list) else 0,
                   "checksum_present": bool(doc.get("checksum")),
                   "checksum_verified": False},
        "quality_control": qc,
        "overall": all_metrics,
        "baseline_50_50": {"log_loss": round(BASELINE_LL, 6), "brier": BASELINE_BRIER, "accuracy_reference": 0.5},
        "chronological_segments": {"rule": "60/20/20 by saved forecast order; rows with invalid outcomes/probabilities are excluded before splitting",
            "train_descriptive": metrics(train), "validation_descriptive": metrics(validation), "audit_descriptive": metrics(audit),
            "warning": "segments are not guaranteed untouched, and this report does not select/promote a model"},
        "rolling_drift": drift_report(rows),
        "confidence_calibration": confidence_bins(rows),
        "high_confidence_errors": {"threshold": 0.70, "count": len(wrong), "examples": wrong[-50:]},
        "error_hypotheses": hypothesis_summary(rows, learner.get("errors", [])),
        "prequential_shadow_candidates": prequential_candidate_report(raw, learner.get("selection", {}).get("champion") if isinstance(learner.get("selection"), dict) else None),
        "selection_trial": selection_trial_report(learner),
        "limitations": [
            "This report evaluates saved probabilities against saved outcomes; it does not validate the truth of the outcomes.",
            "An exported Brain alone cannot prove forecasts were created before outcomes or prevent repeated holdout inspection.",
            "A positive historical skill score is not proof of future predictive edge; use timestamped, prospective collection and independent benchmarks.",
            "Checksum presence is reported but not verified by this offline tool. The V4.5 app verifies export checksums on import.",
            "For randomized processes, historical pattern memory alone does not establish predictability.",
            "Historical metrics for the five shadow candidates remain descriptive; only a completed prospective trial may pass the app promotion gate.",
            "The paired 95% lower bound uses a normal approximation and is a guardrail, not a substitute for domain-specific statistical review."
        ]
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="Audit NEXUS ARC V4.5 Brain forecasts and pre-outcome shadow candidates (stdlib only).")
    parser.add_argument("brain_json", type=Path, help="Brain JSON exported from NEXUS ARC")
    parser.add_argument("--out", type=Path, help="Optional path for the JSON audit report")
    args = parser.parse_args()
    try:
        doc = json.loads(args.brain_json.read_text(encoding="utf-8"))
    except FileNotFoundError:
        print(f"ERROR: file not found: {args.brain_json}", file=sys.stderr); return 2
    except (UnicodeDecodeError, json.JSONDecodeError) as e:
        print(f"ERROR: invalid JSON: {e}", file=sys.stderr); return 2
    if not isinstance(doc, dict) or not isinstance(doc.get("learner"), dict):
        print("ERROR: expected a Brain export object with a learner field", file=sys.stderr); return 2
    report = build_report(doc)
    text = json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False) + "\n"
    if args.out:
        args.out.write_text(text, encoding="utf-8")
        print(f"Audit report written: {args.out}")
    o = report["overall"]
    d = report["rolling_drift"]
    print(f"NEXUS ARC V4.5 offline audit · schema={report['source']['schema']} · valid scored cases={o['n']}")
    print(f"Log Loss={o['log_loss']} (50/50 baseline={BASELINE_LL:.6f}) · Brier={o['brier']} (baseline=0.5) · Accuracy={o['accuracy']}")
    print(f"Rolling drift={d['status']} · {d.get('reason','')}")
    print("LIMIT: descriptive historical audit only; no guarantee of predictive edge.")
    if not args.out:
        print(text)
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
