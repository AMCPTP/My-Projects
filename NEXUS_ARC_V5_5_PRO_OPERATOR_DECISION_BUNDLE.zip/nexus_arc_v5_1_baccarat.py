"""NEXUS ARC V5.1 Baccarat Pro Decision Support.
Descriptive statistics and guardrails only; no next-hand prediction or betting edge claims.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Iterable

BASELINE_8_DECK = {"B": 0.458597, "P": 0.446247, "T": 0.095156}


def parse_outcomes(values: str | Iterable[str]) -> list[str]:
    if isinstance(values, str):
        import re
        tokens = re.split(r"[^A-Za-z]+", values.upper())
    else:
        tokens = [str(x).upper() for x in values]
    aliases = {"B": "B", "BANKER": "B", "P": "P", "PLAYER": "P", "T": "T", "TIE": "T"}
    return [aliases[t] for t in tokens if t in aliases]


def baseline_ev_per_unit(side: str, *, banker_commission: float = 0.05, tie_net_payout: float = 8.0) -> float:
    """Expected net profit per one unit staked under standard 8-deck probabilities.
    Banker/Player tie is a push. Tie bet wins tie_net_payout units and loses 1 otherwise.
    Table rules and probabilities can differ.
    """
    side = side.upper()
    b, p, t = BASELINE_8_DECK["B"], BASELINE_8_DECK["P"], BASELINE_8_DECK["T"]
    if not 0 <= banker_commission <= 1:
        raise ValueError("banker_commission must be between 0 and 1")
    if tie_net_payout < 0:
        raise ValueError("tie_net_payout must be nonnegative")
    if side == "B": return b * (1 - banker_commission) - p
    if side == "P": return p - b
    if side == "T": return t * tie_net_payout - (b + p)
    raise ValueError("side must be B, P, or T")


def wilson_interval(successes: int, total: int, z: float = 1.96) -> tuple[float, float] | None:
    if total < 0 or successes < 0 or successes > total or z <= 0:
        raise ValueError("invalid interval inputs")
    if total == 0: return None
    phat = successes / total
    z2 = z*z
    den = 1 + z2/total
    center = (phat + z2/(2*total))/den
    half = z*((phat*(1-phat)/total + z2/(4*total*total))**0.5)/den
    return max(0.0, center-half), min(1.0, center+half)


def summarize(values: str | Iterable[str]) -> dict:
    seq = parse_outcomes(values)
    b, p, t = seq.count("B"), seq.count("P"), seq.count("T")
    decisive = b+p
    pb = [x for x in seq if x != "T"]
    switches = sum(a != c for a, c in zip(pb, pb[1:]))
    runs: list[dict] = []
    for x in pb:
        if runs and runs[-1]["side"] == x: runs[-1]["length"] += 1
        else: runs.append({"side": x, "length": 1})
    ci = wilson_interval(b, decisive)
    return {
        "n_total": len(seq), "banker": b, "player": p, "tie": t,
        "decisive_n": decisive,
        "banker_share_decisive": b/decisive if decisive else None,
        "banker_share_wilson95": ci,
        "switches": switches,
        "switch_rate": switches/(decisive-1) if decisive > 1 else None,
        "last_run": runs[-1] if runs else None,
        "decision": "PASS_NO_DEMONSTRATED_EDGE_FROM_ROADS_ALONE",
        "warning": "Historical P/B/T patterns do not establish next-hand predictive edge."
    }


@dataclass(frozen=True)
class SessionGuard:
    bankroll: float
    unit: float
    stop_loss: float
    session_pl: float

    def evaluate(self) -> dict:
        vals = (self.bankroll, self.unit, self.stop_loss, self.session_pl)
        if any(not isinstance(x, (int, float)) for x in vals): raise ValueError("all values must be numeric")
        if self.bankroll < 0 or self.unit < 0 or self.stop_loss < 0: raise ValueError("bankroll, unit and stop_loss must be nonnegative")
        if self.unit > self.bankroll and self.unit > 0:
            status = "STOP_UNIT_EXCEEDS_BANKROLL"
        elif self.stop_loss == 0:
            status = "PAUSE_STOP_LOSS_NOT_SET"
        elif self.session_pl <= -self.stop_loss:
            status = "STOP_LOSS_LIMIT_REACHED"
        else:
            status = "WITHIN_USER_SET_LIMIT"
        return {**asdict(self), "status": status, "note": "A guardrail is not a prediction or a signal to bet."}
