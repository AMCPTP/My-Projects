"""NEXUS ARC V5.2 prospective forecast evaluation.

This module tests whether a submitted probability forecast improves on a fixed
8-deck baccarat baseline. It is an audit/evaluation harness, not a next-hand
predictor, betting recommendation, or proof of profitability.
"""
from __future__ import annotations
from datetime import datetime, timezone
from math import log, sqrt
from statistics import mean, stdev
from typing import Any, Mapping, Sequence
from uuid import uuid4

BASELINE = {"B": 0.458597, "P": 0.446247, "T": 0.095156}
OUTCOMES = ("B", "P", "T")
EPSILON = 1e-12


def validate_probabilities(probabilities: Mapping[str, Any], *, tolerance: float = 1e-6) -> dict[str, float]:
    """Validate a full B/P/T distribution. Values are fractions in [0,1]."""
    if not isinstance(probabilities, Mapping) or any(k not in probabilities for k in OUTCOMES):
        raise ValueError("probabilities must include B, P and T")
    result: dict[str, float] = {}
    for key in OUTCOMES:
        value = probabilities[key]
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise ValueError(f"probability {key} must be numeric")
        value = float(value)
        if not 0 <= value <= 1:
            raise ValueError(f"probability {key} must be between 0 and 1")
        result[key] = value
    if abs(sum(result.values()) - 1.0) > tolerance:
        raise ValueError("B + P + T probabilities must sum to 1")
    return result


def _time(value: str | None) -> str:
    if value is None:
        return datetime.now(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")
    if not isinstance(value, str) or not value.strip():
        raise ValueError("timestamp must be a non-empty ISO-8601 string")
    try:
        parsed = datetime.fromisoformat(value.strip().replace("Z", "+00:00"))
    except ValueError as exc:
        raise ValueError("timestamp must be ISO-8601") from exc
    if parsed.tzinfo is None:
        raise ValueError("timestamp must include a timezone")
    return parsed.astimezone(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")


def create_forecast(probabilities: Mapping[str, Any], *, created_at: str | None = None, forecast_id: str | None = None) -> dict[str, Any]:
    """Create one pending forecast before the associated outcome is known."""
    return {
        "forecast_id": forecast_id or str(uuid4()),
        "created_at": _time(created_at),
        "probabilities": validate_probabilities(probabilities),
        "status": "PENDING",
        "actual": None,
        "resolved_at": None,
    }


def score_probabilities(probabilities: Mapping[str, Any], actual: str) -> dict[str, float]:
    """Return multiclass Brier (0..2; lower is better) and log loss."""
    p = validate_probabilities(probabilities)
    actual = str(actual).upper().strip()
    if actual not in OUTCOMES:
        raise ValueError("actual must be B, P or T")
    brier = sum((p[k] - (1.0 if k == actual else 0.0)) ** 2 for k in OUTCOMES)
    log_loss = -log(max(EPSILON, p[actual]))
    return {"brier": brier, "log_loss": log_loss}


def resolve_forecast(record: Mapping[str, Any], actual: str, *, resolved_at: str | None = None) -> dict[str, Any]:
    """Resolve a pending forecast exactly once, preserving the forecast itself."""
    if record.get("status") != "PENDING" or record.get("actual") is not None:
        raise ValueError("forecast has already been resolved or is invalid")
    outcome = str(actual).upper().strip()
    if outcome not in OUTCOMES:
        raise ValueError("actual must be B, P or T")
    created = datetime.fromisoformat(_time(record.get("created_at")).replace("Z", "+00:00"))
    resolved_text = _time(resolved_at)
    resolved = datetime.fromisoformat(resolved_text.replace("Z", "+00:00"))
    if resolved < created:
        raise ValueError("resolved_at cannot precede created_at")
    probs = validate_probabilities(record.get("probabilities", {}))
    model_score = score_probabilities(probs, outcome)
    baseline_score = score_probabilities(BASELINE, outcome)
    result = dict(record)
    result.update({
        "status": "RESOLVED",
        "actual": outcome,
        "resolved_at": resolved_text,
        "score": model_score,
        "baseline_score": baseline_score,
        "delta_vs_baseline": {
            "brier": model_score["brier"] - baseline_score["brier"],
            "log_loss": model_score["log_loss"] - baseline_score["log_loss"],
        },
    })
    return result


def _mean_ci(values: Sequence[float]) -> dict[str, float] | None:
    """Normal-approximation 95% CI for a paired mean difference; diagnostic only."""
    n = len(values)
    if n == 0:
        return None
    avg = mean(values)
    if n == 1:
        return {"mean": avg, "lower95": avg, "upper95": avg, "n": n, "method": "single_observation_no_uncertainty_estimate"}
    se = stdev(values) / sqrt(n)
    return {"mean": avg, "lower95": avg - 1.96 * se, "upper95": avg + 1.96 * se, "n": n, "method": "paired_mean_normal_approximation"}


def _calibration(records: Sequence[Mapping[str, Any]], bins: int = 10) -> dict[str, list[dict[str, float | int]]]:
    result: dict[str, list[dict[str, float | int]]] = {}
    for label in OUTCOMES:
        rows = []
        for idx in range(bins):
            low, high = idx / bins, (idx + 1) / bins
            subset = [r for r in records if low <= float(r["probabilities"][label]) < high or (idx == bins - 1 and float(r["probabilities"][label]) == 1.0)]
            if not subset:
                continue
            rows.append({
                "bin_low": low,
                "bin_high": high,
                "n": len(subset),
                "mean_predicted": mean(float(r["probabilities"][label]) for r in subset),
                "observed_rate": mean(1.0 if r["actual"] == label else 0.0 for r in subset),
            })
        result[label] = rows
    return result


def summarize_ledger(records: Sequence[Mapping[str, Any]], *, min_sample: int = 100, review_sample: int = 300, drift_window: int = 50) -> dict[str, Any]:
    """Summarize outcomes; scores are recomputed from probability + result fields.

    This report never authorizes a bet. CI estimates are approximate and do not
    account for dependence between consecutive baccarat outcomes.
    """
    if min_sample < 1 or review_sample < min_sample or drift_window < 2:
        raise ValueError("invalid evaluation thresholds")
    if not isinstance(records, Sequence) or isinstance(records, (str, bytes)):
        raise ValueError("records must be a sequence")
    ids: set[str] = set()
    resolved: list[dict[str, Any]] = []
    pending = 0
    pending_seen = False
    previous_created = None
    previous_resolved = None
    for raw in records:
        if not isinstance(raw, Mapping):
            raise ValueError("each record must be an object")
        if pending_seen:
            raise ValueError("a pending forecast must be the final record in the sequential ledger")
        rid = str(raw.get("forecast_id", "")).strip()
        if not rid or rid in ids:
            raise ValueError("forecast IDs must be non-empty and unique")
        ids.add(rid)
        probs = validate_probabilities(raw.get("probabilities", {}))
        created = datetime.fromisoformat(_time(raw.get("created_at")).replace("Z", "+00:00"))
        if previous_created is not None and created < previous_created:
            raise ValueError("forecast ledger must be ordered by created_at")
        if previous_resolved is not None and created < previous_resolved:
            raise ValueError("next forecast cannot precede the prior observed outcome")
        previous_created = created
        status = raw.get("status")
        if status == "PENDING":
            pending += 1
            pending_seen = True
            if raw.get("actual") is not None:
                raise ValueError("pending forecast cannot contain an actual result")
        elif status == "RESOLVED":
            actual = str(raw.get("actual", "")).upper()
            if actual not in OUTCOMES:
                raise ValueError("resolved forecast needs actual B/P/T")
            resolved_at = datetime.fromisoformat(_time(raw.get("resolved_at")).replace("Z", "+00:00"))
            if resolved_at < created:
                raise ValueError("resolved_at cannot precede created_at")
            previous_resolved = resolved_at
            row = dict(raw)
            row["probabilities"] = probs
            row["actual"] = actual
            row["score"] = score_probabilities(probs, actual)
            row["baseline_score"] = score_probabilities(BASELINE, actual)
            row["delta_vs_baseline"] = {
                "brier": row["score"]["brier"] - row["baseline_score"]["brier"],
                "log_loss": row["score"]["log_loss"] - row["baseline_score"]["log_loss"],
            }
            resolved.append(row)
        else:
            raise ValueError("status must be PENDING or RESOLVED")
    n = len(resolved)
    model_brier = mean(r["score"]["brier"] for r in resolved) if n else None
    baseline_brier = mean(r["baseline_score"]["brier"] for r in resolved) if n else None
    model_ll = mean(r["score"]["log_loss"] for r in resolved) if n else None
    baseline_ll = mean(r["baseline_score"]["log_loss"] for r in resolved) if n else None
    brier_ci = _mean_ci([r["delta_vs_baseline"]["brier"] for r in resolved])
    ll_ci = _mean_ci([r["delta_vs_baseline"]["log_loss"] for r in resolved])
    if n < min_sample:
        gate = "WARMING_INSUFFICIENT_SAMPLE"
        explanation = f"ต้องมีผลที่ปิดแล้วอย่างน้อย {min_sample} รายการก่อนประเมินเบื้องต้น"
    elif n < review_sample:
        gate = "EVALUATING_NO_PROMOTION"
        explanation = f"มี {n} รายการ แต่ยังต่ำกว่าเกณฑ์ทบทวน {review_sample}; ห้ามสรุปว่าชนะค่าฐาน"
    elif brier_ci and ll_ci and brier_ci["upper95"] < 0 and ll_ci["upper95"] < 0:
        gate = "PROVISIONAL_IMPROVEMENT_REQUIRES_INDEPENDENT_REPLICATION"
        explanation = "ดีกว่าค่าฐานทั้ง Brier และ log loss ภายใต้ช่วงประมาณนี้ แต่ต้องทำซ้ำอย่างอิสระ; ไม่ใช่สัญญาณเดิมพัน"
    else:
        gate = "NO_DEMONSTRATED_IMPROVEMENT_OVER_BASELINE"
        explanation = "ยังไม่มีหลักฐานชัดว่าดีกว่าค่าฐานในทั้งสองคะแนน; ใช้ค่าฐาน/งดข้อสรุปต่อไป"
    drift = {"status": "INSUFFICIENT_HISTORY", "delta_brier_worsening": None}
    if n >= drift_window * 2:
        previous = [r["delta_vs_baseline"]["brier"] for r in resolved[-2 * drift_window:-drift_window]]
        recent = [r["delta_vs_baseline"]["brier"] for r in resolved[-drift_window:]]
        worsening = mean(recent) - mean(previous)
        drift = {"status": "DEGRADATION_SIGNAL_REVIEW_REQUIRED" if worsening >= 0.05 else "NO_CLEAR_DEGRADATION_SIGNAL", "delta_brier_worsening": worsening, "previous_window_n": len(previous), "recent_window_n": len(recent), "threshold": 0.05}
    return {
        "schema": "nexus-arc-v5.2-evaluation-summary-v1",
        "resolved_n": n,
        "pending_n": pending,
        "min_sample": min_sample,
        "review_sample": review_sample,
        "model_brier_mean": model_brier,
        "baseline_brier_mean": baseline_brier,
        "brier_skill_vs_baseline": (1 - model_brier / baseline_brier) if model_brier is not None and baseline_brier and baseline_brier > 0 else None,
        "model_log_loss_mean": model_ll,
        "baseline_log_loss_mean": baseline_ll,
        "paired_brier_delta_ci95": brier_ci,
        "paired_log_loss_delta_ci95": ll_ci,
        "gate": gate,
        "explanation": explanation,
        "drift": drift,
        "calibration": _calibration(resolved),
        "decision": "NO_BET_RECOMMENDATION_FROM_ROADMAP_OR_THIS_AUDIT",
        "limitations": [
            "Requires forecasts recorded before the corresponding outcome; retrospectively entered data invalidates the audit.",
            "Browser JSON is editable and is not a tamper-proof or independently verified ledger.",
            "The baseline assumes approximate standard 8-deck probabilities and can vary by rules/shoe.",
            "Normal-approximation intervals ignore serial dependence and are diagnostic, not certification.",
            "A score improvement does not establish profitability or a causal betting edge.",
        ],
    }
