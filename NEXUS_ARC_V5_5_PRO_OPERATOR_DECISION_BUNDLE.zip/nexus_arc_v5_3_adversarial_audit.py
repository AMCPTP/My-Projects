"""NEXUS ARC V5.3 adversarial, prequential and regime-aware audit.

This evaluates a submitted forecast stream against a fixed baseline. It does not
predict baccarat outcomes, recommend wagers, or certify profitability.
"""
from __future__ import annotations

from datetime import datetime, timezone
from hashlib import sha256
import json
from math import log
import random
from statistics import mean
from typing import Any, Mapping, Sequence
from uuid import uuid4

BASELINE = {"B": 0.458597, "P": 0.446247, "T": 0.095156}
OUTCOMES = ("B", "P", "T")
EPSILON = 1e-12
SCHEMA = "nexus-arc-v5.3-prospective-ledger-v1"


def validate_probabilities(probabilities: Mapping[str, Any], *, tolerance: float = 1e-6) -> dict[str, float]:
    if not isinstance(probabilities, Mapping) or any(k not in probabilities for k in OUTCOMES):
        raise ValueError("probabilities must include B, P and T")
    result: dict[str, float] = {}
    for key in OUTCOMES:
        value = probabilities[key]
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise ValueError(f"probability {key} must be numeric")
        value = float(value)
        if not 0 <= value <= 1:
            raise ValueError(f"probability {key} must be between 0 and 1")
        result[key] = value
    if abs(sum(result.values()) - 1.0) > tolerance:
        raise ValueError("B + P + T probabilities must sum to 1")
    # Normalize tolerated floating-point rounding, preserving a valid distribution.
    total = sum(result.values())
    if total <= 0:
        raise ValueError("probabilities must sum to a positive value")
    return {k: v / total for k, v in result.items()}


def _parse_time(value: str | None) -> datetime:
    if not isinstance(value, str) or not value.strip():
        raise ValueError("timestamp must be a non-empty ISO-8601 string")
    try:
        parsed = datetime.fromisoformat(value.strip().replace("Z", "+00:00"))
    except ValueError as exc:
        raise ValueError("timestamp must be ISO-8601") from exc
    if parsed.tzinfo is None:
        raise ValueError("timestamp must include a timezone")
    return parsed.astimezone(timezone.utc)


def _time(value: str | None) -> str:
    # Preserve fractional seconds; truncating to whole seconds can hide order violations.
    if value is None:
        parsed = datetime.now(timezone.utc)
    else:
        parsed = _parse_time(value)
    return parsed.isoformat().replace("+00:00", "Z")


def create_forecast(
    probabilities: Mapping[str, Any], *, created_at: str | None = None,
    forecast_id: str | None = None, model_id: str = "candidate-unlabelled",
) -> dict[str, Any]:
    model_id = str(model_id).strip()
    if not model_id:
        raise ValueError("model_id must be non-empty")
    return {
        "forecast_id": forecast_id or str(uuid4()),
        "model_id": model_id,
        "created_at": _time(created_at or datetime.now(timezone.utc).isoformat()),
        "probabilities": validate_probabilities(probabilities),
        "status": "PENDING", "actual": None, "resolved_at": None,
    }


def score_probabilities(probabilities: Mapping[str, Any], actual: str) -> dict[str, float]:
    p = validate_probabilities(probabilities)
    actual = str(actual).upper().strip()
    if actual not in OUTCOMES:
        raise ValueError("actual must be B, P or T")
    return {
        "brier": sum((p[k] - (1.0 if k == actual else 0.0)) ** 2 for k in OUTCOMES),
        "log_loss": -log(max(EPSILON, p[actual])),
    }


def resolve_forecast(record: Mapping[str, Any], actual: str, *, resolved_at: str | None = None) -> dict[str, Any]:
    if record.get("status") != "PENDING" or record.get("actual") is not None:
        raise ValueError("forecast has already been resolved or is invalid")
    outcome = str(actual).upper().strip()
    if outcome not in OUTCOMES:
        raise ValueError("actual must be B, P or T")
    created = _parse_time(str(record.get("created_at", "")))
    resolved_text = _time(resolved_at or datetime.now(timezone.utc).isoformat())
    resolved = _parse_time(resolved_text)
    if resolved < created:
        raise ValueError("resolved_at cannot precede created_at")
    probs = validate_probabilities(record.get("probabilities", {}))
    model_score, baseline_score = score_probabilities(probs, outcome), score_probabilities(BASELINE, outcome)
    result = dict(record)
    result.update({
        "status": "RESOLVED", "actual": outcome, "resolved_at": resolved_text,
        "probabilities": probs, "score": model_score, "baseline_score": baseline_score,
        "delta_vs_baseline": {
            "brier": model_score["brier"] - baseline_score["brier"],
            "log_loss": model_score["log_loss"] - baseline_score["log_loss"],
        },
    })
    return result


def _quantile(sorted_values: Sequence[float], q: float) -> float:
    if not sorted_values:
        raise ValueError("quantile needs at least one value")
    if len(sorted_values) == 1:
        return float(sorted_values[0])
    pos = max(0.0, min(1.0, q)) * (len(sorted_values) - 1)
    lo = int(pos)
    hi = min(len(sorted_values) - 1, lo + 1)
    frac = pos - lo
    return float(sorted_values[lo] * (1 - frac) + sorted_values[hi] * frac)


def moving_block_bootstrap_ci(
    values: Sequence[float], *, confidence: float = 0.95, block_length: int = 5,
    replicates: int = 2000, seed: int = 1729, min_n: int = 30,
) -> dict[str, Any] | None:
    """Moving-block bootstrap CI for a mean, preserving short-range order approximately.

    It cannot fix nonstationarity, adaptive model selection, fabricated timestamps, or
    dependence spanning longer than the chosen block. For small samples returns None.
    """
    vals = [float(v) for v in values]
    n = len(vals)
    if not 0 < confidence < 1:
        raise ValueError("confidence must be in (0, 1)")
    if block_length < 1 or replicates < 100 or min_n < 2:
        raise ValueError("invalid bootstrap settings")
    if any(not __import__("math").isfinite(v) for v in vals):
        raise ValueError("bootstrap values must be finite")
    if n < min_n:
        return None
    block = min(block_length, n)
    rng = random.Random(seed)
    means: list[float] = []
    max_start = n - block
    for _ in range(replicates):
        sample: list[float] = []
        while len(sample) < n:
            start = rng.randrange(max_start + 1)
            sample.extend(vals[start:start + block])
        means.append(mean(sample[:n]))
    means.sort()
    tail = (1.0 - confidence) / 2.0
    return {
        "mean": mean(vals), "lower": _quantile(means, tail),
        "upper": _quantile(means, 1.0 - tail), "n": n,
        "method": "moving_block_bootstrap_mean_ci",
        "block_length": block, "replicates": replicates, "confidence": confidence,
    }


def _validate_ledger(records: Sequence[Mapping[str, Any]]) -> tuple[list[dict[str, Any]], int, set[str]]:
    if not isinstance(records, Sequence) or isinstance(records, (str, bytes)):
        raise ValueError("records must be a sequence")
    ids: set[str] = set()
    resolved: list[dict[str, Any]] = []
    pending = 0
    pending_seen = False
    previous_created: datetime | None = None
    previous_resolved: datetime | None = None
    model_ids: set[str] = set()
    for index, raw in enumerate(records):
        if not isinstance(raw, Mapping):
            raise ValueError("each record must be an object")
        if pending_seen:
            raise ValueError("a pending forecast must be the final record in the sequential ledger")
        rid = str(raw.get("forecast_id", "")).strip()
        if not rid or rid in ids:
            raise ValueError("forecast IDs must be non-empty and unique")
        ids.add(rid)
        model_id = str(raw.get("model_id", "candidate-unlabelled")).strip()
        if not model_id:
            raise ValueError("model_id must be non-empty")
        model_ids.add(model_id)
        probs = validate_probabilities(raw.get("probabilities", {}))
        created = _parse_time(str(raw.get("created_at", "")))
        if previous_created is not None and created < previous_created:
            raise ValueError("forecast ledger must be ordered by created_at")
        if previous_resolved is not None and created < previous_resolved:
            raise ValueError("next forecast cannot precede the prior observed outcome")
        previous_created = created
        status = raw.get("status")
        if status == "PENDING":
            pending += 1
            pending_seen = True
            if raw.get("actual") is not None or raw.get("resolved_at") is not None:
                raise ValueError("pending forecast cannot contain an actual result/resolved timestamp")
        elif status == "RESOLVED":
            actual = str(raw.get("actual", "")).upper()
            if actual not in OUTCOMES:
                raise ValueError("resolved forecast needs actual B/P/T")
            resolved_at = _parse_time(str(raw.get("resolved_at", "")))
            if resolved_at < created:
                raise ValueError("resolved_at cannot precede created_at")
            previous_resolved = resolved_at
            row = dict(raw)
            row["model_id"] = model_id
            row["probabilities"] = probs
            row["actual"] = actual
            row["score"] = score_probabilities(probs, actual)
            row["baseline_score"] = score_probabilities(BASELINE, actual)
            row["delta_vs_baseline"] = {
                "brier": row["score"]["brier"] - row["baseline_score"]["brier"],
                "log_loss": row["score"]["log_loss"] - row["baseline_score"]["log_loss"],
            }
            resolved.append(row)
        else:
            raise ValueError("status must be PENDING or RESOLVED")
    if len(model_ids) > 1:
        raise ValueError("mixed model_id values in one cohort; evaluate each model in a separate cohort")
    return resolved, pending, model_ids


def _calibration(records: Sequence[Mapping[str, Any]], bins: int = 10) -> dict[str, Any]:
    by_class: dict[str, list[dict[str, float | int]]] = {}
    weighted_abs_gap = 0.0
    total_class_bins = 0
    for label in OUTCOMES:
        rows = []
        for idx in range(bins):
            low, high = idx / bins, (idx + 1) / bins
            subset = [r for r in records if low <= r["probabilities"][label] < high or (idx == bins - 1 and r["probabilities"][label] == 1.0)]
            if not subset:
                continue
            predicted = mean(r["probabilities"][label] for r in subset)
            observed = mean(1.0 if r["actual"] == label else 0.0 for r in subset)
            gap = abs(predicted - observed)
            rows.append({"bin_low": low, "bin_high": high, "n": len(subset), "mean_predicted": predicted, "observed_rate": observed, "absolute_gap": gap})
            weighted_abs_gap += len(subset) * gap
            total_class_bins += len(subset)
        by_class[label] = rows
    return {"by_class": by_class, "weighted_calibration_gap": weighted_abs_gap / total_class_bins if total_class_bins else None,
            "note": "Descriptive calibration diagnostic; bins are noisy and not a causal or betting signal."}


def summarize_ledger(
    records: Sequence[Mapping[str, Any]], *, min_sample: int = 100, review_sample: int = 300,
    drift_window: int = 50, block_length: int = 5, bootstrap_replicates: int = 2000,
    bootstrap_seed: int = 1729, min_bootstrap_n: int = 30, trials_inspected: int = 1,
) -> dict[str, Any]:
    """Summarize a prospective cohort with strict order checks and dependence-aware CI."""
    if min_sample < 1 or review_sample < min_sample or drift_window < 2:
        raise ValueError("invalid evaluation thresholds")
    if isinstance(trials_inspected, bool) or not isinstance(trials_inspected, int) or trials_inspected < 1:
        raise ValueError("trials_inspected must be a positive integer")
    resolved, pending, model_ids = _validate_ledger(records)
    n = len(resolved)
    brier_deltas = [r["delta_vs_baseline"]["brier"] for r in resolved]
    ll_deltas = [r["delta_vs_baseline"]["log_loss"] for r in resolved]
    model_brier = mean(r["score"]["brier"] for r in resolved) if n else None
    baseline_brier = mean(r["baseline_score"]["brier"] for r in resolved) if n else None
    model_ll = mean(r["score"]["log_loss"] for r in resolved) if n else None
    baseline_ll = mean(r["baseline_score"]["log_loss"] for r in resolved) if n else None
    brier_ci = moving_block_bootstrap_ci(brier_deltas, block_length=block_length, replicates=bootstrap_replicates, seed=bootstrap_seed, min_n=min_bootstrap_n)
    ll_ci = moving_block_bootstrap_ci(ll_deltas, block_length=block_length, replicates=bootstrap_replicates, seed=bootstrap_seed + 1, min_n=min_bootstrap_n)

    drift: dict[str, Any] = {"status": "INSUFFICIENT_HISTORY", "delta_brier_worsening": None}
    if n >= drift_window * 2:
        previous = brier_deltas[-2 * drift_window:-drift_window]
        recent = brier_deltas[-drift_window:]
        worsening = mean(recent) - mean(previous)
        drift = {
            "status": "DEGRADATION_SIGNAL_REVIEW_REQUIRED" if worsening >= 0.05 else "NO_CLEAR_DEGRADATION_SIGNAL",
            "delta_brier_worsening": worsening, "previous_window_n": len(previous),
            "recent_window_n": len(recent), "threshold": 0.05,
        }

    # Stability check prevents an attractive aggregate from hiding failure in either half.
    stability: dict[str, Any] = {"status": "INSUFFICIENT_HISTORY", "segments": []}
    if n >= min_sample:
        midpoint = n // 2
        segments = []
        for name, part in (("first_half", resolved[:midpoint]), ("second_half", resolved[midpoint:])):
            db = mean(r["delta_vs_baseline"]["brier"] for r in part)
            dl = mean(r["delta_vs_baseline"]["log_loss"] for r in part)
            segments.append({"name": name, "n": len(part), "mean_delta_brier": db, "mean_delta_log_loss": dl,
                             "both_metrics_better_than_baseline": db < 0 and dl < 0})
        stable = all(s["both_metrics_better_than_baseline"] for s in segments)
        stability = {"status": "BOTH_HALVES_IMPROVED" if stable else "INCONSISTENT_ACROSS_HALVES", "segments": segments}

    if n < min_sample:
        gate, explanation = "WARMING_INSUFFICIENT_SAMPLE", f"ต้องมีผลที่ปิดแล้วอย่างน้อย {min_sample} รายการก่อนประเมินเบื้องต้น"
    elif n < review_sample:
        gate, explanation = "EVALUATING_NO_PROMOTION", f"มี {n} รายการ แต่ยังต่ำกว่าเกณฑ์ทบทวน {review_sample}; ห้ามสรุปว่าชนะค่าฐาน"
    elif trials_inspected > 1:
        gate, explanation = "EXPLORATORY_MULTIPLE_TRIALS_NO_PROMOTION", f"รายงานว่าทดลอง {trials_inspected} รุ่น/การตั้งค่า; ผลนี้เป็น exploratory และต้องล็อกโมเดลแล้วทดสอบ cohort ยืนยันใหม่"
    elif drift["status"] == "DEGRADATION_SIGNAL_REVIEW_REQUIRED":
        gate, explanation = "DEGRADATION_SIGNAL_NO_PROMOTION", "ช่วงล่าสุดแย่ลงตามเกณฑ์ที่ตั้งไว้; พักการส่งเสริมโมเดลและตรวจข้อมูล/การเปลี่ยนสภาวะ"
    elif stability["status"] != "BOTH_HALVES_IMPROVED":
        gate, explanation = "INCONSISTENT_ACROSS_HALVES_NO_PROMOTION", "ผลสองช่วงไม่สอดคล้องกัน; ค่าเฉลี่ยรวมอย่างเดียวไม่พอสำหรับเลื่อนสถานะ"
    elif brier_ci and ll_ci and brier_ci["upper"] < 0 and ll_ci["upper"] < 0:
        gate, explanation = "PROVISIONAL_IMPROVEMENT_REQUIRES_INDEPENDENT_REPLICATION", "ดีกว่าค่าฐานในคะแนนทั้งคู่และทั้งสองช่วงภายใต้ moving-block bootstrap; ยังเป็นผลชั่วคราว ต้องทำซ้ำในชุดข้อมูลอิสระ"
    else:
        gate, explanation = "NO_DEMONSTRATED_IMPROVEMENT_OVER_BASELINE", "ยังไม่มีหลักฐานชัดว่าดีกว่าค่าฐานในทั้งสองคะแนน ภายใต้การตรวจที่ตั้งไว้"

    return {
        "schema": "nexus-arc-v5.3-adversarial-audit-summary-v1",
        "model_id": next(iter(model_ids)) if model_ids else None,
        "resolved_n": n, "pending_n": pending, "trials_inspected": trials_inspected,
        "model_brier_mean": model_brier, "baseline_brier_mean": baseline_brier,
        "brier_skill_vs_baseline": (1 - model_brier / baseline_brier) if model_brier is not None and baseline_brier and baseline_brier > 0 else None,
        "model_log_loss_mean": model_ll, "baseline_log_loss_mean": baseline_ll,
        "paired_brier_delta_ci95": brier_ci, "paired_log_loss_delta_ci95": ll_ci,
        "ci_method": "moving block bootstrap; preserves short-range ordering approximately",
        "gate": gate, "explanation": explanation, "drift": drift, "stability": stability,
        "calibration": _calibration(resolved),
        "decision": "NO_BET_RECOMMENDATION_FROM_ROADMAP_OR_THIS_AUDIT",
        "limitations": [
            "Local/browser timestamps and results are editable and not independently time-attested.",
            "Moving-block bootstrap only approximates short-range dependence; results depend on block length and stationarity assumptions.",
            "If several candidates were tried, trials_inspected must report all known trials; exploratory results require a new frozen confirmatory cohort.",
            "The approximate 8-deck baseline varies with rules, shoe state, and outcome definitions.",
            "A scoring improvement does not establish causal advantage, expected profit, or a reliable next-hand edge.",
            "Roadmap patterns alone remain descriptive; no automatic wager or stake recommendation is produced.",
        ],
    }


def canonical_sha256(data: Any) -> str:
    """Stable digest for tamper-evident comparison when digest is stored externally.

    This is not a digital signature: anyone who can edit the data can recompute it.
    """
    canonical = json.dumps(data, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)
    return sha256(canonical.encode("utf-8")).hexdigest()


def verify_external_digest(data: Any, expected_sha256: str) -> bool:
    return canonical_sha256(data).lower() == str(expected_sha256).strip().lower()
