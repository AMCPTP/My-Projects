"""NEXUS ARC V5.4 — Profit Reality & Bankroll Risk Lab.

This module calculates expected value under explicit baccarat payout rules and
simulates session risk for flat staking versus Martingale. It is not a next-hand
predictor and does not imply that staking systems overcome a negative house edge.
"""
from __future__ import annotations

from math import isfinite, sqrt
import random
from statistics import mean, median
from typing import Any, Literal

# Common 8-deck punto banco baseline (rounded published probabilities).
BASELINE: dict[str, float] = {"B": 0.458597, "P": 0.446247, "T": 0.095156}
BetSide = Literal["B", "P", "T"]
Strategy = Literal["flat", "martingale"]


def _finite_number(name: str, value: Any, *, minimum: float = 0.0, maximum: float | None = None) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(f"{name} must be a number")
    out = float(value)
    if not isfinite(out) or out < minimum or (maximum is not None and out > maximum):
        suffix = f" and <= {maximum}" if maximum is not None else ""
        raise ValueError(f"{name} must be finite, >= {minimum}{suffix}")
    return out


def _validate_rules(banker_commission: float, player_payout: float, tie_payout: float) -> tuple[float, float, float]:
    commission = _finite_number("banker_commission", banker_commission, minimum=0.0, maximum=1.0)
    player = _finite_number("player_payout", player_payout, minimum=0.0, maximum=1000.0)
    tie = _finite_number("tie_payout", tie_payout, minimum=0.0, maximum=1000.0)
    return commission, player, tie


def expected_value_per_unit(
    side: BetSide, *, banker_commission: float = 0.05,
    player_payout: float = 1.0, tie_payout: float = 8.0,
    probabilities: dict[str, float] | None = None,
) -> float:
    """Expected net return per unit staked; a tie pushes Banker/Player bets."""
    commission, player, tie = _validate_rules(banker_commission, player_payout, tie_payout)
    probs = dict(BASELINE if probabilities is None else probabilities)
    if set(probs) != {"B", "P", "T"}:
        raise ValueError("probabilities must include exactly B, P and T")
    probs = {k: _finite_number(f"P({k})", v, minimum=0.0, maximum=1.0) for k, v in probs.items()}
    if abs(sum(probs.values()) - 1.0) > 1e-5:
        raise ValueError("probabilities must sum to 1")
    b, p, t = probs["B"], probs["P"], probs["T"]
    normalized_side = str(side).upper()
    if normalized_side == "B":
        return b * (1.0 - commission) - p
    if normalized_side == "P":
        return p * player - b
    if normalized_side == "T":
        return t * tie - (b + p)
    raise ValueError("side must be B, P or T")


def rule_analysis(*, banker_commission: float = 0.05, player_payout: float = 1.0,
                  tie_payout: float = 8.0, probabilities: dict[str, float] | None = None) -> dict[str, Any]:
    """Calculate house edges and break-even payout/commission conditions."""
    commission, player, tie = _validate_rules(banker_commission, player_payout, tie_payout)
    probs = dict(BASELINE if probabilities is None else probabilities)
    b, p, t = probs["B"], probs["P"], probs["T"]
    edges = {side: -expected_value_per_unit(side, banker_commission=commission,
            player_payout=player, tie_payout=tie, probabilities=probs) for side in ("B", "P", "T")}
    break_even = {
        "banker_commission_max": (1.0 - p / b) if b > 0 else None,
        "player_net_payout_min": (b / p) if p > 0 else None,
        "tie_net_payout_min": ((b + p) / t) if t > 0 else None,
    }
    for key, value in break_even.items():
        if value is not None and key == "banker_commission_max":
            # A negative threshold means even zero commission is insufficient under the supplied probability model.
            break_even[key] = value
    return {
        "probabilities": probs,
        "rules": {"banker_commission": commission, "player_payout": player, "tie_payout": tie},
        "house_edge": edges,
        "ev_per_unit": {k: -v for k, v in edges.items()},
        "ev_per_100_turnover": {k: -100.0 * v for k, v in edges.items()},
        "break_even": break_even,
        "assumptions": [
            "Common 8-deck punto banco baseline; table rules can differ.",
            "Tie pushes Banker/Player bets.",
            "Payout inputs are net odds per unit staked, excluding returned stake.",
            "Rounded outcome probabilities are a baseline, not a card/shoe tracker.",
        ],
    }


def _quantile(values: list[float], q: float) -> float:
    if not values:
        raise ValueError("quantile requires values")
    data = sorted(values)
    if len(data) == 1:
        return data[0]
    pos = q * (len(data) - 1)
    lo, hi = int(pos), min(len(data) - 1, int(pos) + 1)
    frac = pos - lo
    return data[lo] * (1 - frac) + data[hi] * frac


def _wilson(successes: int, n: int, z: float = 1.959963984540054) -> dict[str, float]:
    if n <= 0:
        return {"lower": 0.0, "upper": 1.0}
    p = successes / n
    den = 1 + z * z / n
    center = (p + z * z / (2 * n)) / den
    radius = z * sqrt((p * (1 - p) + z * z / (4 * n)) / n) / den
    return {"lower": max(0.0, center - radius), "upper": min(1.0, center + radius)}


def simulate_session_risk(
    *, side: BetSide = "B", strategy: Strategy = "flat", bankroll: float = 1000.0,
    base_stake: float = 10.0, stop_loss: float = 100.0, profit_target: float = 50.0,
    max_hands: int = 100, max_table_stake: float = 500.0, trials: int = 10000,
    seed: int = 20261012, banker_commission: float = 0.05,
    player_payout: float = 1.0, tie_payout: float = 8.0,
) -> dict[str, Any]:
    """Simulate sessions with fixed baseline outcome probabilities.

    Uses a common random number stream per strategy. Flat/Martingale affect stake
    paths only; outcome probabilities and house edge are unchanged. The baseline
    treats each hand as an independent draw from the rounded 8-deck outcome rates,
    so this is a risk illustration, not a shoe-composition simulator.
    """
    side = str(side).upper()  # type: ignore[assignment]
    strategy = str(strategy).lower()  # type: ignore[assignment]
    if side not in {"B", "P", "T"}:
        raise ValueError("side must be B, P or T")
    if strategy not in {"flat", "martingale"}:
        raise ValueError("strategy must be flat or martingale")
    bankroll = _finite_number("bankroll", bankroll, minimum=0.000001)
    base_stake = _finite_number("base_stake", base_stake, minimum=0.000001)
    stop_loss = _finite_number("stop_loss", stop_loss, minimum=0.000001)
    profit_target = _finite_number("profit_target", profit_target, minimum=0.000001)
    max_table_stake = _finite_number("max_table_stake", max_table_stake, minimum=0.000001)
    commission, player, tie = _validate_rules(banker_commission, player_payout, tie_payout)
    for name, value, minimum, maximum in (("max_hands", max_hands, 1, 100000), ("trials", trials, 100, 1000000)):
        if isinstance(value, bool) or not isinstance(value, int) or not minimum <= value <= maximum:
            raise ValueError(f"{name} must be an integer between {minimum} and {maximum}")
    if isinstance(seed, bool) or not isinstance(seed, int):
        raise ValueError("seed must be an integer")
    if base_stake > max_table_stake:
        raise ValueError("base_stake cannot exceed max_table_stake")
    ev = expected_value_per_unit(side, banker_commission=commission,
                                 player_payout=player, tie_payout=tie)
    rng = random.Random(seed)
    profits: list[float] = []
    turnovers: list[float] = []
    max_stakes: list[float] = []
    hands_counts: list[int] = []
    stop_counts = {"profit_target": 0, "stop_loss": 0, "stake_or_bankroll_limit": 0, "hand_limit": 0}
    b, p = BASELINE["B"], BASELINE["P"]
    for _ in range(trials):
        pnl = 0.0
        turnover = 0.0
        hands = 0
        stake = base_stake
        max_stake_seen = 0.0
        reason: str | None = None
        while hands < max_hands:
            if pnl >= profit_target:
                reason = "profit_target"
                break
            if pnl <= -stop_loss:
                reason = "stop_loss"
                break
            if stake > bankroll + pnl + 1e-9 or stake > max_table_stake + 1e-9:
                reason = "stake_or_bankroll_limit"
                break
            u = rng.random()
            outcome = "B" if u < b else ("P" if u < b + p else "T")
            if side == "B":
                delta = stake * (1 - commission) if outcome == "B" else (-stake if outcome == "P" else 0.0)
            elif side == "P":
                delta = stake * player if outcome == "P" else (-stake if outcome == "B" else 0.0)
            else:
                delta = stake * tie if outcome == "T" else -stake
            pnl += delta
            turnover += stake
            hands += 1
            max_stake_seen = max(max_stake_seen, stake)
            if pnl >= profit_target:
                reason = "profit_target"
                break
            if pnl <= -stop_loss:
                reason = "stop_loss"
                break
            if strategy == "martingale":
                if delta > 1e-12:
                    stake = base_stake
                elif delta < -1e-12:
                    stake *= 2.0
            # Flat staking keeps the same stake, and a push under B/P leaves state unchanged.
        if reason is None:
            reason = "hand_limit" if hands >= max_hands else "stake_or_bankroll_limit"
        stop_counts[reason] += 1
        profits.append(pnl)
        turnovers.append(turnover)
        max_stakes.append(max_stake_seen)
        hands_counts.append(hands)
    target_n = stop_counts["profit_target"]
    loss_n = stop_counts["stop_loss"]
    constraint_n = stop_counts["stake_or_bankroll_limit"]
    hand_n = stop_counts["hand_limit"]
    return {
        "side": side, "strategy": strategy, "seed": seed, "trials": trials,
        "mean_profit": mean(profits), "median_profit": median(profits),
        "p05_profit": _quantile(profits, 0.05), "p95_profit": _quantile(profits, 0.95),
        "target_hit_rate": target_n / trials,
        "target_hit_ci95": _wilson(target_n, trials),
        "stop_loss_hit_rate": loss_n / trials,
        "stop_loss_hit_ci95": _wilson(loss_n, trials),
        "stake_or_bankroll_limit_rate": constraint_n / trials,
        "hand_limit_rate": hand_n / trials,
        "mean_turnover": mean(turnovers),
        "mean_max_stake": mean(max_stakes),
        "mean_hands": mean(hands_counts),
        "ev_per_unit": ev,
        "mean_theoretical_ev_at_turnover": ev * mean(turnovers),
        "stops": {"profit_target": target_n, "stop_loss": loss_n,
                  "stake_or_bankroll_limit": constraint_n, "hand_limit": hand_n},
        "warning": "Illustrative Monte Carlo only; independent rounded baseline outcomes; not a future guarantee or profit signal.",
    }


def compare_strategies(**kwargs: Any) -> dict[str, Any]:
    """Compare flat vs Martingale using the same payout/bankroll parameters."""
    base_seed = int(kwargs.pop("seed", 20261012))
    flat = simulate_session_risk(strategy="flat", seed=base_seed, **kwargs)
    martingale = simulate_session_risk(strategy="martingale", seed=base_seed + 1, **kwargs)
    return {
        "rules": rule_analysis(banker_commission=kwargs.get("banker_commission", 0.05),
                                player_payout=kwargs.get("player_payout", 1.0),
                                tie_payout=kwargs.get("tie_payout", 8.0)),
        "flat": flat, "martingale": martingale,
        "interpretation": "Compare distribution and limit-hit rates, not only target-hit frequency. Neither staking progression changes the per-unit house edge.",
    }
