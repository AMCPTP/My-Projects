"""NEXUS ARC V5.5 — Pro Operator Decision Gate.

A conservative, explicit decision gate for reviewing a claimed baccarat edge.
It does not predict the next hand, recommend a side, or authorize a wager.
A positive result is only a candidate for independent review and depends on
operator-supplied evidence that this function cannot authenticate.
"""
from __future__ import annotations
from math import isfinite
from typing import Any, Mapping

BASELINE: dict[str, float] = {"B": 0.458597, "P": 0.446247, "T": 0.095156}
MIN_HOLDOUT_SAMPLE = 1000
REQUIRED_EVIDENCE_CHECKS = (
    "rules_verified",
    "model_preregistered",
    "untouched_holdout",
    "calibration_passed",
    "stability_passed",
    "audit_trail_verified",
    "multiple_testing_controlled",
)


def _number(name: str, value: Any, *, minimum: float | None = None) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(f"{name} must be numeric")
    x = float(value)
    if not isfinite(x):
        raise ValueError(f"{name} must be finite")
    if minimum is not None and x < minimum:
        raise ValueError(f"{name} must be >= {minimum}")
    return x


def calculate_ev(
    side: str,
    probabilities: Mapping[str, float] | None = None,
    *,
    banker_commission: float = 0.05,
    player_payout: float = 1.0,
    tie_payout: float = 8.0,
) -> float:
    """Net EV per unit initially wagered, under supplied probabilities/rules."""
    s = str(side).upper()
    if s not in {"B", "P", "T"}:
        raise ValueError("side must be B, P or T")
    probs = dict(BASELINE if probabilities is None else probabilities)
    if set(probs) != {"B", "P", "T"}:
        raise ValueError("probabilities must contain exactly B, P and T")
    probs = {k: _number(f"P({k})", v, minimum=0.0) for k, v in probs.items()}
    if any(v > 1 for v in probs.values()) or abs(sum(probs.values()) - 1.0) > 1e-5:
        raise ValueError("probabilities must be between 0 and 1 and sum to 1")
    commission = _number("banker_commission", banker_commission, minimum=0.0)
    pp = _number("player_payout", player_payout, minimum=0.0)
    tp = _number("tie_payout", tie_payout, minimum=0.0)
    if commission > 1 or pp > 1000 or tp > 1000:
        raise ValueError("payout/commission outside supported range")
    b, p, t = probs["B"], probs["P"], probs["T"]
    if s == "B":
        return b * (1 - commission) - p
    if s == "P":
        return p * pp - b
    return t * tp - (b + p)


def evaluate_decision_gate(
    *,
    side: str = "B",
    probabilities: Mapping[str, float] | None = None,
    banker_commission: float = 0.05,
    player_payout: float = 1.0,
    tie_payout: float = 8.0,
    bankroll: float = 1000.0,
    stake: float = 10.0,
    stop_loss: float = 100.0,
    profit_target: float = 50.0,
    current_session_pnl: float = 0.0,
    max_table_stake: float = 500.0,
    holdout_sample_size: int = 0,
    holdout_ev_lower_95: float = 0.0,
    evidence_report_id: str = "",
    rules_verified: bool = False,
    model_preregistered: bool = False,
    untouched_holdout: bool = False,
    calibration_passed: bool = False,
    stability_passed: bool = False,
    audit_trail_verified: bool = False,
    multiple_testing_controlled: bool = False,
    chasing_or_emotional: bool = False,
    drift_alert: bool = False,
    minimum_holdout_sample: int = MIN_HOLDOUT_SAMPLE,
) -> dict[str, Any]:
    """Return STOP/HOLD/PASS/REVIEW_ONLY; never returns an authorization to bet."""
    bankroll = _number("bankroll", bankroll, minimum=0.0)
    stake = _number("stake", stake, minimum=0.0)
    stop_loss = _number("stop_loss", stop_loss, minimum=0.0)
    profit_target = _number("profit_target", profit_target, minimum=0.0)
    current_session_pnl = _number("current_session_pnl", current_session_pnl)
    max_table_stake = _number("max_table_stake", max_table_stake, minimum=0.0)
    holdout_ev_lower_95 = _number("holdout_ev_lower_95", holdout_ev_lower_95)
    if isinstance(holdout_sample_size, bool) or not isinstance(holdout_sample_size, int) or holdout_sample_size < 0:
        raise ValueError("holdout_sample_size must be a non-negative integer")
    if isinstance(minimum_holdout_sample, bool) or not isinstance(minimum_holdout_sample, int) or minimum_holdout_sample < 1:
        raise ValueError("minimum_holdout_sample must be a positive integer")

    ev = calculate_ev(side, probabilities, banker_commission=banker_commission,
                      player_payout=player_payout, tie_payout=tie_payout)
    result: dict[str, Any] = {
        "schema": "nexus-arc-v5.5-pro-operator-gate-v1",
        "status": "HOLD",
        "decision": "NO_WAGER_AUTHORIZATION",
        "side_reviewed": str(side).upper(),
        "modelled_ev_per_unit": ev,
        "holdout_sample_size": holdout_sample_size,
        "holdout_ev_lower_95": holdout_ev_lower_95,
        "minimum_holdout_sample": minimum_holdout_sample,
        "evidence_report_id": str(evidence_report_id).strip(),
        "missing_checks": [],
        "reasons": [],
        "note": "User-entered evidence is not independently authenticated. REVIEW_ONLY never authorizes a bet.",
    }

    # Hard session/risk gates outrank any claimed edge.
    if stop_loss <= 0 or profit_target <= 0:
        result.update(status="HOLD_RISK_LIMITS_NOT_SET", reasons=["Stop-loss and profit target must both be greater than zero."])
        return result
    if current_session_pnl <= -stop_loss:
        result.update(status="STOP_SESSION_STOP_LOSS", reasons=["Predeclared session stop-loss reached or exceeded."])
        return result
    if current_session_pnl >= profit_target:
        result.update(status="STOP_SESSION_PROFIT_TARGET", reasons=["Predeclared session profit target reached; stop and review rather than extend the session."])
        return result
    if chasing_or_emotional:
        result.update(status="STOP_SESSION_CHASING_OR_EMOTIONAL", reasons=["Chasing losses or impaired decision state flagged; stop the session."])
        return result
    if bankroll <= 0 or stake <= 0 or stake > bankroll or stake > max_table_stake:
        result.update(status="STOP_STAKE_OR_BANKROLL_LIMIT", reasons=["Stake must be positive and within both available bankroll and table maximum."])
        return result
    if drift_alert:
        result.update(status="HOLD_REGIME_DRIFT", reasons=["A drift/regime alert is active; suspend edge claims and revalidate on fresh data."])
        return result
    if ev <= 0:
        result.update(status="PASS_NO_POSITIVE_MODELLED_EV", reasons=["The supplied probabilities and table rules do not show positive EV for the selected side. Roadmap patterns alone do not overturn this."])
        return result

    checks = {
        "rules_verified": rules_verified,
        "model_preregistered": model_preregistered,
        "untouched_holdout": untouched_holdout,
        "calibration_passed": calibration_passed,
        "stability_passed": stability_passed,
        "audit_trail_verified": audit_trail_verified,
        "multiple_testing_controlled": multiple_testing_controlled,
    }
    missing = [key for key in REQUIRED_EVIDENCE_CHECKS if not bool(checks[key])]
    # Keep evidence ID separate: a label is required to point reviewers to a report.
    if not str(evidence_report_id).strip():
        missing.append("evidence_report_id")
    result["missing_checks"] = missing
    if not rules_verified:
        result["status"] = "HOLD_RULES_UNVERIFIED"
        result["reasons"] = ["Positive EV is only under entered assumptions; exact table rules/payouts have not been independently verified."]
    elif holdout_sample_size < minimum_holdout_sample:
        result["status"] = "HOLD_HOLDOUT_SAMPLE_TOO_SMALL"
        result["reasons"] = [f"Need at least {minimum_holdout_sample} preregistered out-of-sample records as a minimum guardrail; this threshold alone is not proof."]
    elif holdout_ev_lower_95 <= 0:
        result["status"] = "HOLD_HOLDOUT_LOWER_BOUND_NOT_POSITIVE"
        result["reasons"] = ["The operator-entered 95% lower confidence bound for out-of-sample EV is not above zero."]
    elif missing:
        result["status"] = "HOLD_EVIDENCE_CHECKS_INCOMPLETE"
        result["reasons"] = ["The positive-EV claim is not ready: one or more preregistered, holdout, calibration, stability, audit, multiplicity, or report-link checks are missing."]
    else:
        result["status"] = "REVIEW_ONLY_EDGE_CANDIDATE"
        result["reasons"] = ["All operator-entered gates are checked. Independent review of raw records, methodology, payout rules and reproducibility is still mandatory; this is not a bet signal."]
    return result
