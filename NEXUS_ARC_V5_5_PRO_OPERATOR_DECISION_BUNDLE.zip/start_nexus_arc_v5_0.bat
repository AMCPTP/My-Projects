@echo off
cd /d "%~dp0"
py nexus_arc_v5_0_server.py
pause
