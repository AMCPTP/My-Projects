@echo off
cd /d "%~dp0"
set "NEXUS_DASHBOARD_PATH=%~dp0NEXUS_ARC_V5_4_RISK_LAB_DESK.html"
py nexus_arc_v5_0_server.py
pause
