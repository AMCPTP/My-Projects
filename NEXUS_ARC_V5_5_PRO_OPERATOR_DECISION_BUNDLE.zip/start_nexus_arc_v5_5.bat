@echo off
cd /d "%~dp0"
set "NEXUS_DASHBOARD_PATH=%~dp0NEXUS_ARC_V5_5_PRO_OPERATOR_DECISION_DESK.html"
py nexus_arc_v5_0_server.py
pause
