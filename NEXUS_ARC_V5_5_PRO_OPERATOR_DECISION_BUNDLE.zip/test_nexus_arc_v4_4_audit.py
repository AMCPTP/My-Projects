import unittest
from nexus_arc_v4_4_audit import build_report, metrics, valid_cases, drift_report


def case(actual, p, b, cause=None, diagnostic=None, at=0):
    return {"actual": actual, "at": at,
            "forecast": {"prob": {"P": p, "B": b}},
            "cause": cause, "diagnostic": diagnostic}

class AuditTests(unittest.TestCase):
    def test_perfect_forecasts_beat_50_50_baseline(self):
        rows, qc = valid_cases([case("P", .9, .1), case("B", .1, .9)])
        m = metrics(rows)
        self.assertEqual(m["n"], 2)
        self.assertEqual(m["accuracy"], 1.0)
        self.assertGreater(m["log_loss_skill_vs_50_50"], 0)

    def test_invalid_rows_are_not_scored(self):
        rows, qc = valid_cases([case("T", .5, .5), case("P", 1.2, .1), case("B", .2, .8)])
        self.assertEqual(len(rows), 1)
        self.assertEqual(qc["invalid_or_unscored_cases"], 2)

    def test_rolling_drift_detects_degradation(self):
        rows=[]
        for i in range(24):
            rows.append({"source_index": i, "actual": "P", "prob": {"P": .9, "B": .1}, "case": {}})
        for i in range(24, 48):
            rows.append({"source_index": i, "actual": "P", "prob": {"P": .1, "B": .9}, "case": {}})
        report = drift_report(rows)
        self.assertEqual(report["status"], "HIGH")
        self.assertGreater(report["delta"]["log_loss"], .12)

    def test_report_segments_and_limitations(self):
        cases=[]
        for i in range(100):
            # First 60 look useful; last 40 are noisy/misspecified.
            actual = "P" if i % 2 == 0 else "B"
            if i < 60:
                probs = ({"P": .8, "B": .2} if actual == "P" else {"P": .2, "B": .8})
            else:
                probs = ({"P": .8, "B": .2} if actual == "B" else {"P": .2, "B": .8})
            cases.append({"at": i, "actual": actual, "forecast": {"prob": probs}, "cause": "MODEL-MISS" if i >= 60 else None,
                          "diagnostic": {"primary": "MODEL-MISS", "signals": [{"label": "OVERCONFIDENCE"}] } if i >= 60 else None})
        doc={"schema":"NEXUS-ARC-V4.3-WALK-FORWARD-GATE", "history":["P","B"]*50,
             "learner":{"cases":cases,"errors":[]},"events":[],"checksum":"abc"}
        report=build_report(doc)
        self.assertEqual(report["overall"]["n"],100)
        self.assertEqual(report["chronological_segments"]["train_descriptive"]["n"],60)
        self.assertEqual(report["chronological_segments"]["validation_descriptive"]["n"],20)
        self.assertEqual(report["chronological_segments"]["audit_descriptive"]["n"],20)
        self.assertFalse(report["source"]["checksum_verified"])
        self.assertEqual(report["error_hypotheses"]["primary_cause_counts"].get("MODEL-MISS"),40)

    def test_warming_status_with_small_sample(self):
        rows=[{"source_index":i,"actual":"P","prob":{"P":.6,"B":.4},"case":{}} for i in range(39)]
        self.assertEqual(drift_report(rows)["status"], "WARMING")

if __name__ == "__main__":
    unittest.main(verbosity=2)
