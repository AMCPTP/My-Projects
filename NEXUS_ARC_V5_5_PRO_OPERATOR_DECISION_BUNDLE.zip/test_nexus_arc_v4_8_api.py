"""Isolated local API integration tests for NEXUS ARC V4.8.
Uses temporary storage; does not touch the user's live ledger or call external APIs.
"""
import os
import tempfile
import unittest
from pathlib import Path

_TMP = tempfile.TemporaryDirectory(prefix="nexus-v48-api-test-")
os.environ["NEXUS_DATA_DIR"] = str(Path(_TMP.name) / "data")
os.environ["NEXUS_DASHBOARD_PATH"] = str(Path(__file__).with_name("NEXUS_ARC_V4_8_PROSPECTIVE_LEARNING.html"))
os.environ.pop("OPENAI_API_KEY", None)
os.environ.pop("NEXUS_MODEL", None)

from fastapi.testclient import TestClient
import nexus_arc_v4_8_server as server


class ApiIntegrationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.client_ctx = TestClient(server.app)
        cls.client = cls.client_ctx.__enter__()

    @classmethod
    def tearDownClass(cls):
        cls.client_ctx.__exit__(None, None, None)
        _TMP.cleanup()

    def setUp(self):
        # Keep each test independent and make no use of pre-existing user data.
        with server.learning_lock:
            server.learning_ledger.clear()
            server.atomic_save(server.LEARNING_LEDGER_PATH, server.learning_ledger)

    def test_health_meta_and_empty_ledger(self):
        health = self.client.get('/api/health')
        meta = self.client.get('/api/meta')
        verify = self.client.get('/api/learning/verify')
        self.assertEqual(health.status_code, 200)
        self.assertEqual(health.json()['version'], '4.8.0')
        self.assertEqual(meta.status_code, 200)
        self.assertIn('source_freshness_abstention_gate', meta.json()['capabilities'])
        self.assertTrue(verify.json()['valid'])
        self.assertEqual(verify.json()['checked'], 0)

    def test_forecast_outcome_review_lifecycle_and_duplicate_block(self):
        key = 'integration-event-001'
        forecast = self.client.post('/api/learning/forecasts', json={
            'event_key': key, 'domain': 'sequence_pbt', 'model_id': 'api-test-baseline',
            'role': 'standalone', 'probabilities': {'P': 0.5, 'B': 0.5},
            'baseline_probabilities': {'P': 0.5, 'B': 0.5},
            'confidence_threshold': 0.55,
            'rationale': 'test fixture forecast made before outcome', 'coverage': {}
        })
        self.assertEqual(forecast.status_code, 200, forecast.text)
        self.assertEqual(forecast.json()['gate_status'], 'ABSTAIN')
        forecast_id = forecast.json()['forecast_id']
        outcome = self.client.post(f'/api/learning/outcomes/{key}', json={
            'outcome': 'P', 'result_source': 'test fixture only; not real-world evidence'
        })
        self.assertEqual(outcome.status_code, 200, outcome.text)
        review = self.client.post(f'/api/learning/forecasts/{forecast_id}/review', json={
            'category': 'unknown', 'corrective_action': 'test-only', 'notes': 'fixture; not causal proof'
        })
        self.assertEqual(review.status_code, 200, review.text)
        duplicate = self.client.post(f'/api/learning/outcomes/{key}', json={
            'outcome': 'P', 'result_source': 'duplicate fixture'
        })
        self.assertEqual(duplicate.status_code, 400)
        verified = self.client.get('/api/learning/verify').json()
        self.assertTrue(verified['valid'])
        self.assertEqual(verified['checked'], 3)

    def test_cross_origin_mutation_rejected(self):
        response = self.client.post('/api/learning/forecasts', headers={'origin': 'https://attacker.invalid'}, json={
            'event_key': 'blocked', 'domain': 'sequence_pbt', 'model_id': 'api-test',
            'role': 'standalone', 'probabilities': {'P': 0.5, 'B': 0.5}, 'coverage': {}
        })
        self.assertEqual(response.status_code, 403)
        self.assertEqual(self.client.get('/api/learning/verify').json()['checked'], 0)


if __name__ == '__main__':
    unittest.main(verbosity=2)
