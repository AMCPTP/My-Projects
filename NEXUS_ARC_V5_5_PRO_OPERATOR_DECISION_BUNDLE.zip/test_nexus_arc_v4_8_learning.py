import unittest
from datetime import datetime, timezone, timedelta

import nexus_arc_v4_8_learning as L


def iso(dt):
    return dt.astimezone(timezone.utc).isoformat().replace('+00:00', 'Z')


class LearningTests(unittest.TestCase):
    def setUp(self):
        self.events = []
        self.now = datetime(2026, 10, 11, 1, 0, tzinfo=timezone.utc)

    def make_forecast(self, key='evt-1', model='model-a', role='standalone', probs=None, domain='sequence_pbt', coverage=None, baseline=None, now=None):
        raw = {
            'event_key': key, 'domain': domain, 'model_id': model, 'role': role,
            'probabilities': probs or {'P': .6, 'B': .4},
            'baseline_probabilities': baseline or {'P': .5, 'B': .5},
            'coverage': coverage or {}, 'confidence_threshold': .55,
            'rationale': 'test forecast made before result'
        }
        payload = L.validate_forecast_request(raw, self.events, iso(now or self.now))
        return L.append_event(self.events, 'forecast_created', payload, iso(now or self.now)), payload

    def make_outcome(self, key='evt-1', outcome='P', now=None):
        result = L.validate_outcome_request({'event_key': key, 'outcome': outcome, 'result_source': 'unit test'}, self.events, iso(now or self.now + timedelta(minutes=1)))
        return L.append_event(self.events, 'outcome_recorded', result, iso(now or self.now + timedelta(minutes=1)))

    def test_empty_chain_is_valid(self):
        self.assertTrue(L.verify_chain([])['valid'])

    def test_probabilities_are_normalized(self):
        p = L.normalize_probabilities({ 'P': 0.4, 'B': 0.4 })
        self.assertEqual(p, {'P': .5, 'B': .5})

    def test_invalid_probabilities_rejected(self):
        for raw in ({'P': 0, 'B': 0}, {'P': float('nan'), 'B': 1}, {'P': -1, 'B': 2}, {'P': 1}):
            with self.subTest(raw=raw), self.assertRaises(ValueError):
                L.normalize_probabilities(raw)

    def test_general_domain_abstains_without_provenance(self):
        _, f = self.make_forecast(domain='general_research', coverage={})
        self.assertEqual(f['gate_status'], 'ABSTAIN')
        self.assertTrue(any('no provenance sources' in x for x in f['gate_reasons']))

    def test_fresh_source_allows_forecast(self):
        coverage = {'sources': ['https://example.test'], 'source_checked_at': iso(self.now), 'stale_after_seconds': 3600}
        _, f = self.make_forecast(domain='general_research', coverage=coverage, now=self.now)
        self.assertEqual(f['gate_status'], 'ALLOW')

    def test_stale_source_abstains(self):
        coverage = {'sources': ['fixture feed'], 'source_checked_at': iso(self.now - timedelta(hours=3)), 'stale_after_seconds': 60}
        _, f = self.make_forecast(domain='news_events', coverage=coverage, now=self.now)
        self.assertEqual(f['gate_status'], 'ABSTAIN')
        self.assertTrue(any('stale' in x for x in f['gate_reasons']))

    def test_recent_poll_with_stale_source_content_abstains(self):
        coverage = {'sources': ['feed'], 'source_checked_at': iso(self.now), 'source_as_of': iso(self.now - timedelta(days=1)), 'stale_after_seconds': 3600}
        _, f = self.make_forecast(domain='news_events', coverage=coverage, now=self.now)
        self.assertEqual(f['gate_status'], 'ABSTAIN')
        self.assertTrue(any('source content is stale' in x for x in f['gate_reasons']))

    def test_model_role_cannot_change_mid_ledger(self):
        self.make_forecast(key='a', model='same-model', role='champion')
        raw = {'event_key':'b','domain':'sequence_pbt','model_id':'same-model','role':'challenger','probabilities':{'P':.6,'B':.4},'baseline_probabilities':{'P':.5,'B':.5},'coverage':{}}
        with self.assertRaises(ValueError):
            L.validate_forecast_request(raw, self.events, iso(self.now + timedelta(minutes=1)))

    def test_missing_critical_input_abstains(self):
        _, f = self.make_forecast(coverage={'missing_critical_inputs': ['official lineup']})
        self.assertEqual(f['gate_status'], 'ABSTAIN')

    def test_duplicate_model_forecast_rejected(self):
        self.make_forecast()
        with self.assertRaises(ValueError):
            self.make_forecast()

    def test_outcome_requires_preexisting_forecast_and_is_once_only(self):
        with self.assertRaises(ValueError):
            L.validate_outcome_request({'event_key': 'evt-x', 'outcome': 'P'}, self.events, iso(self.now))
        self.make_forecast()
        self.make_outcome()
        with self.assertRaises(ValueError):
            L.validate_outcome_request({'event_key': 'evt-1', 'outcome': 'P'}, self.events, iso(self.now + timedelta(minutes=2)))

    def test_outcome_cannot_precede_forecast(self):
        self.make_forecast(now=self.now)
        with self.assertRaises(ValueError):
            L.validate_outcome_request({'event_key': 'evt-1', 'outcome': 'P', 'observed_at': iso(self.now - timedelta(minutes=1))}, self.events, iso(self.now + timedelta(minutes=1)))

    def test_hash_chain_tamper_detected(self):
        self.make_forecast()
        self.assertTrue(L.verify_chain(self.events)['valid'])
        self.events[0]['payload']['rationale'] = 'tampered'
        self.assertFalse(L.verify_chain(self.events)['valid'])

    def test_error_review_is_append_only_and_requires_outcome(self):
        _, f = self.make_forecast()
        with self.assertRaises(ValueError):
            L.validate_review_request({'forecast_id': f['forecast_id'], 'category': 'reasoning'}, self.events)
        self.make_outcome()
        review = L.validate_review_request({'forecast_id': f['forecast_id'], 'category': 'reasoning', 'notes': 'hypothesis'}, self.events)
        L.append_event(self.events, 'error_reviewed', review, iso(self.now + timedelta(minutes=2)))
        self.assertEqual(L.build_summary(self.events)['error_categories']['reasoning'], 1)

    def test_summary_scores_after_outcome(self):
        _, f = self.make_forecast(probs={'P': .8, 'B': .2})
        before = L.build_summary(self.events)
        self.assertEqual(before['scored_forecast_count'], 0)
        self.make_outcome(outcome='P')
        after = L.build_summary(self.events)
        self.assertEqual(after['scored_forecast_count'], 1)
        self.assertAlmostEqual(after['models']['model-a']['all_forecasts']['accuracy'], 1.0)

    def test_paired_challenger_needs_sixty_outcomes_and_never_auto_promotes(self):
        for i in range(60):
            key = f'pair-{i}'
            y = 'P' if i % 2 == 0 else 'B'
            self.make_forecast(key, 'champ', 'champion', {'P': .5, 'B': .5}, baseline={'P': .5, 'B': .5})
            self.make_forecast(key, 'chall', 'challenger', {'P': .8, 'B': .2} if y == 'P' else {'P': .2, 'B': .8}, baseline={'P': .5, 'B': .5})
            self.make_outcome(key, y)
            self.now += timedelta(minutes=2)
        s = L.build_summary(self.events)
        comparison = s['prospective_challenger_comparisons'][0]
        self.assertEqual(comparison['matched_n'], 60)
        self.assertEqual(comparison['promotion_gate'], 'ELIGIBLE_FOR_REVIEW')
        self.assertFalse(comparison['auto_promotion'])

    def test_review_categories_are_restricted(self):
        _, f = self.make_forecast()
        self.make_outcome()
        with self.assertRaises(ValueError):
            L.validate_review_request({'forecast_id': f['forecast_id'], 'category': 'guaranteed_cause'}, self.events)


if __name__ == '__main__':
    unittest.main(verbosity=2)
