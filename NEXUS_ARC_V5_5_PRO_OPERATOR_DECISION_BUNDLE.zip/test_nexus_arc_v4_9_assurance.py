from datetime import datetime, timezone, timedelta
import copy
import math
import unittest

import nexus_arc_v4_9_assurance as a

class AssuranceLedgerTests(unittest.TestCase):
    def test_hash_chain_append_verify_and_tamper(self):
        rows=[]
        a.append_event(rows,'evidence_added',{'evidence_id':'e1','source_title':'test'})
        a.append_event(rows,'incident_recorded',{'incident_id':'i1','evidence_ids':['e1']})
        self.assertTrue(a.verify_chain(rows)['valid'])
        broken=copy.deepcopy(rows); broken[0]['payload']['source_title']='changed'
        self.assertFalse(a.verify_chain(broken)['valid'])
        with self.assertRaises(ValueError): a.append_event(broken,'x',{})

    def test_projection_cross_links_evidence_incident_analysis_and_experiment(self):
        rows=[]
        a.append_event(rows,'evidence_added',{'evidence_id':'e1','source_title':'source'})
        a.append_event(rows,'incident_recorded',{'incident_id':'i1','evidence_ids':['e1']})
        a.append_event(rows,'analysis_linked',{'evaluation_id':'ev1','domain':'tech'})
        a.append_event(rows,'experiment_registered',{'experiment_id':'x1','direction':'lower_better','holdout_description':'future holdout'})
        a.append_event(rows,'experiment_results_recorded',{'experiment_id':'x1','summary':{'gate':'INSUFFICIENT_EVIDENCE','n':2}})
        p=a.project(rows)
        self.assertIn('e1',p['evidence']); self.assertIn('i1',p['incidents']); self.assertIn('ev1',p['analyses'])
        self.assertEqual(p['experiments']['x1']['results']['summary']['n'],2)

    def test_coverage_separates_fetch_age_from_content_age(self):
        now=datetime.now(timezone.utc)
        recent=(now-timedelta(seconds=10)).isoformat().replace('+00:00','Z')
        old=(now-timedelta(days=2)).isoformat().replace('+00:00','Z')
        feeds=[{'name':'old-content','url':'https://feed.example/rss'}]
        status={'https://feed.example/rss':{'last_check_at':recent,'last_success_at':recent,'latest_source_timestamp':old,'items_seen':3,'new_items':0}}
        r=a.coverage_report(feeds,status,{'last_poll_at':recent,'events':[]},60,now)
        self.assertEqual(r['overall'],'LIMITED_COVERAGE')
        self.assertEqual(r['feeds'][0]['status'],'FETCH_OK_CONTENT_OLD')

    def test_coverage_no_config_not_claimed_fresh(self):
        r=a.coverage_report([],{}, {'events':[]},60)
        self.assertEqual(r['overall'],'NOT_CONFIGURED')
        self.assertEqual(r['configured_feed_count'],0)

    def test_future_source_timestamp_degrades_coverage(self):
        now=datetime.now(timezone.utc)
        future=(now+timedelta(hours=1)).isoformat().replace('+00:00','Z')
        feeds=[{'name':'future','url':'https://future.example/rss'}]
        statuses={'https://future.example/rss':{'last_check_at':now.isoformat().replace('+00:00','Z'),'last_success_at':now.isoformat().replace('+00:00','Z'),'latest_source_timestamp':future}}
        r=a.coverage_report(feeds,statuses,{'events':[]},60,now)
        self.assertEqual(r['overall'],'DEGRADED')
        self.assertEqual(r['feeds'][0]['status'],'SOURCE_TIMESTAMP_IN_FUTURE')

    def test_experiment_gate_sample_too_small(self):
        reg={'experiment_id':'x-small','direction':'lower_better','minimum_effect':0.01,'holdout_description':'later cases'}
        rows=[{'case_id':str(i),'champion_score':1.0,'challenger_score':0.5} for i in range(99)]
        s=a.paired_experiment_summary(reg,rows,n_boot=200)
        self.assertEqual(s['gate'],'INSUFFICIENT_EVIDENCE')
        self.assertFalse(s['auto_promotion'])

    def test_experiment_promising_requires_minimum_effect_and_n(self):
        reg={'experiment_id':'x-big','direction':'lower_better','minimum_effect':0.01,'holdout_description':'future untouched set'}
        rows=[{'case_id':str(i),'champion_score':1.0,'challenger_score':0.8} for i in range(120)]
        s=a.paired_experiment_summary(reg,rows,n_boot=300)
        self.assertEqual(s['gate'],'PROMISING_FOR_INDEPENDENT_REVIEW')
        self.assertGreater(s['ci95'][0],0.01)
        self.assertFalse(s['auto_promotion'])

    def test_no_promotion_when_gain_does_not_clear_effect(self):
        reg={'experiment_id':'x-tiny','direction':'lower_better','minimum_effect':0.2,'holdout_description':'future untouched set'}
        rows=[{'case_id':str(i),'champion_score':1.0,'challenger_score':0.95} for i in range(120)]
        s=a.paired_experiment_summary(reg,rows,n_boot=300)
        self.assertEqual(s['gate'],'IMPROVEMENT_NOT_ESTABLISHED')

    def test_paired_ci_deterministic(self):
        reg={'experiment_id':'x-seed','direction':'higher_better','minimum_effect':0.0,'holdout_description':'future set'}
        rows=[{'case_id':str(i),'champion_score':float(i%3),'challenger_score':float(i%3)+0.1} for i in range(102)]
        self.assertEqual(a.paired_experiment_summary(reg,rows,n_boot=100),a.paired_experiment_summary(reg,rows,n_boot=100))

if __name__=='__main__': unittest.main(verbosity=2)
