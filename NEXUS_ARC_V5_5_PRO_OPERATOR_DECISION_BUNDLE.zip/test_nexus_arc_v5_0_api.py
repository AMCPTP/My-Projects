import os, tempfile, unittest, sys
from pathlib import Path
# Isolate server-side state from the user's normal data directory before importing app.
TEMP_DATA = tempfile.mkdtemp(prefix='nexus_v50_api_test_')
os.environ['NEXUS_DATA_DIR'] = TEMP_DATA
os.environ['NEXUS_DASHBOARD_PATH'] = str(Path(__file__).with_name('NEXUS_ARC_V5_0_ASSURANCE_LEARNING.html'))
os.environ['NEXUS_PORT'] = '18787'
sys.path.insert(0, str(Path(__file__).parent))
from fastapi.testclient import TestClient
import nexus_arc_v5_0_server as server

class AssuranceAPITests(unittest.TestCase):
    def setUp(self):
        server.assurance_ledger.clear()
        server.learning_ledger.clear()
        server.evaluation_records.clear()
        server.state['events']=[]
        server.state['feed_status']={}
        server.state['last_poll_at']=None
        server.feed_sources=[]
        server.atomic_save(server.ASSURANCE_LEDGER_PATH, server.assurance_ledger)
        server.atomic_save(server.FEEDS_PATH, [])
        server.atomic_save(server.LEARNING_LEDGER_PATH, server.learning_ledger)
        server.atomic_save(server.EVAL_PATH, server.evaluation_records)
        server.request_times.clear()
        self.client=TestClient(server.app)

    def test_status_and_integrity_empty_ledger(self):
        r=self.client.get('/api/assurance/status'); self.assertEqual(r.status_code,200)
        self.assertEqual(r.json()['coverage']['overall'],'NOT_CONFIGURED')
        self.assertTrue(r.json()['integrity']['valid'])
        self.assertEqual(self.client.get('/api/assurance/verify').json()['checked'],0)

    def test_configured_recent_feed_reports_monitor_down_without_task(self):
        from datetime import datetime, timezone
        recent=datetime.now(timezone.utc).isoformat().replace('+00:00','Z')
        url='https://feed.example/rss'
        server.feed_sources=[{'name':'Example feed','url':url,'format':'auto'}]
        server.atomic_save(server.FEEDS_PATH, server.feed_sources)
        server.state['feed_status']={url:{'last_check_at':recent,'last_success_at':recent,'latest_source_timestamp':recent,'items_seen':1,'new_items':0}}
        server.monitor_task=None
        r=self.client.get('/api/assurance/status')
        self.assertEqual(r.status_code,200)
        self.assertEqual(r.json()['coverage']['overall'],'MONITOR_DOWN')
        self.assertFalse(r.json()['coverage']['monitor_running'])

    def test_meta_and_health_publish_assurance_fields(self):
        meta=self.client.get('/api/meta').json()
        self.assertEqual(meta['server_version'],'5.0.0')
        self.assertEqual(meta['assurance_status_url'],'/api/assurance/status')
        health=self.client.get('/api/health').json()
        self.assertIn('assurance_ledger_integrity',health)
        self.assertIn('assurance_write_gate',health)

    def test_evidence_and_incident_flow(self):
        ev=self.client.post('/api/assurance/evidence',json={'domain':'technology','source_title':'Official release notes','source_url':'https://example.com/release','claim':'Version changed','excerpt':'operator-entered excerpt','source_kind':'official'})
        self.assertEqual(ev.status_code,200,ev.text)
        eid=ev.json()['evidence_id']
        inc=self.client.post('/api/assurance/incidents',json={'domain':'technology','category':'source_gap','symptom':'Missed update','hypothesis':'Feed was stale','corrective_action':'Add a release-note source','evidence_ids':[eid],'cause_status':'hypothesis'})
        self.assertEqual(inc.status_code,200,inc.text)
        stat=self.client.get('/api/assurance/status').json()
        self.assertEqual(stat['evidence_count'],1); self.assertEqual(stat['incident_count'],1)
        self.assertTrue(self.client.get('/api/assurance/verify').json()['valid'])

    def test_evidence_rejects_non_http_url(self):
        r=self.client.post('/api/assurance/evidence',json={'source_title':'bad','source_url':'javascript:alert(1)','claim':'x'})
        self.assertEqual(r.status_code,400)

    def test_experiment_preregister_results_and_no_auto_promotion(self):
        reg=self.client.post('/api/assurance/experiments',json={'domain':'coding_engineering','champion_id':'A','challenger_id':'B','metric_name':'error_rate','direction':'lower_better','holdout_description':'untouched final test set','minimum_effect':0.01,'hypothesis':'B reduces errors by at least one percent'})
        self.assertEqual(reg.status_code,200,reg.text); xid=reg.json()['experiment_id']
        payload={'pairs':[{'case_id':'c1','champion_score':1.0,'challenger_score':0.7},{'case_id':'c2','champion_score':0.9,'challenger_score':0.6}]}
        r=self.client.post(f'/api/assurance/experiments/{xid}/results',json=payload)
        self.assertEqual(r.status_code,200,r.text); self.assertEqual(r.json()['gate'],'INSUFFICIENT_EVIDENCE'); self.assertFalse(r.json()['auto_promotion'])
        r2=self.client.post(f'/api/assurance/experiments/{xid}/results',json=payload)
        self.assertEqual(r2.status_code,409)

    def test_duplicate_case_ids_rejected(self):
        reg=self.client.post('/api/assurance/experiments',json={'domain':'science','champion_id':'A','challenger_id':'B','metric_name':'score','direction':'higher_better','holdout_description':'independent holdout set','minimum_effect':0.01,'hypothesis':'B improves scoring'})
        xid=reg.json()['experiment_id']
        pairs=[{'case_id':'c1','champion_score':1,'challenger_score':2},{'case_id':'c1','champion_score':1,'challenger_score':2}]
        r=self.client.post(f'/api/assurance/experiments/{xid}/results',json={'pairs':pairs})
        self.assertEqual(r.status_code,400)

    def test_tampered_ledger_blocks_writes(self):
        self.client.post('/api/assurance/evidence',json={'domain':'technology','source_title':'ok','source_url':'https://example.com','claim':'x'})
        server.assurance_ledger[0]['payload']['claim']='tampered'
        r=self.client.post('/api/assurance/evidence',json={'domain':'technology','source_title':'second','source_url':'https://example.org','claim':'y'})
        self.assertEqual(r.status_code,409)


    def test_v5_lesson_requires_review_and_evidence(self):
        ev=self.client.post('/api/assurance/evidence',json={'domain':'technology','source_title':'Official release notes','source_url':'https://example.com/release','claim':'A required field changed','excerpt':'The official change log identifies the field change','source_kind':'official'})
        self.assertEqual(ev.status_code,200,ev.text); eid=ev.json()['evidence_id']
        inc=self.client.post('/api/assurance/incidents',json={'domain':'technology','category':'source_gap','symptom':'Missed a release-note change','hypothesis':'The release notes were not checked','corrective_action':'Check official release notes and current timestamp before finalizing version-sensitive claims.','evidence_ids':[eid],'cause_status':'hypothesis'})
        self.assertEqual(inc.status_code,200,inc.text); iid=inc.json()['incident_id']
        before=self.client.get('/api/v5/learning/lessons?domain=technology').json()
        self.assertEqual(before['lessons'],[])
        approval=self.client.post('/api/v5/learning/lesson-review',json={'incident_id':iid,'decision':'approved','note':'Reviewed the linked official evidence and scope'})
        self.assertEqual(approval.status_code,200,approval.text)
        after=self.client.get('/api/v5/learning/lessons?domain=technology').json()
        self.assertEqual(len(after['lessons']),1)
        self.assertEqual(after['lessons'][0]['lesson_id'],iid)
        diag=self.client.get('/api/v5/learning/diagnostics?domain=technology')
        self.assertEqual(diag.status_code,200,diag.text)
        self.assertFalse(diag.json()['model_weights_updated'])
        self.assertEqual(diag.json()['learning_mode'],'retrieval_guidance_only')

    def test_v5_lesson_approval_requires_existing_evidence(self):
        inc=self.client.post('/api/assurance/incidents',json={'domain':'technology','category':'source_gap','symptom':'Missed update','hypothesis':'A source might be stale','corrective_action':'Check a primary source before answering','evidence_ids':[],'cause_status':'hypothesis'})
        self.assertEqual(inc.status_code,200,inc.text)
        r=self.client.post('/api/v5/learning/lesson-review',json={'incident_id':inc.json()['incident_id'],'decision':'approved','note':'Reviewed this issue carefully'})
        self.assertEqual(r.status_code,400)

    def test_v5_harmful_lesson_feedback_quarantines_retrieval(self):
        ev=self.client.post('/api/assurance/evidence',json={'domain':'technology','source_title':'Official doc','source_url':'https://example.com/doc','claim':'Correct source','source_kind':'official'})
        eid=ev.json()['evidence_id']
        inc=self.client.post('/api/assurance/incidents',json={'domain':'technology','category':'source_gap','symptom':'Missed official source','hypothesis':'The source list was incomplete','corrective_action':'Check official documentation and its update date.','evidence_ids':[eid],'cause_status':'hypothesis'})
        iid=inc.json()['incident_id']
        self.assertEqual(self.client.post('/api/v5/learning/lesson-review',json={'incident_id':iid,'decision':'approved','note':'Reviewed evidence and scope carefully'}).status_code,200)
        for _ in range(2):
            r=self.client.post('/api/v5/learning/lesson-use-review',json={'incident_id':iid,'verdict':'harmful','note':'This heuristic failed in the current context'})
            self.assertEqual(r.status_code,200,r.text)
        lessons=self.client.get('/api/v5/learning/lessons?domain=technology').json()
        self.assertEqual(lessons['lessons'],[])
        self.assertEqual(lessons['quarantined_pending_review_count'],1)

    def test_v5_diagnostics_reject_unknown_domain(self):
        r=self.client.get('/api/v5/learning/diagnostics?domain=made_up_domain')
        self.assertEqual(r.status_code,400)

    def test_feedback_has_assurance_trace(self):
        server.evaluation_records.append({'evaluation_id':'eval-123','domain':'technology','generated_at':'2026-10-11T00:00:00Z','feedback':[]})
        r=self.client.post('/api/evaluations/eval-123/feedback',json={'label':'incorrect','note':'Source date was wrong'})
        self.assertEqual(r.status_code,200,r.text)
        self.assertIsNone(r.json()['assurance_feedback_warning'])
        kinds=[e.get('event_type') for e in server.assurance_ledger]
        self.assertIn('evaluation_feedback_recorded',kinds)


    def test_v5_analysis_injects_approved_memory_and_traces_it(self):
        from types import SimpleNamespace
        import json as jsonlib
        from unittest.mock import patch
        ev=self.client.post('/api/assurance/evidence',json={'domain':'creative','source_title':'Project brief','source_url':'https://example.com/brief','claim':'The approved brief specifies plain-language output','excerpt':'Use plain-language output and label assumptions','source_kind':'operator_supplied'})
        self.assertEqual(ev.status_code,200,ev.text); eid=ev.json()['evidence_id']
        inc=self.client.post('/api/assurance/incidents',json={'domain':'creative','category':'reasoning','symptom':'An earlier response mixed facts with assumptions','hypothesis':'The answer did not distinguish evidence from inference','corrective_action':'Separate verified facts from assumptions and label uncertain claims.','evidence_ids':[eid],'cause_status':'hypothesis'})
        iid=inc.json()['incident_id']
        self.assertEqual(self.client.post('/api/v5/learning/lesson-review',json={'incident_id':iid,'decision':'approved','note':'Reviewed evidence and intended scope carefully'}).status_code,200)
        captured={}
        class FakeResponses:
            async def create(self, **kwargs):
                captured.update(kwargs)
                body={"summary":"ok","verified_facts":[],"analysis_and_inference":[],"uncertainties":[],"missing_information":[],"next_steps":[],"coverage_note":"Mock-only; no external fact checking.","domain_checks":[],"claim_checks":[]}
                return SimpleNamespace(output_text=jsonlib.dumps(body),output=[],id='mock-response')
        class FakeClient:
            def __init__(self, **kwargs): self.responses=FakeResponses()
        server.API_KEY='test-key'; server.MODEL='test-model'
        fake_openai=SimpleNamespace(AsyncOpenAI=FakeClient)
        with patch.object(server, 'API_KEY', 'test-key'), patch.object(server, 'MODEL', 'test-model'), patch.dict('sys.modules', {'openai': fake_openai}):
            response=self.client.post('/api/analyze',json={'domain':'creative','task':'Draft a short description','context':'','events':[],'use_web_search':False})
        self.assertEqual(response.status_code,200,response.text)
        provider_input=jsonlib.loads(captured['input'])
        self.assertEqual(provider_input['prior_operator_lessons_for_applicability_review'][0]['lesson_id'],iid)
        self.assertIn('Separate verified facts from assumptions',provider_input['prior_operator_lessons_for_applicability_review'][0]['corrective_action'])
        self.assertEqual(response.json()['lesson_memory']['candidate_count'],1)
        linked=[e for e in server.assurance_ledger if e.get('event_type')=='analysis_linked'][-1]
        self.assertEqual(linked['payload']['lesson_ids_considered'],[iid])
        self.assertFalse(response.json()['lesson_memory']['model_weights_updated'])

if __name__=='__main__': unittest.main(verbosity=2)
