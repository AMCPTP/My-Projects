#!/usr/bin/env node
'use strict';
// Standard-library-only mock-DOM smoke test for the self-contained NEXUS ARC HTML.
// This tests application logic/initialization but is not a replacement for a real-browser visual test.
const fs = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const { webcrypto } = require('node:crypto');
const { performance } = require('node:perf_hooks');

const htmlPath = process.argv[2] || './NEXUS_ARC_V5_0_ASSURANCE_LEARNING.html';
const html = fs.readFileSync(htmlPath, 'utf8');
const matches = [...html.matchAll(/<script>([\s\S]*?)<\/script>/g)];
assert.equal(matches.length, 7, 'expected core app plus roadmap, learning, unified assurance, V5.3 baccarat pro, V5 learning panel, and V5.3 adversarial prospective audit scripts');

class FakeElement {
  constructor(id = '') {
    this.id = id; this.textContent = ''; this.innerHTML = ''; this.value = '';
    this.checked = false; this.disabled = false; this.className = ''; this.dataset = {};
    this.files = []; this.children = []; this.style = {}; this.attributes = {}; this.listeners = {};
    this.classList = { add() {}, remove() {}, contains() { return false; }, toggle() {} };
  }
  addEventListener(type, fn) { (this.listeners[type] ||= []).push(fn); }
  removeEventListener() {}
  appendChild(child) { this.children.push(child); return child; }
  append(...children) { this.children.push(...children); }
  replaceChildren(...children) { this.children = [...children]; }
  remove() {}
  focus() {}
  click() { return this.dispatch('click', { target: this }); }
  async dispatch(type, event = { target: this }) {
    const results = [];
    for (const fn of this.listeners[type] || []) results.push(await fn(event));
    return results;
  }
  setAttribute(k, v) { this.attributes[k] = v; }
  getAttribute(k) { return this.attributes[k] ?? null; }
  closest() { return null; }
  querySelectorAll() { return []; }
  querySelector() { return new FakeElement(); }
  scrollIntoView() {}
  getBoundingClientRect() { return { width: 100, height: 20 }; }
}

const elements = new Map();
let fetchHandler = async () => { throw new Error('network is intentionally disabled in mock test'); };
const storageMap = new Map();
const localStorage = {
  getItem: k => storageMap.has(k) ? storageMap.get(k) : null,
  setItem: (k, v) => storageMap.set(k, String(v)),
  removeItem: k => storageMap.delete(k),
  clear: () => storageMap.clear(),
};
const resultButtons = ['P', 'B', 'T'].map(result => {
  const button = new FakeElement(`result-${result}`);
  button.dataset.result = result;
  return button;
});
const document = {
  getElementById(id) { if (!elements.has(id)) elements.set(id, new FakeElement(id)); return elements.get(id); },
  querySelectorAll(selector) { return selector === '[data-result]' ? resultButtons : []; },
  createElement(tag) { return new FakeElement(tag); },
  createTextNode(text) { return { textContent: String(text) }; },
  addEventListener() {},
  body: new FakeElement('body'),
};
const window = { localStorage, NEXUS: null, location: { href: 'http://localhost/mock.html' }, addEventListener() {}, removeEventListener() {} };
const context = {
  window, document, crypto: webcrypto, performance, localStorage, console, Date, Math, JSON, Number, String,
  Object, Array, Map, Set, RegExp, Error, Promise, Uint8Array, TextEncoder, TextDecoder, URL, Blob,
  AbortController, setTimeout, clearTimeout, setInterval, clearInterval,
  fetch: (...args) => fetchHandler(...args),
  Notification: function Notification() {}, navigator: {}, location: { href: 'http://localhost/mock.html' },
  structuredClone: global.structuredClone,
};
context.globalThis = context;

(async () => {
  const instrumentedScript = matches[0][1].replace(
    'window.NEXUS={makeForecast,render,deepSelfTest',
    'window.__TEST={importBrainFile,sha256,canonical,normalizeLearning};window.NEXUS={makeForecast,render,deepSelfTest'
  );
  assert.notEqual(instrumentedScript, matches[0][1], 'test-only hooks should be injected');
  vm.runInNewContext(instrumentedScript, context, { timeout: 15000, filename: 'nexus_arc_v5_core_inline.js' });
  assert.equal(window.NEXUS?.version, 'NEXUS-ARC-V4.8-PROSPECTIVE-LEARNING');
  assert.equal(document.getElementById('champion').textContent, 'adaptive-v3');

  await window.NEXUS.deepSelfTest();
  const selfTest = document.getElementById('brainDetail').textContent;
  assert.match(document.getElementById('status').textContent, /Self-test PASS/);
  assert.match(selfTest, /6\/6 suites/);
  assert.match(selfTest, /100 deep checks/);

  const sequence = process.argv.includes('--long')
    ? Array.from({ length: 220 }, (_, i) => 'PBBPBPPB'[i % 8])
    : 'PBBPBPPBPPBPBBPBPBPPBPPBBPBPBPBBPBPBPPBBPBPPBPBPBPPBPPBBPBPPB';
  for (const result of sequence) await resultButtons.find(b => b.dataset.result === result).click();
  const learner = window.NEXUS.learner;
  const fresh = learner.cases.filter(c => c.engineVersion === window.NEXUS.version);
  const complete = fresh.filter(c => ['adaptive-v3', 'base-heavy', 'regime-heavy', 'memory-heavy', 'conservative']
    .every(name => c.shadowPredictions?.[name]?.prob && Number.isFinite(c.shadowPredictions[name].prob.P) && Number.isFinite(c.shadowPredictions[name].prob.B)));
  assert.ok(fresh.length > 0, 'interactions should create scored V4.6 cases');
  assert.equal(complete.length, fresh.length, 'every new scored case should include all five pre-outcome shadow forecasts');
  assert.ok(fresh.every(c => c.activeProfile && c.forecast?.prob), 'each scored case should store active policy and actual forecast');

  console.log('PASS — mock-DOM application initialization');
  console.log(`PASS — in-app Deep Self-Test: ${selfTest}`);
  console.log(`PASS — interaction replay: ${window.NEXUS.history.length} outcomes, ${fresh.length} V4.8 core scored cases, ${complete.length} with all five shadow candidates; Champion=${learner.selection.champion}; trial=${learner.selection.trial ? `${learner.selection.trial.candidate} ${learner.selection.trial.rows.length}/${learner.selection.trial.target}` : 'none'}`);

  const brain = {
    schema: 'NEXUS-ARC-V4.5-PREQUENTIAL-SAFE-ADAPTATION',
    history: ['P','B','P','B','B','P','P','B','T','P','B','T'],
    learner: {
      version: 'NEXUS-ARC-V4.5-PREQUENTIAL-SAFE-ADAPTATION',
      selection: { champion: 'memory-heavy' },
      calibration: { temp: 1.25, rows: [{ prob: { P: .7, B: .3 }, actual: 'P', at: 1 }] },
      cases: [{ actual: 'P', at: 11, forecast: { prob: { P: .6, B: .4 } } }]
    },
    events: [], exportedAt: '2026-10-01T00:00:00Z'
  };
  brain.checksum = await window.__TEST.sha256(window.__TEST.canonical({
    schema: brain.schema, history: brain.history,
    learner: { ...brain.learner, integrity: {} }, events: brain.events
  }));
  await window.__TEST.importBrainFile({ text: async () => JSON.stringify(brain) });
  assert.equal(window.NEXUS.history.length, 12, 'V4.5 history should migrate');
  assert.equal(window.NEXUS.learner.selection.champion, 'memory-heavy', 'selected profile should be preserved');
  assert.equal(window.NEXUS.learner.calibration.temp, 1, 'cross-version calibration temperature must reset');
  assert.equal(window.NEXUS.learner.calibration.rows.length, 0, 'cross-version calibration rows must reset');
  assert.match(document.getElementById('status').textContent, /Import Brain สำเร็จ/);
  console.log('PASS — checksum-verified V4.5 Brain migration into core sequence engine; history/profile preserved, cross-version calibration reset');

  const before = window.NEXUS.history.slice();
  const corrupted = { ...brain, history: ['B', ...brain.history.slice(1)] };
  await window.__TEST.importBrainFile({ text: async () => JSON.stringify(corrupted) });
  assert.match(document.getElementById('status').textContent, /checksum mismatch/);
  assert.deepEqual(window.NEXUS.history, before, 'corrupted Brain import must not mutate active history');
  console.log('PASS — corrupted Brain import rejected without mutating active history');
  // Exercise the V5.2 baccarat pro panel without claiming predictive edge.
  const proScript = matches.find(m => m[1].includes('NEXUSBaccaratPro={wilson,guard,snapshot,baseline}'))[1];
  document.getElementById('bacBankroll').value = '10000';
  document.getElementById('bacUnit').value = '100';
  document.getElementById('bacStopLoss').value = '1000';
  document.getElementById('bacSessionPL').value = '0';
  vm.runInNewContext(proScript, context, { timeout: 5000, filename: 'nexus_arc_v5_1_baccarat_pro.js' });
  assert.equal(window.NEXUSBaccaratPro.baseline.B, 0.458597);
  assert.match(document.getElementById('bacGuardResult').textContent, /WITHIN USER-SET LIMIT/);
  document.getElementById('bacSessionPL').value = '-1000';
  document.getElementById('bacStopLoss').value = '1000';
  await document.getElementById('bacGuardCheck').dispatch('click');
  assert.match(document.getElementById('bacGuardResult').textContent, /STOP/);
  assert.match(html, /PASS \/ NO DEMONSTRATED EDGE/);
  console.log('PASS — V5.3 baccarat pro baseline, bankroll stop gate, and no-edge default');

  // Exercise the new V5.0 panel against local mocked API responses.
  const memoryPanelScript = matches.find(m => m[1].includes('api/v5/learning/diagnostics'))[1];
  assert.match(memoryPanelScript, /api\/v5\/learning\/diagnostics/);
  document.getElementById('v5Domain').value = 'technology';
  document.getElementById('v5IncidentId').value = 'incident-1';
  document.getElementById('v5ReviewDecision').value = 'approved';
  document.getElementById('v5UseVerdict').value = 'helpful';
  document.getElementById('v5ReviewNote').value = 'Checked evidence scope and relevance';
  document.getElementById('v5UseNote').value = 'Helpful for verifying current release notes';
  const requested = [];
  fetchHandler = async (url, opts = {}) => {
    requested.push({ url: String(url), opts });
    let body;
    if (String(url).includes('/api/v5/learning/diagnostics')) {
      body = { schema: 'NEXUS-ARC-V5.0-RETRIEVAL-LEARNING-1', domain_filter: 'technology', assurance_events: 4, incidents: 1, approved_lesson_count: 1, lesson_usage_count_in_linked_analyses: 2, analyses_with_memory_ids: 1, operator_feedback: { technology: { signal: 'INSUFFICIENT_FEEDBACK', recent_negative_rate: null, recent_n: 0 } }, learning_mode: 'retrieval_guidance_only', model_weights_updated: false, automatic_root_cause_discovery: false, automatic_model_promotion: false, safety_note: 'No weight training.' };
    } else if (String(url).includes('/api/v5/learning/lessons')) {
      body = { lessons: [{ lesson_id: 'incident-1', incident_id: 'incident-1', domain: 'technology', symptom: 'Missed release date', corrective_action: 'Check official notes and timestamp.', evidence_ids: ['e1'], effectiveness: { helpful: 0, neutral: 0, harmful: 0 }, use_status: 'not independently validated' }], approved_lesson_count_available: 1 };
    } else if (String(url).includes('/api/v5/learning/lesson-review')) {
      body = { ok: true, incident_id: 'incident-1', decision: 'approved' };
    } else if (String(url).includes('/api/v5/learning/lesson-use-review')) {
      body = { ok: true, incident_id: 'incident-1', verdict: 'helpful', currently_retrievable: true };
    } else {
      throw new Error('unexpected mocked URL ' + url);
    }
    return { ok: true, status: 200, json: async () => body };
  };
  const originalSetTimeout = context.setTimeout;
  context.setTimeout = (fn, ms) => setTimeout(fn, 0);
  vm.runInNewContext(memoryPanelScript, context, { timeout: 5000, filename: 'nexus_arc_v5_memory_panel.js' });
  await document.getElementById('v5Refresh').dispatch('click');
  assert.match(document.getElementById('v5Diagnostics').textContent, /RETRIEVABLE LESSONS/);
  await document.getElementById('v5SubmitReview').dispatch('click');
  assert.ok(requested.some(x => x.url.includes('/api/v5/learning/lesson-review') && JSON.parse(x.opts.body).decision === 'approved'));
  await document.getElementById('v5SubmitUseReview').dispatch('click');
  assert.ok(requested.some(x => x.url.includes('/api/v5/learning/lesson-use-review') && JSON.parse(x.opts.body).verdict === 'helpful'));
  assert.ok(requested.some(x => x.url.includes('/api/v5/learning/lesson-review')));
  assert.ok(requested.some(x => x.url.includes('/api/v5/learning/lesson-use-review')));
  context.setTimeout = originalSetTimeout;
  console.log('PASS — V5.0 memory dashboard diagnostics, lesson approval, and effectiveness-review interactions');

  // Exercise V5.3 audit: frozen model identity, prospective forecast, single pending, post-outcome scoring, stability-aware audit.
  const auditScript = matches.find(m => m[1].includes("nexus_arc_v5_3_prospective_ledger_v1"))[1];
  document.getElementById('v52ProbB').value = '45.8597';
  document.getElementById('v52ProbP').value = '44.6247';
  document.getElementById('v52ProbT').value = '9.5156';
  document.getElementById('v53ModelId').value = 'test-model-v1';
  document.getElementById('v53Trials').value = '1';
  document.getElementById('v53ChangeNote').value = 'Test baseline tracking';
  vm.runInNewContext(auditScript, context, { timeout: 5000, filename: 'nexus_arc_v5_3_prospective_audit.js' });
  await document.getElementById('v52Register').dispatch('click');
  const auditKey = 'nexus_arc_v5_3_prospective_ledger_v1';
  let auditData = JSON.parse(localStorage.getItem(auditKey));
  assert.equal(auditData.records.length, 1);
  assert.equal(auditData.records[0].status, 'PENDING');
  assert.equal(auditData.model_id, 'test-model-v1');
  assert.equal(auditData.records[0].model_id, 'test-model-v1');
  await document.getElementById('v52Register').dispatch('click');
  assert.match(document.getElementById('v52PendingStatus').textContent, /Forecast ค้างอยู่/);
  document.getElementById('v52Actual').value = 'B';
  await document.getElementById('v52Resolve').dispatch('click');
  auditData = JSON.parse(localStorage.getItem(auditKey));
  assert.equal(auditData.records[0].status, 'RESOLVED');
  assert.equal(auditData.records[0].actual, 'B');
  assert.ok(Math.abs(auditData.records[0].score.brier - auditData.records[0].baseline_score.brier) < 1e-12);
  assert.match(document.getElementById('v52Gate').textContent, /WARMING/);
  assert.equal(document.getElementById('v52Register').disabled, false);
  document.getElementById('v53ModelId').value = 'other-model-attempt';
  await document.getElementById('v52Register').dispatch('click');
  assert.match(document.getElementById('v52PendingStatus').textContent, /locked|ล็อกไว้/);
  assert.equal(JSON.parse(localStorage.getItem(auditKey)).records.length, 1, 'cohort model identity must remain frozen');
  document.getElementById('v53ModelId').value = 'test-model-v1';
  await document.getElementById('v53Archive').dispatch('click');
  const archived = JSON.parse(localStorage.getItem('nexus_arc_v5_3_archived_cohorts_v1'));
  assert.equal(archived.length, 1);
  assert.equal(archived[0].ledger.records.length, 1);
  assert.equal(archived[0].ledger.change_note, 'Test baseline tracking');
  assert.equal(localStorage.getItem(auditKey), null, 'active cohort reset must not mix prior candidate records');
  assert.match(html, /This audit never recommends a bet|No betting advice|No bet recommendation/i);
  console.log('PASS — V5.3 frozen-model cohort, forecast-before-outcome registration, single-pending lock, post-outcome scoring, multiple-candidate freeze, archive/new-cohort workflow, baseline comparison, and warm-up gate');
  console.log('LIMIT — mock DOM does not validate actual Chrome/Edge layout, browser-local data tamper resistance, external API credentials, or live source connectivity.');
})().catch(error => { console.error('FAIL —', error.stack || error); process.exitCode = 1; });
