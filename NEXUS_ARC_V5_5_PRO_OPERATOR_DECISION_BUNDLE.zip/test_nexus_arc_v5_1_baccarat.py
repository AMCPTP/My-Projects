import math
import pytest
from nexus_arc_v5_1_baccarat import parse_outcomes, baseline_ev_per_unit, wilson_interval, summarize, SessionGuard


def test_parse_aliases_and_noise():
    assert parse_outcomes('B Banker, p PLAYER / T tie x') == ['B','B','P','P','T','T']


def test_standard_8_deck_ev_baselines():
    assert baseline_ev_per_unit('B') == pytest.approx(-0.01057985, abs=1e-8)
    assert baseline_ev_per_unit('P') == pytest.approx(-0.01235, abs=1e-8)
    assert baseline_ev_per_unit('T') == pytest.approx(-0.143596, abs=1e-8)


def test_ev_rules_validation():
    with pytest.raises(ValueError): baseline_ev_per_unit('X')
    with pytest.raises(ValueError): baseline_ev_per_unit('B', banker_commission=1.2)
    with pytest.raises(ValueError): baseline_ev_per_unit('T', tie_net_payout=-1)


def test_wilson_empty_and_bounds():
    assert wilson_interval(0,0) is None
    lo,hi=wilson_interval(5,10)
    assert 0 < lo < .5 < hi < 1
    with pytest.raises(ValueError): wilson_interval(11,10)


def test_summary_tie_does_not_change_switch_rate():
    s=summarize('B P T B P')
    assert s['n_total']==5 and s['decisive_n']==4
    assert s['switches']==3 and s['switch_rate']==1.0
    assert s['decision']=='PASS_NO_DEMONSTRATED_EDGE_FROM_ROADS_ALONE'


def test_summary_short_history_no_ci():
    s=summarize('T T')
    assert s['banker_share_wilson95'] is None
    assert s['last_run'] is None


def test_guardrails_stop_when_limit_reached():
    assert SessionGuard(1000,100,200,-200).evaluate()['status']=='STOP_LOSS_LIMIT_REACHED'
    assert SessionGuard(100,150,20,0).evaluate()['status']=='STOP_UNIT_EXCEEDS_BANKROLL'
    assert SessionGuard(100,10,0,0).evaluate()['status']=='PAUSE_STOP_LOSS_NOT_SET'
    assert SessionGuard(1000,10,100,-50).evaluate()['status']=='WITHIN_USER_SET_LIMIT'
