from datetime import datetime, timedelta, timezone
import pytest
from nexus_arc_v5_2_evaluation import (
    BASELINE, create_forecast, resolve_forecast, score_probabilities,
    summarize_ledger, validate_probabilities,
)


def test_validate_probabilities_strict_distribution():
    assert validate_probabilities({"B": .4, "P": .5, "T": .1})["T"] == .1
    with pytest.raises(ValueError): validate_probabilities({"B": .4, "P": .4, "T": .1})
    with pytest.raises(ValueError): validate_probabilities({"B": -0.1, "P": .8, "T": .3})
    with pytest.raises(ValueError): validate_probabilities({"B": True, "P": 0, "T": 0})


def test_score_known_case_and_baseline():
    s = score_probabilities({"B": 1.0, "P": 0.0, "T": 0.0}, "B")
    assert s["brier"] == 0
    assert s["log_loss"] == 0
    assert score_probabilities(BASELINE, "T")["brier"] > 0


def test_create_and_resolve_prequentially():
    t0 = "2026-10-12T01:00:00Z"
    t1 = "2026-10-12T01:01:00Z"
    r = create_forecast(BASELINE, created_at=t0, forecast_id="f1")
    assert r["status"] == "PENDING"
    settled = resolve_forecast(r, "B", resolved_at=t1)
    assert settled["status"] == "RESOLVED"
    assert settled["actual"] == "B"
    assert settled["delta_vs_baseline"]["brier"] == pytest.approx(0)
    with pytest.raises(ValueError): resolve_forecast(settled, "P", resolved_at="2026-10-12T01:02:00Z")
    with pytest.raises(ValueError): resolve_forecast(r, "B", resolved_at="2026-10-12T00:59:00Z")


def _row(i, probs, outcome):
    t0 = datetime(2026, 10, 1, tzinfo=timezone.utc) + timedelta(minutes=i)
    r = create_forecast(probs, created_at=t0.isoformat().replace('+00:00', 'Z'), forecast_id=f'f{i}')
    return resolve_forecast(r, outcome, resolved_at=(t0 + timedelta(seconds=20)).isoformat().replace('+00:00', 'Z'))


def test_empty_and_pending_summary_fail_closed():
    s = summarize_ledger([])
    assert s['gate'] == 'WARMING_INSUFFICIENT_SAMPLE'
    r = create_forecast(BASELINE, created_at="2026-10-12T01:00:00Z", forecast_id="pending")
    s2 = summarize_ledger([r])
    assert s2['pending_n'] == 1 and s2['resolved_n'] == 0
    assert s2['decision'] == 'NO_BET_RECOMMENDATION_FROM_ROADMAP_OR_THIS_AUDIT'


def test_duplicate_ids_invalid_state_and_timestamps_rejected():
    r = _row(0, BASELINE, 'B')
    with pytest.raises(ValueError): summarize_ledger([r, r])
    bad = dict(r, status='UNKNOWN')
    with pytest.raises(ValueError): summarize_ledger([bad])
    bad_time = dict(r, resolved_at='2026-09-01T00:00:00Z')
    with pytest.raises(ValueError): summarize_ledger([bad_time])


def test_gate_keeps_baseline_at_no_improvement():
    outcomes = ['B', 'P', 'T', 'B', 'P'] * 60
    rows = [_row(i, BASELINE, out) for i, out in enumerate(outcomes)]
    s = summarize_ledger(rows)
    assert s['resolved_n'] == 300
    assert s['gate'] == 'NO_DEMONSTRATED_IMPROVEMENT_OVER_BASELINE'
    assert abs(s['paired_brier_delta_ci95']['mean']) < 1e-12
    assert s['brier_skill_vs_baseline'] == pytest.approx(0)


def test_provisional_gate_requires_both_metrics_and_300_results():
    # Deliberately informative forecast distribution for this synthetic deterministic test only.
    probs = {'B': .96, 'P': .02, 'T': .02}
    rows = [_row(i, probs, 'B') for i in range(300)]
    s = summarize_ledger(rows)
    assert s['gate'] == 'PROVISIONAL_IMPROVEMENT_REQUIRES_INDEPENDENT_REPLICATION'
    assert s['paired_brier_delta_ci95']['upper95'] < 0
    assert s['paired_log_loss_delta_ci95']['upper95'] < 0
    assert 'serial dependence' in s['limitations'][3]


def test_drift_detection_is_advisory_and_rolling():
    good = {'B': .99, 'P': .005, 'T': .005}
    rows = [_row(i, good, 'B') for i in range(50)]
    rows += [_row(i + 50, {'B': .005, 'P': .99, 'T': .005}, 'B') for i in range(50)]
    s = summarize_ledger(rows)
    assert s['drift']['status'] == 'DEGRADATION_SIGNAL_REVIEW_REQUIRED'
    assert s['decision'] == 'NO_BET_RECOMMENDATION_FROM_ROADMAP_OR_THIS_AUDIT'


def test_ledger_rejects_pending_not_at_end_and_out_of_order_records():
    pending = create_forecast(BASELINE, created_at="2026-10-01T00:00:00Z", forecast_id="pending-early")
    later = _row(2, BASELINE, 'B')
    with pytest.raises(ValueError, match="pending forecast must be the final"):
        summarize_ledger([pending, later])
    first = _row(3, BASELINE, 'B')
    earlier = _row(1, BASELINE, 'P')
    with pytest.raises(ValueError, match="ordered by created_at"):
        summarize_ledger([first, earlier])

