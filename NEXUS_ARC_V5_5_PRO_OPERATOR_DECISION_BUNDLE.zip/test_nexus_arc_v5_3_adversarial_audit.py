from datetime import datetime, timedelta, timezone
import pytest
from nexus_arc_v5_3_adversarial_audit import (
    BASELINE, canonical_sha256, create_forecast, moving_block_bootstrap_ci,
    resolve_forecast, summarize_ledger, verify_external_digest,
)


def row(i, probs, outcome, *, model='candidate-a', seconds=30):
    t0 = datetime(2026, 10, 1, tzinfo=timezone.utc) + timedelta(minutes=i)
    created = t0.isoformat().replace('+00:00', 'Z')
    r = create_forecast(probs, created_at=created, forecast_id=f'f{i}', model_id=model)
    return resolve_forecast(r, outcome, resolved_at=(t0 + timedelta(seconds=seconds)).isoformat().replace('+00:00', 'Z'))


def test_probability_and_score_validation():
    assert create_forecast(BASELINE, model_id='m1')['status'] == 'PENDING'
    with pytest.raises(ValueError): create_forecast({'B': .5, 'P': .3, 'T': .3})
    with pytest.raises(ValueError): create_forecast(BASELINE, model_id=' ')


def test_fractional_timestamp_precision_is_preserved():
    r = create_forecast(BASELINE, created_at='2026-10-01T00:00:00.900Z', forecast_id='f1')
    with pytest.raises(ValueError, match='cannot precede'):
        resolve_forecast(r, 'B', resolved_at='2026-10-01T00:00:00.100Z')


def test_sequence_timestamp_cannot_overlap_prior_resolution():
    a = row(0, BASELINE, 'B', seconds=55)
    b = create_forecast(BASELINE, created_at='2026-10-01T00:00:30.000Z', forecast_id='f1', model_id='candidate-a')
    # created 5 seconds after previous created, but before prior observation was resolved
    with pytest.raises(ValueError, match='cannot precede the prior observed outcome'):
        summarize_ledger([a, b])


def test_bootstrap_is_deterministic_and_preserves_contiguous_block_sampling():
    values = [0.0] * 40 + [1.0] * 40
    a = moving_block_bootstrap_ci(values, block_length=5, replicates=300, seed=7, min_n=30)
    b = moving_block_bootstrap_ci(values, block_length=5, replicates=300, seed=7, min_n=30)
    assert a == b
    assert a['method'] == 'moving_block_bootstrap_mean_ci'
    assert a['lower'] <= a['mean'] <= a['upper']
    assert moving_block_bootstrap_ci([1.0] * 20, min_n=30) is None


def test_empty_and_small_samples_fail_closed():
    s = summarize_ledger([])
    assert s['gate'] == 'WARMING_INSUFFICIENT_SAMPLE'
    assert s['decision'] == 'NO_BET_RECOMMENDATION_FROM_ROADMAP_OR_THIS_AUDIT'
    rows = [row(i, BASELINE, ['B','P','T'][i % 3]) for i in range(60)]
    assert summarize_ledger(rows)['gate'] == 'WARMING_INSUFFICIENT_SAMPLE'


def test_candidate_cannot_be_mixed_inside_one_cohort():
    rows = [row(0, BASELINE, 'B', model='a'), row(1, BASELINE, 'P', model='b')]
    with pytest.raises(ValueError, match='mixed model_id'):
        summarize_ledger(rows)


def test_multiple_candidate_search_blocks_promotion():
    sharp = {'B': .96, 'P': .02, 'T': .02}
    rows = [row(i, sharp, 'B') for i in range(300)]
    s = summarize_ledger(rows, trials_inspected=7, bootstrap_replicates=300)
    assert s['gate'] == 'EXPLORATORY_MULTIPLE_TRIALS_NO_PROMOTION'


def test_candidate_not_promoted_if_second_half_disagrees():
    sharp_b = {'B': .98, 'P': .01, 'T': .01}
    sharp_p = {'B': .01, 'P': .98, 'T': .01}
    rows = [row(i, sharp_b, 'B') for i in range(150)]
    rows += [row(i + 150, sharp_p, 'B') for i in range(150)]
    s = summarize_ledger(rows, bootstrap_replicates=300)
    assert s['stability']['status'] == 'INCONSISTENT_ACROSS_HALVES'
    assert s['gate'] == 'INCONSISTENT_ACROSS_HALVES_NO_PROMOTION'


def test_identical_baseline_model_does_not_claim_improvement():
    outcomes = ['B', 'P', 'T', 'B', 'P'] * 60
    rows = [row(i, BASELINE, out) for i, out in enumerate(outcomes)]
    s = summarize_ledger(rows, bootstrap_replicates=300)
    assert s['resolved_n'] == 300
    assert s['gate'] != 'PROVISIONAL_IMPROVEMENT_REQUIRES_INDEPENDENT_REPLICATION'
    assert abs(s['brier_skill_vs_baseline']) < 1e-12


def test_provisional_gate_needs_bootstrap_ci_and_both_halves_improved():
    probs = {'B': .96, 'P': .02, 'T': .02}
    rows = [row(i, probs, 'B') for i in range(300)]
    s = summarize_ledger(rows, bootstrap_replicates=300)
    assert s['gate'] == 'PROVISIONAL_IMPROVEMENT_REQUIRES_INDEPENDENT_REPLICATION'
    assert s['paired_brier_delta_ci95']['upper'] < 0
    assert s['paired_log_loss_delta_ci95']['upper'] < 0
    assert s['stability']['status'] == 'BOTH_HALVES_IMPROVED'


def test_rejects_duplicate_ids_bad_timestamp_order_and_pending_before_end():
    r = row(0, BASELINE, 'B')
    with pytest.raises(ValueError, match='unique'):
        summarize_ledger([r, r])
    p = create_forecast(BASELINE, created_at='2026-10-01T00:00:00Z', forecast_id='pending')
    later = row(1, BASELINE, 'B')
    with pytest.raises(ValueError, match='pending forecast must be the final'):
        summarize_ledger([p, later])
    first, earlier = row(3, BASELINE, 'B'), row(2, BASELINE, 'P')
    with pytest.raises(ValueError, match='ordered by created_at'):
        summarize_ledger([first, earlier])


def test_external_digest_detects_change_but_is_not_signature():
    payload = {'records': [{'id': 1, 'actual': 'B'}]}
    digest = canonical_sha256(payload)
    assert verify_external_digest(payload, digest)
    payload['records'][0]['actual'] = 'P'
    assert not verify_external_digest(payload, digest)


def test_trials_parameter_validation():
    with pytest.raises(ValueError): summarize_ledger([], trials_inspected=0)
    with pytest.raises(ValueError): summarize_ledger([], trials_inspected=True)
