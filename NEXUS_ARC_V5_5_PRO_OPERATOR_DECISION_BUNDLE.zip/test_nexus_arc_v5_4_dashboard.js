const fs = require('fs');
const vm = require('vm');
const assert = require('assert');
const html = fs.readFileSync(process.argv[2] || 'NEXUS_ARC_V5_4_RISK_LAB_DESK.html', 'utf8');
const match = html.match(/<script id="nexusArcV54RiskLab">([\s\S]*?)<\/script>/);
assert(match, 'V5.4 dashboard script exists');
class El {
  constructor(value = '') { this.value = String(value); this.textContent = ''; this.innerHTML = ''; this.className = ''; this.disabled = false; this.listeners = {}; }
  addEventListener(name, fn) { this.listeners[name] = fn; }
  fire(name) { if (this.listeners[name]) this.listeners[name](); }
}
const defaults = {
  v54Bankroll:1000,v54Stake:10,v54StopLoss:100,v54Target:50,v54Hands:100,
  v54MaxStake:500,v54Trials:5000,v54Seed:20261012,v54Side:'B',v54Commission:5,
  v54PlayerPayout:1,v54TiePayout:8,v54ActualVenue:'Test table',v54ActualStrategy:'flat',
  v54ActualSide:'B',v54ActualHands:100,v54ActualTurnover:1000,v54ActualPnl:20,
  v54ActualNote:'test record'
};
const ids = [...match[1].matchAll(/\$\('([^']+)'\)/g)].map(x=>x[1]);
const elements = {};
for (const [id,value] of Object.entries(defaults)) elements[id] = new El(value);
for (const id of new Set(ids)) if (!elements[id]) elements[id] = new El('');
const store = new Map();
const localStorage = {getItem:k=>store.has(k)?store.get(k):null,setItem:(k,v)=>store.set(k,String(v)),removeItem:k=>store.delete(k)};
const ctx = {document:{getElementById:id=>elements[id]||(elements[id]=new El())},localStorage,crypto:{randomUUID:()=>`id-${Math.random()}`},
  Blob:class Blob {constructor(parts,opts){this.parts=parts;this.type=opts?.type}},URL:{createObjectURL:()=> 'blob:test',revokeObjectURL:()=>{}},setTimeout:()=>{},console,Math,Number,String,JSON,Date,Error,Object,Array,Map,Set,parseInt,parseFloat};
vm.runInNewContext(match[1],ctx,{timeout:5000});
elements.v54Run.fire('click');
assert(elements.v54Decision.textContent.includes('PASS / NO VERIFIED POSITIVE EXPECTANCY'), 'standard Banker rules show no verified positive EV');
assert(elements.v54EVCards.innerHTML.includes('House edge'), 'EV cards populated');
assert(elements.v54EVCards.innerHTML.includes('-1.06%'), 'Banker standard edge displayed about -1.06% EV');
assert(elements.v54Flat.innerHTML.includes('Stop-loss'), 'flat risk simulation populated');
assert(elements.v54Martingale.innerHTML.includes('Max stake'), 'Martingale stake risk displayed');
const first = elements.v54Flat.innerHTML;
elements.v54Run.fire('click');
assert.strictEqual(elements.v54Flat.innerHTML, first, 'fixed seed makes simulation repeatable');
elements.v54Commission.value='0';
elements.v54Run.fire('click');
assert(elements.v54Decision.textContent.includes('MODELLED POSITIVE EV UNDER ENTERED RULES ONLY'), 'custom zero-commission rule is flagged as model-only, not authorized');
elements.v54Trials.value='20000'; elements.v54Hands.value='100';
elements.v54Run.fire('click');
assert(elements.v54Decision.textContent.includes('1,000,000') || elements.v54Decision.textContent.includes('AUDIT BLOCKED'), 'calculation work is bounded');
// Return to sane workload then test actual-session memory.
elements.v54Trials.value='1000';elements.v54Hands.value='50';elements.v54Commission.value='5';
elements.v54Run.fire('click');
elements.v54SaveActual.fire('click');
assert(elements.v54ActualStatus.textContent.includes('บันทึก Session จริงแล้ว'), 'actual session can be saved');
assert(elements.v54ActualSummary.textContent.includes('P/L จริงรวม'), 'actual vs expected summary populated');
const ledger = JSON.parse(store.get('nexus-arc-v5.4-actual-session-ledger-v1'));
assert.strictEqual(ledger.length,1);assert.strictEqual(ledger[0].pnl,20);assert(ledger[0].expectedNet<0,'expected net records negative EV under standard Banker rules');
// Malformed ledger must not be silently overwritten.
store.set('nexus-arc-v5.4-actual-session-ledger-v1','{broken');
elements.v54SaveActual.fire('click');
assert(elements.v54ActualStatus.textContent.includes('เสียหาย'), 'corrupt actual ledger is blocked');
console.log('PASS: V5.4 dashboard EV, no-edge default, deterministic risk simulation, work guard, actual-session memory, and corrupted-ledger safeguard');
