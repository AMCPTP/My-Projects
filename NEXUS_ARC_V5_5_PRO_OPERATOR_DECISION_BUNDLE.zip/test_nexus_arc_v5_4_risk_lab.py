import pytest
from nexus_arc_v5_4_risk_lab import BASELINE, compare_strategies, expected_value_per_unit, rule_analysis, simulate_session_risk


def test_standard_8_deck_expected_value_known_values():
    assert expected_value_per_unit("B") == pytest.approx(-0.01057985, abs=1e-5)
    assert expected_value_per_unit("P") == pytest.approx(-0.012350, abs=1e-5)
    assert expected_value_per_unit("T") == pytest.approx(-0.143596, abs=1e-5)


def test_house_edge_and_break_even_thresholds():
    x = rule_analysis()
    assert x["house_edge"]["B"] == pytest.approx(0.01057985, abs=1e-5)
    assert x["house_edge"]["P"] == pytest.approx(0.012350, abs=1e-5)
    assert x["house_edge"]["T"] == pytest.approx(0.143596, abs=1e-5)
    assert x["break_even"]["tie_net_payout_min"] == pytest.approx((BASELINE["B"]+BASELINE["P"])/BASELINE["T"])
    assert x["break_even"]["banker_commission_max"] < 0.05
    assert x["break_even"]["player_net_payout_min"] > 1.0


def test_zero_commission_banker_has_positive_baseline_ev():
    assert expected_value_per_unit("B", banker_commission=0.0) > 0


def test_probability_and_rule_validation():
    with pytest.raises(ValueError): expected_value_per_unit("X")
    with pytest.raises(ValueError): expected_value_per_unit("B", banker_commission=1.1)
    with pytest.raises(ValueError): expected_value_per_unit("B", probabilities={"B": .5, "P": .5, "T": .1})
    with pytest.raises(ValueError): rule_analysis(tie_payout=-1)


def test_simulation_reproducible_and_stops_partition_trials():
    kwargs = dict(side="B", bankroll=1000, base_stake=10, stop_loss=100, profit_target=50,
                  max_hands=50, max_table_stake=500, trials=500, seed=123)
    a = simulate_session_risk(**kwargs)
    b = simulate_session_risk(**kwargs)
    assert a == b
    assert sum(a["stops"].values()) == 500
    assert a["mean_hands"] <= 50
    assert 0 <= a["target_hit_rate"] <= 1
    assert a["target_hit_ci95"]["lower"] <= a["target_hit_rate"] <= a["target_hit_ci95"]["upper"]


def test_martingale_can_hit_limits_and_does_not_change_unit_ev():
    flat = simulate_session_risk(strategy="flat", trials=1000, seed=88, max_hands=100)
    mart = simulate_session_risk(strategy="martingale", trials=1000, seed=89, max_hands=100)
    assert flat["ev_per_unit"] == pytest.approx(mart["ev_per_unit"])
    assert mart["mean_max_stake"] >= 10
    assert sum(mart["stops"].values()) == 1000


def test_base_stake_constraints():
    with pytest.raises(ValueError): simulate_session_risk(base_stake=600, max_table_stake=500)
    with pytest.raises(ValueError): simulate_session_risk(trials=10)
    with pytest.raises(ValueError): simulate_session_risk(max_hands=0)


def test_compare_returns_both_strategies_and_same_edge():
    result = compare_strategies(trials=250, max_hands=30, seed=9)
    assert result["flat"]["strategy"] == "flat"
    assert result["martingale"]["strategy"] == "martingale"
    assert result["flat"]["ev_per_unit"] == result["martingale"]["ev_per_unit"]
