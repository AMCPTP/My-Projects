const fs = require('fs');
const vm = require('vm');
const assert = require('assert');
const html = fs.readFileSync(process.argv[2] || 'NEXUS_ARC_V5_5_PRO_OPERATOR_DECISION_DESK.html', 'utf8');
const match = html.match(/<script id="nexusArcV55ProOperatorGate">([\s\S]*?)<\/script>/);
assert(match, 'V5.5 pro operator gate script exists');
class El {
  constructor(value = '') { this.value = String(value); this.textContent = ''; this.innerHTML = ''; this.className = ''; this.disabled = false; this.checked = false; this.listeners = {}; }
  addEventListener(name, fn) { this.listeners[name] = fn; }
  fire(name) { if (this.listeners[name]) return this.listeners[name](); }
  click() { if (this.listeners.click) return this.listeners.click(); }
}
const defaults = {
  v54Commission:5,v54PlayerPayout:1,v54TiePayout:8,
  v54Bankroll:1000,v54Stake:10,v54StopLoss:100,v54Target:50,v54MaxStake:500,
  v55Side:'B',v55ProbB:.458597,v55ProbP:.446247,v55ProbT:.095156,
  v55HoldoutN:0,v55LowerEV:0,v55EvidenceId:'',v55CurrentPnl:0
};
const ids = [...match[1].matchAll(/\$\('([^']+)'\)/g)].map(x => x[1]);
const elements = {};
for (const [id, value] of Object.entries(defaults)) elements[id] = new El(value);
for (const id of new Set(ids)) if (!elements[id]) elements[id] = new El('');
const downloads=[];
const ctx = {
  document:{getElementById:id=>elements[id]||(elements[id]=new El())},
  Blob:class Blob {constructor(parts,opts){this.parts=parts;this.type=opts?.type}},
  URL:{createObjectURL:()=> 'blob:test',revokeObjectURL:()=>{}},
  setTimeout:()=>{}, console, Math, Number, String, JSON, Date, Error, Object, Array, Map, Set,
  window:{},
};
ctx.document.createElement=(tag)=>{const e=new El();e.tagName=tag;e.click=()=>downloads.push(e.download);return e;};
vm.runInNewContext(match[1],ctx,{timeout:5000});
const gate=ctx.window.NEXUSArcV55ProGate;
assert(gate,'public test API exposed');
let r=elements.v55Evaluate.fire('click');
assert(elements.v55Status.textContent.includes('PASS_NO_POSITIVE_MODELLED_EV'),'standard rules fail closed when no positive EV');
// Positive EV based on supplied probabilities is insufficient without verified rules.
elements.v55ProbB.value='0.5';elements.v55ProbP.value='0.4';elements.v55ProbT.value='0.1';elements.v54Commission.value='0';
elements.v55Evaluate.fire('click');
assert(elements.v55Status.textContent.includes('HOLD_RULES_UNVERIFIED'),'unverified payout rules prevent promotion');
// Fully checked evidence only reaches REVIEW ONLY, never authorization.
elements.v55HoldoutN.value='1500';elements.v55LowerEV.value='0.001';elements.v55EvidenceId.value='holdout-report-001';
for(const id of gate.CHECKS) elements[id].checked=true;
elements.v55Evaluate.fire('click');
assert(elements.v55Status.textContent.includes('REVIEW_ONLY_EDGE_CANDIDATE'),'all checked items reach review-only status');
assert(elements.v55Details.textContent.includes('NO_WAGER_AUTHORIZATION')===false,'UI copy does not authorize a wager');
// Hard risk stop takes priority over apparently positive edge.
elements.v55CurrentPnl.value='-100';elements.v55Evaluate.fire('click');
assert(elements.v55Status.textContent.includes('STOP_SESSION_STOP_LOSS'),'stop-loss overrides positive edge');
elements.v55CurrentPnl.value='0';elements.v55Chasing.checked=true;elements.v55Evaluate.fire('click');
assert(elements.v55Status.textContent.includes('STOP_SESSION_CHASING_OR_EMOTIONAL'),'chasing flag stops session');
// Drift suspends candidate; invalid probabilities are rejected.
elements.v55Chasing.checked=false;elements.v55Drift.checked=true;elements.v55Evaluate.fire('click');
assert(elements.v55Status.textContent.includes('HOLD_REGIME_DRIFT'),'drift alert prevents candidate');
elements.v55Drift.checked=false;elements.v55ProbP.value='0.5';elements.v55Evaluate.fire('click');
assert(elements.v55Status.textContent.includes('AUDIT BLOCKED'),'bad probability sum is blocked');
// Reset clears evidence assertions.
elements.v55Reset.fire('click');
assert(gate.CHECKS.every(id=>!elements[id].checked),'reset clears evidence checklist');
assert(elements.v55Status.textContent.includes('RESET'),'reset state visible');
console.log('PASS: V5.5 pro gate standard-pass, rules gate, review-only promotion, stop-loss/chasing override, drift block, invalid probability block, and reset');
