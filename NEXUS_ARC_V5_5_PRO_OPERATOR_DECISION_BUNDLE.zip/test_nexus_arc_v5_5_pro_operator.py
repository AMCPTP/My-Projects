import pytest
from nexus_arc_v5_5_pro_operator import BASELINE, calculate_ev, evaluate_decision_gate


def good_candidate(**overrides):
    args = dict(
        side="B", probabilities={"B": .50, "P": .40, "T": .10},
        banker_commission=.05, player_payout=1, tie_payout=8,
        bankroll=1000, stake=10, stop_loss=100, profit_target=50,
        current_session_pnl=0, max_table_stake=500,
        holdout_sample_size=1500, holdout_ev_lower_95=.002,
        evidence_report_id="holdout-report-2026-001",
        rules_verified=True, model_preregistered=True, untouched_holdout=True,
        calibration_passed=True, stability_passed=True, audit_trail_verified=True,
        multiple_testing_controlled=True,
    )
    args.update(overrides)
    return evaluate_decision_gate(**args)


def test_standard_baseline_shows_negative_ev_for_all_common_bets():
    assert calculate_ev("B") == pytest.approx(-.01057985, abs=1e-5)
    assert calculate_ev("P") == pytest.approx(-.01235, abs=1e-5)
    assert calculate_ev("T") == pytest.approx(-.143596, abs=1e-5)
    for side in "BPT":
        assert evaluate_decision_gate(side=side)["status"] == "PASS_NO_POSITIVE_MODELLED_EV"


def test_positive_model_ev_alone_never_authorizes_or_skips_rules_gate():
    r = evaluate_decision_gate(probabilities={"B": .5, "P": .4, "T": .1}, rules_verified=False)
    assert r["status"] == "HOLD_RULES_UNVERIFIED"
    assert r["decision"] == "NO_WAGER_AUTHORIZATION"


def test_only_full_operator_supplied_checks_can_reach_review_only_candidate():
    r = good_candidate()
    assert r["status"] == "REVIEW_ONLY_EDGE_CANDIDATE"
    assert r["decision"] == "NO_WAGER_AUTHORIZATION"
    assert "not a bet signal" in r["reasons"][0]


@pytest.mark.parametrize("overrides,expected", [
    ({"current_session_pnl": -100}, "STOP_SESSION_STOP_LOSS"),
    ({"current_session_pnl": 50}, "STOP_SESSION_PROFIT_TARGET"),
    ({"chasing_or_emotional": True}, "STOP_SESSION_CHASING_OR_EMOTIONAL"),
    ({"stake": 1001}, "STOP_STAKE_OR_BANKROLL_LIMIT"),
    ({"stake": 600, "max_table_stake": 500}, "STOP_STAKE_OR_BANKROLL_LIMIT"),
    ({"drift_alert": True}, "HOLD_REGIME_DRIFT"),
    ({"stop_loss": 0}, "HOLD_RISK_LIMITS_NOT_SET"),
])
def test_hard_risk_gates_override_positive_edge(overrides, expected):
    assert good_candidate(**overrides)["status"] == expected


def test_holdout_sample_floor_is_not_bypassed():
    assert good_candidate(holdout_sample_size=999)["status"] == "HOLD_HOLDOUT_SAMPLE_TOO_SMALL"


def test_nonpositive_lower_bound_blocks_candidate():
    assert good_candidate(holdout_ev_lower_95=0)["status"] == "HOLD_HOLDOUT_LOWER_BOUND_NOT_POSITIVE"


def test_missing_audit_check_blocks_candidate():
    r = good_candidate(audit_trail_verified=False)
    assert r["status"] == "HOLD_EVIDENCE_CHECKS_INCOMPLETE"
    assert "audit_trail_verified" in r["missing_checks"]


def test_missing_report_id_blocks_candidate():
    r = good_candidate(evidence_report_id="")
    assert r["status"] == "HOLD_EVIDENCE_CHECKS_INCOMPLETE"
    assert "evidence_report_id" in r["missing_checks"]


def test_model_probability_validation():
    with pytest.raises(ValueError): calculate_ev("B", {"B": .6, "P": .6, "T": 0})
    with pytest.raises(ValueError): calculate_ev("X")
    with pytest.raises(ValueError): calculate_ev("B", {"B": .5, "P": .4, "T": .1}, banker_commission=1.2)


def test_probability_normal_values_are_part_of_the_review_record():
    r = good_candidate()
    assert r["side_reviewed"] == "B"
    assert r["modelled_ev_per_unit"] == pytest.approx(.5 * .95 - .4)
    assert r["holdout_sample_size"] == 1500
    assert r["evidence_report_id"] == "holdout-report-2026-001"
