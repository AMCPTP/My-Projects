import unittest
from nexus_arc_v5_learning import retrieve_lessons, build_diagnostics


def ev(kind, payload, seq=1):
    return {"seq": seq, "event_type": kind, "created_at": f"2026-10-11T00:00:0{seq}Z", "payload": payload, "event_hash": "mock"}

class V5LearningTests(unittest.TestCase):
    def setUp(self):
        self.events = [
            ev("evidence_added", {"evidence_id": "e1"}, 1),
            ev("incident_recorded", {"incident_id": "i1", "domain": "technology", "symptom": "Missed release", "hypothesis": "The changelog was not checked", "corrective_action": "Check official release notes and timestamp before answering.", "evidence_ids": ["e1"]}, 2),
        ]

    def test_no_lesson_without_explicit_review(self):
        result = retrieve_lessons(self.events, "technology")
        self.assertEqual(result["lessons"], [])
        self.assertEqual(result["pending_review_count"], 1)
        self.assertFalse(result["model_weights_updated"])

    def test_approved_evidence_linked_lesson_retrieved(self):
        self.events.append(ev("lesson_reviewed", {"incident_id": "i1", "decision": "approved", "note": "Verified this lesson for release checks"}, 3))
        result = retrieve_lessons(self.events, "technology")
        self.assertEqual(len(result["lessons"]), 1)
        self.assertEqual(result["lessons"][0]["lesson_id"], "i1")
        self.assertIn("not independently proven", result["lessons"][0]["source_status"])

    def test_lesson_not_retrieved_for_unrelated_domain(self):
        self.events.append(ev("lesson_reviewed", {"incident_id": "i1", "decision": "approved", "note": "Verified this lesson for release checks"}, 3))
        self.assertEqual(retrieve_lessons(self.events, "finance")["lessons"], [])

    def test_harmful_reports_quarantine_lesson(self):
        self.events += [
            ev("lesson_reviewed", {"incident_id": "i1", "decision": "approved", "note": "Verified this lesson for release checks"}, 3),
            ev("lesson_effectiveness_reviewed", {"incident_id": "i1", "verdict": "harmful"}, 4),
            ev("lesson_effectiveness_reviewed", {"incident_id": "i1", "verdict": "harmful"}, 5),
        ]
        result = retrieve_lessons(self.events, "technology")
        self.assertEqual(result["lessons"], [])
        self.assertEqual(result["quarantined_pending_review_count"], 1)

    def test_rejection_overrides_approval(self):
        self.events += [
            ev("lesson_reviewed", {"incident_id": "i1", "decision": "approved", "note": "Verified this lesson for release checks"}, 3),
            ev("lesson_reviewed", {"incident_id": "i1", "decision": "rejected", "note": "The prior rule was not sufficiently supported"}, 4),
        ]
        self.assertEqual(retrieve_lessons(self.events, "technology")["lessons"], [])

    def test_diagnostics_never_claims_weight_training(self):
        out = build_diagnostics(self.events, [])
        self.assertEqual(out["learning_mode"], "retrieval_guidance_only")
        self.assertFalse(out["model_weights_updated"])
        self.assertFalse(out["automatic_root_cause_discovery"])

if __name__ == "__main__":
    unittest.main()
