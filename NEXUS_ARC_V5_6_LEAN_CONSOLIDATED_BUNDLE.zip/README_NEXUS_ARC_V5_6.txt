NEXUS ARC V5.6 — LEAN CONSOLIDATED RELEASE
Release date: 12 October 2026

PURPOSE
A cleaned, single-dashboard release. Duplicate standalone dashboards from older releases have been removed from this package. Active backend modules and regression tests needed for the integrated dashboard are retained. This is packaging/maintenance consolidation, not a claim of new predictive capability.

START ON WINDOWS
1. Extract the ZIP to a new folder.
2. Install Python 3.11+ (recommended).
3. Open Command Prompt in this folder and run: pip install -r requirements.txt
4. Optional for tests: pip install -r requirements-dev.txt
5. Run start_nexus_arc_v5_6.bat. The local backend binds to 127.0.0.1:8787.
6. Keep the console open while using server-backed memory/assurance panels. To use offline dashboard-only panels, open NEXUS_ARC_V5_6_LEAN_OPERATOR_DESK.html directly.

WHAT IS RETAINED
- One integrated dashboard with roadmap, expectancy, session guard, prospective audit, risk lab, actual session memory, closed-loop learning, and Pro Operator Decision Gate.
- Local backend and only its required learning/assurance modules.
- Active Python and JavaScript regression tests.
- Requirements, environment example, and test reports.

WHAT WAS REMOVED
- Separate older V4.8/V4.9/V5.0/V5.2/V5.3/V5.4 dashboard copies, redundant old start scripts, historical duplicate release reports/checksum lists, and tests for retired standalone UI variants that are not part of the single integrated release. The historical feature implementations that are still dependencies remain as modules.

TESTS
Run: python -m pytest -q
Run dashboard regressions:
  node test_nexus_arc_v5_5_dashboard.js ./NEXUS_ARC_V5_6_LEAN_OPERATOR_DESK.html
  node test_nexus_arc_v5_4_dashboard.js ./NEXUS_ARC_V5_6_LEAN_OPERATOR_DESK.html
  node test_nexus_arc_v5_0_mock.js ./NEXUS_ARC_V5_6_LEAN_OPERATOR_DESK.html

LIMITS
- No live casino feed, exact shoe/card composition tracker, verified next-hand edge, or automatic betting.
- Lesson memory is record/retrieval and evaluation; it is not model-weight self-training.
- Browser-local session records can be edited and are not tamper-proof.
- Gate evidence is operator-entered and not independently authenticated.
- Software tests do not prove profit, advantage, or real-browser accessibility.
- Standard baccarat patterns alone do not establish a positive expected value. If there is no independently validated edge, PASS is the disciplined default.
