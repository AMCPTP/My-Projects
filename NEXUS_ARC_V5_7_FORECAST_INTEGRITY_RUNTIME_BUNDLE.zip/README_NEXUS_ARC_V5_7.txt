NEXUS ARC V5.7 — FORECAST INTEGRITY RELEASE
Release date: 12 October 2026

PURPOSE
A focused hardening release for forecast evaluation. It removes the misleading heuristic “high-every-dimension” health certification, fixes a result-recording path that could report success after a failed write, and replaces iid-normal promotion confidence with deterministic moving-block bootstrap and a sequential-trial adjustment.

WHAT CHANGED
- Section 00 now shows empirical prequential forecast metrics for the current engine version: scored N, recent Log Loss, recent Brier score, calibration gap, and baseline comparison. It does not turn handcrafted component scores into a capability certification.
- Forecast header wording says MODEL ESTIMATE / MODEL DIAGNOSTIC ONLY, P/B conditional on non-Tie, and NOT A BET SIGNAL. The old “NEXT HAND” framing was removed.
- Result buttons stop after a failed record/audit write instead of continuing the promotion workflow and displaying a false success message. Save fallback is explicitly disclosed as temporary in-memory storage.
- Champion/challenger promotion uses a deterministic moving-block bootstrap lower bound for paired Log Loss gains (block length 5, 2,000 resamples) and Bonferroni-style alpha adjustment across previous promotion trials. This reduces iid assumptions and repeated-testing risk; it does not eliminate all statistical-selection risk.
- Engine/version labels identify the current V5.7 forecast engine so old V4.8 outcomes are not silently counted as V5.7 empirical performance. Both empirical diagnostics and champion/challenger training exclude older engineVersion records; historical data remains available for audit, not current-version scoring.

RUNTIME FILES
- NEXUS_ARC_V5_7_FORECAST_INTEGRITY_DESK.html
- nexus_arc_v5_7_server.py
- nexus_arc_v4_8_learning.py, nexus_arc_v4_9_assurance.py, nexus_arc_v5_learning.py
- requirements.txt, .env.example, start_nexus_arc_v5_7.bat

INSTALL
1. Extract the runtime bundle to a new folder.
2. Run: py -3 -m pip install -r requirements.txt
3. Run start_nexus_arc_v5_7.bat.
4. Set OPENAI_API_KEY and NEXUS_MODEL in .env only if using the general analysis provider endpoint.
5. Open http://127.0.0.1:8787.

DATA / MIGRATION
Back up nexus_v5_0_data and export browser ledgers before changing versions. Browser localStorage is scoped to browser origin; keep the same profile and http://127.0.0.1:8787 origin to preserve it. Do not run two writable instances against the same data directory concurrently.

LIMITS
- The forecast remains a P/B sequence diagnostic conditioned on non-Tie outcomes. It is not a verified next-hand prediction, shoe composition/card-count model, automatic betting system, or profit guarantee.
- A bootstrap interval cannot make the input trustworthy; local ledgers and operator-entered results remain editable. A model promotion is an internal research signal, not betting authorization.
- No live casino feed, live provider credentials, Chrome/Edge visual/accessibility pass, or profitability benchmark was available in this release test.
