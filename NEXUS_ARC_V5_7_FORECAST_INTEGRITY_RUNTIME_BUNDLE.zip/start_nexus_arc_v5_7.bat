@echo off
setlocal
cd /d "%~dp0"
if not exist ".env" copy ".env.example" ".env" >nul
set "NEXUS_DASHBOARD_PATH=%~dp0NEXUS_ARC_V5_7_FORECAST_INTEGRITY_DESK.html"
py -3 -c "import fastapi, uvicorn, httpx, pydantic, openai" >nul 2>&1
if errorlevel 1 (
  echo Required packages are missing for this Python installation.
  echo Run: py -3 -m pip install -r requirements.txt
  pause
  exit /b 1
)
py -3 nexus_arc_v5_7_server.py
if errorlevel 1 pause
endlocal
