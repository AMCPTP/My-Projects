NEXUS ARC V5.8 — DECISION INTEGRITY RELEASE
Release date: 13 October 2026

PURPOSE
V5.8 corrects probability presentation and tightens the research gate. It does not claim to predict baccarat profitably.

KEY CHANGES
- Fixed double-shrink in the forecast output: reported P/B probabilities now reflect the calibrated model output, rather than shrinking that output a second time using a heuristic confidence score.
- Renamed the display to MODEL PROBABILITY · UNVALIDATED and clarified that heuristic scores are not proven edge or expected value.
- Re-labels the 50/50 comparison as a neutral coin-flip reference only, not a baccarat-specific baseline and not evidence of a wagering edge.
- Candidate trials can finish as exploratory screens, but automatic champion promotion is disabled. Any candidate that appears better requires a pre-registered, independent sealed holdout and review.
- Bootstrap lower-bound calculation returns inconclusive when requested alpha is below the finite resampling resolution instead of silently rounding alpha upward.
- Heuristic root-cause repairs require the same hypothesis to recur at least three times in the recent error log before changing repair weights. This reduces one-mistake overreaction; it does not establish causality.
- V5.7 Brain export schema remains importable; old-version outcomes remain archived but do not count as V5.8 scored cases.

RUNTIME FILES
- NEXUS_ARC_V5_8_DECISION_INTEGRITY_DESK.html
- nexus_arc_v5_8_server.py
- nexus_arc_v4_8_learning.py, nexus_arc_v4_9_assurance.py, nexus_arc_v5_learning.py
- requirements.txt, .env.example, start_nexus_arc_v5_8.bat

INSTALL
1. Extract the runtime bundle into a new folder.
2. Run: py -3 -m pip install -r requirements.txt
3. Run start_nexus_arc_v5_8.bat.
4. Set OPENAI_API_KEY and NEXUS_MODEL in .env only if using the general analysis provider endpoint.
5. Open http://127.0.0.1:8787.

DATA / MIGRATION
Back up nexus_v5_0_data and export browser ledgers before changing versions. Browser localStorage is scoped to browser origin; keep the same browser profile and http://127.0.0.1:8787 origin to preserve it. Do not run two writable instances against the same data directory concurrently. Import V5.7 Brain files using the dashboard importer; V5.7 outcomes are preserved for audit but are not V5.8 performance evidence.

LIMITS
- P/B output is conditional on non-Tie sequence history. This is not a shoe-composition/card-count model or a verified next-hand probability.
- 50/50 is a neutral reference, not the correct baccarat-specific baseline.
- LocalStorage and operator-entered results are editable and not independently time-attested. Hashes are local integrity aids, not external signatures.
- Candidate trials remain exploratory; no automatic promotion or wager authorization occurs.
- No live casino feed, live provider credentials, real-browser accessibility/visual pass, or independent profitability benchmark was available. Passing software tests does not establish predictive edge or profit.
