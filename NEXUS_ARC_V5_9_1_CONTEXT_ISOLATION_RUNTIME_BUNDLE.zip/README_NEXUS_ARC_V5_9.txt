NEXUS ARC V5.9.1 — CONTEXT ISOLATION RUNTIME BUNDLE
==================================================

PURPOSE
This is a local analysis, audit, learning-ledger, and configured-feed monitoring workspace. V5.9.1 adds stricter domain isolation for stored lessons, evidence, incident reviews and forecasts, and prevents reuse of holdout case IDs across registered experiments.

INSTALL / RUN (Windows)
1. Extract this archive to a folder you control.
2. Install Python 3.11+ if not present.
3. Open a terminal in the extracted folder and run: py -3 -m pip install -r requirements.txt
4. Copy .env.example to .env and configure OPENAI_API_KEY and NEXUS_MODEL only if you want the optional server-side LLM analysis function. Never share .env or API keys.
5. Run start_nexus_arc_v5_9.bat. The gateway binds to 127.0.0.1 by default.
6. Open http://127.0.0.1:8787/ in a browser.

REGRESSION TESTS
With dependencies installed, run:
  python -m unittest -v test_nexus_arc_v5_9_1_regression.py
The included independent regression suite contains 14 tests for domain isolation, request-body limits, data-link validation, canonical source identifiers, holdout reuse prevention, lesson quarantine and ledger integrity.

DATA / RESET SCOPE
- Local P/B history, its learner state, and local events are stored in browser localStorage when available. That storage is editable and is not a secure vault; periodically use Export Brain for backups.
- If browser persistence fails, the UI indicates MEMORY ONLY. Such changes are lost when the tab/process is closed unless exported.
- The dashboard reset clears local browser history/Brain/events only. Server-side learning and assurance ledgers are separate and are not silently erased by that button.
- Browser SHA-256 Brain checksums detect unintended alteration relative to a checksum field; they do not authenticate the author or prove imported content is true.

ANALYSIS / LEARNING LIMITS
- The local baccarat module is a heuristic sequence model. It is not a card-counting/shoe-composition model and is not a validated way to predict the next result or earn profit. Forecasts and normalized regime scores are diagnostics, not betting signals.
- Learning adjusts local expert/context weights and calibration from recorded outcomes. It does not fine-tune the underlying LLM, independently verify user-entered outcomes, infer causal explanations from a single miss, or guarantee future improvement.
- V5.9.1 isolates general lessons from domain-specific lessons; lessons must be supported by evidence from their own domain (or qualifying general research evidence). This reduces cross-context contamination, but does not prove a lesson is correct.
- Candidate comparison cannot auto-promote an active profile. Holdouts should be independently defined, fresh, and recorded before reviewing results.
- The eight-deck reference is an initial-shoe P/B probability conditional on a non-Tie result, not adjusted for dealt cards or table-specific conditions.
- External event feeds are monitor-only for the local P/B estimator. General analysis covers only available/configured sources for a specific request; exhaustive worldwide awareness is not possible.
- Mutating API request bodies are limited to 1 MiB even when streamed without a Content-Length header. The feed fetcher includes DNS/public-IP and redirect checks and size/time bounds. These controls reduce risk; they are not a security certification or full penetration test.

VERIFICATION
- See NEXUS_ARC_V5_9_TEST_REPORT.txt, NEXUS_ARC_V5_9_AUDIT_FINDINGS.txt and NEXUS_ARC_V5_9_CHANGELOG.txt.
- SHA-256 file checksums are listed in NEXUS_ARC_V5_9_1_SHA256SUMS.txt.
- The predecessor bundle's report claimed 73 passing tests, but the corresponding original test suite was not included in that archive and could not be independently reproduced from it. Do not treat that historical figure as a result of the V5.9.1 run.
- A real-browser visual test was attempted in the audit environment but blocked by its browser policy (ERR_BLOCKED_BY_ADMINISTRATOR). JavaScript syntax was checked with Node; that is not a substitute for a browser layout/accessibility test.
