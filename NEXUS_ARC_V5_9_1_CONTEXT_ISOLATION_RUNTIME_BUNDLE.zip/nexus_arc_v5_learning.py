"""NEXUS ARC V5.0 memory retrieval and evidence-first learning diagnostics.

This module performs retrieval-guided adaptation at inference time. It does NOT
train model weights, prove causal explanations, or independently verify operator
labels. A lesson can be retrieved only after an explicit approval event and a
linked evidence record; negative-use reports can quarantine it for review.
"""
from __future__ import annotations
from collections import Counter, defaultdict
from datetime import datetime, timezone
from typing import Any

SCHEMA = "NEXUS-ARC-V5.0-RETRIEVAL-LEARNING-1"
VALID_REVIEW_DECISIONS = {"approved", "rejected"}
VALID_USE_VERDICTS = {"helpful", "neutral", "harmful"}


def _event_payload(event: dict[str, Any]) -> dict[str, Any]:
    value = event.get("payload", {})
    return value if isinstance(value, dict) else {}


def _review_state(assurance_events: list[dict[str, Any]]) -> tuple[dict[str, dict[str, Any]], dict[str, Counter[str]]]:
    approvals: dict[str, dict[str, Any]] = {}
    uses: dict[str, Counter[str]] = defaultdict(Counter)
    for event in assurance_events:
        kind = event.get("event_type")
        payload = _event_payload(event)
        incident_id = str(payload.get("incident_id") or "")
        if kind == "lesson_reviewed" and incident_id:
            approvals[incident_id] = {**payload, "recorded_at": event.get("created_at"), "event_hash": event.get("event_hash")}
        elif kind == "lesson_effectiveness_reviewed" and incident_id:
            verdict = str(payload.get("verdict") or "")
            if verdict in VALID_USE_VERDICTS:
                uses[incident_id][verdict] += 1
    return approvals, uses


def _timestamp(value: Any) -> float:
    if not isinstance(value, str):
        return 0.0
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00")).timestamp()
    except (ValueError, TypeError, OverflowError):
        return 0.0


def retrieve_lessons(assurance_events: list[dict[str, Any]], domain: str, limit: int = 5) -> dict[str, Any]:
    """Return explicitly approved, evidence-linked lessons relevant to domain.

    Data entered by an operator is always labeled unverified as a general truth.
    Lessons with >=2 harmful-use reports and more harmful than helpful reports are
    excluded pending review. Only a corrective action is sent to the model; raw
    evidence excerpts and URLs are not injected as trusted instructions.
    """
    limit = max(0, min(10, int(limit)))
    approvals, use_counts = _review_state(assurance_events)
    incidents: dict[str, dict[str, Any]] = {}
    evidence_by_id: dict[str, dict[str, Any]] = {}
    for event in assurance_events:
        payload = _event_payload(event)
        if event.get("event_type") == "evidence_added" and payload.get("evidence_id"):
            evidence_by_id[str(payload["evidence_id"])] = payload
        elif event.get("event_type") == "incident_recorded" and payload.get("incident_id"):
            incidents[str(payload["incident_id"])] = {**payload, "recorded_at": event.get("created_at")}

    eligible: list[dict[str, Any]] = []
    pending = 0
    rejected = 0
    quarantined = 0
    for incident_id, incident in incidents.items():
        lesson_domain = str(incident.get("domain") or "general_research")
        if lesson_domain not in {domain, "general_research"}:
            continue
        if not str(incident.get("corrective_action") or "").strip():
            continue
        review = approvals.get(incident_id)
        if not review:
            pending += 1
            continue
        decision = review.get("decision")
        if decision != "approved":
            if decision == "rejected": rejected += 1
            continue
        lesson_domain = str(incident.get("domain") or "general_research")
        linked_evidence = [
            str(x) for x in incident.get("evidence_ids", [])
            if str(x) in evidence_by_id
            and (
                str(evidence_by_id[str(x)].get("domain") or "general_research") == lesson_domain
                or (
                    str(evidence_by_id[str(x)].get("domain") or "general_research") == "general_research"
                    and lesson_domain != "general_research"
                )
            )
        ]
        # A linked record must exist and not be from an unrelated domain.
        if not linked_evidence:
            pending += 1
            continue
        counts = use_counts.get(incident_id, Counter())
        if counts["harmful"] >= 2 and counts["harmful"] > counts["helpful"]:
            quarantined += 1
            continue
        # General lessons are reusable in a specific domain; domain-specific
        # lessons remain isolated from every other domain.
        eligible.append({
            "lesson_id": incident_id,
            "incident_id": incident_id,
            "domain": lesson_domain,
            "symptom": str(incident.get("symptom") or "")[:600],
            "corrective_action": str(incident.get("corrective_action") or "")[:1000],
            "hypothesis": str(incident.get("hypothesis") or "")[:600],
            "evidence_ids": linked_evidence[:10],
            "approved_at": review.get("recorded_at"),
            "approval_note": str(review.get("note") or "")[:400],
            "source_status": "operator_approved; not independently proven",
            "effectiveness": {k: int(counts[k]) for k in ("helpful", "neutral", "harmful")},
            "use_status": "operator feedback indicates possible harm" if counts["harmful"] else "not independently validated in all contexts",
            "_score": (15 if lesson_domain == domain else 4) + 2 * counts["helpful"] - 3 * counts["harmful"] + _timestamp(review.get("recorded_at")) / 1e12,
        })
    eligible.sort(key=lambda x: x["_score"], reverse=True)
    selected = eligible[:limit]
    for row in selected:
        row.pop("_score", None)
    return {
        "schema": SCHEMA,
        "domain": domain,
        "lessons": selected,
        "approved_lesson_count_available": len(eligible),
        "pending_review_count": pending,
        "rejected_lesson_count": rejected,
        "quarantined_pending_review_count": quarantined,
        "limit": limit,
        "mode": "retrieval_guidance_only",
        "model_weights_updated": False,
        "auto_promotion": False,
        "interpretation": "Approved lessons are operator-reviewed prompts, not facts or causal truths. Retrieved guidance must be checked for applicability at every use.",
    }


def build_diagnostics(assurance_events: list[dict[str, Any]], evaluation_records: list[dict[str, Any]], domain: str | None = None) -> dict[str, Any]:
    approvals, use_counts = _review_state(assurance_events)
    incident_rows: dict[str, dict[str, Any]] = {}
    analysis_rows: list[dict[str, Any]] = []
    feedback_by_domain: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for event in assurance_events:
        payload = _event_payload(event)
        kind = event.get("event_type")
        if kind == "incident_recorded" and payload.get("incident_id"):
            incident_rows[str(payload["incident_id"])] = payload
        elif kind == "analysis_linked":
            analysis_rows.append(payload)
    for record in evaluation_records:
        d = str(record.get("domain") or "unknown")
        if domain and d != domain:
            continue
        for feedback in record.get("feedback", []) if isinstance(record.get("feedback"), list) else []:
            if isinstance(feedback, dict) and feedback.get("label") in {"correct", "partly_correct", "incorrect", "not_verifiable"}:
                feedback_by_domain[d].append({"label": feedback["label"], "submitted_at": feedback.get("submitted_at")})

    evidence_by_id = {
        str(_event_payload(e).get("evidence_id")): _event_payload(e)
        for e in assurance_events
        if e.get("event_type") == "evidence_added" and _event_payload(e).get("evidence_id")
    }
    lessons_approved = 0
    pending_review_count = 0
    rejected_lesson_count = 0
    quarantined_pending_review_count = 0
    for incident_id, incident in incident_rows.items():
        incident_domain = str(incident.get("domain") or "general_research")
        if domain is not None and incident_domain not in {domain, "general_research"}:
            continue
        if domain == "general_research" and incident_domain != "general_research":
            continue
        if not str(incident.get("corrective_action") or "").strip():
            continue
        review = approvals.get(incident_id)
        if not review:
            pending_review_count += 1
            continue
        if review.get("decision") == "rejected":
            rejected_lesson_count += 1
            continue
        incident_domain = str(incident.get("domain") or "general_research")
        linked = [
            str(x) for x in incident.get("evidence_ids", [])
            if str(x) in evidence_by_id
            and (
                str(evidence_by_id[str(x)].get("domain") or "general_research") == incident_domain
                or (
                    str(evidence_by_id[str(x)].get("domain") or "general_research") == "general_research"
                    and incident_domain != "general_research"
                )
            )
        ]
        if review.get("decision") == "approved" and linked:
            lessons_approved += 1
            counts = use_counts.get(incident_id, Counter())
            if counts["harmful"] >= 2 and counts["harmful"] > counts["helpful"]:
                quarantined_pending_review_count += 1
        else:
            pending_review_count += 1
    usage_count = 0
    by_domain_usage: Counter[str] = Counter()
    for row in analysis_rows:
        d = str(row.get("domain") or "unknown")
        ids = row.get("lesson_ids_considered") or []
        if not domain or d == domain:
            usage_count += len(ids) if isinstance(ids, list) else 0
            by_domain_usage[d] += len(ids) if isinstance(ids, list) else 0

    feedback_summary = {}
    for d, rows in feedback_by_domain.items():
        counts = Counter(r["label"] for r in rows)
        ordered = sorted(rows, key=lambda r: str(r.get("submitted_at") or ""))
        window = 10
        recent = ordered[-window:]
        prior = ordered[-2 * window:-window]
        negative_labels = {"incorrect", "partly_correct"}
        def neg_rate(group: list[dict[str, Any]]) -> float | None:
            return sum(1 for r in group if r["label"] in negative_labels) / len(group) if group else None
        recent_rate, prior_rate = neg_rate(recent), neg_rate(prior)
        drift = "INSUFFICIENT_FEEDBACK"
        if len(recent) >= 5 and len(prior) >= 5 and recent_rate is not None and prior_rate is not None:
            drift = "OPERATOR_FEEDBACK_DEGRADATION_REVIEW" if recent_rate - prior_rate >= 0.20 else "NO_CLEAR_FEEDBACK_DEGRADATION"
        feedback_summary[d] = {"total_feedback": len(rows), "counts": dict(counts), "recent_n": len(recent), "recent_negative_rate": round(recent_rate, 4) if recent_rate is not None else None,
                               "prior_n": len(prior), "prior_negative_rate": round(prior_rate, 4) if prior_rate is not None else None,
                               "signal": drift, "interpretation": "Subjective operator-feedback diagnostic; not a ground-truth accuracy score."}

    if domain:
        feedback_summary = {domain: feedback_summary.get(domain, {"total_feedback": 0, "counts": {}, "signal": "INSUFFICIENT_FEEDBACK", "interpretation": "No reviewed feedback is available."})}
    selected_analysis = [r for r in analysis_rows if not domain or r.get("domain") == domain]
    return {
        "schema": SCHEMA,
        "domain_filter": domain,
        "assurance_events": len(assurance_events),
        "incidents": len(incident_rows),
        "approved_lesson_count": lessons_approved,
        "pending_review_count": pending_review_count,
        "rejected_lesson_count": rejected_lesson_count,
        "quarantined_pending_review_count": quarantined_pending_review_count,
        "lesson_usage_count_in_linked_analyses": usage_count,
        "analyses_with_memory_ids": sum(1 for r in selected_analysis if r.get("lesson_ids_considered")),
        "operator_feedback": feedback_summary,
        "recent_analysis_trace": [{"evaluation_id": r.get("evaluation_id"), "domain": r.get("domain"), "generated_at": r.get("generated_at"), "lesson_ids_considered": r.get("lesson_ids_considered", []), "lesson_memory_mode": r.get("lesson_memory_mode", "not_recorded")} for r in selected_analysis[-20:]],
        "learning_mode": "retrieval_guidance_only",
        "model_weights_updated": False,
        "automatic_root_cause_discovery": False,
        "automatic_model_promotion": False,
        "safety_note": "This release adapts inference prompts from explicitly approved, evidence-linked operator lessons. It does not fine-tune model weights. Operator feedback is subjective and insufficient feedback is not evidence of success.",
    }
