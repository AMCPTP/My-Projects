# รายงานตรวจสอบเชิงลึกและแก้ไข NEXUS ARC V5.9.2

วันที่ตรวจสอบ: 14 ตุลาคม 2026  
ขอบเขต: ซอร์สโค้ด Python, API models/routes, learning ledger, assurance ledger, Dashboard HTML/JavaScript, calibration/error attribution, regression tests, static checks และ API smoke test

## ข้อสรุปจากการตรวจ

รอบลึกพบข้อผิดพลาดเพิ่มเติมจากรุ่น V5.9.1 ที่มีผลกับความน่าเชื่อถือของวงจรเรียนรู้จริง โดยเฉพาะบทเรียนทั่วไปที่อาจถูกแชร์ข้ามโดเมนอัตโนมัติ, การให้คะแนนบทเรียนโดยไม่ยืนยันว่า evaluation นั้นได้ใช้บทเรียนจริง, ตัวนับ diagnostic ที่อาจยอมรับการรีวิวผิดโดเมน, การ fit calibration ด้วยค่าที่ผ่าน calibration ไปแล้ว และการตั้งรอบ calibration ที่ทำงานทุกผลหลังหน้าต่างข้อมูลเต็ม 240 แถว นอกจากนี้ยังพบกฎวินิจฉัยที่นับการทายถูกในสถานะ `WAIT` เป็น `MISSED-EDGE` ทั้งที่ไม่ใช่ความผิดพลาดของผลด้านนั้น

ผมแก้จุดเหล่านี้ใน **V5.9.2**, เพิ่ม regression tests และทดสอบแพ็กเกจจริงหลังแก้ไข อย่างไรก็ตาม ผลนี้เป็นการตรวจตามโค้ดและกรณีทดสอบที่ระบุ ไม่ใช่การพิสูจน์ว่าระบบสมบูรณ์ทุกสถานการณ์หรือเก่งเหนือกว่าคนในทุกโดเมน

## จุดที่แก้ใน V5.9.2

| ด้าน | จุดอ่อนที่พบ | การแก้ไข |
|---|---|---|
| การเรียนรู้ข้ามโดเมน | บทเรียน `general_research` ถูกนำไปใช้ข้ามโดเมนได้โดยไม่ต้องระบุเจตนา | เปลี่ยนเป็น opt-in ชัดเจนผ่าน `cross_domain_reusable=true` และอนุญาตเฉพาะ incident ใน `general_research`; ค่าเริ่มต้นเป็นปิด |
| การตรวจรีวิว | การรีวิวที่มีโดเมนไม่ตรง incident อาจถูกนับในการดึงบทเรียนหรือ diagnostic | ปฏิเสธการอนุมัติ/นับผลเมื่อโดเมนรีวิวขัดกับโดเมน incident; records เก่าที่ไม่มีฟิลด์ domain ใช้ค่า compatibility จากโดเมน incident |
| การจดจำว่าใช้บทเรียนได้ผลหรือไม่ | ผู้ใช้สามารถให้ feedback โดยไม่ได้พิสูจน์ว่า evaluation อ้างอิงบทเรียนที่ให้คะแนน | ต้องระบุ evaluation ที่มีอยู่จริง อยู่โดเมนเดียวกัน และมี lesson ID ใน `lesson_ids_considered`; กัน feedback ซ้ำสำหรับคู่ lesson/evaluation เดิม |
| ความสมบูรณ์ของ ledger | record ที่มีรูปร่างคล้าย event แต่มี timestamp/type/payload ผิดอาจผ่านบางการตรวจ | เพิ่ม schema validation ของ event type, sequence, ID, timestamp และ payload ที่จำเป็นใน learning และ assurance ledgers |
| Calibration | ใช้ probability หลัง calibration มาเป็น input ฝึก calibration รอบต่อไป ทำให้ตัวปรับเรียนจาก output ของตัวเอง | บันทึก probability ก่อน calibration แยกจาก probability ที่ใช้ประเมินผลจริง แล้ว fit temperature จากค่าก่อน calibration |
| รอบปรับ calibration | ตรวจ `rows.length % 12` ซึ่งหลังเต็ม 240 แถวจะเป็นจริงทุกครั้ง เพราะหน้าต่างถูก cap ที่ 240 | เปลี่ยนไปใช้จำนวนผล P/B ที่ถูกให้คะแนนจริง ปรับทุก 12 ผล ไม่ขึ้นกับความยาว array ที่ถูก cap |
| วินิจฉัยพลาด | หาก action เป็น `WAIT` แต่ผลจริงตรงกับฝั่งที่ probability นำอยู่ ระบบอาจบันทึก `MISSED-EDGE` | ลบกฎที่ตีความผลถูกว่าเป็น miss และเพิ่ม regression assertion ใน self-test |
| เวอร์ชัน/การย้ายข้อมูล | การเปลี่ยนวิธี fit calibration ต้องไม่ปนแถวแบบเก่ากับแบบใหม่ | เปลี่ยน browser learner schema เป็น V5.9.2 และรองรับ Brain export V5.9 สำหรับ migration อย่างควบคุม |

### สิ่งที่เกิดขึ้นเมื่อนำ Brain เก่ามาใช้

เพื่อป้องกันไม่ให้ calibration rows รูปแบบเดิมปนกับรูปแบบใหม่ ประวัติผลยังคงเก็บไว้ แต่ active model weights, contexts, calibration state และ trial/selection state จะกลับค่าเริ่มต้นเมื่อโหลด learner รุ่นเก่า ส่วน cases/errors เดิมจะถูกเก็บไว้โดยทำเครื่องหมายเป็น legacy การเปลี่ยนนี้ตั้งใจให้ลดความเสี่ยงของข้อมูลเรียนรู้ที่ปะปนกัน ควร export Brain สำรองก่อนอัปเกรด

## ผลตรวจสอบหลังแก้ไข

- `python -m unittest -v test_nexus_arc_v5_9_2_regression.py`: **26 test methods ผ่าน** ไม่มี failure/error และมี 4 subtest cases สำหรับ validation ที่ใช้ parameterized inputs
- `python -m pytest -q`: **26 passed, 4 subtests passed**
- Python `py_compile` สำหรับ server, learning, assurance และ regression tests: ผ่าน
- JavaScript inline 9 บล็อก: ผ่าน `node --check` ครบ 9/9
- HTML ID scan: **374 IDs, 374 unique, 0 duplicate**
- ไม่พบ external/path `src` หรือ `href` resource ใน HTML จาก static scan
- API smoke test: `/api/health` และ `/api/meta` ตอบ HTTP 200 และรายงานเวอร์ชัน `5.9.2` ตรงกัน
- ZIP, รายการ SHA-256 และ regression tests ตรวจซ้ำหลังจัดแพ็กเกจ: ผ่าน

การทดสอบเบราว์เซอร์จริงด้าน layout, keyboard, interaction และ accessibility **ยังไม่ได้ผ่านการตรวจ** เนื่องจาก Chromium ในสภาพแวดล้อมนี้ถูกบล็อกด้วย `ERR_BLOCKED_BY_ADMINISTRATOR` การเช็ก syntax ของ JavaScript ไม่ถือว่าแทนการทดสอบหน้าจอจริง

## สิ่งที่ทำงานร่วมกันอย่างไร

เส้นทางที่ควรตรวจเป็นวงจรเดียวกันคือ:

1. **รับข้อมูล/หลักฐาน** — ตรวจ schema, domain, URL และขอบเขต request ก่อนบันทึก
2. **สร้าง forecast/analysis** — เก็บผลที่คาดการณ์ก่อนรู้ outcome; คะแนนจาก heuristic ไม่ใช่ข้อเท็จจริงที่ผ่านการพิสูจน์
3. **บันทึก outcome** — ใช้ผลจริงที่เกิดหลัง forecast และคำนวณ metrics ตาม proper scoring rules สำหรับ probability
4. **วิเคราะห์เหตุผิดพลาด** — เก็บเป็นสมมติฐานที่ตรวจย้อนกลับได้ ไม่ระบุว่าเป็นสาเหตุแท้จริงโดยไม่มีหลักฐาน
5. **บันทึกบทเรียน** — ต้องมีหลักฐาน ลิงก์โดเมน/เหตุการณ์ที่เกี่ยวข้อง และการอนุมัติตามขอบเขต
6. **นำบทเรียนกลับมาใช้** — ดึงเป็น guidance พร้อมสถานะว่าเป็น operator-reviewed ไม่ใช่ข้อเท็จจริงที่พิสูจน์แล้ว; การแบ่งปันข้ามโดเมนต้องอนุญาตชัดเจน
7. **ประเมินผลของบทเรียน** — ผูก feedback กับ evaluation ที่ระบุว่าใช้บทเรียนนั้นจริง และไม่ให้คะแนนซ้ำกับ evaluation เดิม
8. **เปลี่ยนรุ่นระบบ** — รัน regression tests, แยก legacy state และไม่เลื่อน candidate อัตโนมัติโดยไม่มี evaluation ตามเกณฑ์ที่กำหนด

การเชื่อมทุกขั้นเข้าด้วยกันลดโอกาสที่ feedback ลอย ๆ จะย้อนกลับไปเปลี่ยนวิธีวิเคราะห์ แต่ยังไม่ทำให้การเรียนรู้เป็น causal learning โดยอัตโนมัติ

## ประเด็นที่ยังเป็นข้อจำกัดสำคัญ

### 1. ความสามารถวิเคราะห์บาคาร่า / P-B

โมเดลท้องถิ่นยังเป็น heuristic จากลำดับผล P/B, transition, run length และบริบทในประวัติ ไม่ได้ใช้ข้อมูลไพ่ที่ออกแล้ว, burn card, shoe composition หรือ cut-card position ไม่มีหลักฐานจากการทดลองอิสระแบบ prospective ที่ยืนยันว่าโมเดลมี edge เหนือ baseline หรือทำกำไรได้ ดังนั้นห้ามตีความตัวเลข confidence/opportunity หรือการจัดหมวด pattern ว่าเป็นโอกาสชนะจริง

หากต้องการทดสอบความสามารถ ควรบันทึก probability ก่อนผลทุกครั้ง, กำหนด baseline และ holdout ก่อนเริ่ม, ไม่ปรับโมเดลจาก holdout หลังเห็นผล, ทดสอบหลาย shoe/session และรายงาน log loss, Brier score, calibration, sample size และช่วงความไม่แน่นอน การทายถูกต่อเนื่องช่วงสั้นหรือคะแนนย้อนหลังไม่ใช่หลักฐานของ edge

### 2. การเรียนรู้จากความผิดพลาด

ระบบปรับ local weights/calibration และเก็บบทเรียนเชิง rule-based ไม่ใช่ fine-tune โมเดลภาษาหลัก การระบุ `OVERCONFIDENCE`, `CHANGE-MISSED`, `MODEL-MISS` และป้ายอื่นเป็นสมมติฐานตามกฎ ไม่ใช่ causal proof การเปลี่ยนน้ำหนักหลังพลาดไม่ได้รับประกันว่าระบบเข้าใจเหตุผลที่ถูกต้องหรือจะดีขึ้นในสถานการณ์ใหม่

### 3. Calibration ยังเสี่ยง overfit / drift

การ fit ยังใช้ rolling window ของข้อมูลที่นำมาประเมินตัว temperature เอง มีตัวแปรปรับหลักหนึ่งตัวจึงเรียบง่าย แต่ไม่ได้แทน independent calibration holdout และอาจ overfit หรือปรับไม่ทันเมื่อ distribution เปลี่ยน ต้องประเมินผลแยกตามช่วงเวลา/บริบท และดู proper scoring rules กับ calibration metrics ไม่ใช่ดูแค่จำนวนทายถูก

### 4. ความจำ/ความปลอดภัย

Browser localStorage และไฟล์ Brain สามารถแก้ไขได้โดยเจ้าของเครื่อง SHA-256/hash chain ช่วยจับการเปลี่ยนแปลงเมื่อเทียบค่าเดิม แต่ไม่ใช่ลายเซ็นยืนยันผู้สร้าง หากผู้แก้ไขเปลี่ยนข้อมูลและคำนวณ hash ใหม่ได้ การตรวจนี้ยังไม่ได้ทำ penetration test ภายนอก

### 5. Live intelligence

ระบบตรวจเฉพาะ feed ที่ตั้งค่าและแหล่งข้อมูลที่เข้าถึงได้ในคำขอนั้น ๆ ไม่ได้รู้ทันทุกเหตุการณ์ทั่วโลก การตรวจนี้ไม่มี production API key หรือ live feeds จึงยืนยันความสดของข้อมูลจริงหรือคุณภาพคำตอบจาก provider ไม่ได้

## การเก็บ/ตัดส่วน

ผมเอา report/checksum เก่าที่จะขัดแย้งกับไฟล์ V5.9.2 และ cache folders ออกจาก release archive แล้ว ไม่พบ runtime module ที่พิสูจน์ได้ว่าไม่มี caller หรือไม่มีการใช้งาน จึงไม่ลบโมดูล Python/JavaScript ที่เซิร์ฟเวอร์หรือ Dashboard เรียกอยู่ เพียงเพื่อลดจำนวนไฟล์ เพราะอาจทำให้เส้นทาง API หรือ ledger เสีย

## คำตัดสิน

V5.9.2 แก้จุดบกพร่องที่ทดสอบซ้ำได้ในเรื่องการแชร์บทเรียนข้ามโดเมน การให้คะแนนบทเรียนโดยไม่มี provenance, ความสอดคล้องของ ledger, calibration และ error attribution ได้จริง แต่ **ยังไม่ควรเรียกว่าระบบสมบูรณ์ เก่งทุกรูปแบบ หรือรู้ทันทุกเหตุการณ์** ผลทดสอบเป็นหลักฐานของกฎเฉพาะที่ผ่านเท่านั้น ไม่ใช่หลักฐานความฉลาดทั่วไปหรือความสามารถทำกำไร

เกณฑ์ที่ควรยึดไว้คือ: ถ้าหลักฐานไม่พอ ระบบต้องบอกว่าไม่พอ; ถ้า forecast ไม่พร้อมต้องยอม `WAIT`; ถ้าบทเรียนยังไม่ถูกพิสูจน์ต้องแสดงสถานะอย่างตรงไปตรงมา; และห้ามนำผลทดสอบที่ใช้ในการปรับโมเดลกลับมาอ้างเป็นการทดสอบอิสระ

## วิธีรันทดสอบซ้ำ

```bash
python -m pip install -r requirements.txt
python -m unittest -v test_nexus_arc_v5_9_2_regression.py
```

ดูรายงานย่อเพิ่มเติมใน `NEXUS_ARC_V5_9_TEST_REPORT.txt`, `NEXUS_ARC_V5_9_AUDIT_FINDINGS.txt` และ `NEXUS_ARC_V5_9_CHANGELOG.txt` ภายใน ZIP.
