NEXUS ARC V5.9.2 — CONTEXT ISOLATION RUNTIME BUNDLE
==================================================

PURPOSE
This package is a local analysis, audit, learning-ledger and configured-feed monitoring workspace. V5.9.2 strengthens lesson scope, evaluation feedback provenance, ledger schema checks and the browser-side calibration/error-diagnosis loop. These changes reduce specific classes of contamination and bookkeeping errors; they do not make the system universally intelligent or prove a prediction edge.

INSTALL / RUN (Windows)
1. Extract this archive to a folder you control.
2. Install Python 3.11+ if not present.
3. Open a terminal in the extracted folder and run: py -3 -m pip install -r requirements.txt
4. Copy .env.example to .env and configure OPENAI_API_KEY and NEXUS_MODEL only if you want the optional server-side LLM analysis function. Never share .env or API keys.
5. Run start_nexus_arc_v5_9.bat. The gateway binds to 127.0.0.1 by default.
6. Open http://127.0.0.1:8787/ in a browser.

REGRESSION TESTS
With dependencies installed, run:
  python -m unittest -v test_nexus_arc_v5_9_2_regression.py
The included reproducible suite contains 26 test methods, with four additional subtest cases from parameterized validation. It covers domain isolation, explicit cross-domain lesson reuse, evaluation/lesson provenance, duplicate feedback, ledger schema and hash integrity, streamed request-body limits, holdout reuse, URL canonicalization, browser-side calibration invariants and correct handling of WAIT forecasts.

DATA / MIGRATION / RESET SCOPE
- Local P/B history, its learner state and local events are stored in browser localStorage when available. That storage is editable and is not a secure vault; periodically use Export Brain for backups.
- If browser persistence fails, the UI indicates MEMORY ONLY. Such changes are lost when the tab/process is closed unless exported.
- Dashboard reset clears local browser history/Brain/events only. Server-side learning and assurance ledgers are separate and are not silently erased by that button.
- V5.9.2 intentionally versions the browser learner schema because the calibration-learning inputs changed. On loading an older V5.9 browser learner, history remains, old cases/errors are kept as legacy records, and active weights/context/calibration/trial-selection state resets to defaults. Export a backup before upgrading. Older V5.9 Brain files remain importable for controlled migration.
- Browser SHA-256 Brain checksums detect unintended alteration relative to the checksum field; they do not authenticate the author or prove imported content is true.

ANALYSIS / LEARNING LIMITS
- The local baccarat module is a heuristic sequence model. It is not a card-counting/shoe-composition model and is not a validated way to predict the next result or earn profit. Forecasts and normalized regime scores are diagnostics, not betting signals.
- Learning adjusts local expert/context weights and calibration from recorded outcomes. Calibration is now fit against pre-calibration probabilities and scheduled by scored outcome count. This fixes a self-referential calibration input and a capped-window cadence bug; it does not prove future forecasts improve.
- Error diagnoses remain rule-based hypotheses, not causal proof. “Remembering” an error or changing a weight does not prove the system correctly understood why an error occurred.
- Cross-domain lesson sharing is off by default. To share a general_research lesson with another domain, an operator must explicitly opt in; reviews must be scope-compatible and effectiveness feedback must reference an evaluation that actually considered the lesson.
- Candidate comparison cannot auto-promote an active profile. Holdouts should be independently defined, fresh, and recorded before reviewing results.
- The eight-deck reference is an initial-shoe P/B probability conditional on a non-Tie result, not adjusted for dealt cards or table-specific conditions.
- External event feeds are monitor-only for the local P/B estimator. General analysis covers only available/configured sources for a specific request; exhaustive worldwide awareness is not possible.
- Mutating API request bodies are limited to 1 MiB even when streamed without a Content-Length header. The feed fetcher includes DNS/public-IP and redirect checks and size/time bounds. These controls reduce risk; they are not a security certification or full penetration test.

VERIFICATION
- See NEXUS_ARC_V5_9_3_AUDIT_REPORT.md, NEXUS_ARC_V5_9_TEST_REPORT.txt, NEXUS_ARC_V5_9_AUDIT_FINDINGS.txt and NEXUS_ARC_V5_9_CHANGELOG.txt.
- SHA-256 checksums for package files are listed in NEXUS_ARC_V5_9_2_SHA256SUMS.txt. That checksum file does not checksum itself; verify the archive separately if an independently supplied archive hash is provided.
- The predecessor's report claimed 73 tests passed, but its corresponding original test source was not included in the supplied archive and could not be independently reproduced. Do not treat that historical figure as a V5.9.2 result.
- Python compile checks, the included regression suite, Node JavaScript syntax checks, HTML ID scan and API smoke tests passed in this audit run. A real-browser visual/accessibility run was blocked by the audit environment browser policy (`ERR_BLOCKED_BY_ADMINISTRATOR`).

V5.9.3 follow-up security patch: mutation endpoints now require a localhost/127.0.0.1 Host, including requests with no Origin header. Dashboard Brain schema remains V5.9.2 for compatibility. See NEXUS_ARC_V5_9_3_AUDIT_REPORT.md.
