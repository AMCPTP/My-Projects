# NEXUS ARC V5.9.4 — Cluster-Aware Prospective Evaluation Audit

Date: 2026-10-14  
Scope: runtime source, prospective learning ledger, API model/route, paired model comparison, regression suite, dashboard static checks, release packaging.

## Change rationale

In baccarat and other sequential settings, multiple observations from one shoe/session can be dependent. The earlier paired comparison bootstrap sampled individual hands as if each row were independent. That can produce overly narrow intervals and overstate the strength of evidence when hands share a common shoe/session context.

## Implemented

- Added optional `cluster_id` to forecast requests and stored forecast records.
- Enforced that forecasts for the same `event_key` agree on `cluster_id`.
- When every matched champion/challenger observation has a consistent declared cluster ID, paired log-loss intervals resample whole clusters, retaining within-cluster rows together.
- When cluster IDs are absent, the fallback remains row-wise but now explicitly warns that it assumes independent rows and may understate uncertainty for clustered data.
- For `sequence_pbt`, comparison review eligibility is blocked unless there are at least 60 matched cases, at least 20 distinct matched clusters, a paired log-loss interval fully below zero, and non-worse Brier difference. This is a screening gate only; it does not prove an edge.
- Kept the dashboard Brain schema at V5.9.2 to avoid forcing an unrelated local-state migration. Updated server/API release version and visible dashboard release branding to V5.9.4.

## Verification results

- `python -m unittest -v test_nexus_arc_v5_9_4_regression.py`: **34 tests passed**.
- `python -m pytest -q test_nexus_arc_v5_9_4_regression.py`: **34 passed, 4 subtests passed**.
- Python `py_compile` for server, learning, assurance, and regression test modules: passed.
- Inline JavaScript syntax checks with `node --check`: **9/9 blocks passed**.
- HTML ID scan: **374 IDs, 374 unique, 0 duplicates**.
- API test confirms `/api/meta` reports `5.9.4` and the forecast endpoint persists `cluster_id`.
- Regression test confirms 60 matched P/B/T cases across only 10 declared clusters are blocked as `NOT_ENOUGH_INDEPENDENT_CLUSTERS`.

These are local automated checks. Browser layout/keyboard/accessibility testing and independent security penetration testing were not performed in this release pass.

## Limitations and truth conditions

- `cluster_id` is operator-supplied. The application does not independently verify shoe/session identity or detect dishonest grouping.
- The 20-cluster minimum is a conservative review floor, not a universal statistical guarantee. Cluster bootstrap remains exploratory, particularly with few or highly heterogeneous clusters.
- No actual baccarat shoe/card-composition data or independently verified outcome feed was provided. The release has not demonstrated predictive advantage or profitability.
- Baccarat road patterns remain descriptive unless prospective, independent, repeatable evaluation establishes otherwise. The system must not describe its gate as a betting signal or claim it can reliably predict the next hand.
- Hash chaining is tamper-evident but is not a digital signature and cannot prove who entered a record or whether an operator-entered outcome is true.

## Recommended use

Record forecasts before the outcome, use a consistent shoe/session `cluster_id` for every model evaluated on a given hand, record outcomes once, and reserve genuinely unseen sessions for evaluation. Do not tune against the final holdout and then report it as independent. Report log loss, Brier score, calibration, cluster count, matched sample size, and uncertainty together.
