NEXUS ARC V5.9.4 — Cluster-Aware Prospective Evaluation

Contents
- nexus_arc_v5_9_server.py: localhost FastAPI backend (version 5.9.4)
- nexus_arc_v4_8_learning.py: prospective forecast ledger and scoring
- nexus_arc_v4_9_assurance.py: assurance/evidence/experiment ledger
- nexus_arc_v5_learning.py: domain-scoped lesson retrieval and diagnostics
- NEXUS_ARC_V5_9_4_CLUSTER_AWARE_DESK.html: browser dashboard
- test_nexus_arc_v5_9_4_regression.py: regression tests
- requirements.txt, .env.example, start script, changelog and audit/test notes

Install/run
1. Install Python 3.11+ (recommended) and dependencies: `python -m pip install -r requirements.txt`
2. Copy `.env.example` to `.env` only if needed; keep API keys private.
3. Run `python -m unittest -v test_nexus_arc_v5_9_4_regression.py`.
4. Start using `start_nexus_arc_v5_9.bat` on Windows or run `uvicorn nexus_arc_v5_9_server:app --host 127.0.0.1 --port 8765`.
5. Open http://127.0.0.1:8787 (default `NEXUS_PORT=8787`). If you start Uvicorn manually with `--port 8765`, open http://127.0.0.1:8765.

Cluster-aware evaluation
- Prospective forecast API accepts optional `cluster_id` (1–120 characters using letters, digits, dot, underscore, colon, hyphen).
- Use a consistent cluster ID for all models on the same event; for baccarat P/B/T, identify the shoe/session, not the hand.
- When matched forecasts have consistent cluster IDs, paired comparison uncertainty resamples whole clusters.
- For sequence_pbt, review eligibility is blocked below 20 distinct matched clusters and the existing 60 matched cases.
- The ID is user-entered and not verified. A threshold is not evidence of a real edge.

Important
Baccarat road patterns are descriptive. This software does not receive hidden cards or necessarily know shoe composition, burn cards, or cut-card position. No guarantee of next-hand prediction or profitability. Do not interpret gate status as a betting signal. A hash chain is tamper-evident, not a digital signature.

Compatibility
The dashboard learner's internal Brain schema remains V5.9.2 to preserve compatibility with existing local data. Server/API version is V5.9.4.
