# NEXUS ARC V5.9.5 — Pattern Audit + Prospective WAIT Guard

**Release date:** 2026-10-15  
**Scope:** pattern classifier, retrospective walk-forward audit, separate prospective pattern ledger, browser dashboard integration, existing API/learning/assurance code carried forward from V5.9.4, automated tests, static checks and release integrity.

## Verdict

V5.9.5 makes pattern interpretation and retrospective evaluation more explicit and adds a separate prospective record of predictions locked before the next non-Tie result. It does **not** establish that baccarat patterns predict the next hand. The primary action remains **WAIT**; no bet recommendation or expected-value claim is produced by the new pattern module.

## Changes

- Added deterministic descriptive classes for four-result alternation, two-by-two blocks, streak of at least three, a terminal double, mixed/other and insufficient history. Descriptions explicitly avoid claiming that a pattern must continue or reverse.
- Added a walk-forward replay. A forecast at row `i` uses only outcomes before `i` and updates its pattern counts after scoring the target. Tie is excluded from conditional P/B scoring. The replay reports per-pattern sample counts, log loss, Brier score and accuracy against a fixed reference baseline.
- Added a separate prospective browser ledger. Forecast records include user-entered session/shoe ID, version, pre-outcome history snapshot, class, probabilities and timestamp. Only one record can be pending at once. Tie does not settle the conditional forecast. A changed/reset history prefix cancels it rather than awarding a score.
- Pattern-conditioned probabilities can use only completed observations from other user-labelled sessions, after at least 30 matching observations across 10 other sessions. Otherwise the module falls back to a rounded eight-deck initial-shoe reference conditional on non-Tie and labels the state `WAIT`.
- Added session-cluster bootstrap intervals and a stricter review screen (at least 100 completed forecasts over 20 distinct labelled sessions, with upper 95% cluster-bootstrap bounds below zero for both log-loss and Brier deltas) that can only nominate independent replication; it cannot promote or authorize betting.
- Held the dashboard's visible action at `WAIT · VALIDATION REQUIRED` because a descriptive road-pattern score or in-sample retrospective result is not validated predictive edge.
- Kept the existing V5.9.4 API/learning/assurance files and legacy Brain schema for compatibility; the new pattern ledger has a separate storage key/schema.

## Verification performed

- JavaScript pattern-engine tests: **15 passed** using `node test_nexus_arc_v5_9_5_pattern_engine.js`.
- Existing API/assurance/dashboard regression suite: **36 passed** using `python -m unittest -q test_nexus_arc_v5_9_5_regression.py`.
- Python `py_compile` for server, learning, assurance and regression modules: passed.
- Node syntax check for the new pattern engine: passed.
- Syntax check of all nonempty inline JavaScript blocks in the HTML: passed (**11 inline script blocks found; all nonempty blocks parsed successfully**).
- HTML structure scan: **399 IDs, all unique**.
- Release archive integrity: to be verified by the release build step and recorded in the external SHA-256 file.

Browser-rendering, keyboard/accessibility, cross-browser storage and security penetration tests have **not** been completed in this pass. Automated unit tests are not an assessment of predictive performance.

## Interpretation limits and known risks

1. **No verified real-data edge.** No independent real baccarat dataset or externally attested outcome feed was provided. The test suite proves code behaviours, not prediction accuracy, net returns or profitability.
2. **Historical input has no verified shoe boundaries or immutable capture time.** Walk-forward scoring prevents direct target-row leakage in the function, but replaying a user-provided history is still exploratory; the sequence bootstrap is not shoe-clustered.
3. **Prospective records are browser-local and user-editable.** Local timestamps and manually entered session IDs are not independently attested. Cluster intervals are only as trustworthy as the supplied session labels.
4. **Reference probabilities are not card-removal tracking.** The baseline represents a rounded initial eight-deck probability conditional on a non-Tie result; it does not inspect remaining cards, burn cards, cut-card location or the actual shoe.
5. **Selection bias remains possible.** Fixed pattern definitions reduce discretionary relabelling, but patterns and gates can still be chosen after looking at the same sequence. A sealed future holdout and independent replication are required.
6. **Candidate status is not a betting signal.** Even if a future ledger passes its screening criteria, the system must remain `WAIT` until a pre-registered, sealed holdout and independent replication support the claim. Tests do not justify increasing stakes.

## Recommended usage

Keep the dashboard HTML and `nexus_arc_v5_9_5_pattern_engine.js` together in the same directory. Enter a consistent unique shoe/session ID before locking every prospective forecast. Lock forecasts before the outcome; do not edit them after the fact. Export backups regularly. Do not merge cancelled forecasts into scored results. Reserve future sessions that are not used to tune or choose patterns for independent replication.
