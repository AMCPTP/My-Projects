NEXUS ARC V5.9.5 — Pattern Audit + Prospective WAIT Guard

PURPOSE
This release adds an auditable pattern-analysis layer to the existing NEXUS ARC V5.9.4 application. It classifies common sequence shapes, evaluates them walk-forward against a fixed reference baseline, and records prospective forecasts separately. It does NOT establish that baccarat patterns predict future outcomes.

CONTENTS
- NEXUS_ARC_V5_9_5_PATTERN_AUDIT_DESK.html: integrated browser dashboard
- nexus_arc_v5_9_5_pattern_engine.js: pattern classification, walk-forward scoring and prospective ledger engine (must remain beside the HTML file)
- nexus_arc_v5_9_server.py: localhost FastAPI backend (API version 5.9.5)
- nexus_arc_v4_8_learning.py: prospective forecast ledger and scoring
- nexus_arc_v4_9_assurance.py: assurance/evidence/experiment ledger
- nexus_arc_v5_learning.py: domain-scoped lesson retrieval and diagnostics
- test_nexus_arc_v5_9_5_regression.py: existing API/assurance/dashboard regression tests
- test_nexus_arc_v5_9_5_pattern_engine.js: new pattern-engine regression tests
- requirements.txt, .env.example, start_nexus_arc_v5_9.bat, changelog, audit/test reports, SHA-256 manifest

INSTALL / RUN
1. Use Python 3.11+ and install dependencies: `python -m pip install -r requirements.txt`.
2. Keep the HTML and `nexus_arc_v5_9_5_pattern_engine.js` in the same directory.
3. Run `python -m unittest -v test_nexus_arc_v5_9_5_regression.py`.
4. Run `node test_nexus_arc_v5_9_5_pattern_engine.js`.
5. On Windows, launch `start_nexus_arc_v5_9.bat`; the local dashboard defaults to http://127.0.0.1:8787. The server binds to loopback under its default configuration.

PATTERN ANALYSIS
- Pattern classes: four-result alternation, two-by-two blocks, streak of at least three, simple double, and mixed/other.
- Historical walk-forward: after a 12-result warm-up, each forecast is formed using only prior outcomes associated with that pattern class; its target result is added only after scoring. Tie is excluded from the conditional P/B outcome stream.
- The reference baseline is the existing application's rounded eight-deck initial-shoe P/B distribution conditional on non-Tie. It is not card-removal tracking and does not fit every table/shoe.
- The prospective estimator can use resolved examples of the same pattern only from other user-labelled sessions, and only after at least 30 pattern examples across at least 10 sessions. Otherwise it falls back to the reference distribution and declares WAIT.
- Prospective review requires at least 100 scored forecasts across at least 20 distinct user-labelled sessions, with both session-cluster bootstrap upper confidence bounds below zero. Meeting the screen only nominates the model for independent replication; auto-promotion is disabled.
- The visible top-level action is held at WAIT until predictive edge is established with prospective data, a sealed independent holdout, and separate replication. Probability, accuracy, confidence, and pattern name are not a betting signal or guarantee.

DATA / LIMITATIONS
- Session/shoe identifiers are manually entered and not verified independently.
- The historical sequence does not carry trustworthy shoe/session boundaries, so its moving-block intervals are exploratory and not session-clustered.
- Prospective pattern ledger is in browser localStorage, editable by the user and not server-timestamped or cryptographically chained. Export backups regularly.
- The app does not know hidden cards, burn cards, cut-card position, or actual remaining shoe composition unless separately supplied; this release does not add those data sources.
- No real-world baccarat dataset or verified outcome feed was supplied for this build. Software tests validate implementation behaviour, not prediction accuracy or profitability.

COMPATIBILITY
Legacy browser Brain schema remains V5.9.2 to avoid a destructive data migration. Server/API release metadata is V5.9.5. The added pattern prospective ledger uses its own isolated schema and localStorage key.
