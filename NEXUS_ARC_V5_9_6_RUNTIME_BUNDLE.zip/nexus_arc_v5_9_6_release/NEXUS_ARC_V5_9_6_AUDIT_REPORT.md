# NEXUS ARC V5.9.6 — Technical Audit Report

**Release goal:** prevent a pending prospective pattern forecast from being evaluated against a newly imported Brain history.

## Change reviewed

The previous V5.9.5 integration stored prospective pattern forecasts in a separate localStorage ledger. A Brain import replaced `history` and learner state, but the import transaction did not explicitly invalidate a pending pattern-ledger forecast first. The ledger's history observer would usually cancel the pending record when the incoming history differed from the saved prefix; however, reliance on prefix comparison alone is unsafe when a new Brain shares an initial sequence with the old one.

V5.9.6 adds `prepareBrainImport()` to the pattern-ledger integration. Once a Brain passes parsing, schema/checksum, history, and event validation—but before `history=safeHistory`—it snapshots the prospective ledger and cancels any pending record with `brain_import_replaced_history`. The record stays in the ledger as `CANCELLED` and is not scored. If the app's Brain save fails, the import transaction rolls back the in-memory app state and tries to restore the ledger snapshot. A corrupt/blocked ledger fails closed rather than being silently overwritten.

## Compatibility boundaries

- App/API release metadata: **5.9.6**.
- Existing learner Brain data schema: **NEXUS-ARC-V5.9.2-CONTEXT-ISOLATION-INTEGRITY** (kept deliberately; this is not the app release version).
- Prospective pattern-ledger storage schema remains **nexus-arc-v5.9.5-pattern-audit-ledger-v1** because the record layout is unchanged.
- The release package contains the three-file export audit summary, but not the user's original Brain JSONs.

## Validation

- Python API/assurance/dashboard regression tests include a root-route smoke test and import-guard ordering/rollback checks.
- Dedicated JavaScript tests exercise no-op, cancellation without scoring, rollback, committed import, and corrupt-ledger refusal.
- The existing V5.9.5 pattern engine test suite is retained unchanged.
- All embedded browser JavaScript blocks are syntax-checked separately; this is not a full real-browser interaction test.
- Brain exports are checked against the application's canonical SHA-256 convention and scored from saved case probabilities.

## Findings from the three uploaded Brain exports

See `NEXUS_ARC_V5_9_6_BRAIN_EXPORT_AUDIT.md` and the corresponding CSV. All three embedded checksums verify and all saved `actual` labels match `history[at]`. Yet the files have no shoe/session/cluster IDs, no formal evaluation/promotion trials, and no T outcomes. Per-export Log Loss and Brier scores are worse than the uniform 50/50 diagnostic baseline. The samples are small and their independence is unknown; no predictive edge is established, and weights were not merged automatically.

## Remaining limitations

- Browser localStorage is editable and not independently timestamped.
- Session IDs are entered by the operator; the release cannot independently verify that two IDs represent different real shoes.
- The imported V5.9.2 cases are historical records, not an attested prospective ledger.
- No claim of baccarat prediction edge or profitability is supported. The primary action remains WAIT pending prospective, session-clustered validation and independent replication.
