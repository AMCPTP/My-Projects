NEXUS ARC V5.9.6 — Brain Import Context Guard + Pattern Audit

PURPOSE
This is a maintenance release on the V5.9.5 Pattern Audit application. It fixes a context-boundary hazard: a pending prospective pattern forecast is now cancelled before an imported Brain snapshot replaces the active history, so a result already present in the imported history cannot accidentally resolve an old pending forecast. If import fails, the previous app state is restored and the pattern-ledger snapshot is rolled back when possible.

CONTENTS
- NEXUS_ARC_V5_9_6_PATTERN_AUDIT_DESK.html: integrated browser dashboard
- nexus_arc_v5_9_5_pattern_engine.js: unchanged V5.9.5 pattern/ledger schema and engine (must remain beside HTML)
- nexus_arc_v5_9_server.py: localhost FastAPI backend (API version 5.9.6)
- test_nexus_arc_v5_9_6_regression.py: API/assurance/dashboard regression tests, including the import-context fix
- test_nexus_arc_v5_9_5_pattern_engine.js: regression tests for the unchanged V5.9.5 pattern engine
- test_nexus_arc_v5_9_6_brain_import_guard.js: dynamic tests for pending-forecast cancellation, rollback, and corrupt-ledger refusal
- NEXUS_ARC_V5_9_6_BRAIN_EXPORT_AUDIT.md: measurements from the three user-supplied Brain exports
- NEXUS_ARC_V5_9_6_BRAIN_EXPORT_METRICS.csv: machine-readable audit summary; no raw Brain exports included
- verify_brain_checksums.js: optional checksum verifier matching the app's Brain canonicalization
- requirements.txt, .env.example, start_nexus_arc_v5_9.bat, changelog, audit/test reports, SHA-256 manifest

INSTALL / RUN
1. Use Python 3.11+ and install dependencies: `python -m pip install -r requirements.txt`.
2. Keep the HTML and `nexus_arc_v5_9_5_pattern_engine.js` in the same directory.
3. Run `python -m unittest -v test_nexus_arc_v5_9_6_regression.py`.
4. Run `node test_nexus_arc_v5_9_5_pattern_engine.js`.
5. Run `node test_nexus_arc_v5_9_6_brain_import_guard.js`.
6. On Windows, launch `start_nexus_arc_v5_9.bat`; the local dashboard defaults to http://127.0.0.1:8787. The server binds to loopback under its default configuration.
7. To verify Brain files with the same checksum canonicalization as the browser, run `node verify_brain_checksums.js path\to\Brain1.json path\to\Brain2.json ...`.

BRAIN COMPATIBILITY / IMPORT SAFETY
- The UI/API release version is V5.9.6. The existing learner Brain schema remains `NEXUS-ARC-V5.9.2-CONTEXT-ISOLATION-INTEGRITY` intentionally to preserve compatible migration behavior; this is a data-schema version, not the app release number.
- The separate prospective pattern ledger remains schema `nexus-arc-v5.9.5-pattern-audit-ledger-v1`; the schema was not changed because its record layout is unchanged.
- A valid Brain import cancels any pending prospective pattern forecast before swapping histories. The record remains in the pattern ledger with status CANCELLED and is never scored against the imported history. On a failed Brain import, the transaction attempts to restore the prior prospective ledger snapshot.
- These exports are snapshots. Importing one replaces the current history and learner; importing multiple in sequence does not merge their data.

PATTERN ANALYSIS SAFEGUARDS
- Pattern classes: four-result alternation, two-by-two blocks, streak of at least three, simple double, and mixed/other.
- Historical walk-forward evaluation uses only prior outcomes, excludes Tie from conditional P/B targets, and is exploratory; historic input lacks trusted shoe boundaries.
- Prospective forecasts require a user-entered shoe/session ID and are locked before the next non-Tie P/B outcome. IDs are not independently verified.
- Review requires at least 100 scored forecasts across at least 20 distinct sessions and both session-cluster bootstrap upper confidence bounds below zero before nomination for independent replication. No automatic promotion or betting signal.
- The dashboard remains WAIT and does not claim predictive edge or profitability.

BRAIN AUDIT FINDINGS
The three supplied files have valid embedded SHA-256 checksums and internally consistent case indexes, but no session/shoe/cluster IDs, no formal evaluation/trial ledger, and no T results. Their per-export log loss (0.7127, 0.7115, 0.7419) and Brier sum (0.5176, 0.5170, 0.5473) are worse than a uniform 50/50 diagnostic baseline (0.6931 and 0.5000 respectively). Samples are small and are not evidence of a definitive loss of skill, but they do not support a predictive-edge claim. See NEXUS_ARC_V5_9_6_BRAIN_EXPORT_AUDIT.md.

