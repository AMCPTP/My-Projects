# NEXUS ARC V5.9.7 — Startup/Version Mismatch Audit

## Reported symptom
Opening `http://127.0.0.1:8787` displayed V5.9.4 after a newer bundle was available.

## Root-cause assessment
Inspection of the V5.9.6 package shows that its backend default points to `NEXUS_ARC_V5_9_6_PATTERN_AUDIT_DESK.html`, the API version is `5.9.6`, and its batch launcher sets `NEXUS_DASHBOARD_PATH` to that exact file. Therefore the package's normal fresh-start configuration is not configured to serve V5.9.4. The most likely explanation is that the older Python server was already listening on port 8787, or the user launched the server from the older installation directory. A browser address alone cannot distinguish which local process owns the port.

## Fix
- Launcher checks `/api/health` for both `version` and `dashboard`.
- Known NEXUS listeners are restarted from the current folder if their reported release is stale.
- Unrecognized listeners are never terminated automatically.
- API health includes `dashboard_path`; the root HTML response includes no-cache headers and app-version header.
- A unique query parameter is used when opening the page, avoiding reuse of a cached document URL.
- Upgrade documentation advises extracting over the existing folder after backing up `.env`, local data, and Brain exports; extracting elsewhere can select a different default data directory.

## Validation
The packaged Python/JavaScript suites are carried forward and run during build. A regression check verifies API version `5.9.7` and the expected dashboard filename. Static tests inspect the launcher safety conditions. This Linux environment cannot validate Windows PowerShell process management end-to-end, so the report does not claim a native Windows runtime test.

## Remaining limitation
A stale process owned by another account, missing command-line metadata, or an unrelated application on the port will not be forcibly stopped. The launcher will report the conflict. Check `http://127.0.0.1:8787/api/health`: expected `version` is `5.9.7`, `dashboard` is `NEXUS_ARC_V5_9_7_PATTERN_AUDIT_DESK.html`.
