NEXUS ARC V5.9.7 — Stale-Server Launch Guard

WHY THIS PATCH EXISTS
If http://127.0.0.1:8787 still showed V5.9.4 after extracting a newer package, an older NEXUS process was likely still listening on port 8787. Starting a second server on the same port cannot replace the process already serving requests. The old V5.9.6 batch launcher did not diagnose or safely replace that stale listener.

WHAT CHANGED
- The Windows launcher now checks both /api/health version and the exact dashboard filename before opening the browser.
- If an older NEXUS server is listening on the chosen port, the launcher stops only a process whose command line identifies nexus_arc_v5_9_server.py, then starts the release in this directory.
- If an unrelated process owns the port, the launcher does NOT kill it; it reports the conflict.
- The server health response includes dashboard_path and the HTML route sends no-cache headers, reducing stale-browser surprises.
- The app/API release version is 5.9.7. The learner Brain schema V5.9.2 and prospective-pattern ledger schema V5.9.5 remain unchanged for compatibility.

SAFE UPGRADE (WINDOWS)
1. Back up the whole current NEXUS folder, including .env and the nexus_v5_0_data directory if present. Export your Brain as a separate backup too.
2. Extract this ZIP directly INTO THE EXISTING NEXUS INSTALLATION FOLDER and choose to overwrite matching application files. This ZIP stores files at its root for that purpose. Do not delete .env or existing data folders. (Extracting into a different folder creates a separate default data directory unless NEXUS_DATA_DIR is explicitly pointed at the existing data directory.)
3. Double-click start_nexus_arc_v5_9.bat from that folder. It checks the running server version and dashboard name, then opens the browser only after the API confirms V5.9.7.
4. The browser URL remains http://127.0.0.1:8787 by default. If you customized NEXUS_PORT in .env, the launcher uses that port.
5. For manual diagnosis, open http://127.0.0.1:8787/api/health and confirm version is "5.9.7" and dashboard is "NEXUS_ARC_V5_9_7_PATTERN_AUDIT_DESK.html".

PYTHON / TESTS
- Python 3.11+ and the packages in requirements.txt are required.
- Run: py -3 -m pip install -r requirements.txt
- Run: py -3 -m unittest -v test_nexus_arc_v5_9_7_regression.py
- Run: node test_nexus_arc_v5_9_5_pattern_engine.js
- Run: node test_nexus_arc_v5_9_7_brain_import_guard.js

SAFETY
The launcher will not terminate a process whose command line does not identify the NEXUS server script. If the process is unrelated, stop it yourself or select a different NEXUS_PORT. The Windows PowerShell process-management path requires Windows PowerShell and permission to query process metadata. The packaged launcher was statically reviewed and guarded by tests, but this environment cannot execute it on the user's Windows machine; follow the /api/health check to verify the active service after launch.

PREDICTION LIMITATIONS
The app remains WAIT and does not claim a proven predictive edge or profitability. The Brain exports previously audited remain small, lack verified shoe/session IDs, and scored worse than the uniform 50/50 diagnostic baseline on Log Loss and Brier Score.
