# NEXUS ARC V5.9.8 — Analyst Reasoning Audit

## Objective
Extend the missing analysis layer without turning descriptive baccarat road patterns into an unsupported prediction engine.

## Implemented reasoning layers
1. Input hygiene and separated P/B/T counts; Tie is reported independently and excluded from conditional P/B sequence metrics.
2. Multi-label detection: 4/6 alternation, 2-2 block, current run/double/long streak, and suffix run-shapes 1-2, 1-3, 2-1-2, 3-1, 2-2.
3. Run profile: current run, maximum run, mean run length and run count.
4. Multiscale windows: 6/12/20 non-Tie outcomes, P/B share, flip rate and maximum run.
5. Observed first-order transition counts P→P/P→B/B→P/B→B, with sample size and descriptive row-level Wilson intervals.
6. Candidate shift check comparing the last 8 P/B outcomes against the preceding 8. A difference ≥25 percentage points triggers only SHIFT_CANDIDATE, not a regime claim or forecast.
7. Historical suffix recurrence search for 2–5-result sequences; only past followers before the current suffix are counted. These data are overlapping, same-sequence observations and are explicitly descriptive-only.
8. A mandatory WAIT forecast assessment. The engine does not update next-hand probabilities based on roadmap motifs.

## Important interpretation boundaries
- The fresh-shoe 8-deck reference P=49.3176%, B=50.6824% is provided as a baseline reference conditional on a non-Tie, not as a shoe-current estimate.
- Result history P/B/T cannot recover the remaining cards' ranks/suits. Exact shoe-conditioned probability or card-counting is not present.
- Wilson intervals are descriptive row-level intervals, not shoe-clustered inference.
- Same-history suffix rates are subject to selection bias, overlap, small sample size, and dependence.
- The three Brain exports previously examined do not contain independently verified shoe/session IDs in the prospective record metadata and previously scored worse than the uniform 50/50 diagnostic baseline on Log Loss/Brier. This release does not promote those weights.

## Integration finding fixed in this release
The dashboard loads its pattern and analyst engines as relative JavaScript assets. The prior backend had no route to serve root-level static assets, which could cause a visible HTML page while the client engine requests returned 404. V5.9.8 adds an exact allowlist for the two named JavaScript modules, sends no-cache/version headers, and rejects unlisted root assets. API tests now verify both engine files return 200 and an unlisted asset returns 404.

## Validation
See NEXUS_ARC_V5_9_8_TEST_REPORT.txt for actual run results. Browser-based visual/interaction tests and native Windows PowerShell process-control were not executed in this Linux environment. The health endpoint and exact dashboard name should be verified after starting the packaged app.

## Decision
The panel is a descriptive analyst and audit tool, not a baccarat winner predictor. The only allowed decision is WAIT until prospective data logged before outcomes, verified shoe/session segmentation, appropriate baselines, calibrated probabilities, sufficient sample size, and independent replication support any stronger claim.
