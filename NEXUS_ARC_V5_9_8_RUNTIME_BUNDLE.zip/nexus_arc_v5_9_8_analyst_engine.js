/* NEXUS ARC V5.9.8 Analyst Reasoning Engine
 * Explainable, descriptive diagnostics for P/B/T sequences.
 * It deliberately does NOT infer a wagering side from road patterns.
 * Exact shoe composition is not recoverable from P/B/T result history alone.
 */
(function(root){
  'use strict';
  const VERSION = '5.9.8';
  const BASELINE = Object.freeze({P:0.49317561922276104, B:0.5068243807772389});
  const MIN_ANALYSIS_PB = 12;
  const WINDOWS = Object.freeze([6, 12, 20]);

  function token(v){
    const s=String(v==null?'':v).trim().toUpperCase();
    if(s==='P'||s==='PLAYER') return 'P';
    if(s==='B'||s==='BANKER') return 'B';
    if(s==='T'||s==='TIE') return 'T';
    return null;
  }
  function parse(input){
    if(Array.isArray(input)){
      const out=[]; let ignored=0;
      for(const v of input){const t=token(v&&typeof v==='object'?(v.result??v.outcome??''):v);if(t)out.push(t);else ignored++;}
      return {outcomes:out, raw_count:input.length, ignored_count:ignored};
    }
    const s=String(input==null?'':input).trim().toUpperCase();
    if(!s)return {outcomes:[],raw_count:0,ignored_count:0};
    const compact=s.replace(/[\s,;|/\\._:-]+/g,'');
    if(/^[PBT]+$/.test(compact))return {outcomes:compact.split(''),raw_count:compact.length,ignored_count:0};
    const matches=s.match(/\b(?:PLAYER|BANKER|TIE|P|B|T)\b/g)||[];
    const out=matches.map(token).filter(Boolean);
    return {outcomes:out,raw_count:matches.length,ignored_count:0};
  }
  function normalizeOutcomes(input){return parse(input).outcomes;}
  function pbOnly(input){return normalizeOutcomes(input).filter(x=>x==='P'||x==='B');}
  function runsOf(seq){
    const runs=[];
    for(let i=0;i<seq.length;i++){
      const v=seq[i], last=runs[runs.length-1];
      if(last&&last.side===v){last.length++;last.end=i;}
      else runs.push({side:v,length:1,start:i,end:i});
    }
    return runs;
  }
  function pShare(seq){return seq.length?seq.filter(x=>x==='P').length/seq.length:null;}
  function rateCI(successes,n){
    if(!n)return null;
    const z=1.959963984540054,p=successes/n,z2=z*z,den=1+z2/n;
    const center=(p+z2/(2*n))/den;
    const half=(z*Math.sqrt((p*(1-p)/n)+(z2/(4*n*n))))/den;
    return {low:Math.max(0,center-half),high:Math.min(1,center+half)};
  }
  function summarizeWindow(seq,n){
    const x=seq.slice(-n), runs=runsOf(x), flips=x.slice(1).filter((v,i)=>v!==x[i]).length;
    return {window:n,n:x.length,P:x.filter(v=>v==='P').length,B:x.filter(v=>v==='B').length,p_share:pShare(x),b_share:x.length?pShare(x)===null?null:1-pShare(x):null,flip_count:flips,flip_rate:x.length>1?flips/(x.length-1):null,max_run:runs.reduce((m,r)=>Math.max(m,r.length),0),sequence:x.join('')};
  }
  function suffixRunPattern(runLengths){
    const suffixes=[
      {id:'RUN_SHAPE_1_2',seq:[1,2],label:'จังหวะ 1-2',meaning:'สอง run ท้ายมีความยาว 1 แล้ว 2 ผล; เป็นรูปทรงย้อนหลัง ไม่ใช่ forecast'},
      {id:'RUN_SHAPE_1_3',seq:[1,3],label:'จังหวะ 1-3',meaning:'สอง run ท้ายมีความยาว 1 แล้ว 3 ผล; เป็นรูปทรงย้อนหลัง ไม่ใช่ forecast'},
      {id:'RUN_SHAPE_2_1_2',seq:[2,1,2],label:'จังหวะ 2-1-2',meaning:'สาม run ท้ายมีความยาว 2, 1 และ 2 ผล; เป็นรูปทรงย้อนหลัง ไม่ใช่ forecast'},
      {id:'RUN_SHAPE_3_1',seq:[3,1],label:'จังหวะ 3-1',meaning:'สอง run ท้ายมีความยาว 3 แล้ว 1 ผล; เป็นรูปทรงย้อนหลัง ไม่ใช่ forecast'},
      {id:'RUN_SHAPE_2_2',seq:[2,2],label:'จังหวะ 2-2',meaning:'สอง run ท้ายมีความยาว 2 ผลทั้งคู่; เป็นรูปทรงย้อนหลัง ไม่ใช่ forecast'}
    ];
    return suffixes.filter(p=>runLengths.length>=p.seq.length&&p.seq.every((v,i)=>runLengths[runLengths.length-p.seq.length+i]===v));
  }
  function classifyAll(seq,runs){
    const out=[];
    if(seq.length<4)out.push({id:'WARMUP',label:'ข้อมูลยังไม่พอ',meaning:'มีผล P/B น้อยกว่า 4 รายการ'});
    if(seq.length>=4){
      const tail4=seq.slice(-4),alt4=tail4.every((v,i)=>i===0||v!==tail4[i-1]);
      if(alt4)out.push({id:'ALTERNATION_4',label:'สลับฝั่ง 4 ผล',meaning:'สี่ผลท้ายสลับ P/B ทุกช่วง'});
      if(tail4[0]===tail4[1]&&tail4[2]===tail4[3]&&tail4[0]!==tail4[2])out.push({id:'TWO_BY_TWO',label:'กลุ่มละ 2 ผล',meaning:'สี่ผลท้ายเป็น PPBB หรือ BBPP'});
    }
    if(seq.length>=6){const tail6=seq.slice(-6);if(tail6.every((v,i)=>i===0||v!==tail6[i-1]))out.push({id:'ALTERNATION_6',label:'สลับฝั่ง 6 ผล',meaning:'หกผลท้ายสลับ P/B ทุกช่วง'});}
    const run=runs[runs.length-1]?.length||0;
    if(run>=2)out.push({id:'CURRENT_RUN',label:run>=5?'Streak ยาว ≥ 5':run>=3?'Streak ≥ 3':'คู่ซ้ำท้าย',meaning:`ผลฝั่ง ${seq[seq.length-1]||'—'} ต่อเนื่อง ${run} ครั้ง` ,run_length:run});
    for(const p of suffixRunPattern(runs.map(r=>r.length)))out.push(p);
    if(!out.length)out.push({id:'MIXED',label:'รูปแบบผสม',meaning:'ยังไม่ตรงเกณฑ์เฉพาะที่ตัววิเคราะห์กำหนด'});
    return out;
  }
  function transitionStats(seq){
    const counts={P:{P:0,B:0},B:{P:0,B:0}};
    for(let i=1;i<seq.length;i++)counts[seq[i-1]][seq[i]]++;
    return ['P','B'].map(from=>{
      const n=counts[from].P+counts[from].B;
      return {from,n,to_P:counts[from].P,to_B:counts[from].B,p_to_P:n?counts[from].P/n:null,p_to_B:n?counts[from].B/n:null,ci_P:rateCI(counts[from].P,n),ci_B:rateCI(counts[from].B,n)};
    });
  }
  function entropy(seq){
    if(!seq.length)return null;
    const p=seq.filter(x=>x==='P').length/seq.length,b=1-p;
    const h=(v)=>v>0?-v*Math.log2(v):0;
    return h(p)+h(b); // 0..1 for binary sequence
  }
  function suffixMatches(seq){
    const out=[]; const n=seq.length;
    for(const k of [2,3,4,5]){
      if(n<2*k+1)continue;
      const suffix=seq.slice(n-k).join(''), targetStart=n-k; let p=0,b=0,occ=0;
      for(let i=0;i+k<targetStart;i++){
        if(seq.slice(i,i+k).join('')===suffix){const next=seq[i+k];if(next==='P')p++;else if(next==='B')b++;occ++;}
      }
      out.push({length:k,suffix,occurrences:occ,following_P:p,following_B:b,p_share:occ?p/occ:null,decision:occ>=10?'DESCRIPTIVE_ONLY_SAMPLE_AVAILABLE':'TOO_FEW_MATCHES'});
    }
    return out;
  }
  function analyze(input){
    const parsed=parse(input), raw=parsed.outcomes, pb=raw.filter(x=>x==='P'||x==='B'), tieN=raw.filter(x=>x==='T').length;
    const runs=runsOf(pb), n=pb.length, currentRun=runs[runs.length-1]||null;
    const windowStats=WINDOWS.map(w=>summarizeWindow(pb,w));
    const prior8=n>=16?pb.slice(n-16,n-8):[],recent8=n>=8?pb.slice(-8):[];
    const prevShare=pShare(prior8),recentShare=pShare(recent8),delta=prevShare===null||recentShare===null?null:recentShare-prevShare;
    const shiftStatus=delta===null?'INSUFFICIENT_DATA':Math.abs(delta)>=0.25?'SHIFT_CANDIDATE':'NO_LARGE_SHIFT_DETECTED';
    const transitions=transitionStats(pb), entropy20=entropy(pb.slice(-20));
    const patterns=classifyAll(pb,runs), matches=suffixMatches(pb);
    const pN=pb.filter(x=>x==='P').length,bN=pb.filter(x=>x==='B').length;
    const tiesRate=raw.length?tieN/raw.length:null;
    const consistency=[];
    if(n<MIN_ANALYSIS_PB)consistency.push(`มีผลที่ไม่ใช่ Tie เพียง ${n} มือ; เกณฑ์วิเคราะห์บริบทหลายช่วงตั้งไว้ที่อย่างน้อย ${MIN_ANALYSIS_PB} มือ`);
    if(shiftStatus==='SHIFT_CANDIDATE')consistency.push(`สัดส่วน Player ใน 8 มือท้ายต่างจาก 8 มือก่อนหน้า ${Math.abs(delta*100).toFixed(1)} จุดเปอร์เซ็นต์; เป็นเพียงสัญญาณให้ตรวจข้อมูล ไม่ใช่การยืนยันว่าแนวโน้มเปลี่ยนจริง`);
    else if(shiftStatus==='NO_LARGE_SHIFT_DETECTED')consistency.push('ไม่พบความต่างของสัดส่วน Player ระหว่าง 8 มือท้ายกับ 8 มือก่อนหน้าถึงเกณฑ์ 25 จุดเปอร์เซ็นต์');
    else consistency.push('ยังไม่มีข้อมูลครบ 8+8 มือสำหรับเปรียบเทียบช่วงล่าสุดกับช่วงก่อนหน้า');
    if(currentRun&&currentRun.length>=4)consistency.push(`พบ streak ${currentRun.side} ยาว ${currentRun.length} มือ; ความยาว streak ไม่ได้ทำให้ฝั่งนั้น “ถึงคิว” ออกหรือกลับฝั่ง`);
    if(tieN)consistency.push(`มี Tie ${tieN} ครั้ง (${(tiesRate*100).toFixed(1)}% ของผลที่ป้อน); นับแยกจากลำดับ P/B สำหรับสถิติแบบ conditional`);
    if(matches.some(x=>x.occurrences>0&&x.occurrences<10))consistency.push('พบ suffix ที่เคยเกิดซ้ำเพียงเล็กน้อย; ไม่ควรอ่านอัตราตามหลังเป็นโอกาสของมือถัดไป');
    const evidenceGate = n<MIN_ANALYSIS_PB ? 'WAIT_INSUFFICIENT_SEQUENCE' : 'WAIT_NO_VERIFIED_CROSS_SESSION_EDGE';
    return {
      schema:'nexus-arc-v5.9.8-analyst-reasoning-v1',version:VERSION,
      data_quality:{input_items:parsed.raw_count,accepted_outcomes:raw.length,ignored_items:parsed.ignored_count,pb_n:n,tie_n:tieN,player_n:pN,banker_n:bN,tie_rate:tiesRate,has_session_ids:false,has_card_composition:false},
      current_state:{last_outcome:raw.length?raw[raw.length-1]:null,last_non_tie:pb.length?pb[pb.length-1]:null,current_run_side:currentRun?currentRun.side:null,current_run_length:currentRun?currentRun.length:0,run_count:runs.length,longest_run:runs.reduce((m,r)=>Math.max(m,r.length),0),mean_run_length:runs.length?runs.reduce((s,r)=>s+r.length,0)/runs.length:null,recent_entropy_20:entropy20,entropy_label:entropy20===null?'ไม่พอ':entropy20<0.75?'สัดส่วนเอนเอียงไปข้างหนึ่ง':entropy20>0.95?'สัดส่วน P/B ใกล้สมดุล':'ผสม'},
      patterns,windows:windowStats,transition_stats:transitions,recent_vs_previous_8:{recent_n:recent8.length,previous_n:prior8.length,recent_player_share:recentShare,previous_player_share:prevShare,delta_player_share:delta,status:shiftStatus},historical_suffix_matches:matches,
      forecast_assessment:{decision:'WAIT',status:evidenceGate,baseline_reference:BASELINE,baseline_note:'ค่าอ้างอิงสำหรับ shoe ใหม่มาตรฐาน 8 สำรับ โดยคิดโอกาส P/B แบบมีเงื่อนไขเมื่อไม่ใช่ Tie; ไม่ใช่ความน่าจะเป็นที่คำนวณจากไพ่คงเหลือของ shoe ปัจจุบัน',pattern_adjustment_applied:false,why_wait:[
        'Roadmap และแพตเทิร์นเป็นข้อมูลย้อนหลัง ไม่ได้พิสูจน์ว่ามือถัดไปต้องตามหรือสวน',
        'ข้อมูล input นี้ไม่มีรหัส shoe/session ที่ยืนยันได้ จึงไม่สามารถวัดความไม่แน่นอนแบบแยก shoe อย่างน่าเชื่อถือ',
        'ประวัติ P/B/T ไม่บอกองค์ประกอบไพ่ที่เหลืออยู่ จึงคำนวณความน่าจะเป็นเฉพาะ shoe ปัจจุบันไม่ได้',
        'ยังไม่มีหลักฐาน prospective อิสระที่ผ่านเกณฑ์เทียบ baseline; ระบบไม่เลือก P/B เป็นสัญญาณเดิมพัน'
      ]},
      reasoning:consistency,
      methodology:{rule_order:['validate inputs and count ties separately','describe run lengths and overlapping tail motifs','compare multiple time windows','measure observed transitions with sample sizes and intervals','check recent-vs-prior regime shift without turning it into a forecast','review historical suffix matches as exploratory only','require independent session-level prospective evidence before any prediction claim'],limits:['Within-sequence counts may be dependent and overlapping.','Wilson intervals are descriptive row-level intervals, not shoe-clustered confidence intervals.','No historical suffix match is treated as a predictive probability.','No card-counting or exact composition model is used.','Always WAIT until independent prospective validation and replication.']}
    };
  }
  const api={VERSION,BASELINE,MIN_ANALYSIS_PB,WINDOWS,parse,normalizeOutcomes,pbOnly,runsOf,classifyAll,transitionStats,suffixMatches,analyze};
  root.NexusAnalystReasoningV598=api;
  if(typeof module!=='undefined'&&module.exports)module.exports=api;
})(typeof window!=='undefined'?window:globalThis);
