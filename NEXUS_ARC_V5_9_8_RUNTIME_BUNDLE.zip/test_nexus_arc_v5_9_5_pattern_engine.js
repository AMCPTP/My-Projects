'use strict';
const assert = require('node:assert/strict');
const E = require('./nexus_arc_v5_9_5_pattern_engine.js');
let passed = 0;
function test(name, fn) { fn(); passed++; process.stdout.write(`PASS ${name}\n`); }

test('normalizes compact, delimited, and named outcomes', () => {
  assert.deepEqual(E.normalizeOutcomes('PBT-P B, T'), ['P','B','T','P','B','T']);
  assert.deepEqual(E.normalizeOutcomes(['PLAYER','BANKER','TIE','invalid']), ['P','B','T']);
});
test('classifies four strict alternations', () => {
  assert.equal(E.classifyPattern('PBPB').id, 'ALTERNATION_4');
  assert.equal(E.classifyPattern('BPBP').id, 'ALTERNATION_4');
});
test('classifies two-by-two blocks without calling them predictive', () => {
  assert.equal(E.classifyPattern('PPBB').id, 'TWO_BY_TWO');
  assert.equal(E.classifyPattern('BBPP').id, 'TWO_BY_TWO');
  assert.match(E.classifyPattern('PPBB').description, /ไม่สมมติ/);
});
test('classifies streak and simple double separately', () => {
  assert.equal(E.classifyPattern('BPPPP').id, 'STREAK_3');
  assert.equal(E.classifyPattern('PBB').id, 'WARMUP');
  assert.equal(E.classifyPattern('PBPBB').id, 'DOUBLE');
});
test('walk-forward scores only after 12 previous P/B results', () => {
  const r = E.walkForwardAudit('PBPBPBBPBBPPBPPBBPBPBPPBBP');
  assert.equal(r.n_scored, r.input_n_pb - E.MIN_PREFIX);
  assert.equal(r.rows[0].prefix_length, E.MIN_PREFIX);
});
test('walk-forward does not leak the target outcome into its probability', () => {
  const a = E.walkForwardAudit('PPBBPBPBBPPBPBBPBPBPBPBPPB');
  const b = E.walkForwardAudit('PPBBPBPBBPPBPBBPBPBPBPBPPP');
  assert.deepEqual(a.rows[a.rows.length-1].probabilities, b.rows[b.rows.length-1].probabilities);
});
test('Tie outcomes are excluded from conditional P/B sequence', () => {
  const a = E.walkForwardAudit('PBPBBPBPBPPBBPBPBPBP');
  const seq = 'PBPBBPBPBPPBBPBPBPBP';
  const b = E.walkForwardAudit(seq.slice(0, 4) + 'T' + seq.slice(4, 11) + 'T' + seq.slice(11));
  assert.equal(a.input_n_pb, b.input_n_pb);
  assert.equal(a.n_scored, b.n_scored);
  assert.equal(a.ties_excluded_from_conditional_pb, 0);
  assert.equal(b.ties_excluded_from_conditional_pb, 2);
});
test('short walk-forward samples cannot be promoted and have no CI', () => {
  const r = E.walkForwardAudit('PBPBBPBPBBPPBPBBPB');
  assert.match(r.status, /WARMING/);
  assert.equal(r.metrics.ci_delta_log_loss, null);
});
test('locks require a valid session ID and enough prior results', () => {
  const ledger = E.emptyLedger();
  assert.throws(() => E.makeProspectiveForecast('PBP', ledger, 'shoe-001', '2026-10-15T00:00:00Z', 'f1'), /at least 12/);
  assert.throws(() => E.makeProspectiveForecast('PBPBPBBPBBPP', ledger, 'x', '2026-10-15T00:00:00Z', 'f1'), /session ID/);
});
test('one pending forecast at a time and tied outcomes do not resolve it', () => {
  const ledger = E.emptyLedger();
  const h = 'PBPBBPBPBBPP';
  const f = E.makeProspectiveForecast(h, ledger, 'shoe-001', '2026-10-15T00:00:00Z', 'f1');
  assert.equal(f.decision, 'WAIT');
  assert.equal(f.estimator_status, 'WAIT_BASELINE_ONLY_INSUFFICIENT_CROSS_SESSION_PATTERN_EVIDENCE');
  assert.throws(() => E.makeProspectiveForecast(h, ledger, 'shoe-001', '2026-10-15T00:01:00Z', 'f2'), /already pending/);
  const tied = E.resolvePendingAgainstHistory(ledger, h + 'T', '2026-10-15T00:02:00Z');
  assert.equal(tied.changed, false);
  const resolved = E.resolvePendingAgainstHistory(ledger, h + 'TP', '2026-10-15T00:03:00Z');
  assert.equal(resolved.resolved, true);
  assert.equal(resolved.record.actual, 'P');
  assert.equal(ledger.pending_id, null);
});
test('editing/resetting history cancels instead of contaminating the score', () => {
  const ledger = E.emptyLedger();
  E.makeProspectiveForecast('PBPBBPBPBBPP', ledger, 'shoe-001', '2026-10-15T00:00:00Z', 'f1');
  const r = E.resolvePendingAgainstHistory(ledger, 'BBBBBPBPBBPPB', '2026-10-15T00:01:00Z');
  assert.equal(r.cancelled, true);
  assert.equal(ledger.records[0].status, 'CANCELLED');
  assert.equal(ledger.records[0].actual, null);
});
test('prospective comparison stays WAIT under 20 distinct sessions even with many rows', () => {
  const l = E.emptyLedger();
  for (let i = 0; i < 120; i++) l.records.push({
    forecast_id: `x${i}`, model_version: E.VERSION, created_at: '2026-10-01T00:00:00Z', session_id: `ses${i%10}`,
    target_definition: 'next non-Tie P/B result; Tie does not settle forecast', status: 'RESOLVED', prefix_raw_sequence: 'PBPBBPBPBBPP',
    prefix_pb_sequence: 'PBPBBPBPBBPP', prefix_pb_count: 12, pattern_id: 'STREAK_3', pattern_label: 'streak', pattern_description: 'test',
    probabilities: {P:0.49317561922276104, B:0.5068243807772389}, baseline: {...E.BASELINE}, training_pattern_rows:0, training_other_sessions:0,
    estimator_status:'WAIT_BASELINE_ONLY_INSUFFICIENT_CROSS_SESSION_PATTERN_EVIDENCE', decision:'WAIT', actual:i%2?'P':'B', resolved_at:'2026-10-01T00:01:00Z', cancel_reason:null
  });
  const s = E.summarizeProspective(l);
  assert.equal(s.n_scored, 120);
  assert.equal(s.distinct_sessions, 10);
  assert.match(s.status, /NOT_ENOUGH_DISTINCT_SESSIONS/);
});
test('ledger validation blocks corrupt or duplicate records', () => {
  const l = E.emptyLedger(); l.records.push({ forecast_id:'dup', model_version:E.VERSION, session_id:'shoe-001', pattern_id:'STREAK_3', status:'PENDING', prefix_pb_count:12, prefix_pb_sequence:'PBPBBPBPBBPP', prefix_raw_sequence:'PBPBBPBPBBPP', probabilities:{P:.49,B:.51} }); l.pending_id = 'dup';
  assert.doesNotThrow(() => E.validateLedger(l));
  l.records.push({...l.records[0]});
  assert.throws(() => E.validateLedger(l), /duplicate/);
});

test('pattern-conditioned probabilities learn only from completed other-session records', () => {
  const l = E.emptyLedger();
  for (let i = 0; i < 30; i++) {
    const session = `shoe-${String(1 + (i % 10)).padStart(2,'0')}`;
    l.records.push({ forecast_id:`train${i}`, model_version:E.VERSION, created_at:'2026-10-01T00:00:00Z', session_id:session,
      target_definition:'next non-Tie P/B result; Tie does not settle forecast', status:'RESOLVED', prefix_raw_sequence:'PBPBBPBPBBPPP', prefix_pb_sequence:'PBPBBPBPBBPPP', prefix_pb_count:13,
      pattern_id:'STREAK_3', pattern_label:'streak', pattern_description:'test', probabilities:{...E.BASELINE}, baseline:{...E.BASELINE}, training_pattern_rows:0, training_other_sessions:0,
      estimator_status:'WAIT', decision:'WAIT', actual:'P', resolved_at:'2026-10-01T00:01:00Z', cancel_reason:null });
  }
  const forecast = E.makeProspectiveForecast('PBPBBPBPBBPPP', l, 'shoe-target', '2026-10-15T00:00:00Z', 'live1');
  assert.equal(forecast.pattern_id, 'STREAK_3');
  assert.equal(forecast.training_pattern_rows, 30);
  assert.equal(forecast.training_other_sessions, 10);
  assert.ok(forecast.probabilities.P > E.BASELINE.P + 0.15);
  const sameSession = E.makeProspectiveForecast('PBPBBPBPBBPPP', E.emptyLedger(), 'shoe-target', '2026-10-15T00:00:00Z', 'live2');
  assert.deepEqual(sameSession.probabilities, E.BASELINE);
});
test('prospective gate can only nominate independent replication and never removes WAIT', () => {
  const l = E.emptyLedger();
  for (let i = 0; i < 100; i++) l.records.push({ forecast_id:`strong${i}`, model_version:E.VERSION, created_at:'2026-10-01T00:00:00Z', session_id:`shoe-${String(i%20).padStart(2,'0')}`,
    target_definition:'next non-Tie P/B result; Tie does not settle forecast', status:'RESOLVED', prefix_raw_sequence:'PBPBBPBPBBPPP', prefix_pb_sequence:'PBPBBPBPBBPPP', prefix_pb_count:13,
    pattern_id:'STREAK_3', pattern_label:'streak', pattern_description:'test', probabilities:{P:.99,B:.01}, baseline:{...E.BASELINE}, training_pattern_rows:0, training_other_sessions:0,
    estimator_status:'CROSS_SESSION_PATTERN_ESTIMATE', decision:'WAIT', actual:'P', resolved_at:'2026-10-01T00:01:00Z', cancel_reason:null });
  const s = E.summarizeProspective(l);
  assert.match(s.status, /CANDIDATE_FOR_INDEPENDENT_REPLICATION/);
  assert.equal(s.criteria.auto_promotion, false);
  assert.equal(s.criteria.betting_signal, false);
});

console.log(`\n${passed} tests passed.`);
