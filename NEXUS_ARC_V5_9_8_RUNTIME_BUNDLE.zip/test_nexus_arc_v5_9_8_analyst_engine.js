'use strict';
const assert = require('node:assert/strict');
const A = require('./nexus_arc_v5_9_8_analyst_engine.js');
let passed=0;
function test(name,fn){fn();passed++;console.log('PASS '+name);}
test('normalizes P/B/T and counts raw ties separately',()=>{
  const r=A.analyze('PBPBTT-BB');
  assert.equal(r.data_quality.pb_n,6);assert.equal(r.data_quality.tie_n,2);assert.equal(r.data_quality.accepted_outcomes,8);
});
test('detects alternate as a description not a forecast',()=>{
  const r=A.analyze('PBPBPB');
  assert.ok(r.patterns.some(x=>x.id==='ALTERNATION_6'));
  assert.equal(r.forecast_assessment.decision,'WAIT');
  assert.equal(r.forecast_assessment.pattern_adjustment_applied,false);
});
test('detects 2-2 and current double independently',()=>{
  const r=A.analyze('PPBB');
  assert.ok(r.patterns.some(x=>x.id==='TWO_BY_TWO'));
  assert.ok(r.patterns.some(x=>x.id==='CURRENT_RUN'));
});
test('detects long streak and labels it non-predictive',()=>{
  const r=A.analyze('PPBBBBB');
  assert.equal(r.current_state.current_run_side,'B');assert.equal(r.current_state.current_run_length,5);
  assert.ok(r.reasoning.some(x=>x.includes('ถึงคิว')));
});
test('detects run pattern 2-1-2',()=>{
  const r=A.analyze('PPBP P'.replace(/ /g,''));
  assert.ok(r.patterns.some(x=>x.id==='RUN_SHAPE_2_1_2'));
});
test('transition rates include sample sizes and wide intervals',()=>{
  const r=A.analyze('PBPB');const p=r.transition_stats.find(x=>x.from==='P');
  assert.equal(p.n,2);assert.ok(p.ci_P.low <= p.p_to_P);assert.ok(p.ci_P.high >= p.p_to_P);
});
test('multi-window metrics show smaller windows on short histories',()=>{
  const r=A.analyze('PBPBBPBP');
  assert.equal(r.windows.find(x=>x.window===6).n,6);
  assert.equal(r.windows.find(x=>x.window===20).n,8);
});
test('regime shift is only a candidate and never a side prediction',()=>{
  const r=A.analyze('BBBBBBBBPPPPPPPP');
  assert.equal(r.recent_vs_previous_8.status,'SHIFT_CANDIDATE');
  assert.equal(r.forecast_assessment.decision,'WAIT');
});
test('suffix matches are descriptive and explicitly not predictions',()=>{
  const r=A.analyze('PBPBPBPBPB');
  assert.ok(r.historical_suffix_matches.every(x=>!('forecast' in x)));
  assert.ok(r.methodology.limits.some(x=>x.includes('suffix match')));
});
test('short data is held in WAIT insufficient sequence status',()=>{
  const r=A.analyze('PBTB');
  assert.equal(r.forecast_assessment.status,'WAIT_INSUFFICIENT_SEQUENCE');
});
test('P/B/T history never claims exact shoe composition',()=>{
  const r=A.analyze('PBPBBPPBTBPB');
  assert.equal(r.data_quality.has_card_composition,false);
  assert.ok(r.forecast_assessment.why_wait.some(x=>x.includes('องค์ประกอบไพ่')));
});
test('ignores invalid array values and reports them',()=>{
  const r=A.analyze(['P','B','nope','T']);
  assert.equal(r.data_quality.ignored_items,1);assert.equal(r.data_quality.accepted_outcomes,3);
});
console.log(`\n${passed} analyst engine tests passed.`);
