# NEXUS ARC V5.9.9 — Rapid Multi-Lens Analyst Audit

## Purpose
Reduce the user-visible delay caused by treating every lack of validated predictive edge as a total `WAIT`. The analyst now returns an immediate, explicitly provisional directional lean (`P`, `B`, or `NEUTRAL`) when at least four non-Tie outcomes are available, while retaining a separate `WAIT` validation gate for any claim of predictive edge.

## Changes
- Added `rapidRead()` to the analyst engine.
- Uses weighted P-share deviations from 6/12/20-hand windows and a smoothed previous-side transition statistic only when that row has at least 12 observations.
- Surfaces run/streak, alternation, 2-2, recent-vs-prior shift, entropy, suffix repeats, and sample-size caveats as context; these pattern labels do not directly add directional score.
- Returns a bounded heuristic score and a qualitative `LOW`/`MODERATE` strength label, never a probability. `probability` is explicitly `null`, `validated` is false, and `edge_claim` is false.
- Keeps `validation_gate: WAIT_NO_VERIFIED_CROSS_SESSION_EDGE` until independently registered prospective evidence and replication exist.
- Dashboard updates while the user types, so the quick read appears without a separate analysis-button click.
- Updated backend version, dashboard filename, launcher checks, and JavaScript allowlist to 5.9.9.

## Test results
- Python regression suite: 44/44 passed.
- Rapid Analyst Engine: 14/14 passed.
- Pattern Engine: 15/15 passed.
- Brain Import Guard: 5/5 passed.
- Python compilation: passed.
- 11 inline Dashboard JavaScript blocks: syntax check passed.
- JavaScript syntax check for Rapid Analyst Engine: passed.

Total automated tests: 78 passed.

## Limitations
The directional lean is a transparent heuristic for fast situational reading, not a calibrated forecast, betting instruction, or evidence of positive expected value. The scoring uses observed recent P/B balance and conditional transition history; overlapping observations may be dependent. Streaks, road patterns, entropy, and suffix matches are reported as context, not as predictive evidence. P/B/T outcomes alone do not reveal the remaining card composition of the current shoe. Browser interaction and PowerShell process management have not been executed on the user's own Windows computer; verify `/api/health` after installation.
