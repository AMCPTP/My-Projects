NEXUS ARC V5.9.9 — Rapid Multi-Lens Analyst

PURPOSE
This release extends the V5.9.7 app with an explainable P/B/T descriptive analysis panel, upgrades the app/server identity to 5.9.9, and fixes allowlisted delivery of the dashboard JavaScript modules. It treats baccarat road patterns as observations of past results, not as forecasts. The analyst panel reports multiple pattern tags, run-length structure, last-6/12/20 P/B window statistics, observed transition counts with row-level Wilson intervals, a recent-vs-previous window shift candidate, and repeated suffixes found in the same history.

WHAT THE ANALYST PANEL DOES
- Separates P/B sequence statistics from Tie count.
- Detects overlapping labels rather than forcing every history into one exclusive pattern: alternation 4/6, 2-2 blocks, current run, 1-2/1-3/2-1-2/3-1 run shapes, and mixed/warm-up states.
- Compares several window sizes and gives sample sizes alongside rates.
- Labels changes as candidates, not confirmed regime changes.
- Looks up earlier occurrences of 2–5-result suffixes in the supplied history, but labels results exploratory because same-sequence matches overlap and aren't independent evidence.
- Adds an immediate heuristic directional lean (P/B/NEUTRAL) after at least 4 non-Tie outcomes, while keeping the empirical validation gate at WAIT. The lean is not a calibrated probability, betting instruction, or verified edge.
- Exports a JSON report for audit/review.

WHAT IT DOES NOT CLAIM
- No pattern is considered predictive solely because it appears on a roadmap.
- P/B/T history does not identify the ranks and suits remaining in the current shoe. No exact remaining-card model or card counter is included.
- Historical suffix frequencies and transition rates are descriptive. Their displayed Wilson intervals are row-level and not clustered by shoe/session.
- The baseline reference (P=49.3176%, B=50.6824% conditional on non-Tie) is a standard fresh 8-deck reference only, not a prediction for a shoe already in progress.
- No edge, profit, or next-hand accuracy is claimed. The live action remains WAIT pending properly registered prospective data and independent replication.

SAFE UPGRADE (WINDOWS)
1. Back up the whole existing NEXUS folder, .env, nexus_v5_0_data (if present), and Brain exports.
2. Extract this ZIP directly into the existing installation folder and overwrite matching application files. Files are stored at the root of the ZIP for in-place upgrade. Do not delete .env or user data.
3. Run start_nexus_arc_v5_9.bat. It should confirm server version 5.9.9 and dashboard NEXUS_ARC_V5_9_9_RAPID_ANALYST_DESK.html before opening a browser.
4. Verify http://127.0.0.1:8787/api/health reports version 5.9.9 and the exact V5.9.9 dashboard filename.
5. The dashboard's Analyst Reasoning section follows the live P/B/T history. To analyze a pasted sequence, enter it in the Rapid Analyst input and click Analyze Rapid Read; click Copy Live History to return to the current table history.

REQUIREMENTS / TESTS
Python 3.11+ and dependencies in requirements.txt.
Run: py -3 -m pip install -r requirements.txt
Run: py -3 -m unittest -v test_nexus_arc_v5_9_9_regression.py
Run: node test_nexus_arc_v5_9_5_pattern_engine.js
Run: node test_nexus_arc_v5_9_9_brain_import_guard.js
Run: node test_nexus_arc_v5_9_9_rapid_analyst_engine.js

VERSION COMPATIBILITY
Application/backend version: 5.9.9.
Legacy Brain learner schema stays NEXUS-ARC-V5.9.2-CONTEXT-ISOLATION-INTEGRITY for migration compatibility.
Prospective pattern ledger stays at nexus-arc-v5.9.5-pattern-audit-ledger-v1 to preserve existing local records.

LIMITATIONS
The Linux build environment cannot execute Windows PowerShell process management or a full real browser session on the user's computer. The previous Brain export audit and its metrics CSV are included as historical review artifacts; they are not used to promote model weights. The release tests statically check the launcher and locally test the API/dashboard. Verify /api/health after launch. The new analysis panel must not be interpreted as a wagering recommendation.
