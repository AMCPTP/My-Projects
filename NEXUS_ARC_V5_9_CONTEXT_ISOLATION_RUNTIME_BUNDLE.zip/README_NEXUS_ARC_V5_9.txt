NEXUS ARC V5.9 — CONTEXT ISOLATION RELEASE
===========================================

PURPOSE
This is a local analysis, audit, learning-ledger, and configured-feed monitoring workspace. It separates the local P/B sequence heuristic from general multi-domain analysis, and separates monitor-only external events from the P/B estimator.

INSTALL / RUN (Windows)
1. Extract this archive to a folder you control.
2. Install Python 3.11+ if not present.
3. Open a terminal in the extracted folder and run: py -3 -m pip install -r requirements.txt
4. Copy .env.example to .env and configure OPENAI_API_KEY and NEXUS_MODEL only if you want the server-side LLM analysis function. Never share .env or API keys.
5. Run start_nexus_arc_v5_9.bat. The gateway binds to 127.0.0.1 by default.
6. Open http://127.0.0.1:8787/ in a browser.

DATA / RESET SCOPE
- Local P/B history, its learner state, and local events are stored in browser localStorage when available. That storage is editable and is not a secure vault; periodically use Export Brain for backups.
- If browser persistence fails, the UI indicates MEMORY ONLY. Such changes are lost when the tab/process is closed unless exported.
- The dashboard reset clears local browser history/Brain/events only. Server-side learning and assurance ledgers are separate and are not silently erased by that button.
- Browser SHA-256 Brain checksums detect unintended alteration to a file; they do not authenticate the author or prove that imported content is true.

ANALYSIS / LEARNING LIMITS
- The local baccarat module is a heuristic sequence model. It is not a card-counting/shoe-composition model. P/B forecasts and normalized regime scores are unvalidated diagnostics, not betting signals.
- Learning adjusts local expert/context weights and calibration from entered outcomes. It does not fine-tune the underlying LLM, independently verify user-entered outcomes, or guarantee that a change improves future results.
- Candidate comparison cannot auto-promote an active profile; an exploratory pass requires an independently defined holdout review.
- The 8-deck reference is initial-shoe P/B probability conditional on a non-Tie result, not adjusted for dealt cards or table-specific conditions.
- External event feeds are monitor-only for the local P/B estimator. The general analysis workspace queries only the sources available for a particular request plus any configured feeds; exhaustive worldwide awareness is not possible.
- The server's feed fetcher revalidates DNS and pins each connection to validated public IP addresses, rejects private/reserved destinations and redirects, and bounds size/time. This reduces specific SSRF risks but is not a blanket security certification.

VERIFICATION
See NEXUS_ARC_V5_9_TEST_REPORT.txt and NEXUS_ARC_V5_9_CHANGELOG.txt. SHA-256 checksums are listed in NEXUS_ARC_V5_9_SHA256SUMS.txt.
