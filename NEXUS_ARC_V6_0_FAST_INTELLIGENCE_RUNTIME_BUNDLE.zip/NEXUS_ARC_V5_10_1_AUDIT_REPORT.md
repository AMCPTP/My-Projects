# NEXUS ARC V5.10.1 — Rapid Multi-Lens Read Audit

## Scope
This release addresses the user's main usability complaint: the prominent analyzer stayed at WAIT until the full-history historical-tilt threshold was reached. The release splits **rapid hypothesis/readiness** from **independent edge validation**. It keeps the P/B-only workflow introduced in V5.10.0.

## Behavior changed
- `rapidRead()` is a dedicated O(n) path used by the main status guard. It avoids invoking the full analyzer repeatedly simply to update the main display.
- At 0–3 accepted P/B observations, the UI says `BUILDING READ · n/4`, not system-wide WAIT.
- At 4+ results, the quick panel immediately returns `RAPID_HEURISTIC_READ` with P lean, B lean, or neutral and a support label. It does not wait for the 12-result full-history tilt threshold.
- Score uses smoothed P-share lenses for available recent 6, recent 12, recent 20 and all-history data, with an 8-count prior around the fixed reference. A small momentum term compares the last 6 outcomes with the preceding 6 when available. A repeating 2–2 phase guard suppresses a transient lean when the last 8 outcomes form two exact 2–2 blocks and the latest 12 remain balanced.
- Road patterns, streaks, transition rows, suffix matches, and shift candidates are detected and shown as context. They are not treated as proof that the next outcome must continue or reverse.
- Full-history Wilson 95% tilt remains a separate diagnostic requiring at least 12 outcomes. The rapid score is not a calibrated probability.
- `probability` remains `null`, `validated` remains false, `edge_claim` remains false, and `VALIDATION GATE` remains WAIT until prospective, session-separated evidence is adequately scored and independently replicated.
- P/B-only entry, Tie rejection/reporting, Brain migration compatibility, pattern ledger, walk-forward audit, and risk panels remain in place.

## Scenario checks from the actual engine

| Input | Rapid Read | Support | Notes |
|---|---|---|---|
| `PBP` (3 outcomes) | `WARMUP_FAST_READ`, neutral | `WARMUP` | Count shown as 3/4; this is only warm-up, not a 12-result system lock |
| `PBPB` | `NEUTRAL`, score 0.002 | `VERY_LOW_SUPPORT` | Balanced short sequence does not generate a directional lean |
| `PPPP` | `P LEAN`, score 0.169 | `VERY_LOW_SUPPORT` | A very short all-P run triggers only a low-support heuristic; no probability is issued |
| `PBPBPBPBPBPB` | `NEUTRAL`, score 0.003 | `LOW_SUPPORT` | Alternation is shown as context, not treated as a guarantee of another alternation |
| `PPBBPPBBPPBB` | `NEUTRAL`, score 0.000 | `LOW_SUPPORT` | Repeating 2–2 shape phase guard stops a temporary last-six count imbalance from forcing B lean |
| `BBBBBBBBBBBBPPPPPPPPPPPP` | `P LEAN`, score 0.186 | `LIMITED_SUPPORT` | 12-vs-12 shift is labeled candidate, not confirmed regime change |
| `PB` repeated 50 times | `NEUTRAL`, score 0.004 | `HISTORICAL_SUPPORT_ONLY` | Transition counts do not overrule the long alternating history |
| `P` repeated 12 times | `P LEAN`, score 0.258 | `LOW_SUPPORT` | Streak is detected; no claim that the next outcome has 100% probability |

For all cases, `probability=null`, `validated=false`, and `edge_claim=false`.

## Automated verification
- Python server/dashboard/learning regression: 45 tests passed.
- Rapid analyst engine: 14 tests passed, including exhaustive P/B sequences of length 0–10 (2,047 sequences) and a rapid read over 100,000 outcomes. A five-run Node benchmark measured 13.03–24.41 ms (median 17.78 ms) for `rapidRead()` on 100,000 outcomes in this build container; this is not a runtime guarantee on the user's machine.
- Pattern engine: 15 tests passed.
- Brain import guard: 5 tests passed.
- Roadmap parser: 3 tests passed.
- Total: **82 automated tests passed**.
- JavaScript syntax checking, Python compilation, inline-script syntax checks, HTTP health/version/dashboard route checks, and ZIP integrity/checksum verification are included in the build verification steps.

## Important limitations
1. The new directional score is a **heuristic** created for faster reading, not a calibrated forecast model. The above scenario tests demonstrate software behavior, not prediction accuracy.
2. P/B road shapes and sequence history alone do not expose the remaining shoe card composition. No positive expected value or profitable edge is claimed.
3. Memory/learning remains handled by the persistent prospective pattern ledger and existing Brain-compatible workflow. Forecasts should be locked before results, then scored by session. The quick-read coefficients are not automatically updated from a single outcome, to avoid overfitting.
4. A full Chromium browser E2E run could not be completed in this environment: navigation to both the local HTTP dashboard and the local HTML file was blocked by the environment's administrator policy. The actual server `/api/health` endpoint, FastAPI dashboard/asset routes, inline-script syntax, and regression tests were checked. Verify in the user's Windows browser after installation.
