# NEXUS ARC V5.9.7 — Brain Export Audit

**Audit date:** 2026-10-15 (Asia/Bangkok)  
**Source:** three user-supplied NEXUS ARC V5.9.2 Brain JSON exports. Original Brain files are not embedded in the release bundle.

## Executive finding

The three Brain exports are structurally readable and their embedded SHA-256 checksums validate against the application’s canonicalization method. They contain 131 recorded P/B prediction cases across three saved histories. Their current observed metrics do **not** show evidence of predictive edge: each file has mean log loss above the uniform 50/50 diagnostic baseline of ln(2) ≈ 0.6931 and Brier sum above 0.5000. Samples are small, lack session/shoe IDs and contain no recorded T outcomes, so this is a cautionary diagnostic—not a definitive statistical verdict.

## Per-export measurements

| Export (UTC) | History / P-B-T | Cases | Top-probability accuracy | Recorded P/B actions correct | WAIT | Log loss | Brier sum | Hazard expert >99% confident |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| 2026-10-15T03-07-30-679Z.json | 58 / 23-35-0 | 50 | 29/50 (58.0%) | 13/26 (50.0%) | 24 | 0.7127 | 0.5176 | 8/50 |
| 2026-10-15T03-26-00-045Z.json | 60 / 30-30-0 | 52 | 26/52 (50.0%) | 18/35 (51.4%) | 17 | 0.7115 | 0.5170 | 11/52 |
| 2026-10-15T03-34-01-151Z.json | 37 / 17-20-0 | 29 | 12/29 (41.4%) | 7/19 (36.8%) | 10 | 0.7419 | 0.5473 | 10/29 |

**Metric definitions.** Top-probability accuracy selects P or B from the larger saved probability even when the recorded action is `WAIT`; it is therefore not betting accuracy. “Recorded P/B actions correct” excludes `WAIT`. Log loss and Brier sum are calculated from the saved P/B probabilities at each recorded case, conditional on the stored P/B target. Lower is better. The 50/50 values are simple no-information diagnostics, not an exact baccarat payout/EV benchmark.

## Combined descriptive totals — not an inferential aggregate

- Saved cases: **131**; argmax outcomes correct: **67/131 (51.1%)**.
- Actions P/B (excluding WAIT): **80**, correct **38/80 (47.5%)**.
- Row-weighted log loss: **0.7187** vs uniform baseline **0.6931**.
- Row-weighted Brier sum: **0.5239** vs uniform baseline **0.5000**.

These arithmetic totals are provided for inspection only. Do **not** treat 131 cases as 131 independent samples: session/shoe boundaries are missing, and the three histories cannot be safely classified as independent shoes.

## Data-integrity and comparability checks

- All three exports declare schema `NEXUS-ARC-V5.9.2-CONTEXT-ISOLATION-INTEGRITY`; checksums verified: `PASS` for `NEXUS_ARC_V5_9_2_Brain_2026-10-15T03-07-30-679Z.json`, `PASS` for `NEXUS_ARC_V5_9_2_Brain_2026-10-15T03-26-00-045Z.json`, `PASS` for `NEXUS_ARC_V5_9_2_Brain_2026-10-15T03-34-01-151Z.json`.

- For each export, every stored case’s `actual` matches `history[at]`; each `auditTail` also matches the final case `auditHash`. This establishes internal consistency with the saved data, **not** proof that each forecast was cryptographically time-stamped before its outcome.

- All histories contain **zero T outcomes** (155 recorded outcomes total). Confirm whether Tie results were intentionally omitted; if so, these records evaluate only the filtered P/B sequence and do not test Tie handling.

- No `session`, `shoe`, or `cluster` identifier occurs anywhere in these Brain JSONs. The first and third histories share only the first 7 outcomes (`BBPBPBB`) then diverge; the second has no shared prefix with either. Their relationship is therefore ambiguous.

- Top-level `events` is empty in all three exports. There is no evaluation/lesson ledger in the learner object, and selection reports `lastEval=0`, `totalTrials=0`. The model states contain online counters and weights, but there is no recorded formal challenger evaluation or promotion trial.

- The `hazard` expert is extremely confident (>99%) in 8/50, 11/52, and 10/29 cases respectively. The corresponding weak-expert loss log has losses ≥10 in 4, 4, and 5 records; a log loss of about 13.8155 is consistent with assigning the realized side probability near 0.000001. This is a concrete reason to cap/smooth extreme expert probabilities and calibrate them before letting them influence an ensemble.

## Safely using these exports

1. Treat each JSON as a **saved Brain snapshot**, not a partial data chunk. Importing one replaces the active history/learner state; importing all three one after another does not merge them and simply overwrites the previous imported state.
2. Keep the original files unchanged. Do not pool their weights, calibration rows, contexts, or model counters; the histories are not guaranteed to be independent and have no reliable shoe/session IDs.
3. Use these cases for exploratory diagnosis only. New validation should use the prospective pattern ledger: enter a stable shoe/session ID, lock each forecast before the outcome, record ties explicitly, and maintain one ID per shoe/session. Target at least 100 resolved prospective forecasts over at least 20 distinct sessions before considering independent replication, with no automatic betting signal.

## V5.9.6 software change driven by this audit

V5.9.6 added an import-context guard: before a valid Brain import swaps the active history/learner, any pending prospective pattern forecast is marked `CANCELLED` with reason `brain_import_replaced_history` and is not scored against the imported history. If the Brain import fails to save, the helper attempts to restore the previous prospective ledger snapshot. The prospective ledger schema remains `nexus-arc-v5.9.5-pattern-audit-ledger-v1`; the Brain learner schema remains V5.9.2 for migration compatibility. App/API release version at that time was V5.9.6.

## Raw SHA-256 of the supplied files

- `NEXUS_ARC_V5_9_2_Brain_2026-10-15T03-07-30-679Z.json` — `8209cf63d895c1f477aa9259f19efc30f5b213bbc8f0a03677624bcf03801bf6`

- `NEXUS_ARC_V5_9_2_Brain_2026-10-15T03-26-00-045Z.json` — `1eb742e5ec3576c3bb92c765653f536d02b332fba78f7efad18145f8ade3939b`

- `NEXUS_ARC_V5_9_2_Brain_2026-10-15T03-34-01-151Z.json` — `6baf0dd5028b5bb2b7ca2a03048921d563dfb4cd4ddb4aa29684b2094ab43cff`


**Limitations:** The evaluation is reconstructed from saved forecast probabilities and actual labels. It cannot verify external event time, randomization of session selection, bet settlement rules, profitability after commission, or the independence of observations. No claim of predictive edge is supported by these files.
