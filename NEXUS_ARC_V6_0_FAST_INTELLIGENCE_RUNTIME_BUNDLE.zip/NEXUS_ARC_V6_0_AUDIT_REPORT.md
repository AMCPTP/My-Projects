# NEXUS ARC V6.0.0 — Fast Intelligence & Multi-Lens Analyst

## Release intent
V6.0 is a first implementation of the proposed intelligence-layer upgrade. It preserves the V5.10.1 rapid P/B analysis as a compatibility base, adds cross-window synthesis and a prospective read ledger, and separates fast descriptive reads from independent predictive validation.

## Implemented
- Active server identity `6.0.0`; default dashboard is `NEXUS_ARC_V6_0_INTELLIGENCE_ANALYST_DESK.html`.
- Explicit asset allowlist includes the legacy pattern engine, V5.10.1 rapid engine, and V6.0 intelligence engine.
- Quick Read remains available after 4 accepted P/B results; the separate validation gate is not used to block the first read.
- Multi-lens comparison uses recent 6, recent 12, recent 20 and all-history descriptive windows with shrinkage around the fixed reference. Material short-vs-history conflicts suppress the directional headline to NEUTRAL.
- Alternation, 2–2 shapes, streaks, transition counts, repeated suffixes and shift candidates remain descriptive context; none is independently treated as proof of the next result.
- Adds a prospective lean ledger that freezes the current read and P/B prefix before the next accepted outcome, then scores only after history extends beyond that prefix. Prefix edits/replacements cancel pending rows instead of scoring against the wrong outcome.
- NEUTRAL records count toward coverage, not directional misses. Directional accuracy is compared to a fixed always-B descriptive reference. No automatic weight changes or model promotion.
- Brain import integration cancels pending V6 reads on history replacement and supports rollback if import fails.
- Existing V5.10.1 engines, pattern audit ledger, legacy learning/assurance APIs and server data remain in the package for compatibility.

## Automated verification performed in this build environment
- Python regression/server/dashboard tests: 47 passed.
- Legacy pattern engine tests: 15 passed.
- V5.10.1 Brain import guard tests: 5 passed.
- V5.10.1 rapid analyst tests: 14 passed.
- Roadmap parser tests: 3 passed.
- V6.0 intelligence engine tests: 15 passed.
- V6.0 Brain import guard tests: 4 passed.
- Total: **103 automated tests passed**.
- Python compile check passed for server and learning modules.
- `node --check` passed for the V6 engine; all 11 inline JavaScript blocks in the V6 dashboard passed syntax checks.
- The V6 engine test exhaustively checks all 2,047 binary P/B sequences of length 0–10, ledger invariants and a 100,000-result history. In this run the 100,000-result `rapidRead` benchmark was 83.58 ms in the build container; this is not a performance guarantee on the user's computer.
- Regression suite includes health/version/dashboard and asset-route checks. ZIP integrity and SHA-256 are generated as part of release packaging.

## Limitations / honest interpretation
1. A Quick Read is an **uncalibrated heuristic**, not a calibrated probability, betting instruction, or demonstrated predictive edge.
2. Rolling windows overlap and are not independent samples. Window agreement is diagnostic only.
3. P/B sequence history and road shapes do not reveal remaining card composition in the shoe.
4. The V6 prospective ledger is stored in browser `localStorage`; it can be edited and is not server-attested or independently timestamped. Session/shoe IDs are operator-entered.
5. A fixed always-B baseline is only a simple descriptive comparison. Accuracy alone does not establish positive expected value.
6. No profitability, EV or guaranteed prediction is claimed. Any predictive-performance claim requires sufficiently large prospective samples, session-separated walk-forward tests, calibration and independent replication.
7. Full browser end-to-end interaction on the user's Windows computer has not been performed in this environment. The build has syntax, automated regression, route/health, and package-integrity checks; post-install browser verification remains necessary.

## Installation / upgrade
1. Stop NEXUS ARC if running.
2. Back up the full installation folder, `.env`, `nexus_v5_0_data` if present, Brain exports and any browser-localStorage records you want to preserve.
3. Extract this release ZIP over the existing installation folder, allowing matching application files to be updated. Do not delete `.env` or user-data folders.
4. Run `start_nexus_arc_v5_9.bat`.
5. Verify `http://127.0.0.1:8787/api/health` reports version `6.0.0` and dashboard `NEXUS_ARC_V6_0_INTELLIGENCE_ANALYST_DESK.html`.
6. If the configured port is occupied by an unrelated process, the launcher refuses to kill it. Resolve the port conflict manually or set `NEXUS_PORT` in `.env`.

## Prospective ledger use
1. Enter the live P/B results and verify the history.
2. Enter a stable shoe/session ID.
3. Click “ล็อก V6 Quick Read ก่อนผล” before the next result is known.
4. Enter the next real P/B result. The ledger resolves the frozen read against the first result after the saved prefix.
5. If the history is edited/replaced before resolution, the pending read is cancelled rather than scored.
6. Export the ledger periodically. Do not treat local browser storage as tamper-proof evidence.
