NEXUS ARC V6.0.0 — FAST INTELLIGENCE + MULTI-LENS ANALYST

WHAT THIS RELEASE DOES
- Keeps the existing V5.10.1 P/B-only analyst as a compatibility base and adds a V6.0 intelligence layer.
- Quick Read remains available from 4 accepted P/B results; deep historical review and validation do not block the first read.
- Compares recent 6, recent 12, recent 20, and all-history descriptive windows using a shrinkage reference.
- Detects material recent-vs-history disagreements. When those lenses conflict by the defined criteria, V6 suppresses the directional headline to NEUTRAL instead of picking a side by force.
- Shows window hints, evidence level, conflict status, support/against reasons, shift information, and invalidation caveats.
- Keeps patterns, streaks, transitions, repeated suffixes, and shift as descriptive context. It does not turn those shapes into a next-hand probability.
- Adds a V6 prospective lean ledger: lock the current live-history read before the next outcome, then auto-score against the next accepted P/B result when the live history extends. It records source lean, final lean, evidence level, conflict state, frozen prefix, session ID, outcome, and hit/miss.
- Neutral reads are counted as coverage-only, not directional misses. Directional accuracy is shown against a fixed always-B descriptive reference. There is no auto-promotion or automatic weight change.
- Existing Brain import guard, pattern audit ledger, legacy learning/assurance API, and dashboard modules are retained.

IMPORTANT LIMITATIONS
- A Quick Read is an uncalibrated heuristic, not a next-hand probability or betting instruction.
- Rolling windows overlap. They are not independent samples, and the agreement count must not be interpreted as independent evidence.
- The V6 ledger lives in browser localStorage. It can be edited and is not independently timestamped or server-attested. Session IDs are operator-entered.
- Historical road patterns and P/B sequence alone do not reveal the cards remaining in a shoe.
- The displayed fixed-B comparison is only a simple descriptive reference, not proof of predictive edge. Accuracy alone is insufficient.
- No EV, profit, or guaranteed prediction is claimed. Prospective logs need enough independent sessions and replication before any model-performance claim.
- The package was tested in the build environment; browser end-to-end operation on the user's Windows computer has not been performed.

WINDOWS INSTALL / UPGRADE
1. Stop NEXUS ARC if it is running.
2. Back up the whole installation folder, .env, nexus_v5_0_data (if present), Brain exports, and any localStorage-backed records you wish to preserve. The new V6 ledger starts under its own schema/key and does not overwrite V5 ledgers.
3. Extract this ZIP over the existing installation folder, allowing matching application files to be updated. Do not delete .env or user data folders.
4. Run start_nexus_arc_v5_9.bat. The launcher expects version 6.0.0 and the exact V6 dashboard filename before opening a browser.
5. Verify http://127.0.0.1:8787/api/health reports version 6.0.0 and dashboard NEXUS_ARC_V6_0_INTELLIGENCE_ANALYST_DESK.html.
6. If a local port conflict occurs, do not terminate an unrelated process; the launcher is designed to stop only a known NEXUS server process.

HOW TO USE V6 PROSPECTIVE LEAN MEMORY
1. Enter P/B outcomes through live result buttons and verify the live history is correct.
2. Enter a stable session/shoe ID (3–80 letters/digits/dot/underscore/colon/hyphen).
3. Click “ล็อก V6 Quick Read ก่อนผล” before the next result is known.
4. Add the next real live P/B outcome. The ledger resolves the frozen prediction against the first result beyond the prefix. If history is replaced/edited before resolution, the pending row is cancelled rather than scored.
5. Export the V6 ledger JSON periodically. Do not edit the ledger manually. If a schema/validation problem is found, writes are blocked to protect existing data.

TEST COMMANDS
- py -3 -m unittest -v test_nexus_arc_v5_10_1_regression.py
- node test_nexus_arc_v5_9_5_pattern_engine.js
- node test_nexus_arc_v5_10_1_brain_import_guard.js
- node test_nexus_arc_v5_10_1_rapid_analyst_engine.js
- node test_nexus_arc_v5_10_1_roadmap_parser.js
- node test_nexus_arc_v6_0_intelligence_engine.js
- node test_nexus_arc_v6_0_brain_import_guard.js
- node --check nexus_arc_v6_0_intelligence_engine.js

COMPATIBILITY NOTE
Files with V5.10.1 in their filename remain intentionally present as the tested compatibility layer and legacy test harness. The active runtime release identity is V6.0.0.
