"""NEXUS ARC V4.8 prospective learning, coverage gates, and tamper-evident ledger.

Standard-library-only core. The hash chain is tamper-evident, not a digital signature
or proof of who entered a record. Forecast and outcome timestamps are server assigned.
"""
from __future__ import annotations

import hashlib
import hmac
import json
import math
import random
import re
from collections import Counter, defaultdict
from datetime import datetime, timezone, timedelta
from typing import Any

SCHEMA = "NEXUS-ARC-V4.8-PROSPECTIVE-LEARNING-1"
GENESIS = "GENESIS"
MAX_EVENTS = 20000
EPS = 1e-6
MODEL_ID_RE = re.compile(r"^[A-Za-z0-9_.:-]{1,80}$")
ERROR_CATEGORIES = {
    "input_stale", "source_gap", "source_conflict", "data_quality",
    "reasoning", "model_misspecification", "overconfidence", "distribution_shift", "unknown"
}
ROLES = {"champion", "challenger", "standalone"}


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="microseconds").replace("+00:00", "Z")


def parse_time(value: Any) -> datetime | None:
    if not isinstance(value, str) or not value.strip():
        return None
    try:
        dt = datetime.fromisoformat(value.strip().replace("Z", "+00:00"))
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt.astimezone(timezone.utc)
    except (ValueError, TypeError, OverflowError):
        return None


def canonical(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False)


def sha256(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def normalize_probabilities(raw: Any, field_name: str = "probabilities") -> dict[str, float]:
    if not isinstance(raw, dict) or not 2 <= len(raw) <= 8:
        raise ValueError(f"{field_name} must be an object with 2–8 outcome labels")
    clean: dict[str, float] = {}
    for key, value in raw.items():
        label = str(key).strip()
        if not label or len(label) > 60 or label in clean:
            raise ValueError(f"{field_name} contains an invalid/duplicate label")
        if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(float(value)):
            raise ValueError(f"{field_name}[{label}] must be a finite number")
        num = float(value)
        if num < 0 or num > 1:
            raise ValueError(f"{field_name}[{label}] must be between 0 and 1")
        clean[label] = num
    total = sum(clean.values())
    if total <= 0:
        raise ValueError(f"{field_name} must sum to more than zero")
    return {k: v / total for k, v in clean.items()}


def normalize_coverage(domain: str, raw: Any, now: datetime | None = None) -> dict[str, Any]:
    now = now or datetime.now(timezone.utc)
    raw = raw if isinstance(raw, dict) else {}
    sources = raw.get("sources", [])
    missing = raw.get("missing_critical_inputs", [])
    if not isinstance(sources, list) or len(sources) > 20:
        raise ValueError("coverage.sources must be a list of at most 20 source names/URLs")
    if not isinstance(missing, list) or len(missing) > 30:
        raise ValueError("coverage.missing_critical_inputs must be a list of at most 30 items")
    sources = [str(s).strip()[:500] for s in sources if str(s).strip()]
    missing = [str(s).strip()[:300] for s in missing if str(s).strip()]
    stale_after = raw.get("stale_after_seconds", 3600)
    if isinstance(stale_after, bool) or not isinstance(stale_after, (int, float)) or not 1 <= int(stale_after) <= 31 * 86400:
        raise ValueError("stale_after_seconds must be in 1..2678400")
    checked = raw.get("source_checked_at")
    as_of = raw.get("source_as_of")
    checked_dt = parse_time(checked) if checked else None
    as_of_dt = parse_time(as_of) if as_of else None
    if checked and checked_dt is None:
        raise ValueError("coverage.source_checked_at must be a valid ISO-8601 timestamp")
    if as_of and as_of_dt is None:
        raise ValueError("coverage.source_as_of must be a valid ISO-8601 timestamp")
    reasons: list[str] = []
    if raw.get("force_abstain") is True:
        reasons.append("manual abstention requested")
    if missing:
        reasons.append("missing critical inputs: " + ", ".join(missing[:5]))
    if domain != "sequence_pbt":
        if not sources:
            reasons.append("no provenance sources were supplied")
        if checked_dt is None:
            reasons.append("source check time is missing")
        else:
            if checked_dt > now + timedelta(minutes=5):
                reasons.append("source check time is in the future")
            age = max(0.0, (now - checked_dt).total_seconds())
            if age > int(stale_after):
                reasons.append(f"source check is stale ({int(age)}s > {int(stale_after)}s)")
        if as_of_dt and checked_dt and as_of_dt > checked_dt + timedelta(minutes=5):
            reasons.append("source_as_of is later than source_checked_at")
        if as_of_dt:
            content_age = max(0.0, (now - as_of_dt).total_seconds())
            if content_age > int(stale_after):
                reasons.append(f"source content is stale ({int(content_age)}s > {int(stale_after)}s)")
    else:
        # Local P/B/T data can be checked without external sources, but this never
        # establishes predictive advantage for randomized games.
        if checked_dt and checked_dt > now + timedelta(minutes=5):
            reasons.append("source check time is in the future")
    return {
        "sources": sources,
        "source_count": len(sources),
        "source_checked_at": checked_dt.isoformat().replace("+00:00", "Z") if checked_dt else None,
        "source_as_of": as_of_dt.isoformat().replace("+00:00", "Z") if as_of_dt else None,
        "stale_after_seconds": int(stale_after),
        "missing_critical_inputs": missing,
        "force_abstain": raw.get("force_abstain") is True,
        "coverage_note": str(raw.get("coverage_note") or "Coverage reflects only the supplied sources and timestamps.")[:1000],
        "freshness_age_seconds": round(max(0.0, (now - checked_dt).total_seconds()), 1) if checked_dt else None,
        "gate_reasons": reasons,
    }


def verify_chain(events: Any) -> dict[str, Any]:
    if not isinstance(events, list):
        return {"valid": False, "checked": 0, "bad_index": 0, "reason": "ledger root is not a list", "last_hash": None}
    if len(events) > MAX_EVENTS:
        return {"valid": False, "checked": 0, "bad_index": 0, "reason": "ledger exceeds supported event limit", "last_hash": None}
    prev = GENESIS
    for index, event in enumerate(events):
        if not isinstance(event, dict):
            return {"valid": False, "checked": index, "bad_index": index, "reason": "event is not an object", "last_hash": prev}
        if type(event.get("seq")) is not int or event.get("seq") != index + 1 or event.get("prev_hash") != prev:
            return {"valid": False, "checked": index, "bad_index": index, "reason": "sequence or previous hash mismatch", "last_hash": prev}
        if not isinstance(event.get("event_id"), str) or not event["event_id"].strip():
            return {"valid": False, "checked": index, "bad_index": index, "reason": "event_id is missing or invalid", "last_hash": prev}
        if not isinstance(event.get("event_type"), str) or not event["event_type"].strip():
            return {"valid": False, "checked": index, "bad_index": index, "reason": "event_type is missing or invalid", "last_hash": prev}
        if not isinstance(event.get("payload"), dict):
            return {"valid": False, "checked": index, "bad_index": index, "reason": "event payload must be an object", "last_hash": prev}
        if parse_time(event.get("created_at")) is None:
            return {"valid": False, "checked": index, "bad_index": index, "reason": "event timestamp is missing or invalid", "last_hash": prev}
        payload = event["payload"]
        required_by_type = {
            "forecast_created": ("forecast_id", "event_key", "domain", "model_id", "probabilities", "gate_status"),
            "outcome_recorded": ("event_key", "outcome"),
            "error_reviewed": ("forecast_id", "category"),
        }
        required = required_by_type.get(event["event_type"])
        if required is None or any(key not in payload for key in required):
            return {"valid": False, "checked": index, "bad_index": index, "reason": "event type or payload schema is unsupported", "last_hash": prev}
        given = event.get("event_hash")
        material = {k: v for k, v in event.items() if k != "event_hash"}
        try:
            expected = sha256(canonical(material))
        except (TypeError, ValueError):
            return {"valid": False, "checked": index, "bad_index": index, "reason": "event cannot be canonicalized", "last_hash": prev}
        if not isinstance(given, str) or not hmac.compare_digest(given, expected):
            return {"valid": False, "checked": index, "bad_index": index, "reason": "event hash mismatch", "last_hash": prev}
        prev = given
    return {"valid": True, "checked": len(events), "bad_index": None, "reason": "hash chain verified (tamper-evident; not a signature)", "last_hash": prev if events else GENESIS}


def append_event(events: list[dict[str, Any]], event_type: str, payload: dict[str, Any], now: str | None = None) -> dict[str, Any]:
    verification = verify_chain(events)
    if not verification["valid"]:
        raise ValueError("learning ledger integrity failure; writes disabled until reviewed")
    if len(events) >= MAX_EVENTS:
        raise ValueError("learning ledger reached its event limit; archive before adding more")
    event = {
        "seq": len(events) + 1,
        "event_id": __import__("uuid").uuid4().hex,
        "event_type": event_type,
        "created_at": now or utc_now(),
        "payload": payload,
        "prev_hash": verification["last_hash"],
    }
    event["event_hash"] = sha256(canonical(event))
    events.append(event)
    return event


def project_ledger(events: list[dict[str, Any]]) -> dict[str, Any]:
    forecasts: dict[str, dict[str, Any]] = {}
    outcomes: dict[str, dict[str, Any]] = {}
    reviews: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for event in events:
        p = event.get("payload") if isinstance(event.get("payload"), dict) else {}
        kind = event.get("event_type")
        if kind == "forecast_created":
            row = dict(p)
            row["created_at"] = event.get("created_at")
            row["forecast_event_hash"] = event.get("event_hash")
            row["ledger_seq"] = event.get("seq")
            forecasts[row["forecast_id"]] = row
        elif kind == "outcome_recorded":
            outcomes[str(p.get("event_key"))] = {**p, "recorded_at": event.get("created_at"), "ledger_seq": event.get("seq")}
        elif kind == "error_reviewed":
            reviews[str(p.get("forecast_id"))].append({**p, "recorded_at": event.get("created_at"), "ledger_seq": event.get("seq")})
    return {"forecasts": forecasts, "outcomes": outcomes, "reviews": reviews}


def _case_metrics(rows: list[dict[str, Any]]) -> dict[str, Any]:
    if not rows:
        return {"n": 0, "accuracy": None, "log_loss": None, "brier": None, "mean_confidence": None, "calibration_gap": None, "confidence_bias": None, "calibration_bins": []}
    acc = []; losses = []; briers = []; conf = []
    for row in rows:
        probs, actual = row["probabilities"], row["actual"]
        if not isinstance(probs, dict) or actual not in probs or not probs:
            continue
        total = sum(float(v) for v in probs.values())
        normalized = {str(k): float(v) / total for k, v in probs.items()} if total > 0 else {}
        if not normalized or actual not in normalized:
            continue
        confidence = max(normalized.values())
        acc.append(1.0 if max(normalized, key=normalized.get) == actual else 0.0)
        losses.append(-math.log(max(EPS, min(1.0, normalized[actual]))))
        briers.append(sum((value - (1.0 if label == actual else 0.0)) ** 2 for label, value in normalized.items()))
        conf.append(confidence)
    if not acc:
        return {"n": 0, "accuracy": None, "log_loss": None, "brier": None, "mean_confidence": None, "calibration_gap": None, "confidence_bias": None, "calibration_bins": []}
    accuracy = sum(acc) / len(acc); mean_conf = sum(conf) / len(conf)
    bins = []; ece = 0.0; n = len(acc)
    for index in range(10):
        lower, upper = index / 10, (index + 1) / 10
        members = [i for i, value in enumerate(conf) if value >= lower and (value < upper or (index == 9 and value <= upper))]
        if not members:
            continue
        bin_conf = sum(conf[i] for i in members) / len(members)
        bin_acc = sum(acc[i] for i in members) / len(members)
        gap = abs(bin_conf - bin_acc)
        contribution = len(members) / n * gap
        ece += contribution
        bins.append({"bin": index + 1, "n": len(members), "mean_confidence": round(bin_conf, 6), "accuracy": round(bin_acc, 6), "gap": round(gap, 6), "contribution": round(contribution, 6)})
    return {"n": n, "accuracy": round(accuracy, 6), "log_loss": round(sum(losses) / n, 6),
            "brier": round(sum(briers) / n, 6), "mean_confidence": round(mean_conf, 6),
            "calibration_gap": round(ece, 6), "confidence_bias": round(mean_conf - accuracy, 6), "calibration_bins": bins,
            "calibration_method": "top-label expected calibration error; 10 equal-width confidence bins",
            "interpretation": "descriptive and sample-sensitive; not evidence of future performance by itself"}


def _paired_ci(diffs: list[float], n_boot: int = 1200, cluster_ids: list[str | None] | None = None) -> dict[str, Any]:
    n = len(diffs)
    if n < 2:
        return {"n": n, "mean_difference": round(sum(diffs)/n, 6) if n else None, "ci95": None}
    usable_clusters = bool(cluster_ids) and len(cluster_ids) == n and all(isinstance(x, str) and x.strip() for x in cluster_ids)
    rng = random.Random(20261011 + n + (len(set(cluster_ids)) if usable_clusters else 0))
    means = []
    if usable_clusters:
        grouped: dict[str, list[float]] = defaultdict(list)
        for cluster, difference in zip(cluster_ids, diffs):
            grouped[str(cluster)].append(difference)
        keys = sorted(grouped)
        # Resample whole clusters, not individual hands, to preserve within-session dependence.
        for _ in range(n_boot):
            sampled = [keys[rng.randrange(len(keys))] for _ in keys]
            values = [value for key in sampled for value in grouped[key]]
            means.append(sum(values) / len(values))
        method = "paired cluster percentile bootstrap; clusters are operator-declared and not independently verified"
        cluster_count = len(keys)
    else:
        for _ in range(n_boot):
            means.append(sum(diffs[rng.randrange(n)] for _ in range(n)) / n)
        method = "paired row-wise percentile bootstrap; assumes independent rows and may understate uncertainty for clustered data"
        cluster_count = None
    means.sort()
    result = {"n": n, "mean_difference": round(sum(diffs) / n, 6),
            "ci95": [round(means[int(0.025 * (n_boot - 1))], 6), round(means[int(0.975 * (n_boot - 1))], 6)],
            "method": method}
    if cluster_count is not None:
        result["independent_cluster_count"] = cluster_count
    return result


def build_summary(events: Any) -> dict[str, Any]:
    chain = verify_chain(events)
    if not chain["valid"]:
        return {"schema": SCHEMA, "integrity": chain, "write_gate": "BLOCKED", "note": "Ledger integrity failed; scoring summary is withheld."}
    projected = project_ledger(events)
    forecasts = list(projected["forecasts"].values())
    outcomes = projected["outcomes"]
    for f in forecasts:
        outcome = outcomes.get(f["event_key"])
        if outcome and outcome.get("outcome") in f["probabilities"]:
            f["actual"] = outcome["outcome"]
            f["outcome_recorded_at"] = outcome.get("recorded_at")
    scored = [f for f in forecasts if "actual" in f]
    model_ids = sorted({str(f.get("model_id") or "unknown") for f in forecasts})
    per_model = {}
    for model_id in model_ids:
        all_f = [f for f in forecasts if f.get("model_id") == model_id]
        rows = [{"probabilities": f["probabilities"], "actual": f["actual"]} for f in all_f if "actual" in f]
        eligible = [f for f in all_f if f.get("gate_status") == "ALLOW"]
        eligible_rows = [{"probabilities": f["probabilities"], "actual": f["actual"]} for f in eligible if "actual" in f]
        b_rows = []
        p = projected
        for f in all_f:
            if "actual" in f and isinstance(f.get("baseline_probabilities"), dict):
                b_rows.append({"probabilities": f["baseline_probabilities"], "actual": f["actual"]})
        gate_counts = Counter(f.get("gate_status", "UNKNOWN") for f in all_f)
        per_model[model_id] = {
            "role": (all_f[-1].get("role") if all_f else "unknown"),
            "forecast_count": len(all_f), "scored_count": len(rows),
            "all_forecasts": _case_metrics(rows), "gate_allowed_scored": _case_metrics(eligible_rows),
            "baseline_on_matched_cases": _case_metrics(b_rows), "gate_counts": dict(gate_counts),
            "error_reviews": sum(len(projected["reviews"].get(f.get("forecast_id"), [])) for f in all_f),
        }
    # Compare challenger and champion on matched event_key values, with one outcome per event.
    model_lookup: dict[tuple[str, str], dict[str, Any]] = {}
    for f in forecasts:
        model_lookup[(str(f["event_key"]), str(f["model_id"]))] = f
    comparisons = []
    champion_ids = [m for m, x in per_model.items() if x.get("role") == "champion"]
    challenger_ids = [m for m, x in per_model.items() if x.get("role") == "challenger"]
    for champ in champion_ids:
        for cand in challenger_ids:
            diffs = []; brier_diffs = []; paired_clusters: list[str | None] = []; comparison_domain = None
            for event_key, outcome in outcomes.items():
                a = model_lookup.get((event_key, champ)); b = model_lookup.get((event_key, cand))
                if not a or not b or outcome.get("outcome") not in a["probabilities"] or outcome.get("outcome") not in b["probabilities"]:
                    continue
                y = outcome["outcome"]
                la = -math.log(max(EPS, a["probabilities"][y])); lb = -math.log(max(EPS, b["probabilities"][y]))
                ba = sum((v - (1.0 if k == y else 0.0)) ** 2 for k, v in a["probabilities"].items())
                bb = sum((v - (1.0 if k == y else 0.0)) ** 2 for k, v in b["probabilities"].items())
                diffs.append(lb - la); brier_diffs.append(bb - ba)
                cluster_a, cluster_b = a.get("cluster_id"), b.get("cluster_id")
                paired_clusters.append(cluster_a if cluster_a and cluster_a == cluster_b else None)
                comparison_domain = a.get("domain")
            clusters_complete = bool(paired_clusters) and all(paired_clusters)
            ci = _paired_ci(diffs, cluster_ids=paired_clusters if clusters_complete else None)
            brier_delta = sum(brier_diffs) / len(brier_diffs) if brier_diffs else None
            n = len(diffs)
            enough = n >= 60
            interval = ci.get("ci95")
            independent_clusters = len(set(paired_clusters)) if clusters_complete else 0
            cluster_gate_blocked = comparison_domain == "sequence_pbt" and independent_clusters < 20
            pass_stat = bool(enough and interval and interval[1] < 0 and brier_delta is not None and brier_delta <= 0 and not cluster_gate_blocked)
            if cluster_gate_blocked:
                promotion_gate = "NOT_ENOUGH_INDEPENDENT_CLUSTERS"
            elif pass_stat:
                promotion_gate = "ELIGIBLE_FOR_REVIEW"
            elif not enough:
                promotion_gate = "NOT_ENOUGH_DATA"
            else:
                promotion_gate = "NOT_PASSED"
            comparisons.append({"champion": champ, "challenger": cand, "matched_n": n,
                "log_loss_difference_candidate_minus_champion": ci.get("mean_difference"), "paired_log_loss_ci95": interval,
                "brier_difference_candidate_minus_champion": round(brier_delta, 6) if brier_delta is not None else None,
                "promotion_gate": promotion_gate, "independent_cluster_count": independent_clusters or None,
                "auto_promotion": False,
                "note": ("P/B/T comparisons require at least 20 distinct, matched, operator-declared shoe/session clusters before review eligibility; this is a screening floor, not proof of edge." if comparison_domain == "sequence_pbt" else "Gate is only a screening rule; independent audit and ongoing monitoring remain required.")})
    abstentions = Counter()
    source_total = 0
    for f in forecasts:
        if f.get("gate_status") == "ABSTAIN":
            for reason in f.get("gate_reasons", []): abstentions[reason] += 1
        source_total += int((f.get("coverage") or {}).get("source_count", 0))
    categories = Counter()
    for forecast_id, reviews in projected["reviews"].items():
        for review in reviews:
            categories[review.get("category", "unknown")] += 1
    return {
        "schema": SCHEMA,
        "integrity": chain,
        "write_gate": "OPEN",
        "forecast_count": len(forecasts), "unique_event_count": len({f["event_key"] for f in forecasts}),
        "resolved_event_count": len(outcomes), "scored_forecast_count": len(scored),
        "abstained_forecast_count": sum(1 for f in forecasts if f.get("gate_status") == "ABSTAIN"),
        "mean_sources_per_forecast": round(source_total / len(forecasts), 3) if forecasts else 0,
        "models": per_model, "prospective_challenger_comparisons": comparisons,
        "abstention_reasons": dict(abstentions), "error_categories": dict(categories),
        "notes": [
            "Predictions and outcomes are appended as separate server-timestamped events; an outcome can be recorded once per event_key.",
            "Hash chaining detects modification/deletion/reordering when the chain is checked, but does not prove identity, timestamp truth on a compromised host, or external outcome truth.",
            "A prospective cohort is stronger than retrospective pattern search, but user-entered forecasts/outcomes still need independent provenance.",
            "When cluster_id is supplied consistently, paired intervals resample whole clusters to reduce false precision from dependent observations; cluster IDs are operator-declared.",
            "For sequence_pbt, model-comparison review eligibility requires at least 20 distinct matched cluster IDs; missing cluster metadata or fewer clusters blocks promotion review.",
            "Abstention is a quality-control state, not a guarantee that other predictions are correct.",
            "Baccarat P/B/T patterns remain descriptive; the learning layer cannot create information about a random next hand.",
        ],
    }


def validate_forecast_request(raw: dict[str, Any], events: list[dict[str, Any]], now: str | None = None) -> dict[str, Any]:
    if not isinstance(raw, dict): raise ValueError("forecast payload must be an object")
    event_key = str(raw.get("event_key", "")).strip()
    domain = str(raw.get("domain", "general_research")).strip()
    model_id = str(raw.get("model_id", "nexus-arc")).strip()
    role = str(raw.get("role", "standalone")).strip()
    if not re.fullmatch(r"[A-Za-z0-9_.:-]{1,160}", event_key): raise ValueError("event_key must use 1–160 letters, digits, dot, underscore, colon, or hyphen")
    if not re.fullmatch(r"[A-Za-z0-9_.:-]{1,60}", domain): raise ValueError("domain contains unsupported characters")
    if not MODEL_ID_RE.fullmatch(model_id): raise ValueError("model_id must be 1–80 safe characters")
    if role not in ROLES: raise ValueError("role must be champion, challenger, or standalone")
    projections = project_ledger(events)
    if event_key in projections["outcomes"]: raise ValueError("outcome already recorded for this event_key; closed event cannot accept more forecasts")
    probs = normalize_probabilities(raw.get("probabilities"), "probabilities")
    baseline_raw = raw.get("baseline_probabilities")
    baseline = normalize_probabilities(baseline_raw, "baseline_probabilities") if baseline_raw is not None else None
    if baseline is not None and set(baseline) != set(probs): raise ValueError("baseline probability labels must exactly match prediction labels")
    existing_forecasts = list(projections["forecasts"].values())
    if any(f.get("event_key") == event_key and f.get("model_id") == model_id for f in existing_forecasts):
        raise ValueError("this model already has a forecast for this event_key")
    same_event = [f for f in existing_forecasts if f.get("event_key") == event_key]
    if same_event and any(f.get("domain") != domain for f in same_event):
        raise ValueError("all forecasts for the same event_key must use the same domain")
    same_model = [f for f in existing_forecasts if f.get("model_id") == model_id]
    if same_model and any(f.get("role") != role for f in same_model):
        raise ValueError("a model_id must keep a consistent role across the ledger")
    cluster_raw = raw.get("cluster_id")
    cluster_id = str(cluster_raw).strip() if cluster_raw is not None else None
    if cluster_id is not None and not re.fullmatch(r"[A-Za-z0-9_.:-]{1,120}", cluster_id):
        raise ValueError("cluster_id must be 1–120 safe characters when supplied")
    if same_event and any(f.get("cluster_id") != cluster_id for f in same_event):
        raise ValueError("all forecasts for the same event_key must use the same cluster_id")
    server_now = parse_time(now or utc_now()) or datetime.now(timezone.utc)
    coverage = normalize_coverage(domain, raw.get("coverage", {}), server_now)
    threshold = raw.get("confidence_threshold", 0.55)
    if isinstance(threshold, bool) or not isinstance(threshold, (int, float)) or not 0.0 <= float(threshold) <= 1.0:
        raise ValueError("confidence_threshold must be between 0 and 1")
    reasons = list(coverage["gate_reasons"])
    max_prob = max(probs.values())
    if max_prob < float(threshold): reasons.append(f"top probability {max_prob:.3f} below threshold {float(threshold):.3f}")
    gate = "ABSTAIN" if reasons else "ALLOW"
    rationale = str(raw.get("rationale") or "").strip()[:3000]
    forecast_id = __import__("uuid").uuid4().hex
    payload = {
        "forecast_id": forecast_id, "event_key": event_key, "domain": domain,
        "model_id": model_id, "role": role, "probabilities": probs,
        "baseline_probabilities": baseline, "cluster_id": cluster_id, "coverage": coverage,
        "confidence_threshold": float(threshold), "top_probability": max_prob,
        "gate_status": gate, "gate_reasons": reasons, "rationale": rationale,
        "schema": SCHEMA,
    }
    # Do not mutate or reinterpret past entries; append is a separate tamper-evident event.
    return payload


def validate_outcome_request(raw: dict[str, Any], events: list[dict[str, Any]], now: str | None = None) -> dict[str, Any]:
    if not isinstance(raw, dict): raise ValueError("outcome payload must be an object")
    event_key = str(raw.get("event_key", "")).strip()
    outcome = str(raw.get("outcome", "")).strip()
    if not re.fullmatch(r"[A-Za-z0-9_.:-]{1,160}", event_key): raise ValueError("event_key is invalid")
    projected = project_ledger(events)
    forecasts = [f for f in projected["forecasts"].values() if f.get("event_key") == event_key]
    if not forecasts: raise ValueError("no pre-existing forecast for this event_key")
    if event_key in projected["outcomes"]: raise ValueError("outcome has already been recorded for this event_key")
    labels = set(forecasts[0]["probabilities"])
    if any(set(f["probabilities"]) != labels for f in forecasts): raise ValueError("inconsistent outcome labels for this event_key")
    if outcome not in labels: raise ValueError("outcome must match a forecast outcome label")
    server_now = parse_time(now or utc_now()) or datetime.now(timezone.utc)
    observed_raw = raw.get("observed_at")
    observed = parse_time(observed_raw) if observed_raw else server_now
    if observed is None: raise ValueError("observed_at must be valid ISO-8601")
    earliest = min(parse_time(f["created_at"]) for f in forecasts if parse_time(f.get("created_at")))
    if earliest and observed <= earliest: raise ValueError("outcome observed_at must be later than the first server-recorded forecast")
    if observed > server_now + timedelta(minutes=5): raise ValueError("observed_at cannot be in the future")
    return {"event_key": event_key, "outcome": outcome, "observed_at": observed.isoformat().replace("+00:00", "Z"),
            "result_source": str(raw.get("result_source") or "user-entered; not independently verified")[:1000]}


def validate_review_request(raw: dict[str, Any], events: list[dict[str, Any]]) -> dict[str, Any]:
    if not isinstance(raw, dict): raise ValueError("review payload must be an object")
    forecast_id = str(raw.get("forecast_id", "")).strip()
    projected = project_ledger(events)
    f = projected["forecasts"].get(forecast_id)
    if not f: raise ValueError("forecast_id not found")
    category = str(raw.get("category", "unknown")).strip()
    if category not in ERROR_CATEGORIES: raise ValueError("invalid error category")
    if f.get("event_key") not in projected["outcomes"]: raise ValueError("record the observed outcome before reviewing a forecast error")
    return {"forecast_id": forecast_id, "event_key": f["event_key"], "model_id": f["model_id"],
            "category": category, "corrective_action": str(raw.get("corrective_action") or "").strip()[:2000],
            "notes": str(raw.get("notes") or "").strip()[:3000], "status": "human_review_hypothesis"}


def recent_ledger(events: Any, limit: int = 100) -> dict[str, Any]:
    rows = events if isinstance(events, list) else []
    projected = project_ledger(rows) if verify_chain(rows)["valid"] else {"forecasts": {}, "outcomes": {}, "reviews": {}}
    forecasts = projected["forecasts"]
    recent = []
    for e in reversed(rows[-max(1, min(500, int(limit))):]):
        p = e.get("payload", {})
        item = {"seq": e.get("seq"), "event_type": e.get("event_type"), "created_at": e.get("created_at"), "event_hash": e.get("event_hash"), "prev_hash": e.get("prev_hash")}
        if e.get("event_type") == "forecast_created":
            item.update({k: p.get(k) for k in ("forecast_id", "event_key", "domain", "model_id", "role", "probabilities", "baseline_probabilities", "gate_status", "gate_reasons", "coverage")})
            outcome = projected["outcomes"].get(p.get("event_key"))
            item["outcome"] = outcome.get("outcome") if outcome else None
            reviews = projected["reviews"].get(p.get("forecast_id"), [])
            item["latest_review"] = reviews[-1] if reviews else None
        else:
            item["payload"] = p
        recent.append(item)
    return {"count": len(rows), "returned": len(recent), "events": recent}
