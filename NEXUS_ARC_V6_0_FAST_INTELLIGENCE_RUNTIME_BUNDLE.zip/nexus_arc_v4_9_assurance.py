"""NEXUS ARC V4.9 assurance primitives.

Standard-library-only. Stores operator-supplied evidence and benchmark records in a
hash-linked ledger. A hash chain is tamper-evident, not a digital signature and not
proof that entered source material or labels are true.
"""
from __future__ import annotations
import hashlib, hmac, json, math, random, uuid
from datetime import datetime, timezone
from typing import Any
from urllib.parse import urlsplit

SCHEMA = "NEXUS-ARC-V4.9-ASSURANCE-1"
GENESIS = "GENESIS"
MAX_EVENTS = 30000
MAX_EVIDENCE = 10000
MAX_EXPERIMENT_PAIRS = 1000


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="microseconds").replace("+00:00", "Z")


def canonical(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False)


def sha256_text(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def verify_chain(events: Any) -> dict[str, Any]:
    if not isinstance(events, list):
        return {"valid": False, "checked": 0, "bad_index": 0, "reason": "ledger root is not a list", "last_hash": None}
    if len(events) > MAX_EVENTS:
        return {"valid": False, "checked": 0, "bad_index": 0, "reason": "ledger exceeds event limit", "last_hash": None}
    prev = GENESIS
    required_by_type = {
        "evidence_added": ("evidence_id",),
        "incident_recorded": ("incident_id",),
        "experiment_registered": ("experiment_id",),
        "experiment_results_recorded": ("experiment_id",),
        "analysis_linked": ("evaluation_id",),
        "lesson_reviewed": ("incident_id", "decision"),
        "lesson_effectiveness_reviewed": ("incident_id", "verdict"),
        "evaluation_feedback_recorded": ("evaluation_id", "label"),
    }
    for i, row in enumerate(events):
        if not isinstance(row, dict) or type(row.get("seq")) is not int or row.get("seq") != i + 1 or row.get("prev_hash") != prev:
            return {"valid": False, "checked": i, "bad_index": i, "reason": "sequence/previous hash mismatch", "last_hash": prev}
        if not isinstance(row.get("event_id"), str) or not row["event_id"].strip():
            return {"valid": False, "checked": i, "bad_index": i, "reason": "event_id is missing or invalid", "last_hash": prev}
        if not isinstance(row.get("event_type"), str) or row["event_type"] not in required_by_type:
            return {"valid": False, "checked": i, "bad_index": i, "reason": "event_type is unsupported", "last_hash": prev}
        if not isinstance(row.get("payload"), dict):
            return {"valid": False, "checked": i, "bad_index": i, "reason": "event payload must be an object", "last_hash": prev}
        try:
            dt = datetime.fromisoformat(str(row.get("created_at", "")).replace("Z", "+00:00"))
        except (ValueError, TypeError):
            return {"valid": False, "checked": i, "bad_index": i, "reason": "event timestamp is missing or invalid", "last_hash": prev}
        payload = row["payload"]
        if any(key not in payload for key in required_by_type[row["event_type"]]):
            return {"valid": False, "checked": i, "bad_index": i, "reason": "event payload schema is invalid", "last_hash": prev}
        material = {k: v for k, v in row.items() if k != "event_hash"}
        try:
            expected = sha256_text(canonical(material))
        except (ValueError, TypeError):
            return {"valid": False, "checked": i, "bad_index": i, "reason": "event cannot be canonicalized", "last_hash": prev}
        if not isinstance(row.get("event_hash"), str) or not hmac.compare_digest(row["event_hash"], expected):
            return {"valid": False, "checked": i, "bad_index": i, "reason": "event hash mismatch", "last_hash": prev}
        prev = row["event_hash"]
    return {"valid": True, "checked": len(events), "bad_index": None, "reason": "hash chain valid; source truth not verified", "last_hash": prev}


def append_event(events: list[dict[str, Any]], event_type: str, payload: dict[str, Any], now: str | None = None) -> dict[str, Any]:
    integrity = verify_chain(events)
    if not integrity["valid"]:
        raise ValueError("assurance ledger integrity failure; writes are blocked")
    if len(events) >= MAX_EVENTS:
        raise ValueError("assurance ledger reached event limit; archive before adding more")
    event = {"seq": len(events) + 1, "event_id": uuid.uuid4().hex, "event_type": event_type,
             "created_at": now or utc_now(), "payload": payload, "prev_hash": integrity["last_hash"]}
    event["event_hash"] = sha256_text(canonical(event))
    events.append(event)
    return event


def project(events: list[dict[str, Any]]) -> dict[str, Any]:
    evidence: dict[str, dict[str, Any]] = {}
    incidents: dict[str, dict[str, Any]] = {}
    experiments: dict[str, dict[str, Any]] = {}
    analyses: dict[str, dict[str, Any]] = {}
    for event in events:
        p = event.get("payload", {}) if isinstance(event.get("payload"), dict) else {}
        kind = event.get("event_type")
        if kind == "evidence_added":
            evidence[p["evidence_id"]] = {**p, "recorded_at": event["created_at"], "event_hash": event["event_hash"]}
        elif kind == "incident_recorded":
            incidents[p["incident_id"]] = {**p, "recorded_at": event["created_at"], "event_hash": event["event_hash"]}
        elif kind == "experiment_registered":
            experiments[p["experiment_id"]] = {**p, "registered_at": event["created_at"], "registration_hash": event["event_hash"], "results": None}
        elif kind == "experiment_results_recorded":
            exp = experiments.get(p.get("experiment_id"))
            if exp is not None:
                exp["results"] = {**p, "recorded_at": event["created_at"], "event_hash": event["event_hash"]}
        elif kind == "analysis_linked":
            analyses[p["evaluation_id"]] = {**p, "recorded_at": event["created_at"], "event_hash": event["event_hash"]}
    return {"evidence": evidence, "incidents": incidents, "experiments": experiments, "analyses": analyses}


def _num(x: Any) -> bool:
    return isinstance(x, (int, float)) and not isinstance(x, bool) and math.isfinite(float(x))


def paired_experiment_summary(registration: dict[str, Any], rows: list[dict[str, Any]], n_boot: int = 2500) -> dict[str, Any]:
    n = len(rows)
    direction = registration["direction"]
    diffs = []
    for row in rows:
        raw = float(row["challenger_score"]) - float(row["champion_score"])
        diffs.append(-raw if direction == "lower_better" else raw)
    if not diffs:
        return {"n": 0, "mean_improvement": None, "ci95": None, "gate": "INSUFFICIENT_EVIDENCE", "auto_promotion": False}
    avg = sum(diffs) / n
    ci = None
    if n >= 2:
        seed = int(sha256_text(registration["experiment_id"])[:16], 16)
        rng = random.Random(seed)
        means = []
        for _ in range(n_boot):
            means.append(sum(diffs[rng.randrange(n)] for _ in range(n)) / n)
        means.sort()
        ci = [means[int(0.025 * (n_boot - 1))], means[int(0.975 * (n_boot - 1))]]
    minimum_n = 100
    min_effect = float(registration.get("minimum_effect", 0.0))
    holdout = bool(str(registration.get("holdout_description", "")).strip())
    if n < minimum_n or ci is None or not holdout:
        gate = "INSUFFICIENT_EVIDENCE"
    elif ci[0] > min_effect:
        gate = "PROMISING_FOR_INDEPENDENT_REVIEW"
    else:
        gate = "IMPROVEMENT_NOT_ESTABLISHED"
    return {"n": n, "mean_improvement": round(avg, 8), "ci95": [round(float(v), 8) for v in ci] if ci else None,
            "minimum_sample_for_review": minimum_n, "minimum_effect": min_effect, "gate": gate, "auto_promotion": False,
            "holdout_status": "operator-declared; not independently verified",
            "interpretation": "Exploratory paired bootstrap interval. Passing is not proof of causality, independence, generalization, or safe promotion."}


def coverage_report(feeds: list[dict[str, Any]], statuses: dict[str, Any], state: dict[str, Any], poll_seconds: int, now: datetime | None = None) -> dict[str, Any]:
    now = now or datetime.now(timezone.utc)
    active = []
    max_age = max(2 * int(poll_seconds), 120)
    def age(value: Any) -> float | None:
        if not isinstance(value, str): return None
        try:
            dt = datetime.fromisoformat(value.replace("Z", "+00:00"))
            if dt.tzinfo is None: dt = dt.replace(tzinfo=timezone.utc)
            return (now - dt.astimezone(timezone.utc)).total_seconds()
        except (ValueError, TypeError): return None
    for feed in feeds:
        url = str(feed.get("url") or "")
        row = dict(statuses.get(url) or {})
        checked_age = age(row.get("last_check_at"))
        success_age = age(row.get("last_success_at"))
        content_age = age(row.get("latest_source_timestamp"))
        if not row.get("last_check_at"):
            status = "NOT_CHECKED"
        elif (checked_age is not None and checked_age < -300) or (success_age is not None and success_age < -300):
            status = "FETCH_TIMESTAMP_IN_FUTURE"
        elif row.get("last_error"):
            status = "FETCH_FAILED"
        elif success_age is None or success_age > max_age:
            status = "FETCH_STALE"
        elif content_age is not None and content_age < -300:
            status = "SOURCE_TIMESTAMP_IN_FUTURE"
        elif content_age is not None and content_age > max(6 * int(poll_seconds), 3600):
            status = "FETCH_OK_CONTENT_OLD"
        elif content_age is None:
            status = "FETCH_OK_CONTENT_TIME_UNKNOWN"
        else:
            status = "FRESH"
        active.append({"name": str(feed.get("name") or url)[:120], "url": url, "status": status,
                       "last_check_age_seconds": round(checked_age, 1) if checked_age is not None else None,
                       "last_success_age_seconds": round(success_age, 1) if success_age is not None else None,
                       "source_content_age_seconds": round(content_age, 1) if content_age is not None else None,
                       "consecutive_failures": int(row.get("consecutive_failures", 0) or 0),
                       "last_error": str(row.get("last_error") or "")[:300] or None,
                       "items_seen": int(row.get("items_seen", 0) or 0), "new_items": int(row.get("new_items", 0) or 0)})
    counts: dict[str, int] = {}
    for row in active: counts[row["status"]] = counts.get(row["status"], 0) + 1
    if not active: overall = "NOT_CONFIGURED"
    elif counts.get("FETCH_FAILED") or counts.get("FETCH_STALE") or counts.get("NOT_CHECKED") or counts.get("FETCH_TIMESTAMP_IN_FUTURE") or counts.get("SOURCE_TIMESTAMP_IN_FUTURE"): overall = "DEGRADED"
    elif counts.get("FETCH_OK_CONTENT_OLD") or counts.get("FETCH_OK_CONTENT_TIME_UNKNOWN"): overall = "LIMITED_COVERAGE"
    else: overall = "FRESH"
    last_poll_age = age(state.get("last_poll_at"))
    return {"schema": SCHEMA, "overall": overall, "configured_feed_count": len(feeds), "statuses": counts,
            "poll_seconds": int(poll_seconds), "freshness_threshold_seconds": max_age,
            "last_poll_at": state.get("last_poll_at"), "last_poll_age_seconds": round(last_poll_age, 1) if last_poll_age is not None else None,
            "event_count": len(state.get("events", [])) if isinstance(state.get("events"), list) else 0,
            "feeds": active,
            "scope_note": "Coverage covers configured feeds only. A successful fetch does not prove source truth, complete event coverage, or that the feed's content is current."}
