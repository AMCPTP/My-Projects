/* NEXUS ARC V5.9.5 Pattern Audit Engine
 * Fixed-pattern, walk-forward retrospective evaluator and a separate
 * prospective, session-aware ledger. This is a research/audit utility,
 * not a wagering signal. No pattern is assumed predictive by definition.
 */
(function (root) {
  'use strict';
  const VERSION = '5.9.5';
  const SCHEMA = 'nexus-arc-v5.9.5-pattern-audit-ledger-v1';
  const BASELINE = Object.freeze({ P: 0.49317561922276104, B: 0.5068243807772389 });
  const PRIOR_STRENGTH = 20;
  const MIN_PREFIX = 12;
  const MIN_PATTERN_ROWS = 30;
  const MIN_PATTERN_SESSIONS = 10;
  const MIN_REVIEW_ROWS = 100;
  const MIN_REVIEW_SESSIONS = 20;
  const BLOCK_LENGTH = 10;
  const BOOT_REPS = 500;
  const PATTERNS = Object.freeze({
    ALTERNATION_4: { label: 'สลับฝั่ง 4 ผล', description: 'P-B-P-B หรือ B-P-B-P; จำแนกลักษณะเท่านั้น ไม่ได้สมมติว่าต้องสลับต่อ' },
    TWO_BY_TWO: { label: 'กลุ่มละ 2 ผล', description: 'P-P-B-B หรือ B-B-P-P ในสี่ผลล่าสุด; ตรวจอัตราเกิดจริง ไม่สมมติว่าต้องย้อนกลับ' },
    STREAK_3: { label: 'Streak ≥ 3', description: 'ผลฝั่งเดียวกันอย่างน้อย 3 ครั้งติด; ไม่สมมติว่ามังกรต้องยาวต่อ' },
    DOUBLE: { label: 'คู่ซ้ำท้ายลำดับ', description: 'ผลท้ายซ้ำ 2 ครั้ง แต่ไม่เข้าเกณฑ์กลุ่มละ 2; ไม่มีทิศทางตายตัว' },
    MIXED: { label: 'รูปแบบผสม/อื่น ๆ', description: 'ไม่ตรงเงื่อนไขเฉพาะด้านบน' },
    WARMUP: { label: 'ข้อมูลยังน้อย', description: 'ต้องมีอย่างน้อย 4 ผล P/B เพื่อจำแนกรูปแบบ' }
  });

  function token(v) {
    const s = String(v == null ? '' : v).trim().toUpperCase();
    if (s === 'P' || s === 'PLAYER') return 'P';
    if (s === 'B' || s === 'BANKER') return 'B';
    // Tie is not accepted in this P/B-only workflow.
    if (s === 'T' || s === 'TIE') return null;
    return null;
  }
  function parseInput(input) {
    const outcomes = []; let raw_count = 0, ignored_count = 0;
    function accept(value) {
      const s = String(value == null ? '' : value).trim().toUpperCase();
      if (!s) return;
      const t = token(s); raw_count++;
      if (t === 'P' || t === 'B') outcomes.push(t); else ignored_count++;
    }
    if (Array.isArray(input)) {
      for (const value of input) accept(value && typeof value === 'object' ? (value.result ?? value.outcome ?? '') : value);
      return { outcomes, raw_count, ignored_count };
    }
    const s = String(input == null ? '' : input).trim().toUpperCase();
    if (!s) return { outcomes, raw_count, ignored_count };
    const compact = s.replace(/[\s,;|/\\._:-]+/g, '');
    if (/^[PBT]+$/.test(compact)) {
      for (const ch of compact) accept(ch);
      return { outcomes, raw_count, ignored_count };
    }
    const pieces = s.split(/[\s,;|/\\._:-]+/).filter(Boolean);
    for (const piece of pieces) {
      if (/^[PBT]+$/.test(piece)) { for (const ch of piece) accept(ch); }
      else accept(piece);
    }
    return { outcomes, raw_count, ignored_count };
  }
  function normalizeOutcomes(input) { return parseInput(input).outcomes; }
  function pbOnly(input) { return normalizeOutcomes(input).filter(x => x === 'P' || x === 'B'); }
  function runLength(seq) {
    if (!seq.length) return 0;
    let n = 1;
    for (let i = seq.length - 1; i > 0 && seq[i] === seq[i - 1]; i--) n++;
    return n;
  }
  function classifyPattern(input) {
    const x = pbOnly(input);
    if (x.length < 4) return { id: 'WARMUP', label: PATTERNS.WARMUP.label, description: PATTERNS.WARMUP.description, n: x.length, lastRun: runLength(x) };
    const q = x.slice(-4);
    const alternating = q.every((v, i) => i === 0 || v !== q[i - 1]);
    if (alternating) return { id: 'ALTERNATION_4', ...PATTERNS.ALTERNATION_4, n: x.length, lastRun: runLength(x) };
    if (q[0] === q[1] && q[2] === q[3] && q[0] !== q[2]) {
      return { id: 'TWO_BY_TWO', ...PATTERNS.TWO_BY_TWO, n: x.length, lastRun: runLength(x) };
    }
    const run = runLength(x);
    if (run >= 3) return { id: 'STREAK_3', ...PATTERNS.STREAK_3, n: x.length, lastRun: run };
    if (run === 2) return { id: 'DOUBLE', ...PATTERNS.DOUBLE, n: x.length, lastRun: run };
    return { id: 'MIXED', ...PATTERNS.MIXED, n: x.length, lastRun: run };
  }
  function probabilityFromCounts(counts) {
    const n = Math.max(0, Number(counts && counts.n) || 0);
    const p = Math.max(0, Number(counts && counts.P) || 0);
    const b = Math.max(0, Number(counts && counts.B) || 0);
    const z = PRIOR_STRENGTH + n;
    const pp = (BASELINE.P * PRIOR_STRENGTH + p) / z;
    const pb = (BASELINE.B * PRIOR_STRENGTH + b) / z;
    const total = pp + pb;
    return { P: pp / total, B: pb / total };
  }
  function score(prob, actual) {
    const p = Math.max(1e-12, Math.min(1 - 1e-12, Number(prob.P)));
    const b = Math.max(1e-12, Math.min(1 - 1e-12, Number(prob.B)));
    const z = p + b;
    const pp = p / z, pb = b / z;
    const yP = actual === 'P' ? 1 : 0, yB = actual === 'B' ? 1 : 0;
    return { log_loss: -(yP * Math.log(pp) + yB * Math.log(pb)), brier: (pp - yP) ** 2 + (pb - yB) ** 2, predicted: pp >= pb ? 'P' : 'B', correct: (pp >= pb ? 'P' : 'B') === actual };
  }
  function avg(xs) { return xs.length ? xs.reduce((a, b) => a + b, 0) / xs.length : null; }
  function quantile(a, q) {
    if (!a.length) return null;
    const s = a.slice().sort((x, y) => x - y), p = (s.length - 1) * q, i = Math.floor(p), j = Math.min(s.length - 1, i + 1);
    return s[i] + (s[j] - s[i]) * (p - i);
  }
  function makeRng(seed) {
    let a = (seed >>> 0) || 1;
    return () => { a |= 0; a = (a + 0x6D2B79F5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t ^= t + Math.imul(t ^ (t >>> 7), 61 | t); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
  }
  function movingBlockCI(values, seed) {
    const n = values.length;
    if (n < 30) return null;
    const block = Math.min(BLOCK_LENGTH, Math.max(2, Math.floor(n / 3)));
    const rng = makeRng(seed || 20261015), means = [];
    for (let r = 0; r < BOOT_REPS; r++) {
      const sample = [];
      while (sample.length < n) {
        const start = Math.floor(rng() * Math.max(1, n - block + 1));
        for (let j = 0; j < block && sample.length < n; j++) sample.push(values[(start + j) % n]);
      }
      means.push(avg(sample));
    }
    return { method: 'moving-block bootstrap (sequential blocks; not shoe-clustered)', block_length: block, replicates: BOOT_REPS, mean: avg(values), low: quantile(means, 0.025), high: quantile(means, 0.975) };
  }
  function rowMetrics(rows) {
    if (!rows.length) return { n: 0, log_loss: null, baseline_log_loss: null, delta_log_loss: null, brier: null, baseline_brier: null, delta_brier: null, accuracy: null, baseline_accuracy: null, delta_accuracy: null };
    const l = rows.map(r => score(r.probabilities, r.actual));
    const bl = rows.map(r => score(BASELINE, r.actual));
    const acc = avg(l.map(x => x.correct ? 1 : 0)), bacc = avg(bl.map(x => x.correct ? 1 : 0));
    const ll = avg(l.map(x => x.log_loss)), bll = avg(bl.map(x => x.log_loss));
    const br = avg(l.map(x => x.brier)), bbr = avg(bl.map(x => x.brier));
    return { n: rows.length, log_loss: ll, baseline_log_loss: bll, delta_log_loss: ll - bll, brier: br, baseline_brier: bbr, delta_brier: br - bbr, accuracy: acc, baseline_accuracy: bacc, delta_accuracy: acc - bacc };
  }
  function walkForwardAudit(input) {
    const parsedInput = parseInput(input);
    const normalized = parsedInput.outcomes;
    const full = normalized.slice(-6000), pb = full.filter(x => x === 'P' || x === 'B');
    const counts = Object.fromEntries(Object.keys(PATTERNS).map(k => [k, { n: 0, P: 0, B: 0 }]));
    const rows = [];
    for (let i = MIN_PREFIX; i < pb.length; i++) {
      const prefix = pb.slice(0, i);
      const pattern = classifyPattern(prefix);
      const c = counts[pattern.id] || { n: 0, P: 0, B: 0 };
      const probabilities = probabilityFromCounts(c);
      const actual = pb[i];
      rows.push({ index_pb: i, prefix_length: i, pattern_id: pattern.id, probabilities, baseline: { P: BASELINE.P, B: BASELINE.B }, actual,
        score: score(probabilities, actual), baseline_score: score(BASELINE, actual) });
      // Important: update only AFTER scoring this row, preventing current-outcome leakage.
      c.n++; c[actual]++; counts[pattern.id] = c;
    }
    const overall = rowMetrics(rows);
    const dLL = rows.map(r => r.score.log_loss - r.baseline_score.log_loss);
    const dBr = rows.map(r => r.score.brier - r.baseline_score.brier);
    const seed = 20261015 + pb.length * 17;
    overall.ci_delta_log_loss = movingBlockCI(dLL, seed);
    overall.ci_delta_brier = movingBlockCI(dBr, seed + 1);
    const byPattern = Object.keys(PATTERNS).filter(k => k !== 'WARMUP').map(id => {
      const r = rows.filter(x => x.pattern_id === id);
      return { pattern_id: id, label: PATTERNS[id].label, description: PATTERNS[id].description, ...rowMetrics(r) };
    });
    const uniquePatternN = new Set(rows.map(r => r.pattern_id)).size;
    let status = 'WARMING · N_LT_100';
    if (overall.n >= 100) {
      if (overall.ci_delta_log_loss && overall.ci_delta_brier && overall.ci_delta_log_loss.high < 0 && overall.ci_delta_brier.high < 0) status = 'RETROSPECTIVE_CANDIDATE_ONLY · REQUIRES PROSPECTIVE REPLICATION';
      else if (overall.ci_delta_log_loss && overall.ci_delta_brier && overall.ci_delta_log_loss.low > 0 && overall.ci_delta_brier.low > 0) status = 'WORSE_THAN_BASELINE_IN_THIS_SEQUENCE';
      else status = 'NO_CLEAR_IMPROVEMENT';
    }
    return { schema: 'nexus-arc-v5.9.5-walk-forward-audit-v1', version: VERSION, input_n_raw: parsedInput.raw_count, input_n_pb: pb.length, ignored_input_tokens: parsedInput.ignored_count, truncated_to_last_6000_raw_outcomes: normalized.length > 6000, unsupported_tie_tokens_removed: true,
      min_prefix: MIN_PREFIX, prior_strength: PRIOR_STRENGTH, baseline: { ...BASELINE, description: 'Rounded eight-deck initial-shoe reference, P/B conditional on a non-Tie; not shoe-composition tracking and not universal.' },
      n_scored: overall.n, status, metrics: overall, by_pattern: byPattern, rows, pattern_coverage_count: uniquePatternN,
      limitations: ['Retrospective walk-forward only; imported historical sequence has no independently attested point-in-time capture.', 'Current-sequence pattern classes may be data-mined; results are exploratory, not proof of predictive edge.', 'Moving-block intervals use sequence order but are not shoe/session-clustered because input has no verified shoe boundaries.', 'This workflow accepts P/B only; unsupported tokens including Tie are not analyzed. No EV or wagering recommendation is computed.'] };
  }
  function validSessionId(v) { return typeof v === 'string' && /^[A-Za-z0-9._:-]{3,80}$/.test(v); }
  function emptyLedger() { return { schema: SCHEMA, version: VERSION, created_at: new Date().toISOString(), records: [], pending_id: null }; }
  function validateLedger(d) {
    if (!d || typeof d !== 'object' || d.schema !== SCHEMA || d.version !== VERSION || !Array.isArray(d.records) || d.records.length > 10000) throw new Error('Pattern audit ledger has an invalid schema/shape; writes are blocked to avoid overwriting data. Export and inspect it first.');
    const ids = new Set(); let pending = 0;
    for (const r of d.records) {
      if (!r || typeof r !== 'object' || typeof r.forecast_id !== 'string' || !r.forecast_id || ids.has(r.forecast_id)) throw new Error('Invalid/duplicate forecast id in pattern ledger.');
      ids.add(r.forecast_id);
      if (r.model_version !== VERSION || !validSessionId(r.session_id) || !Object.hasOwn(PATTERNS, r.pattern_id)) throw new Error('Invalid model/session/pattern metadata in pattern ledger.');
      if (!Number.isInteger(r.prefix_pb_count) || r.prefix_pb_count < MIN_PREFIX || typeof r.prefix_pb_sequence !== 'string' || typeof r.prefix_raw_sequence !== 'string') throw new Error('Invalid pre-outcome prefix snapshot in pattern ledger.');
      if (!r.probabilities || !Number.isFinite(r.probabilities.P) || !Number.isFinite(r.probabilities.B) || r.probabilities.P <= 0 || r.probabilities.B <= 0 || Math.abs(r.probabilities.P + r.probabilities.B - 1) > 1e-6) throw new Error('Invalid probabilities in pattern ledger.');
      if (!['PENDING', 'RESOLVED', 'CANCELLED'].includes(r.status)) throw new Error('Invalid status in pattern ledger.');
      if (r.status === 'PENDING') pending++;
      if (r.status === 'RESOLVED' && !['P', 'B'].includes(r.actual)) throw new Error('Resolved ledger row must have a P/B outcome.');
    }
    if (pending > 1) throw new Error('More than one pending pattern forecast exists; manual repair required.');
    const p = d.records.find(r => r.status === 'PENDING');
    if ((p ? p.forecast_id : null) !== (d.pending_id || null)) throw new Error('Pattern ledger pending_id does not match records.');
    return d;
  }
  function makeProspectiveForecast(history, ledger, sessionId, now, id) {
    validateLedger(ledger);
    if (!validSessionId(sessionId)) throw new Error('Enter a shoe/session ID (3–80 letters/digits/dot/underscore/colon/hyphen) before locking a forecast.');
    if (ledger.pending_id) throw new Error('A forecast is already pending. Resolve it or cancel it before locking another.');
    const full = normalizeOutcomes(history), pb = full.filter(x => x === 'P' || x === 'B');
    if (pb.length < MIN_PREFIX) throw new Error(`Need at least ${MIN_PREFIX} prior P/B outcomes before locking a pattern audit forecast.`);
    const pattern = classifyPattern(pb);
    const prior = ledger.records.filter(r => r.status === 'RESOLVED' && r.pattern_id === pattern.id && r.session_id !== sessionId && ['P', 'B'].includes(r.actual));
    const priorSessions = [...new Set(prior.map(r => r.session_id))];
    const canUsePattern = prior.length >= MIN_PATTERN_ROWS && priorSessions.length >= MIN_PATTERN_SESSIONS;
    const c = { n: prior.length, P: prior.filter(r => r.actual === 'P').length, B: prior.filter(r => r.actual === 'B').length };
    const probabilities = canUsePattern ? probabilityFromCounts(c) : { ...BASELINE };
    const record = { forecast_id: id || `pa-${Date.now()}-${Math.random().toString(36).slice(2, 10)}`, model_version: VERSION, created_at: now || new Date().toISOString(), session_id: sessionId,
      target_definition: 'next P/B result only; unsupported tokens are not part of the sequence', status: 'PENDING', prefix_raw_sequence: full.join(''), prefix_pb_sequence: pb.join(''), prefix_pb_count: pb.length,
      pattern_id: pattern.id, pattern_label: pattern.label, pattern_description: pattern.description, probabilities, baseline: { ...BASELINE }, training_pattern_rows: prior.length,
      training_other_sessions: priorSessions.length, estimator_status: canUsePattern ? 'CROSS_SESSION_PATTERN_ESTIMATE' : 'WAIT_BASELINE_ONLY_INSUFFICIENT_CROSS_SESSION_PATTERN_EVIDENCE',
      decision: 'WAIT', actual: null, resolved_at: null, cancel_reason: null };
    ledger.records.push(record); ledger.pending_id = record.forecast_id; validateLedger(ledger);
    return record;
  }
  function resolvePendingAgainstHistory(ledger, history, now) {
    validateLedger(ledger);
    if (!ledger.pending_id) return { changed: false, message: 'No pending pattern forecast.' };
    const record = ledger.records.find(r => r.forecast_id === ledger.pending_id);
    const full = normalizeOutcomes(history), raw = full.join(''), pb = full.filter(x => x === 'P' || x === 'B');
    if (!raw.startsWith(record.prefix_raw_sequence)) {
      record.status = 'CANCELLED'; record.cancel_reason = 'history_prefix_changed_or_new_shoe'; record.resolved_at = now || new Date().toISOString(); ledger.pending_id = null; validateLedger(ledger);
      return { changed: true, cancelled: true, message: 'Pending forecast cancelled because the live history prefix changed; no score was written.' };
    }
    if (pb.length <= record.prefix_pb_count) return { changed: false, message: 'Still waiting for the next P/B outcome.' };
    const actual = pb[record.prefix_pb_count];
    if (actual !== 'P' && actual !== 'B') return { changed: false, message: 'No P/B target outcome found; forecast remains pending.' };
    record.status = 'RESOLVED'; record.actual = actual; record.resolved_at = now || new Date().toISOString();
    record.score = score(record.probabilities, actual); record.baseline_score = score(BASELINE, actual);
    ledger.pending_id = null; validateLedger(ledger);
    return { changed: true, resolved: true, record, message: `Prospective forecast resolved with outcome ${actual}; ties before target do not count as P/B.` };
  }
  function cancelPending(ledger, reason, now) {
    validateLedger(ledger);
    if (!ledger.pending_id) return { changed: false, message: 'No pending pattern forecast.' };
    const record = ledger.records.find(r => r.forecast_id === ledger.pending_id);
    record.status = 'CANCELLED'; record.cancel_reason = String(reason || 'operator_cancelled').slice(0, 160); record.resolved_at = now || new Date().toISOString(); ledger.pending_id = null;
    validateLedger(ledger); return { changed: true, record, message: 'Pending forecast cancelled without scoring.' };
  }
  function clusterBootstrapCI(rows, field, seed) {
    const groups = new Map();
    for (const r of rows) { const d = Number(r[field]); if (!Number.isFinite(d)) continue; if (!groups.has(r.session_id)) groups.set(r.session_id, []); groups.get(r.session_id).push(d); }
    const keys = [...groups.keys()];
    if (keys.length < MIN_REVIEW_SESSIONS) return null;
    const estimate = avg(rows.map(r => Number(r[field]))), rng = makeRng(seed || 20595), dist = [];
    // Resample whole sessions, then average all selected forecast rows. This preserves
    // within-session dependence while keeping the point estimate aligned to row-level metrics.
    for (let i = 0; i < BOOT_REPS; i++) {
      const vals = [];
      for (let j = 0; j < keys.length; j++) vals.push(...groups.get(keys[Math.floor(rng() * keys.length)]));
      dist.push(avg(vals));
    }
    return { method: 'session-cluster bootstrap', clusters: keys.length, replicates: BOOT_REPS, mean: estimate, low: quantile(dist, 0.025), high: quantile(dist, 0.975) };
  }
  function summarizeProspective(ledger) {
    validateLedger(ledger);
    const rows = ledger.records.filter(r => r.model_version === VERSION && r.status === 'RESOLVED' && ['P', 'B'].includes(r.actual)).map(r => {
      const a = score(r.probabilities, r.actual), b = score(BASELINE, r.actual);
      return { ...r, log_loss: a.log_loss, baseline_log_loss: b.log_loss, delta_log_loss: a.log_loss - b.log_loss, brier: a.brier, baseline_brier: b.brier, delta_brier: a.brier - b.brier };
    });
    const overall = rowMetrics(rows), sessions = [...new Set(rows.map(r => r.session_id))];
    overall.ci_delta_log_loss = clusterBootstrapCI(rows, 'delta_log_loss', 2501 + rows.length);
    overall.ci_delta_brier = clusterBootstrapCI(rows, 'delta_brier', 2502 + rows.length);
    let status = 'WARMING · N_LT_100';
    if (overall.n >= MIN_REVIEW_ROWS && sessions.length < MIN_REVIEW_SESSIONS) status = 'WAIT · NOT_ENOUGH_DISTINCT_SESSIONS';
    else if (overall.n >= MIN_REVIEW_ROWS && sessions.length >= MIN_REVIEW_SESSIONS && overall.ci_delta_log_loss && overall.ci_delta_brier && overall.ci_delta_log_loss.high < 0 && overall.ci_delta_brier.high < 0) status = 'CANDIDATE_FOR_INDEPENDENT_REPLICATION · NOT A BETTING SIGNAL';
    else if (overall.n >= MIN_REVIEW_ROWS && sessions.length >= MIN_REVIEW_SESSIONS) status = 'NO_CLEAR_IMPROVEMENT · KEEP WAIT';
    const byPattern = Object.keys(PATTERNS).filter(k => k !== 'WARMUP').map(id => ({ pattern_id: id, label: PATTERNS[id].label, ...rowMetrics(rows.filter(r => r.pattern_id === id)) }));
    return { schema: 'nexus-arc-v5.9.5-prospective-summary-v1', n_scored: overall.n, distinct_sessions: sessions.length, pending_n: ledger.records.filter(r => r.status === 'PENDING').length,
      cancelled_n: ledger.records.filter(r => r.status === 'CANCELLED').length, status, metrics: overall, by_pattern: byPattern,
      criteria: { min_scored_forecasts: MIN_REVIEW_ROWS, min_distinct_sessions: MIN_REVIEW_SESSIONS, both_cluster_ci_upper_bounds_below_zero: true, auto_promotion: false, betting_signal: false },
      limitations: ['Session IDs are operator-entered and not independently verified.', 'Cluster bootstrap assumes supplied session IDs are meaningful independent clusters.', 'Even a screening pass requires a separate sealed holdout and independent replication.', 'Pattern probabilities use other-session prospective data only; when per-pattern minimums are absent the forecast falls back to the fixed reference baseline.', 'No bankroll EV is computed because probabilities, payout rules and edge have not been independently validated.'] };
  }
  const api = { VERSION, SCHEMA, BASELINE, PRIOR_STRENGTH, MIN_PREFIX, MIN_PATTERN_ROWS, MIN_PATTERN_SESSIONS, MIN_REVIEW_ROWS, MIN_REVIEW_SESSIONS, PATTERNS, parseInput,
    normalizeOutcomes, pbOnly, runLength, classifyPattern, probabilityFromCounts, score, walkForwardAudit, validSessionId, emptyLedger, validateLedger, makeProspectiveForecast, resolvePendingAgainstHistory, cancelPending, summarizeProspective };
  root.NexusPatternAuditV595 = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof window !== 'undefined' ? window : globalThis);
