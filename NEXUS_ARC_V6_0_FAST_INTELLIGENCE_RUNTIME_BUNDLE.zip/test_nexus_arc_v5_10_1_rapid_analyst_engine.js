'use strict';
const assert = require('node:assert/strict');
const A = require('./nexus_arc_v5_10_1_rapid_analyst_engine.js');
let passed = 0;
function test(name, fn) { fn(); passed++; console.log('PASS ' + name); }

test('P/B-only parser strips Tie and reports every unsupported token', () => {
  const p = A.parse('PBTB TIE P, X, B, ?');
  assert.deepEqual(p.outcomes, ['P', 'B', 'B', 'P', 'B']);
  assert.equal(p.ignored_count, 4);
  assert.equal(A.analyze('PBTB').data_quality.tie_n, undefined);
});

test('under 4 results shows warm-up rather than blocking the whole system', () => {
  for (const s of ['', 'P', 'B', 'PBT', 'PBP']) {
    const q = A.rapidRead(s);
    assert.equal(q.mode, 'WARMUP_FAST_READ');
    assert.equal(q.sample_n, A.parse(s).outcomes.length);
    assert.equal(q.minimum_n, 4);
    assert.equal(q.lean, 'NEUTRAL');
    assert.equal(q.probability, null);
  }
});

test('Quick Read starts at four results without waiting for 12-result historical tilt', () => {
  const q = A.rapidRead('PPPP');
  assert.equal(q.mode, 'RAPID_HEURISTIC_READ');
  assert.equal(q.lean, 'P');
  assert.equal(q.strength, 'VERY_LOW_SUPPORT');
  assert.equal(q.probability, null);
  assert.equal(q.validated, false);
  assert.equal(q.edge_claim, false);
});

test('alternation is contextual and does not create a lean', () => {
  const r = A.analyze('PBPBPBPBPBPB');
  assert.ok(r.patterns.some(x => x.id === 'ALTERNATION_6'));
  assert.equal(r.forecast_assessment.quick_read.lean, 'NEUTRAL');
});

test('stable repeated 2-2 shape does not turn phase into a directional lean', () => {
  const r = A.analyze('PPBBPPBBPPBB');
  assert.ok(r.patterns.some(x => x.id === 'TWO_BY_TWO'));
  assert.equal(r.forecast_assessment.quick_read.lean, 'NEUTRAL');
  assert.ok(r.forecast_assessment.quick_read.context.some(x => x.includes('2-2 cycle guard')));
  assert.equal(r.forecast_assessment.quick_read.edge_claim, false);
});

test('long streak can show a low-support heuristic lean but never 100% probability', () => {
  const q = A.rapidRead('PPPPPPPPPPPP');
  assert.equal(q.lean, 'P');
  assert.equal(q.strength, 'LOW_SUPPORT');
  assert.equal(q.probability, null);
  assert.equal(q.edge_claim, false);
  assert.equal(A.analyze('PPPPPPPPPPPP').forecast_assessment.validation_gate, 'WAIT_NO_VERIFIED_CROSS_SESSION_EDGE');
});

test('12 B then 12 P reads the recent shift immediately and labels it candidate', () => {
  const r = A.analyze('BBBBBBBBBBBBPPPPPPPPPPPP');
  assert.equal(r.recent_vs_previous_12.status, 'SHIFT_CANDIDATE');
  assert.equal(r.forecast_assessment.quick_read.mode, 'RAPID_HEURISTIC_READ');
  assert.equal(r.forecast_assessment.quick_read.lean, 'P');
  assert.equal(r.forecast_assessment.quick_read.validated, false);
});

test('long alternating history stays neutral despite transition bias', () => {
  const q = A.rapidRead('PB'.repeat(50));
  assert.equal(q.lean, 'NEUTRAL');
  const r = A.analyze('PB'.repeat(50));
  assert.ok(r.transition_stats.every(t => t.use_for_direction === false));
});

test('transition and suffix statistics remain context only', () => {
  const r = A.analyze('PBPBPBPBPBPBPBPBPBPBPBPBPBPBPB');
  assert.ok(r.transition_stats.every(x => x.use_for_direction === false));
  assert.ok(r.historical_suffix_matches.every(x => x.use_for_direction === false));
  assert.ok(r.forecast_assessment.quick_read.transition_context.use_for_direction === false);
});

test('input quality reports unknown and unsupported tokens', () => {
  const r = A.analyze('P, X, B, ?, TIE');
  assert.equal(r.data_quality.accepted_outcomes, 2);
  assert.equal(r.data_quality.ignored_items, 3);
  assert.ok(r.reasoning.some(x => x.includes('token')));
});

test('schema and validation gate stay stable during warm-up and rapid mode', () => {
  const a = A.analyze('PBP'), b = A.analyze('P'.repeat(30));
  for (const k of ['schema','version','data_quality','current_state','patterns','windows','transition_stats','recent_vs_previous_12','historical_suffix_matches','forecast_assessment','reasoning','methodology']) {
    assert.ok(k in a); assert.ok(k in b);
  }
  assert.equal(a.forecast_assessment.validation_gate, b.forecast_assessment.validation_gate);
  assert.equal(a.forecast_assessment.decision, 'WARMUP_FAST_READ');
  assert.equal(b.forecast_assessment.decision, 'RAPID_HEURISTIC_READ');
  assert.equal(A.VERSION, '5.10.1');
});

test('full historical tilt remains separate from rapid heuristic read', () => {
  const short = A.analyze('P'.repeat(8));
  assert.equal(short.forecast_assessment.historical_tilt.evidence, 'INSUFFICIENT_SAMPLE');
  assert.equal(short.forecast_assessment.quick_read.lean, 'P');
  const full = A.analyze('P'.repeat(40));
  assert.equal(full.forecast_assessment.quick_read.probability, null);
  assert.equal(full.forecast_assessment.quick_read.edge_claim, false);
  assert.ok(full.forecast_assessment.historical_tilt.ci.low > A.BASELINE.P);
});

test('all P/B sequences through length 10 preserve parser, read and probability invariants', () => {
  for (let n = 0; n <= 10; n++) {
    for (let mask = 0; mask < (1 << n); mask++) {
      let s = '';
      for (let i = 0; i < n; i++) s += (mask & (1 << i)) ? 'P' : 'B';
      const r = A.analyze(s), q = A.rapidRead(s);
      assert.equal(r.data_quality.accepted_outcomes, n);
      assert.equal(r.data_quality.player_n + r.data_quality.banker_n, n);
      assert.ok(r.windows.every(w => w.n <= n));
      assert.ok(r.transition_stats.every(t => t.n >= 0));
      assert.equal(r.forecast_assessment.quick_read.probability, null);
      assert.equal(r.forecast_assessment.quick_read.edge_claim, false);
      assert.equal(q.sample_n, n);
      assert.equal(q.mode, n < 4 ? 'WARMUP_FAST_READ' : 'RAPID_HEURISTIC_READ');
      assert.deepEqual(q, A.rapidRead(s)); // deterministic read for the same sequence
    }
  }
});

test('rapid-only read remains linear and handles 100,000 outcomes', () => {
  const s = 'PPBB'.repeat(25000);
  const q = A.rapidRead(s);
  assert.equal(q.sample_n, 100000);
  assert.equal(q.mode, 'RAPID_HEURISTIC_READ');
  assert.equal(q.lean, 'NEUTRAL');
  assert.equal(q.probability, null);
});

console.log(`\n${passed} V5.10.1 rapid analyst tests passed.`);
