'use strict';
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');
const html = fs.readFileSync(path.join(__dirname, 'NEXUS_ARC_V6_0_INTELLIGENCE_ANALYST_DESK.html'), 'utf8');
const start = html.indexOf('function prepareV6BrainImport(){');
const end = html.indexOf('\nwindow.NexusArcV600LedgerIntegration=', start);
if (start < 0 || end <= start) throw new Error('V6 Brain-import guard helper was not found.');
const source = html.slice(start, end);
const copy = x => JSON.parse(JSON.stringify(x));
let checks = 0;
function test(name, fn) { fn(); checks++; console.log('PASS ' + name); }
function makeHarness(pending=true) {
  let ledger = pending ? {schema:'nexus-arc-v6.0-prospective-lean-ledger-v1',version:'6.0.0',created_at:'2026-10-17T00:00:00.000Z',pending_id:'f1',records:[{forecast_id:'f1',session_id:'shoe-001',predicted_lean:'P',prefix_pb_sequence:'PBPB',prefix_pb_count:4,status:'PENDING',actual:null,hit:null,cancel_reason:null,resolved_at:null}]} : {schema:'nexus-arc-v6.0-prospective-lean-ledger-v1',version:'6.0.0',created_at:'2026-10-17T00:00:00.000Z',pending_id:null,records:[]};
  let saved=0,rendered=0,cancelled=0;
  const A={cancelPending(d,reason,now){cancelled++;const r=d.records.find(x=>x.forecast_id===d.pending_id);if(!r)return{changed:false};r.status='CANCELLED';r.cancel_reason=reason;r.resolved_at=now;d.pending_id=null;return{changed:true,record:r,message:'cancelled'};}};
  const context={A,V6_LEDGER_KEY:'nexus-arc-v6.0-prospective-lean-ledger-v1',v6MemoryLedger:null,v6StorageMode:'LOCAL',
    loadV6Ledger(){return copy(ledger)},saveV6Ledger(d){ledger=copy(d);saved++;return true},renderV6Ledger(){rendered++},localStorage:{setItem(k,v){ledger=JSON.parse(v);saved++;}},
    getLedger(){return copy(ledger)},stats(){return{saved,rendered,cancelled}}};
  context.window={};context.globalThis=context;vm.createContext(context);vm.runInContext(source+'\nglobalThis.guardApi={prepareV6BrainImport};',context);
  return {api:context.guardApi,context};
}
test('no pending V6 read is a no-op',()=>{const h=makeHarness(false);const tx=h.api.prepareV6BrainImport();if(tx.cancelled!==false)throw Error('should be no-op');if(h.context.stats().cancelled!==0)throw Error('cancel called unexpectedly');});
test('pending V6 read cancels before Brain history changes, without a score',()=>{const h=makeHarness(true);const tx=h.api.prepareV6BrainImport(),r=h.context.getLedger().records[0];if(tx.cancelled!==true)throw Error('expected cancellation');if(r.status!=='CANCELLED'||r.cancel_reason!=='brain_import_replaced_history'||r.hit!==null||h.context.getLedger().pending_id!==null)throw Error('pending V6 row was not safely cancelled');});
test('failed Brain import rollback restores the exact prior pending snapshot',()=>{const h=makeHarness(true),before=h.context.getLedger(),tx=h.api.prepareV6BrainImport();tx.rollback();const after=h.context.getLedger();if(JSON.stringify(after)!==JSON.stringify(before))throw Error('V6 ledger snapshot was not restored');});
test('successful Brain import commit does not resurrect old pending read',()=>{const h=makeHarness(true),tx=h.api.prepareV6BrainImport();tx.commit();tx.rollback();if(h.context.getLedger().pending_id!==null)throw Error('committed cancelled V6 read was resurrected');});
console.log(`\n${checks} V6 Brain import guard tests passed.`);
