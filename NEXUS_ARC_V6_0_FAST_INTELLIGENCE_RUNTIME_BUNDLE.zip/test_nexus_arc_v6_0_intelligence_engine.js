'use strict';
const assert = require('node:assert/strict');
const Base = require('./nexus_arc_v5_10_1_rapid_analyst_engine.js');
const V6 = require('./nexus_arc_v6_0_intelligence_engine.js');
let passed = 0;
function test(name, fn) { fn(); passed++; console.log('PASS ' + name); }

test('V6 wrapper and stable schema', () => {
  assert.equal(V6.VERSION, '6.0.0');
  const a = V6.analyze('PBPB'), b = V6.analyze('P'.repeat(30));
  for (const key of ['schema','version','data_quality','current_state','patterns','windows','transition_stats','recent_vs_previous_12','historical_suffix_matches','forecast_assessment','reasoning','methodology','multi_lens']) assert.ok(key in a, key);
  assert.equal(a.version, '6.0.0');
  assert.equal(b.forecast_assessment.quick_read.probability, null);
  assert.equal(b.forecast_assessment.quick_read.edge_claim, false);
});

test('fast read does not wait for deep-analysis 12-result threshold', () => {
  assert.equal(V6.rapidRead('PBP').mode, 'WARMUP_FAST_READ');
  const q = V6.rapidRead('PPPP');
  assert.equal(q.mode, 'RAPID_HEURISTIC_READ');
  assert.equal(q.sample_n, 4);
  assert.equal(q.validated, false);
});

test('all P/B rolling lenses have documented non-independent status', () => {
  const m = V6.analyze('PPBBPPBBPPBBPPBBPPBBPPBBPPBB').multi_lens;
  assert.deepEqual(m.windows.map(w => w.name), ['recent_6','recent_12','recent_20','all_history']);
  assert.ok(m.windows.every(w => w.interpretation.includes('overlapping') || w.interpretation.includes('too few')));
  assert.ok(m.boundaries.some(x => x.includes('not independent')));
});

test('material recent/history conflict suppresses lean rather than choosing either side', () => {
  const history = 'B'.repeat(20) + 'P'.repeat(6);
  const r = V6.analyze(history);
  assert.ok(r.multi_lens.conflicts.some(x => x.id === 'RECENT_VS_HISTORY'));
  assert.equal(r.forecast_assessment.quick_read.lean, 'NEUTRAL');
  assert.equal(r.forecast_assessment.quick_read.multi_lens_conflict, true);
  assert.equal(r.forecast_assessment.quick_read.probability, null);
});

test('consistent long history may retain a descriptive lean without probability claim', () => {
  const r = V6.analyze('P'.repeat(50));
  assert.equal(r.forecast_assessment.quick_read.lean, 'P');
  assert.equal(r.forecast_assessment.quick_read.probability, null);
  assert.equal(r.forecast_assessment.quick_read.edge_claim, false);
  assert.equal(r.forecast_assessment.validation_gate, 'WAIT_NO_VERIFIED_CROSS_SESSION_EDGE');
});

test('2-2 and alternation remain contextual rather than being treated as certainty', () => {
  const a = V6.analyze('PBPBPBPBPBPB');
  const b = V6.analyze('PPBBPPBBPPBB');
  assert.equal(a.forecast_assessment.quick_read.lean, 'NEUTRAL');
  assert.equal(b.forecast_assessment.quick_read.lean, 'NEUTRAL');
  assert.ok(a.multi_lens.contextual_patterns.some(x => x.startsWith('ALTERNATION')));
  assert.ok(b.multi_lens.contextual_patterns.includes('TWO_BY_TWO'));
});

test('input issues are visible; P/B-only parser never turns unknown/Tie into result', () => {
  const r = V6.analyze('P, X, B, ?, TIE');
  assert.equal(r.data_quality.accepted_outcomes, 2);
  assert.equal(r.data_quality.ignored_items, 3);
});

test('prospective lock requires valid session and minimum prefix', () => {
  const l = V6.emptyLedger();
  assert.throws(() => V6.makeProspectiveForecast('PBP', l, 'shoe-1'), /at least 4/);
  assert.throws(() => V6.makeProspectiveForecast('PBPB', l, 'a'), /session\/shoe ID/i);
  const r = V6.makeProspectiveForecast('PBPB', l, 'shoe-001', '2026-10-17T12:00:00.000Z');
  assert.equal(r.status, 'PENDING');
  assert.equal(r.predicted_lean, V6.analyze('PBPB').forecast_assessment.quick_read.lean);
  assert.equal(l.pending_id, r.forecast_id);
  assert.equal(r.prefix_pb_sequence, 'PBPB');
});

test('prospective lock freezes read; result resolves only after prefix is extended', () => {
  const l = V6.emptyLedger();
  const rec = V6.makeProspectiveForecast('PBPB', l, 'shoe-001', '2026-10-17T12:00:00.000Z');
  assert.equal(V6.resolvePendingAgainstHistory(l, 'PBPB').changed, false);
  const res = V6.resolvePendingAgainstHistory(l, 'PBPBP');
  assert.equal(res.resolved, true);
  assert.equal(res.record.actual, 'P');
  assert.equal(res.record.hit, rec.predicted_lean === 'NEUTRAL' ? null : rec.predicted_lean === 'P');
  assert.equal(l.pending_id, null);
});

test('changed/replaced prefix cancels without scoring', () => {
  const l=V6.emptyLedger(); V6.makeProspectiveForecast('PBPB',l,'shoe-001');
  const res=V6.resolvePendingAgainstHistory(l,'BBBBB');
  assert.equal(res.cancelled,true); assert.equal(res.record.status,'CANCELLED'); assert.equal(res.record.hit,null); assert.equal(l.pending_id,null);
});

test('neutral forecast contributes to coverage, not directional misses', () => {
  const l=V6.emptyLedger();
  const r=V6.makeProspectiveForecast('PBPBPBPB',l,'shoe-001');
  r.predicted_lean='NEUTRAL';
  V6.resolvePendingAgainstHistory(l,'PBPBPBPBP');
  const s=V6.summarizeLedger(l);
  assert.equal(s.resolved_rows,1); assert.equal(s.directional_scored,0); assert.equal(s.neutral_rows,1); assert.equal(s.directional_accuracy,null);
});

test('directional scores compare with fixed-B reference without automatic promotion', () => {
  const l=V6.emptyLedger();
  let a=V6.makeProspectiveForecast('P'.repeat(20),l,'shoe-001');
  a.predicted_lean='P'; V6.resolvePendingAgainstHistory(l,'P'.repeat(21));
  a=V6.makeProspectiveForecast('B'.repeat(20),l,'shoe-002');
  a.predicted_lean='P'; V6.resolvePendingAgainstHistory(l,'B'.repeat(21));
  const s=V6.summarizeLedger(l);
  assert.equal(s.directional_scored,2); assert.equal(s.directional_hits,1); assert.equal(s.always_B_baseline_hits,1); assert.equal(s.status,'WARMING');
});

test('one pending forecast only; duplicate/malformed ledger blocks writes', () => {
  const l=V6.emptyLedger(); V6.makeProspectiveForecast('PBPB',l,'shoe-001');
  assert.throws(() => V6.makeProspectiveForecast('PBPB',l,'shoe-001'), /already pending/);
  const bad=JSON.parse(JSON.stringify(l)); bad.pending_id='missing';
  assert.throws(() => V6.validateLedger(bad), /pending_id/);
});

test('all 2,047 binary sequences up to 10 results keep invariants', () => {
  for(let n=0;n<=10;n++)for(let mask=0;mask<(1<<n);mask++){
    let seq=''; for(let i=0;i<n;i++) seq += (mask&(1<<i))?'P':'B';
    const r=V6.analyze(seq),q=V6.rapidRead(seq);
    assert.equal(r.data_quality.accepted_outcomes,n); assert.equal(q.sample_n,n);
    assert.equal(q.probability,null); assert.equal(q.edge_claim,false);
    assert.ok(r.multi_lens.windows.length===4); assert.deepEqual(q,V6.rapidRead(seq));
  }
});

test('large historical sequence is handled deterministically', () => {
  const seq='PPBB'.repeat(25000), start=process.hrtime.bigint(), q=V6.rapidRead(seq), ms=Number(process.hrtime.bigint()-start)/1e6;
  assert.equal(q.sample_n,100000); assert.equal(q.probability,null); assert.equal(q.edge_claim,false);
  console.log(`INFO rapidRead 100,000 outcomes: ${ms.toFixed(2)} ms in build container`);
});

console.log(`\n${passed} V6.0 intelligence-engine tests passed.`);
