# NEXUS ARC V6.1.0 — Release Audit

## Scope
V6.1 adds a session-aware walk-forward replay layer to the V6.0 P/B-only multi-lens analyst. It does not claim that road patterns predict the next baccarat result. The change is intended to improve measurement discipline, not to promise better betting outcomes.

## Main invariants reviewed
- The first target result is the fifth P/B result in each session: four prior accepted outcomes are required before the rapid read.
- Every decision is computed from the prefix strictly before its target outcome.
- Each non-empty input line is a separate session/shoe; the warm-up resets at each line.
- Replay accepts only P/B outcomes and common separators; Tie and unsupported characters are rejected.
- Replay is bounded to 50 sessions and 2,000 outcomes per run.
- NEUTRAL rows remain in tested-decision coverage and are not counted as directional misses.
- Model-vs-fixed-B accuracy uses the same directional rows; fixed-B accuracy across all tested rows is shown separately.
- Session delta is equally weighted across sessions. Bootstrap resamples session-level deltas, not individual hands, and is unavailable below five directional sessions.
- The V6.0 local prospective ledger schema/key remains compatible; prior rows are not silently discarded.
- Brain import cancels pending V6 forecasts before history replacement and rollback remains tested.
- The release launcher checks both server version and dashboard filename. The server asset allowlist includes the V6.1 engine.
- No auto-promotion, auto-weight changes, calibrated probability, expected-value or profitability claim is introduced.

## Verification results
- Python server/regression suite: 47 passed.
- Legacy pattern engine: 15 passed.
- V5.10.1 Brain import guard: 5 passed.
- V5.10.1 rapid analyst engine: 14 passed.
- Roadmap parser: 3 passed.
- V6.0 intelligence engine: 15 passed.
- V6.0 Brain import guard: 4 passed.
- V6.1 validation engine: 12 passed.
- V6.1 Brain import guard: 4 passed.
- **Total automated tests: 119 passed.**
- Python server compilation passed.
- Node syntax check passed for V6.1 engine.
- Syntax checks passed for all 12 inline JavaScript blocks in the V6.1 dashboard.
- Static UI checks passed: validation engine script is included before replay UI, and required replay DOM IDs are present.
- ZIP integrity and SHA-256 manifest are generated for the release package.

## Known limits
1. Historical replay is retrospective and not an untouched out-of-sample test. Prior sequences may have influenced heuristic design.
2. This environment did not perform a full interactive browser test on the user's Windows computer. Automated tests cover engine invariants, server routes, health/version checks, syntax and packaging.
3. Browser localStorage can be edited and is not independently timestamp-attested. Session IDs in the prospective ledger are operator-entered.
4. Sessions may not be statistically independent. Bootstrap intervals are exploratory, not proof of skill.
5. P/B road history does not reveal remaining card composition. Accuracy alone cannot establish calibrated probabilities, positive EV or profitability.

## Release decision
V6.1.0 passes the automated checks listed above and is packaged for controlled installation and validation. Keep the validation gate at WAIT; collect prospective records and evaluate session-separated results before considering further changes.
