# NEXUS ARC V6.2.0 — Release Audit

## Scope
V6.2 extends V6.1's strict prefix-only walk-forward replay with a diagnostic baseline suite and miss-streak audit. This release improves measurement transparency; it does not assert that baccarat road patterns predict future outcomes.

## Invariants reviewed
- Target decisions are computed only after four accepted P/B outcomes exist within that session. Each non-empty line starts a separate session and warm-up.
- For every target, all five comparator predictions are computed from the prefix strictly before that target: fixed B, fixed P, repeat last outcome, alternate last outcome, and prefix-majority (ties to B).
- Input accepts P/B plus supported separators only; Tie and unsupported characters are rejected. Replay is capped at 50 sessions / 2,000 outcomes.
- Model directional accuracy uses only directional model rows. Baseline accuracy on those exact same rows is reported separately from each baseline's all-tested accuracy.
- Equal-session-weighted matched-row deltas and per-baseline session-cluster bootstrap intervals are available only when at least five sessions have directional reads. This is a minimal UI/report gate, not an assertion that five sessions provide strong statistical power.
- Session win/tie/loss counts are calculated from session-level matched-row deltas. Sessions with no model directional read do not contribute a directional delta.
- Miss streaks count adjacent tested decision misses; a neutral or hit resets the streak, and sessions are isolated.
- Existing V6.0/V6.1 prospective ledger records remain readable. The stored key/schema is not changed.
- Brain import cancels pending V6 forecasts before history replacement; rollback paths continue to be tested.
- Launcher requires health version 6.2.0 and exact V6.2 dashboard identity. Dashboard engine is served by the asset allowlist.
- No automatic weighting/promotion, calibrated probability, expected value or profitability assertion is introduced.

## Verification results
- Python server/regression tests: 49 passed.
- Legacy pattern engine: 15 passed.
- V5.10.1 Brain import guard: 5 passed.
- V5.10.1 rapid analyst engine: 14 passed.
- V5.10.1 roadmap parser: 3 passed.
- V6.0 intelligence engine: 15 passed.
- V6.0 Brain import guard: 4 passed.
- V6.2 baseline/replay engine: 18 passed.
- V6.2 Brain import guard: 4 passed.
- **Total automated tests: 127 passed.**
- Python server/test compilation passed; V6.2 engine JavaScript syntax passed.
- Syntax checks passed for all 12 inline JavaScript blocks in the dashboard.
- Chromium component-level replay smoke test passed: actual analyst and V6.2 engine scripts were loaded with the replay section, the UI ran sample sessions, rendered five baseline rows, and emitted no uncaught page errors.
- Python API tests verified `/api/health`, dashboard identity, and allowlisted engine asset serving.
- ZIP integrity and SHA-256 manifest generated at packaging.

## Known limits
1. Historical replay is retrospective and not an untouched out-of-sample test. Historical design influence remains possible.
2. Full-page loopback navigation in the container Chromium was blocked with `ERR_BLOCKED_BY_ADMINISTRATOR`; component-level DOM interaction passed, but this is not a full-site browser E2E test. No interactive test on the user's Windows PC has been run.
3. Browser localStorage can be edited and is not independently timestamp-attested. Session IDs are operator-entered.
4. Shoes may not be statistically independent. Bootstrap intervals are exploratory, not proof of skill.
5. Baselines are simple comparators and selecting the best after testing is subject to post-hoc multiple comparisons.
6. P/B history does not reveal remaining shoe card composition. Accuracy alone cannot establish calibrated probabilities, positive EV or profitability.

## Release decision
V6.2.0 passes the enumerated automated checks and is packaged for controlled installation and validation. Keep the validation gate at WAIT. Collect genuinely prospective, pre-result records over a sufficiently broad set of sessions and evaluate the complete baseline suite before considering a rule change.
