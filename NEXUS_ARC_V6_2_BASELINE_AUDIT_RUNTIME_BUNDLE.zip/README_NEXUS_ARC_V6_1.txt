NEXUS ARC V6.1.0 — FAST INTELLIGENCE + SESSION-AWARE WALK-FORWARD VALIDATION

WHAT CHANGED IN V6.1
- Retains the V6.0 multi-lens P/B analyst and prospective read ledger.
- Adds a Walk-Forward Replay Lab to the dashboard. It evaluates each next P/B result only after building the read from that session's preceding prefix, then starts warm-up again at the next session line.
- Replay input format: one shoe/session per line, P/B only. Within a line, spaces, commas, semicolons and | are allowed separators. T/Tie and other tokens are rejected instead of silently removed.
- Caps replay at 50 session lines and 2,000 total P/B outcomes per run.
- Reports the number of tested decisions, directional coverage, directional accuracy, NEUTRAL coverage, fixed-B accuracy on exactly the same directional rows, and fixed-B accuracy across all tested results.
- Adds equal-session-weighted difference versus fixed-B, with deterministic percentile-bootstrap interval across session-level differences when at least five sessions have directional reads. Rows within a shoe are not treated as independent bootstrap units.
- Shows session-level and last-100 decision-level audits and supports JSON export.
- Keeps the validation gate at WAIT. No auto-promotion, auto-weight changes, calibrated next-hand probability, EV or profit claim.
- Reads the existing V6.0 local prospective ledger schema/key and upgrades the stored version metadata to 6.1 when possible, preserving past records. The browser localStorage remains editable and is not independently timestamped.
- Active server identity is 6.1.0; launcher requires the V6.1 dashboard and health endpoint to both match before opening it. The localhost server still uses the existing server filename for compatibility.

HOW TO USE THE WALK-FORWARD REPLAY LAB
1. Open the V6.1 dashboard.
2. Paste historical P/B sequences into the replay box; each line must be one separate shoe/session. Example:
   P B B P P B P B B P
   B B P P B P B P B B
3. Click “รัน Walk-Forward Replay”. The first target is the fifth result within each line because four prior P/B outcomes are needed for the rapid read.
4. Read coverage with accuracy. NEUTRAL rows count as tested decisions but are not directional hits or misses.
5. Compare the model's directional accuracy with fixed-B on the same directional rows; also inspect fixed-B across all tested rows to see the broader result mix.
6. Treat the session bootstrap interval as exploratory uncertainty, not proof of skill. Export JSON to save the current report; replay input/results are not automatically saved.

PROSPECTIVE LEDGER
- Enter the live history and a stable shoe/session ID, then click the V6 read lock before the next result is known.
- Add the next accepted P/B outcome. The frozen record is resolved against that outcome only if the old history prefix remains unchanged.
- Replacing/editing history cancels pending rows rather than scoring them against the wrong result.
- Export the ledger periodically. Browser localStorage is editable and is not a signed, server-attested timestamp record.

IMPORTANT LIMITATIONS
- Replay is retrospective. Even though each row only sees its past prefix, the heuristic/rules may have been designed after inspecting similar historical sequences; this is not an untouched out-of-sample test.
- P/B road history does not reveal the remaining card composition of a baccarat shoe.
- Rolling windows overlap; agreement among them is not independent evidence.
- High directional accuracy at low coverage may be misleading. Always read directional coverage, sample sizes, neutral counts, baseline comparisons and session counts together.
- Bootstrap is available only with at least five sessions containing directional forecasts, weights sessions equally, and cannot establish independence of sessions.
- Accuracy alone does not prove calibrated probabilities, positive expected value or profitability.
- Full browser end-to-end interaction on the user's Windows computer has not been run in this environment. Syntax, automated engine tests, API regression checks, server asset routes and package integrity are tested locally here.

WINDOWS INSTALL / UPGRADE
1. Stop NEXUS ARC if it is running.
2. Back up the full installation folder, .env, nexus_v5_0_data (if present), Brain exports, and the browser localStorage records you want to preserve.
3. Extract the V6.1 runtime ZIP over the existing installation folder, allowing matching files to be updated. Do not delete .env or user-data folders.
4. Run start_nexus_arc_v5_9.bat. The launcher's filename is retained for backward compatibility; it checks for server 6.1.0 and NEXUS_ARC_V6_1_VALIDATION_ANALYST_DESK.html.
5. Confirm http://127.0.0.1:8787/api/health reports version 6.1.0 and dashboard NEXUS_ARC_V6_1_VALIDATION_ANALYST_DESK.html.
6. If the chosen local port is owned by an unrelated process, the launcher refuses to terminate that process. Resolve the conflict manually or set NEXUS_PORT in .env.

TEST COMMANDS
- py -3 -m unittest -v test_nexus_arc_v6_1_regression.py
- node test_nexus_arc_v5_9_5_pattern_engine.js
- node test_nexus_arc_v5_10_1_brain_import_guard.js
- node test_nexus_arc_v5_10_1_rapid_analyst_engine.js
- node test_nexus_arc_v5_10_1_roadmap_parser.js
- node test_nexus_arc_v6_0_intelligence_engine.js
- node test_nexus_arc_v6_0_brain_import_guard.js
- node test_nexus_arc_v6_1_validation_engine.js
- node test_nexus_arc_v6_1_brain_import_guard.js
- node --check nexus_arc_v6_1_validation_engine.js

COMPATIBILITY NOTE
Legacy V5/V6.0 engines and test files are retained deliberately as compatibility layers and regression references. The active runtime is V6.1.0. The previous V6.0 prospective ledger key/schema is retained to preserve data during upgrade.
