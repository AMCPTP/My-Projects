NEXUS ARC V6.2.0 — FAST INTELLIGENCE + BASELINE SUITE + WALK-FORWARD VALIDATION

WHAT CHANGED IN V6.2
- Retains the V6.0 multi-lens P/B analyst, V6.1 walk-forward replay, prospective lean ledger and Brain-import guard.
- Adds five prefix-only replay comparators: fixed B, fixed P, repeat the previous result, alternate the previous result, and prefix-majority (ties resolve to B).
- Reports every baseline on all tested target results AND separately on the exact rows where the model issued a directional P/B read. Those denominators are different and must not be conflated.
- Adds model-versus-baseline differences at the same model-directional rows, per-session win/tie/loss counts, and equal-session-weighted percentile-bootstrap intervals when at least five sessions have directional reads.
- Adds a consecutive directional-decision miss-streak audit by session. A hit or NEUTRAL breaks a streak, and streaks reset at session boundaries; this is descriptive only.
- The UI explicitly warns that choosing the best-looking baseline after replay is a post-hoc multiple-comparison risk, not evidence of predictive edge.
- Replay accepts P/B only, one shoe/session per line; Tie and unsupported tokens are rejected. Caps remain 50 sessions / 2,000 outcomes per run.
- Keeps validation at WAIT; no auto-promotion, auto-weight updates, next-hand probability calibration, EV or profit claim.
- Compatible with the existing V6.0/V6.1 local prospective ledger schema and records. Current engine version is 6.2.0; existing server and launcher filenames remain unchanged for compatibility.

HOW TO USE THE WALK-FORWARD REPLAY LAB
1. Open the V6.2 dashboard.
2. Paste historical P/B sequences; each line is one separate shoe/session, for example:
   P B B P P B P B B P
   B B P P B P B P B B
3. Click “รัน Walk-Forward Replay”. The first tested target is result five because four prior P/B outcomes are required; warm-up resets on every line.
4. Read tested-decision count, directional coverage, directional accuracy and NEUTRAL count together. Directional accuracy alone can conceal low coverage.
5. In the baseline table, compare all-tested baseline accuracy separately from baseline accuracy on the model's directional rows. “Model Δ” uses the second, matched-row comparison.
6. Review session-level win/tie/loss counts and confidence intervals. The bootstrap resamples session deltas, not individual hands; it needs at least five directional sessions and cannot establish session independence.
7. Inspect the miss-streak audit for session fragility, not as a staking signal. Export JSON to save the report; replay input is not persisted automatically.

PROSPECTIVE LEDGER
- Enter live history and a stable shoe/session ID, then lock the V6 read before the next result is known.
- Add the next accepted P/B outcome. The frozen record is resolved only if the stored prefix still matches.
- Replacing/editing the history cancels pending forecasts instead of scoring against an unrelated outcome.
- Export the ledger periodically. Browser localStorage is editable and is not a signed, independently timestamped record.

IMPORTANT LIMITATIONS
- Replay remains retrospective. The heuristic may have been developed after inspecting similar sequences; this is not an untouched out-of-sample test.
- Baselines are simple diagnostics, not proven strategies. Selecting the best result after testing creates a post-hoc selection problem.
- Matched-row comparisons condition on the model's own directional selections; the separate all-tested baseline metric is shown to make that coverage effect visible.
- P/B road history does not reveal remaining card composition. Rolling windows overlap and are not independent evidence.
- Session bootstrap intervals are exploratory. Shoes may not be independent; five sessions is only a minimum display gate, not a strong sample-size guarantee.
- A miss streak cannot predict the next hand and does not justify increasing stakes.
- No calibration, positive expected value, predictive edge, or profitability is demonstrated by this release.
- Verification here includes engine tests, server/API regression tests, all 12 inline-script syntax checks, and a Chromium component-level replay smoke test. A full-page HTTP browser navigation was blocked by the container's Chromium policy; no full browser run on the user's Windows computer has been performed.

WINDOWS INSTALL / UPGRADE
1. Stop NEXUS ARC if it is running.
2. Back up the full installation folder, .env, nexus_v5_0_data (if present), Brain exports, and browser localStorage data you need to preserve.
3. Extract the V6.2 runtime ZIP over the existing installation folder, allowing matching files to be updated. Do not delete .env or user-data folders.
4. Run start_nexus_arc_v5_9.bat. The historical launcher name is retained for compatibility; it now requires server version 6.2.0 and dashboard NEXUS_ARC_V6_2_VALIDATION_ANALYST_DESK.html.
5. Confirm http://127.0.0.1:8787/api/health reports version 6.2.0 and dashboard NEXUS_ARC_V6_2_VALIDATION_ANALYST_DESK.html.
6. If the port is owned by an unrelated process, the launcher refuses to terminate it. Resolve the conflict manually or set NEXUS_PORT in .env.

TEST COMMANDS
- py -3 test_nexus_arc_v6_2_regression.py
- node test_nexus_arc_v5_9_5_pattern_engine.js
- node test_nexus_arc_v5_10_1_brain_import_guard.js
- node test_nexus_arc_v5_10_1_rapid_analyst_engine.js
- node test_nexus_arc_v5_10_1_roadmap_parser.js
- node test_nexus_arc_v6_0_intelligence_engine.js
- node test_nexus_arc_v6_0_brain_import_guard.js
- node test_nexus_arc_v6_2_validation_engine.js
- node test_nexus_arc_v6_2_brain_import_guard.js
- node --check nexus_arc_v6_2_validation_engine.js

COMPATIBILITY NOTE
Legacy V5/V6.0/V6.1 engines and regression artifacts are retained as references/compatibility layers. The active runtime is V6.2.0. The prior V6 prospective-ledger storage key/schema is deliberately retained so local records are not discarded during upgrade.
