# NEXUS ARC V6.3.0 — Audit Report

## Scope

V6.3 adds server-side prospective evidence logging to the V6.2 analyst and walk-forward replay runtime. The active server release is `6.3.0`; the default dashboard is `NEXUS_ARC_V6_3_VALIDATION_ANALYST_DESK.html`. The old server and launcher filenames are retained for compatibility.

## Evidence chain design

- Storage file: `nexus_v5_0_data/v6_3_prospective_evidence_ledger.json` by default, configurable through `NEXUS_DATA_DIR`.
- Event types: `forecast_locked`, `forecast_resolved`, `forecast_cancelled`.
- Each event includes ordered `seq`, event id, client event id, server-created ISO timestamp, event payload, previous hash and event hash. Event hashes are SHA-256 over canonical JSON; sequence and previous hash are validated.
- The chain is verified before appending and before projecting its forecast records. If the file is corrupted or invalid, writes are blocked and the existing data is preserved.
- Retry of a request with the same `client_event_id`, type and payload is idempotent. An ID reused with a different event or payload is rejected.
- State machine permits at most one pending V6.3 forecast. A lock requires 4–2000 P/B prefix characters and an exactly matching prefix count. Actual outcome must be P or B; ties are excluded rather than coerced. A resolution must target `prefix_pb_count + 1`. Cancellation requires a pending forecast.
- Dashboard waits for a successful server response before marking a lock server-audited; failures remain local-only. Resolution/cancellation events use a client outbox with idempotent retry.
- Local old browser-ledger records are not copied into the server chain because backfilling cannot establish prospective capture.

## Validation results

**178 automated tests passed** in the selected release suite:

| Suite | Passed |
|---|---:|
| V6.3 evidence ledger tests | 13 |
| V6.3 server/API and app regression | 54 |
| V6.3 walk-forward engine | 18 |
| V6.3 Brain import guard | 4 |
| V6.2 walk-forward engine | 18 |
| V6.2 Brain import guard | 4 |
| V6.1 walk-forward engine | 12 |
| V6.1 Brain import guard | 4 |
| V6.0 intelligence engine | 15 |
| V6.0 Brain import guard | 4 |
| V5.10.1 rapid analyst engine | 14 |
| V5.9.5 pattern engine | 15 |
| Roadmap parser | 3 |
| **Total** | **178** |

Additional checks passed: Python byte-compilation of current server/evidence/tests; Node syntax check of V6.3 engine; 12 inline JavaScript syntax checks in the V6.3 dashboard; ZIP integrity and SHA-256 manifest verification (release build step).

A component-level Chromium Replay smoke test ran using a harness and rendered the baseline table with no uncaught JavaScript error. Full-page Chromium navigation to the local HTTP/file URL was blocked by the environment's browser policy, so a complete page E2E is **not** claimed. The user's Windows computer has not been tested directly.

## Interpretation limits / residual risk

1. The SHA-256 chain is tamper-evident, not a digital signature. Someone with local filesystem access can rewrite the entire ledger and recompute all hashes.
2. Timestamps are generated on the local server, not externally trusted. The chain proves internally consistent server-recorded order only; it does not independently establish that an operator-entered result is true or that a prediction was sent before a result unless the corresponding lock receipt is present.
3. If a lock post never receives a server confirmation, its local row is not server-audited. Retrying the lock uses an idempotency key; the first successful server receipt is the logged lock time.
4. One globally pending forecast is allowed. This is intentionally conservative and can restrict concurrent shoes/sessions.
5. Browser outbox storage remains user-controlled; loss of browser storage before pending events reach the server may lose those not-yet-appended events. Back up/export the server ledger; investigate integrity failures rather than deleting data.
6. Retrospective replay is still exposed to model-selection bias. Five baseline strategies are comparison diagnostics, not proven wagering strategies. The best result selected after seeing data is not an unbiased estimate.
7. P/B sequence patterns do not reveal the shoe's remaining cards. No predictive edge, calibrated next-hand probability, expected value or profitability has been demonstrated. Validation remains `WAIT`.

## Release checks

- Server release guard expects `6.3.0` and the V6.3 dashboard filename.
- Server binds to loopback (`127.0.0.1`) by default.
- Existing `.env` and `nexus_v5_0_data` must be preserved through upgrade.
- New server evidence uses a separate file; old localStorage evidence is not automatically backfilled.
