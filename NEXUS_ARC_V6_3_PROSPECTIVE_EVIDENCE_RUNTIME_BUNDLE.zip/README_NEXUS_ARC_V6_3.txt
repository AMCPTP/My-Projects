NEXUS ARC V6.3.0 — PROSPECTIVE EVIDENCE CHAIN + WALK-FORWARD AUDIT

PURPOSE
V6.3 adds a server-side, append-only-by-application prospective evidence ledger to the V6.2 analyst/replay system. The ledger records a frozen forecast before the next accepted result, then records its P/B resolution or cancellation as a later event. Events are SHA-256 hash-linked and validated before every append/read projection. Duplicate client-event retries are idempotent, and a damaged chain blocks further writes rather than silently rewriting the evidence.

WHAT CHANGED
- New server module: nexus_arc_v6_3_evidence.py.
- New local-server endpoints:
  GET  /api/v6_3/evidence/status
  GET  /api/v6_3/evidence/verify
  GET  /api/v6_3/evidence/ledger
  POST /api/v6_3/evidence/events
- Server evidence file: nexus_v5_0_data/v6_3_prospective_evidence_ledger.json by default, or under NEXUS_DATA_DIR if configured.
- Forecast locks are sent immediately to the local server. The dashboard only marks a forecast server-audited after it receives a successful server response. If the local server cannot confirm the lock, the local forecast can remain available but is explicitly not server-audited.
- Resolution/cancellation events use an outbox and idempotent client_event_id so temporary network failures can be retried without duplicate appends.
- A forecast resolution must point exactly to prefix count + 1. The ledger accepts P/B outcomes only; Tie is not silently converted to P or B.
- The V6.2 replay suite remains and compares five simple prefix-only baselines. V6.0/V6.1/V6.2 local browser-ledger metadata continues to be readable by the V6.3 engine.
- Existing server, dashboard components, local learning/assurance modules, and legacy launcher names are retained for compatibility. Runtime version is 6.3.0.

HOW TO USE THE PROSPECTIVE LEDGER
1. Start V6.3 and open the dashboard through the checked launcher.
2. Enter a stable session/shoe ID and a valid P/B history (minimum four accepted P/B outcomes for the rapid read).
3. Lock the read before the next outcome is known. Wait for an explicit server-chain receipt in the V6.3 evidence status area before treating it as server-audited.
4. Record the next accepted P/B result through the dashboard. The server checks that the result index exactly matches the locked prefix plus one.
5. If the history is replaced or imported from Brain, the pending read is cancelled rather than scored against unrelated data.
6. Use the evidence status / verification controls to check chain integrity. Export the server ledger periodically and retain an offline copy if it matters for an audit.

EVIDENCE ENDPOINT NOTES
- The server-side chain preserves event order as recorded by this local server and includes server-generated timestamps.
- POST events is idempotent when a client retries the same client_event_id with the same type and payload; reusing an ID with changed content is rejected.
- A duplicate pending forecast is blocked. There may be only one globally pending V6.3 forecast in this ledger at a time.
- Writes stop if the existing chain fails integrity validation. Back up the corrupted file before investigating; do not delete or edit it merely to clear the warning.
- Export is a JSON copy, not a digital signature or external timestamp service.

WINDOWS INSTALL / UPGRADE
1. Stop NEXUS ARC before changing files.
2. Make a full backup of the current install, .env, nexus_v5_0_data (or your configured NEXUS_DATA_DIR), Brain exports, and browser localStorage records you need. In particular, preserve all existing learning/assurance ledger files.
3. Extract the V6.3 runtime ZIP into the existing install directory and allow matching runtime files to be updated. Do not remove .env or the data directory.
4. Run start_nexus_arc_v5_9.bat. The legacy filename is retained but its PowerShell release guard now expects server 6.3.0 and NEXUS_ARC_V6_3_VALIDATION_ANALYST_DESK.html.
5. Open http://127.0.0.1:8787/api/health and verify version=6.3.0 and dashboard=NEXUS_ARC_V6_3_VALIDATION_ANALYST_DESK.html. If NEXUS_PORT is customized, use that port instead.
6. Confirm V6.3 evidence status says the hash chain is valid. A new server evidence ledger is separate from old browser localStorage; old local records are not automatically backfilled into server evidence because doing so would not be prospective.
7. Back up the new file nexus_v5_0_data/v6_3_prospective_evidence_ledger.json periodically.

TEST COMMANDS (run from this directory)
- py -3 -m unittest -v test_nexus_arc_v6_3_evidence.py test_nexus_arc_v6_3_regression.py
- node test_nexus_arc_v5_9_5_pattern_engine.js
- node test_nexus_arc_v5_10_1_rapid_analyst_engine.js
- node test_nexus_arc_v5_10_1_roadmap_parser.js
- node test_nexus_arc_v6_0_intelligence_engine.js
- node test_nexus_arc_v6_0_brain_import_guard.js
- node test_nexus_arc_v6_1_validation_engine.js
- node test_nexus_arc_v6_1_brain_import_guard.js
- node test_nexus_arc_v6_2_validation_engine.js
- node test_nexus_arc_v6_2_brain_import_guard.js
- node test_nexus_arc_v6_3_validation_engine.js
- node test_nexus_arc_v6_3_brain_import_guard.js
- node --check nexus_arc_v6_3_validation_engine.js

IMPORTANT LIMITATIONS
- A hash chain detects accidental/tampering changes unless an actor can rewrite the entire local file and recompute the chain. The local administrator controls the server and ledger file; this is not independently witnessed or digitally signed.
- The server timestamp is generated by the machine running NEXUS; it is not a trusted external clock. This log does not prove that an operator-entered result is true, that a casino result was recorded correctly, or that a forecast was not withheld before being sent.
- Existing browser localStorage remains editable. A local record without a confirmed server lock receipt must not be described as server-audited.
- The V6.2 replay is retrospective, not an untouched out-of-sample test. V6.3 improves prospective record-keeping, but does not prove a predictive edge.
- P/B road history alone does not reveal remaining cards. No calibrated next-hand probability, positive expected value, profitability or guarantee is established.
- Baseline results and hit rate must be read alongside directional coverage, neutral count, session dependence, and pre-specified comparison criteria. Choosing whichever baseline looks best after testing introduces post-hoc selection bias.
- Automated regression and engine checks passed. Inline JavaScript syntax was checked for all 12 embedded blocks. A component-level Chromium Replay smoke test was run, but full-page HTTP/file navigation in Chromium was blocked by the environment policy; no end-to-end run on the user's Windows computer has been performed.

SECURITY / OPERATING NOTES
- The server binds to 127.0.0.1 by default. Do not expose it to a public network without a separate threat model and authentication.
- Do not share .env or real API credentials. .env.example is only a template.
- If the port is occupied by an unrelated process, the checked launcher refuses to terminate that process; choose another NEXUS_PORT or resolve the conflict manually.
