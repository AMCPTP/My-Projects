'use strict';
const assert = require('node:assert/strict');
require('./nexus_arc_v5_10_1_rapid_analyst_engine.js');
const V61 = require('./nexus_arc_v6_1_validation_engine.js');
let passed = 0;
function test(name, fn) { fn(); passed++; console.log('PASS ' + name); }

 test('V6.1 API adds validation replay and preserves V6.0 ledger compatibility', () => {
  assert.equal(V61.VERSION, '6.1.0');
  assert.equal(typeof V61.walkForwardReplay, 'function');
  assert.equal(typeof V61.validateLedger, 'function');
  const old = {schema:'nexus-arc-v6.0-prospective-lean-ledger-v1',version:'6.0.0',created_at:'2026-10-01T00:00:00.000Z',pending_id:null,records:[]};
  assert.equal(V61.validateLedger(old), old);
  assert.equal(V61.emptyLedger().version, '6.1.0');
 });

test('parser treats each non-empty line as a separate P/B session', () => {
  const sessions = V61.parseReplaySessions('P B, B;P|P\n\nB,B P P;B');
  assert.deepEqual(sessions.map(x => x.sequence), ['PBBPP','BBPPB']);
  assert.deepEqual(sessions.map(x => x.session_id), ['session-01','session-02']);
});

test('strict walk-forward uses only prefix and targets the next accepted result', () => {
  const r = V61.walkForwardReplay('BBBBB');
  assert.equal(r.tested_decisions, 1);
  assert.equal(r.decisions[0].prefix_pb_count, 4);
  assert.equal(r.decisions[0].prefix_pb_sequence, 'BBBB');
  assert.equal(r.decisions[0].actual, 'B');
  assert.equal(r.decisions[0].predicted_lean, 'B');
  assert.equal(r.directional_accuracy, 1);
  assert.equal(r.always_b_accuracy_on_same_directional_rows, 1);
  assert.equal(r.always_b_accuracy_all_tested, 1);
});

test('each shoe restarts warm-up; no prior session outcomes leak forward', () => {
  const r = V61.walkForwardReplay('PBPB\nBBBBB');
  assert.equal(r.input_sessions, 2);
  assert.equal(r.input_outcomes, 9);
  assert.equal(r.tested_decisions, 1);
  assert.equal(r.session_summaries[0].tested_decisions, 0);
  assert.equal(r.session_summaries[1].tested_decisions, 1);
  assert.equal(r.decisions[0].prefix_pb_sequence, 'BBBB');
});

test('first tested decision is on the fifth result; length-based count invariant', () => {
  const r = V61.walkForwardReplay('PPPPPP\nBBBBBBB\nPBPB\nBPPBBB');
  assert.equal(r.tested_decisions, (6-4)+(7-4)+0+(6-4));
  assert.ok(r.decisions.every(x => x.prefix_pb_count >= 4));
  assert.ok(r.decisions.every(x => x.prefix_pb_sequence.length === x.prefix_pb_count));
});

test('neutral decisions count toward coverage, not directional misses', () => {
  const r = V61.walkForwardReplay('PBPBP');
  assert.equal(r.tested_decisions, 1);
  assert.equal(r.neutral_reads, 1);
  assert.equal(r.directional_scored, 0);
  assert.equal(r.directional_accuracy, null);
  assert.equal(r.directional_coverage, 0);
});

test('model and fixed-B comparison use exactly the same directional rows', () => {
  const r = V61.walkForwardReplay('PPPPBPBBPP');
  const rows = r.decisions.filter(x => x.predicted_lean === 'P' || x.predicted_lean === 'B');
  const hits = rows.filter(x => x.hit).length;
  const bHits = rows.filter(x => x.actual === 'B').length;
  assert.equal(r.directional_scored, rows.length);
  assert.equal(r.directional_accuracy, hits/rows.length);
  assert.equal(r.always_b_accuracy_on_same_directional_rows, bHits/rows.length);
  assert.equal(r.delta_accuracy_vs_always_b_same_rows, (hits-bHits)/rows.length);
});

test('session bootstrap stays unavailable below five directional sessions', () => {
  const r = V61.walkForwardReplay('PPPPP\nBBBBB\nPPPPP\nBBBBB');
  assert.equal(r.directional_sessions, 4);
  assert.equal(r.bootstrap_95_ci_session_delta.available, false);
  assert.equal(r.bootstrap_95_ci_session_delta.low, null);
});

test('session-cluster bootstrap is deterministic and requires five eligible sessions', () => {
  const text = Array.from({length:10}, (_,i) => i%2 ? 'BBBBB' : 'PPPPP').join('\n');
  const a = V61.walkForwardReplay(text), b = V61.walkForwardReplay(text);
  assert.equal(a.directional_sessions, 10);
  assert.equal(a.bootstrap_95_ci_session_delta.available, true);
  assert.equal(a.bootstrap_95_ci_session_delta.replicates, 3000);
  assert.deepEqual(a.bootstrap_95_ci_session_delta, b.bootstrap_95_ci_session_delta);
  assert.ok(a.bootstrap_95_ci_session_delta.low <= a.bootstrap_95_ci_session_delta.high);
});

test('tie / invalid tokens rejected rather than silently filtered', () => {
  assert.throws(() => V61.walkForwardReplay('PBTBP'), /unsupported characters/);
  assert.throws(() => V61.walkForwardReplay('Player Banker Tie'), /unsupported characters/);
  assert.throws(() => V61.walkForwardReplay(''), /at least one/);
});

test('replay input caps sessions and total outcomes', () => {
  assert.throws(() => V61.parseReplaySessions(Array.from({length:51},()=> 'PPPPP').join('\n')), /up to 50/);
  assert.throws(() => V61.parseReplaySessions('P'.repeat(2001)), /at most 2000/);
});

test('replay output explicitly disclaims calibrated probabilities and profitability', () => {
  const r = V61.walkForwardReplay('PPPPPP');
  assert.equal(r.version, '6.1.0');
  assert.ok(r.warnings.some(x => x.includes('not an untouched out-of-sample test')));
  assert.ok(r.warnings.some(x => x.includes('No probability calibration')));
  assert.equal(Object.prototype.hasOwnProperty.call(r, 'predicted_probability'), false);
});

console.log(`\n${passed} V6.1 validation-engine tests passed.`);
