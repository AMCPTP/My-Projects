import copy
import unittest
from datetime import datetime, timezone

import nexus_arc_v6_3_evidence as E


def lock_payload(fid='f-001', lean='P', seq='PBPB', session='shoe-001'):
    return {
        'forecast_id': fid,
        'session_id': session,
        'model_version': '6.3.0',
        'prefix_pb_sequence': seq,
        'prefix_pb_count': len(seq),
        'predicted_lean': lean,
        'source_lean': lean,
        'evidence_level': 'EXPLORATORY',
        'lens_conflict': False,
        'client_created_at': '2026-10-18T00:00:00.000Z',
    }


def resolved_payload(fid='f-001', actual='P', target_index=5):
    return {'forecast_id': fid, 'actual': actual, 'target_index': target_index}


class V63EvidenceLedgerTests(unittest.TestCase):
    def setUp(self):
        self.events = []

    def append(self, kind, payload, eid):
        return E.append_event(self.events, kind, payload, eid, now='2026-10-18T01:00:00.000Z')

    def test_empty_chain_is_valid_and_has_genesis_head(self):
        v = E.verify_chain(self.events)
        self.assertTrue(v['valid'])
        self.assertEqual(v['checked'], 0)
        self.assertEqual(v['last_hash'], E.GENESIS)

    def test_freeze_then_resolve_creates_server_ordered_hash_chain_and_projection(self):
        lock, duplicate = self.append('forecast_locked', lock_payload(), 'v63-event-lock-001')
        self.assertFalse(duplicate)
        self.assertEqual(lock['seq'], 1)
        self.assertEqual(lock['prev_hash'], E.GENESIS)
        resolved, duplicate = self.append('forecast_resolved', resolved_payload(), 'v63-event-resolve-001')
        self.assertFalse(duplicate)
        self.assertEqual(resolved['seq'], 2)
        self.assertEqual(resolved['prev_hash'], lock['event_hash'])
        integrity = E.verify_chain(self.events)
        self.assertTrue(integrity['valid'], integrity)
        projected = E.project(self.events)['forecasts']['f-001']
        self.assertEqual(projected['status'], 'RESOLVED')
        self.assertEqual(projected['actual'], 'P')
        self.assertTrue(projected['hit'])
        self.assertEqual(projected['server_locked_at'], lock['created_at'])

    def test_neutral_forecast_resolves_for_coverage_without_directional_hit(self):
        self.append('forecast_locked', lock_payload(lean='NEUTRAL'), 'v63-event-lock-neutral')
        self.append('forecast_resolved', resolved_payload(actual='B'), 'v63-event-resolve-neutral')
        f = E.project(self.events)['forecasts']['f-001']
        self.assertIsNone(f['hit'])
        self.assertEqual(f['status'], 'RESOLVED')

    def test_same_client_event_retry_is_idempotent(self):
        row, dup = self.append('forecast_locked', lock_payload(), 'v63-event-lock-001')
        retry, dup = self.append('forecast_locked', lock_payload(), 'v63-event-lock-001')
        self.assertTrue(dup)
        self.assertEqual(row, retry)
        self.assertEqual(len(self.events), 1)

    def test_reused_client_id_with_different_payload_is_rejected(self):
        self.append('forecast_locked', lock_payload(), 'v63-event-lock-001')
        changed = lock_payload(lean='B')
        with self.assertRaisesRegex(ValueError, 'different event payload'):
            self.append('forecast_locked', changed, 'v63-event-lock-001')
        self.assertEqual(len(self.events), 1)

    def test_second_pending_lock_is_blocked(self):
        self.append('forecast_locked', lock_payload(), 'v63-event-lock-001')
        with self.assertRaisesRegex(ValueError, 'another forecast is already pending'):
            self.append('forecast_locked', lock_payload(fid='f-002'), 'v63-event-lock-002')
        self.assertEqual(len(self.events), 1)

    def test_wrong_target_index_does_not_resolve_or_append(self):
        self.append('forecast_locked', lock_payload(), 'v63-event-lock-001')
        with self.assertRaisesRegex(ValueError, 'target index'):
            self.append('forecast_resolved', resolved_payload(target_index=6), 'v63-event-resolve-001')
        self.assertEqual(len(self.events), 1)
        self.assertEqual(E.project(self.events)['forecasts']['f-001']['status'], 'PENDING')

    def test_cancellation_is_not_scored_and_allows_next_lock(self):
        self.append('forecast_locked', lock_payload(), 'v63-event-lock-001')
        self.append('forecast_cancelled', {'forecast_id':'f-001','cancel_reason':'history_prefix_changed'}, 'v63-event-cancel-001')
        self.append('forecast_locked', lock_payload(fid='f-002', session='shoe-002'), 'v63-event-lock-002')
        projection = E.project(self.events)['forecasts']
        self.assertEqual(projection['f-001']['status'], 'CANCELLED')
        self.assertNotIn('hit', {k for k,v in projection['f-001'].items() if v is not None})
        self.assertEqual(projection['f-002']['status'], 'PENDING')

    def test_tampering_payload_or_event_hash_is_detected_and_blocks_append(self):
        self.append('forecast_locked', lock_payload(), 'v63-event-lock-001')
        self.events[0]['payload']['predicted_lean'] = 'B'
        result = E.verify_chain(self.events)
        self.assertFalse(result['valid'])
        self.assertIn('event hash mismatch', result['reason'])
        with self.assertRaisesRegex(ValueError, 'integrity failure'):
            E.append_event(self.events, 'forecast_cancelled', {'forecast_id':'f-001','cancel_reason':'test'}, 'v63-event-cancel-001')

    def test_invalid_prefix_lean_tie_and_extra_payload_fields_are_rejected(self):
        for payload in [lock_payload(seq='PBTT'), lock_payload(lean='T'), {**lock_payload(), 'extra':'no'}]:
            with self.assertRaises(ValueError):
                E.append_event([], 'forecast_locked', payload, 'v63-event-lock-001')

    def test_resolving_unknown_forecast_is_rejected(self):
        with self.assertRaisesRegex(ValueError, 'existing pending lock'):
            self.append('forecast_resolved', resolved_payload(), 'v63-event-resolve-001')

    def test_server_timestamps_must_be_iso_and_chain_has_fixed_sequence(self):
        self.append('forecast_locked', lock_payload(), 'v63-event-lock-001')
        broken = copy.deepcopy(self.events)
        broken[0]['created_at'] = 'not-a-time'
        self.assertFalse(E.verify_chain(broken)['valid'])
        broken2 = copy.deepcopy(self.events)
        broken2[0]['seq'] = 4
        self.assertFalse(E.verify_chain(broken2)['valid'])

    def test_payload_size_caps_prefix(self):
        with self.assertRaisesRegex(ValueError, '4 to 2000'):
            E.append_event([], 'forecast_locked', lock_payload(seq='P'*2001), 'v63-event-lock-001')


if __name__ == '__main__':
    unittest.main(verbosity=2)
