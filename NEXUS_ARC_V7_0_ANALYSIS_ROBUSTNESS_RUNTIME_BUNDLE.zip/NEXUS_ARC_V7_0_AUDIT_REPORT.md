# NEXUS ARC V7.0.0 — Analysis Weakness Audit

## Summary
V7 adds an analysis-robustness layer on top of the V6.3 runtime. It does not change the existing lean-generation formula or promote a strategy. It asks whether order-based road features are unusual under a stated conditional null model and whether the current read changes when recent observations are removed.

## V6.3 analytical weaknesses and V7 handling

| Weakness | Why it matters | V7 handling | Residual risk |
|---|---|---|---|
| Visual pattern over-interpretation | Streaks and alternation occur in finite random-looking sequences | Conditional permutation distribution for max run and alternations, preserving P/B counts | Assumes exchangeability; only two predeclared metrics tested |
| Multiple pattern search / researcher degrees of freedom | A pattern can look impressive after many patterns/windows were inspected | Bonferroni adjustment across the two V7 metrics and explicit warning | Does not correct for all earlier model-development choices |
| Lean sensitivity to newest outcomes | A short suffix can change the apparent direction | Drop-last-1/2/3 sensitivity report | Sensitivity is not accuracy and does not establish which read is better |
| Overlapping rolling windows | Window agreement is not independent evidence | Existing V6.3 overlap caveat retained | No new independent evidence is created |
| Retrospective/model-selection bias | Strategy and thresholds were developed after inspecting historical patterns | Weakness register explicitly marks it unresolved; prospective V6.3 evidence chain and walk-forward replay retained | Needs independent pre-registered future sessions |
| Missing card composition | P/B outcomes alone do not show remaining cards | Explicitly reports composition as unavailable | Cannot calculate shoe-specific next-hand odds |
| Probability/EV overclaim | Directional lean is not a calibrated probability | No probability or EV output added; gate remains WAIT | No predictive edge demonstrated |
| Prospective provenance limitations | Local records can be edited; session/result data are operator supplied | V6.3 server hash-chain retained | Local server time is not externally attested; local administrator can rewrite chain |

## V7 null test
- Input is strict P/B only; maximum 2,000 outcomes.
- Requires at least 12 outcomes and both P and B; otherwise returns unavailable rather than a result.
- Uniformly shuffles observed labels, preserving exact P and B counts.
- `max_run`: upper-tail empirical p-value.
- `alternations`: two-sided empirical p-value around the simulated null median.
- Empirical p-value uses the plus-one correction. Bonferroni adjustment is applied to these two metrics.
- Default 1,999 permutations, with dashboard options 999 / 1,999 / 4,999. Output is deterministic for identical sequence and replicate count.

The test is conditional on a null model; it does not test the full baccarat mechanism, cannot predict the next outcome, and is not a proof of randomness or non-randomness. The two-metric adjustment does not fix unrecorded prior pattern searches.

## V7 suffix sensitivity
The module removes the final 1, 2 and 3 outcomes, recomputes the V6.3 lean, and marks changes against the full-sequence read. This is deliberately a fragility report, not an optimization tool. Users must not choose the prefix that happens to yield the preferred direction.

## Validation results
- V7 diagnostics tests: 12 passed.
- V6.3 server/API regression suite under V7 release identity: 54 passed.
- V6.3 evidence ledger tests: 13 passed.
- Compatibility JavaScript tests: V5.9.5 pattern 15; V5.10.1 analyst 14; roadmap 3; V6.0 engine 15 + guard 4; V6.1 engine 12 + guard 4; V6.2 engine 18 + guard 4; V6.3 engine 18 + guard 4. These totals plus the V7/server/evidence suites equal 190 tests.
- Python byte compilation passed.
- Node syntax check for V7 engine passed.
- 13 inline JavaScript blocks in the V7 dashboard passed syntax checks.
- Server health/dashboard version checks and static-asset allowlist tests passed as part of the 54 API/regression tests.

## Not claimed
- No full interactive browser E2E on the user's Windows machine has been performed.
- No independently collected prospective result set has been supplied in this development turn.
- No calibrated next-hand probability, expected value, profitability, or predictive edge has been demonstrated.
- The V7 diagnostics do not alter the core lean formula or auto-update weights.
