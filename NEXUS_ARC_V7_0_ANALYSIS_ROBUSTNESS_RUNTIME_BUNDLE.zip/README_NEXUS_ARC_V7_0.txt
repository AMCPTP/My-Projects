NEXUS ARC V7.0.0 — ANALYSIS ROBUSTNESS + VALIDATION
===================================================

PURPOSE
V7 continues the V6.3 P/B analyst, prospective evidence chain, walk-forward replay, baseline comparison, and legacy compatibility. The new diagnostic layer aims to expose weaknesses in retrospective pattern reading rather than make the directional lean sound more confident.

NEW IN V7
1. Conditional order-randomization test. It shuffles the observed P/B sequence while preserving the exact counts of P and B, then compares the observed maximum run and number of alternations against that null distribution. Default 1,999 permutations; selectable 999 / 1,999 / 4,999 in the dashboard. Two metrics receive Bonferroni adjustment.
2. Suffix sensitivity. Recomputes the V6.3 read after dropping the last 1, 2, or 3 outcomes. A change means the read is fragile to recent observations; it is not a reason to select a favorable prefix.
3. Weakness register. Explicitly marks model-selection bias unresolved, remaining-card composition unavailable, and prospective capture/future leakage as outside this diagnostic module.
4. JSON export of the diagnostic report.

INTERPRETATION / LIMITS
- The permutation test assumes order exchangeability conditional on the observed P/B counts. This is an exploratory null model, not a proven description of baccarat shoe mechanics.
- The adjusted p-values correct only the two predeclared metrics shown in this module. They do not correct for every pattern previously explored or selected during model development.
- A small p-value is not evidence of next-hand predictability, expected value, or profitability. A large p-value does not prove randomness.
- The suffix test measures sensitivity, not accuracy. Never tune the model by choosing the prefix with the most attractive result.
- P/B road history does not reveal remaining card composition. V7 does not produce next-hand probability or a wagering recommendation.
- Keep prospective Validation Gate at WAIT pending sufficient independently captured, pre-registered sessions.

INSTALL / UPGRADE
1. Stop NEXUS ARC.
2. Back up the complete installation folder, .env, configured NEXUS_DATA_DIR (including nexus_v5_0_data), Brain exports, and any browser localStorage data you need.
3. Extract this bundle over the existing installation without deleting the data directory or .env.
4. Run start_nexus_arc_v5_9.bat (legacy filename retained; it invokes the checked launcher).
5. Confirm http://127.0.0.1:8787/api/health reports version 7.0.0 and dashboard NEXUS_ARC_V7_0_ANALYSIS_ROBUSTNESS_DESK.html.
6. Verify the V6.3 server evidence chain before prospective use. V7 preserves the existing V6.3 evidence endpoints and ledger format; it does not backfill old localStorage records as prospective server evidence.

FILES
- NEXUS_ARC_V7_0_ANALYSIS_ROBUSTNESS_DESK.html: active dashboard
- nexus_arc_v7_diagnostics_engine.js: V7 diagnostic module
- NEXUS_ARC_V7_0_SHA256SUMS.txt: per-file integrity manifest for this bundle
- nexus_arc_v6_3_validation_engine.js: V6.3 core analyst, evidence-ledger integration and walk-forward engine
- nexus_arc_v5_9_server.py: server version 7.0.0; legacy filename retained
- launch_nexus_arc_v5_9.ps1 / start_nexus_arc_v5_9.bat: checked launcher chain
- test_nexus_arc_v7_diagnostics_engine.js: V7 diagnostic unit tests
- test_nexus_arc_v6_3_regression.py: server/API regression adapted to V7 release identity
- test_nexus_arc_v6_3_evidence.py: evidence ledger tests

This build has not been installed on the user's Windows machine. See the audit and test reports for verified checks and remaining limitations.
