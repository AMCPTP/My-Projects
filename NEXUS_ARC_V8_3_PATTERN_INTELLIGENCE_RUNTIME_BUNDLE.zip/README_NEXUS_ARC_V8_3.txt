NEXUS ARC V8.3 — PATTERN INTELLIGENCE + VALIDATION DESK
======================================================

PURPOSE
V8.3 consolidates the planned V8.0/V8.1/V8.2/V8.3 analysis roadmap into one release based on V7.0. It expands descriptive P/B pattern coverage, compares multiple windows, exposes conflicts and instability, adds a conditional fixed-margin pattern test, and adds retrospective walk-forward scoring and a controlled candidate-review gate.

WHAT'S NEW
1. Pattern inventory: current/max run, alternations, repeated overlapping motifs of length 2–5, and historical transition counts/shares.
2. Multi-scale view: trailing windows 4, 8, 12, 20, and 40 outcomes. Partial windows are labeled. Descriptive labels use predeclared rules (P/B share within 10 percentage points of 50% is BALANCED; alternation rate >= 0.70 is ALTERNATING; <= 0.30 is PERSISTENT/CLUSTERED).
3. Context/conflict panel: compares short and broad windows and calls out rhythm changes and repeated motifs. This is context, not a next-hand signal.
4. Suffix sensitivity: drops the final 1–3 outcomes and compares qualitative window classes, the current-run length band, and repeated motifs. It is a robustness diagnostic, not a method to find a favorable prefix.
5. Pattern null test: by default 999 random permutations, optionally 1,999 or 4,999, preserving exact observed P/B counts. Reports max run, alternations and maximum repeated-motif count; Bonferroni adjustment covers those three displayed metrics only.
6. Retrospective prequential audit: scores five fixed heuristic baselines from a minimum history of 20 outcomes: fixed 0.5, follow-last, alternate-last, prefix-majority with Laplace smoothing, and transition-smoothed. Metrics include log loss/Brier on all scored rows and directional hit rate only where a side is actually selected. The fixed-0.5 neutral baseline has zero directional coverage, so hit rate is N/A.
7. Controlled candidate review: candidate evidence remains SHADOW_ONLY until minimum counts are supplied. At least 200 pre-registered forecasts and 20 sessions are required to consider further review. Both log-loss and Brier deltas must favor the candidate, both supplied upper confidence bounds must be below zero, and at least two independent replications must be reported before the tool says ELIGIBLE_FOR_HUMAN_REVIEW. This never promotes automatically. The form values are operator-entered and are not automatically verified against the ledger.
8. Existing V6.3 evidence ledger endpoints, schema, local data directories and core live-lean logic remain in place. V8.3 does not replace V6.3 prospective validation or auto-update production models.

INSTALL / UPGRADE
1. Stop the running NEXUS ARC window/server.
2. Back up the full installation folder, .env, the configured NEXUS_DATA_DIR / nexus_v5_0_data, Brain exports, and browser localStorage records you need.
3. Extract this bundle into the existing application folder. Do not delete the data directory or .env.
4. Run start_nexus_arc_v5_9.bat; the legacy filename intentionally remains and invokes launch_nexus_arc_v5_9.ps1.
5. Verify http://127.0.0.1:8787/api/health reports version 8.3.0 and dashboard NEXUS_ARC_V8_3_PATTERN_INTELLIGENCE_DESK.html. If NEXUS_PORT differs, use that port.
6. Confirm the V6.3 evidence-chain integrity before capturing new prospective records. Existing events are not retroactively made independently verified.
7. Open the V8.3 Pattern Intelligence section, click Run V8.3 Pattern Analysis, then inspect windows, motifs, context conflicts, null test, and walk-forward baselines. Use the Export button to save a JSON report.

IMPORTANT INTERPRETATION LIMITS
- P/B-only road history does not reveal the remaining card composition of the shoe.
- No next-hand probability, betting recommendation, expected value, or profitability claim is produced by V8.3.
- A repeated motif can occur by chance; the null model assumes exchangeable P/B ordering conditional on the margins, which is an assumption, not a fact about baccarat mechanics.
- Bonferroni adjustment covers only the three metrics displayed in this V8.3 null test. It does not correct for all historic exploration or model-selection bias.
- Historical walk-forward on one pasted sequence is retrospective and remains vulnerable to selection bias. It is not the prospective evidence gate.
- User-supplied candidate-review numbers are not authenticated. Strong-looking input values cannot verify themselves.
- Independent session capture and the V6.3 validation gate should remain WAIT until the evidence floor is genuinely met and independently replicated.

FILES
- NEXUS_ARC_V8_3_PATTERN_INTELLIGENCE_DESK.html: active dashboard
- nexus_arc_v8_3_pattern_intelligence_engine.js: new pattern analysis and review module
- nexus_arc_v7_diagnostics_engine.js: preserved V7 null/stability diagnostics
- nexus_arc_v5_9_server.py: API-compatible server, version 8.3.0
- NEXUS_ARC_V7_0_ANALYSIS_ROBUSTNESS_DESK.html: preserved V7 dashboard fallback
- NEXUS_ARC_V8_3_AUDIT_REPORT.md / NEXUS_ARC_V8_3_TEST_REPORT.txt: release audit and test evidence
- NEXUS_ARC_V8_3_SHA256SUMS.txt: per-file SHA-256 manifest for the release contents

TEST SCOPE
The build tests cover V8.3 analytical invariants, V6.3 server/evidence regression, legacy engine compatibility, server asset allowlisting, route/version guard behavior, Python compilation and JavaScript syntax. Tests do not establish predictive edge and do not substitute for testing the launch flow on the user's Windows machine.
