/* NEXUS ARC V8.3 Pattern Intelligence Engine
 * Descriptive P/B pattern detection + robustness + retrospective prequential audits.
 * Does not produce next-hand probabilities, wagering advice, or a claim of edge.
 */
(function(root){
  'use strict';
  const VERSION = '8.3.0';
  const MAX_SEQUENCE = 2000;
  const DEFAULT_WINDOWS = [4,8,12,20,40];
  const MIN_SEQUENCE = 8;
  const MIN_WF_HISTORY = 20;
  const EPS = 1e-12;

  function parseSequence(input){
    if(typeof input !== 'string') throw new Error('Sequence must be text containing P/B outcomes.');
    const raw = input.toUpperCase();
    if(/[^PB\s,;|/._-]/.test(raw)) throw new Error('Use only P and B outcomes plus spaces or separators.');
    const s = raw.replace(/[^PB]/g,'');
    if(s.length > MAX_SEQUENCE) throw new Error(`Sequence exceeds ${MAX_SEQUENCE} P/B outcomes.`);
    return s;
  }
  function assertSequence(s){
    if(typeof s !== 'string' || !/^[PB]*$/.test(s)) throw new Error('Sequence must contain only P and B outcomes.');
    if(s.length > MAX_SEQUENCE) throw new Error(`Sequence exceeds ${MAX_SEQUENCE} P/B outcomes.`);
    return s;
  }
  function maxRun(s){ let best=0, run=0, side=null; for(const x of s){run=x===side?run+1:1;side=x;if(run>best)best=run;} return best; }
  function currentRun(s){ if(!s.length)return {side:null,length:0};let i=s.length-1;while(i>0&&s[i-1]===s[s.length-1])i--;return {side:s[s.length-1],length:s.length-i}; }
  function alternations(s){let n=0;for(let i=1;i<s.length;i++)if(s[i]!==s[i-1])n++;return n;}
  function counts(s){let P=0;for(const x of s)if(x==='P')P++;return {n:s.length,P,B:s.length-P,p_share:s.length?P/s.length:null,b_share:s.length?(s.length-P)/s.length:null};}
  function transitionMatrix(s){
    const m={P:{P:0,B:0,total:0},B:{P:0,B:0,total:0}};
    for(let i=1;i<s.length;i++){m[s[i-1]][s[i]]++;m[s[i-1]].total++;}
    for(const from of ['P','B']) for(const to of ['P','B']) m[from][`${to}_share`]=m[from].total?m[from][to]/m[from].total:null;
    return m;
  }
  function countMotifs(s,minLen=2,maxLen=5){
    const all=[];
    for(let k=minLen;k<=maxLen;k++){
      if(s.length<k)continue;
      const map=new Map();
      for(let i=0;i<=s.length-k;i++){
        const motif=s.slice(i,i+k);let row=map.get(motif);
        if(!row){row={motif,length:k,count:0,positions:[]};map.set(motif,row);}
        row.count++;if(row.positions.length<10)row.positions.push(i+1);
      }
      for(const row of map.values()) if(row.count>=2) all.push(row);
    }
    all.sort((a,b)=>b.count-a.count||b.length-a.length||a.motif.localeCompare(b.motif));
    return all.slice(0,30);
  }
  function windowSummary(s,requested=DEFAULT_WINDOWS){
    return requested.map(w=>{
      const seq=s.slice(Math.max(0,s.length-w));const c=counts(seq);const a=alternations(seq);
      return {window:w,n:seq.length,P:c.P,B:c.B,p_share:c.p_share,alternations:a,alternation_rate:seq.length>1?a/(seq.length-1):null,max_run:maxRun(seq),current_run:currentRun(seq),status:seq.length===w?'FULL_WINDOW':'PARTIAL_WINDOW'};
    });
  }
  function classifyWindow(w){
    if(w.n<4)return 'INSUFFICIENT';
    const share=w.p_share;
    const balance=Math.abs(share-.5);
    const alt=w.alternation_rate===null?0:w.alternation_rate;
    const majority=balance<.1?'BALANCED':share>.5?'P_HEAVY':'B_HEAVY';
    const rhythm=alt>=.7?'ALTERNATING':alt<=.3?'PERSISTENT/CLUSTERED':'MIXED_RHYTHM';
    return `${majority} · ${rhythm}`;
  }
  function contextAndConflict(s,windows,transitions,motifs){
    const usable=windows.filter(w=>w.n>=4);
    const short=usable.find(w=>w.window===8)||usable[0]||null;
    const broad=usable.find(w=>w.window===40)||usable[usable.length-1]||null;
    const flags=[];
    if(!short||!broad||short.n<4||broad.n<8) flags.push({id:'WINDOW_COVERAGE',status:'INSUFFICIENT',detail:'Not enough history to compare short and broad contexts.'});
    else {
      const shortSide=short.P>short.B?'P':short.B>short.P?'B':'TIE';
      const broadSide=broad.P>broad.B?'P':broad.B>broad.P?'B':'TIE';
      flags.push({id:'SHORT_VS_BROAD_BALANCE',status:shortSide===broadSide?'ALIGNED':'DIFFERENT',detail:`Short window ${short.window}: ${shortSide}; broad window ${broad.window}: ${broadSide}. This is descriptive, not predictive.`});
      if(short.alternation_rate!==null&&broad.alternation_rate!==null&&Math.abs(short.alternation_rate-broad.alternation_rate)>=.25){
        flags.push({id:'RHYTHM_SHIFT',status:'DIFFERENT',detail:`Alternation rate differs by ${(Math.abs(short.alternation_rate-broad.alternation_rate)).toFixed(2)} between selected windows.`});
      } else flags.push({id:'RHYTHM_SHIFT',status:'NO_LARGE_DIFFERENCE_BY_RULE',detail:'The fixed descriptive threshold was not crossed; this does not prove stability.'});
    }
    const run=currentRun(s); const priorTransitionTotal=transitions[run.side]?.total||0;
    if(run.length>=3) flags.push({id:'CURRENT_STREAK',status:'VISIBLE_STREAK',detail:`Current ${run.side} run length ${run.length}; prior outgoing-transition sample for ${run.side} is ${priorTransitionTotal}.`});
    const repeated=motifs.find(x=>x.count>=3);
    flags.push({id:'REPEATED_MOTIF',status:repeated?'REPETITIONS_FOUND':'NO_MOTIF_REPEATED_3X',detail:repeated?`Motif ${repeated.motif} occurs ${repeated.count} times (overlapping positions possible).`:'No length-2..5 motif reached 3 occurrences.'});
    const statuses=flags.map(x=>x.status);
    const conflict=statuses.includes('DIFFERENT')||flags.some(x=>x.id==='SHORT_VS_BROAD_BALANCE'&&x.status==='DIFFERENT');
    return {flags,context_status:flags.some(x=>x.status==='INSUFFICIENT')?'INSUFFICIENT':conflict?'MIXED_CONTEXT':'NO_MATERIAL_CONFLICT_BY_RULE',note:'Context labels summarize historical sequence properties only; they do not indicate the next result.'};
  }
  function suffixSensitivity(s,maxDrop=3){
    if(!Number.isInteger(maxDrop)||maxDrop<1||maxDrop>5)throw new Error('maxDrop must be 1..5.');
    const signature=(seq)=>{
      const ws=windowSummary(seq).filter(x=>x.n>=4).map(w=>`${w.window}:${classifyWindow(w)}`);
      const run=currentRun(seq),runBand=run.length===0?'0':run.length===1?'1':run.length===2?'2':'3+';
      const motifs=countMotifs(seq).filter(x=>x.count>=3).slice(0,3).map(x=>`${x.motif}:${x.count>=5?'5+':x.count}`).join(',');
      return `${ws.join('|')}|run:${run.side||'-'}:${runBand}|motif:${motifs||'none'}`;
    };
    const base=signature(s),checks=[];
    for(let d=1;d<=maxDrop;d++){
      const p=s.slice(0,Math.max(0,s.length-d));const sig=signature(p);checks.push({drop_last_n:d,prefix_n:p.length,available:p.length>=MIN_SEQUENCE,signature:sig,changed_vs_full:sig!==base});
    }
    const valid=checks.filter(x=>x.available);return {checks,available_checks:valid.length,changed_when_dropping:valid.filter(x=>x.changed_vs_full).map(x=>x.drop_last_n),fragile:valid.some(x=>x.changed_vs_full),comparison:'Qualitative window classes, run-length band, and repeated motifs with capped frequency buckets; raw counts are not compared directly.',interpretation:'Sensitivity is not accuracy and must not be used to cherry-pick a favorable prefix.'};
  }
  function fnv1a(s){let h=2166136261;for(let i=0;i<s.length;i++)h=Math.imul(h^s.charCodeAt(i),16777619)>>>0;return h>>>0;}
  function rng(seed){let x=seed>>>0;return()=>{x=(Math.imul(1664525,x)+1013904223)>>>0;return x/4294967296;};}
  function shuffle(s,random){const a=s.split('');for(let i=a.length-1;i>0;i--){const j=Math.floor(random()*(i+1));[a[i],a[j]]=[a[j],a[i]];}return a.join('');}
  function motifMaxCount(s,minLen=2,maxLen=5){let max=0;for(let k=minLen;k<=maxLen;k++){const m=new Map();for(let i=0;i<=s.length-k;i++){const q=s.slice(i,i+k);m.set(q,(m.get(q)||0)+1);if(m.get(q)>max)max=m.get(q);} }return max;}
  function patternNullTest(s,replicates=999){
    assertSequence(s);
    if(!Number.isInteger(replicates)||replicates<199||replicates>9999)throw new Error('replicates must be integer 199..9999.');
    const c=counts(s),obs={max_run:maxRun(s),alternations:alternations(s),max_motif_count:motifMaxCount(s)};
    if(s.length<12||c.P===0||c.B===0)return {available:false,reason:'Need at least 12 outcomes and both P and B.',observed:obs,replicates:0};
    const rand=rng(fnv1a(`${s}|${replicates}|v8.3-null`));const sims=[];
    for(let i=0;i<replicates;i++){const x=shuffle(s,rand);sims.push({max_run:maxRun(x),alternations:alternations(x),max_motif_count:motifMaxCount(x)});}
    const p={};for(const k of Object.keys(obs)){let tail=0;if(k==='alternations'){const median=sims.map(x=>x[k]).sort((a,b)=>a-b)[Math.floor(sims.length/2)];const d=Math.abs(obs[k]-median);tail=sims.filter(x=>Math.abs(x[k]-median)>=d).length;}else tail=sims.filter(x=>x[k]>=obs[k]).length;p[k]=(1+tail)/(replicates+1);}
    const adj={};for(const k of Object.keys(p))adj[k]=Math.min(1,p[k]*3);
    return {available:true,replicates,seed:fnv1a(`${s}|${replicates}|v8.3-null`),null_model:'Uniformly shuffled order conditioned on fixed P/B counts; exchangeability is an assumption.',observed:obs,empirical_p:p,bonferroni_adjusted_p:adj,interpretation:'Exploratory max-run, alternation and repeated-motif checks only. Family-wise adjustment covers these three metrics only, not all prior searches. This is not a next-hand forecast.'};
  }
  function historicalWalkForward(s){
    assertSequence(s);
    const rows=[];const names=['fixed_half','follow_last','alternate_last','prefix_majority','transition_smoothed'];
    function clampProb(p){return Math.min(1-EPS,Math.max(EPS,p));}
    for(let i=MIN_WF_HISTORY;i<s.length;i++){
      const past=s.slice(0,i),actual=s[i],prev=past[past.length-1];const c=counts(past),tm=transitionMatrix(past);
      const pred={
        fixed_half:.5,
        follow_last:prev==='P'?.55:.45,
        alternate_last:prev==='P'?.45:.55,
        prefix_majority:(c.P+1)/(past.length+2),
        transition_smoothed:((tm[prev][ 'P']+1)/(tm[prev].total+2))
      };
      const scored={};for(const name of names){const p=clampProb(pred[name]);const y=actual==='P'?1:0;scored[name]={p_P:p,hit:Math.abs(p-.5)<EPS?null:(p>.5?'P':'B')===actual,log_loss:-(y*Math.log(p)+(1-y)*Math.log(1-p)),brier:(p-y)*(p-y)};}
      rows.push({index_1based:i+1,prefix_n:i,prefix_end:prev,actual,scored});
    }
    const models={};for(const name of names){const v=rows.map(r=>r.scored[name]);const directional=v.filter(x=>x.hit!==null);models[name]={n:v.length,directional_n:directional.length,directional_coverage:v.length?directional.length/v.length:null,accuracy:directional.length?directional.filter(x=>x.hit).length/directional.length:null,mean_log_loss:v.length?v.reduce((a,x)=>a+x.log_loss,0)/v.length:null,mean_brier:v.length?v.reduce((a,x)=>a+x.brier,0)/v.length:null};}
    const enough=rows.length>=50;
    return {schema:'nexus-arc-v8.3-retrospective-walk-forward-v1',available:rows.length>0,sequence_n:s.length,scored_steps:rows.length,minimum_seed_history:MIN_WF_HISTORY,models,rows:rows.slice(-100),evaluation:'Retrospective prequential replay on this single supplied sequence; overlapping prefixes are dependent and model-selection bias remains. At least 50 scored steps is a descriptive minimum, not proof of an edge.',status:rows.length<20?'INSUFFICIENT':enough?'DESCRIPTIVE_REPLAY_READY':'SHORT_REPLAY',warnings:['These are heuristic backtest baselines, not validated baccarat odds.','Results on one historical sequence are not prospective validation.','Do not tune model choices on this same sequence and report the same rows as independent evidence.','P/B history does not reveal remaining shoe composition.']};
  }
  function reviewCandidate(input){
    const x=input||{};const n=Number(x.forecasts),sessions=Number(x.sessions),replications=Number(x.independent_replications);
    const dLL=Number(x.delta_log_loss),uLL=Number(x.upper_ci_delta_log_loss),dBr=Number(x.delta_brier),uBr=Number(x.upper_ci_delta_brier);
    const valid=[n,sessions,replications,dLL,uLL,dBr,uBr].every(Number.isFinite)&&n>=0&&sessions>=0&&replications>=0;
    if(!valid)return {status:'SHADOW_ONLY',reason:'Missing or invalid review metrics; module stays out of the live/core analyst.',promote:false};
    if(n<200||sessions<20)return {status:'SHADOW_ONLY',reason:'Require at least 200 pre-registered forecasts and 20 independent sessions before considering promotion.',promote:false};
    if(dLL>=0&&dBr>=0)return {status:'DEMOTE_CANDIDATE',reason:'Both point estimates fail to improve log loss and Brier versus champion; disable or demote in the shadow registry, not automatically in production.',promote:false};
    if(dLL<0&&dBr<0&&uLL<0&&uBr<0&&replications>=2)return {status:'ELIGIBLE_FOR_HUMAN_REVIEW',reason:'Both proper-score deltas and their supplied upper confidence bounds favor the candidate, with at least two independent replications. Still requires audit and explicit release approval.',promote:false};
    return {status:'HOLD_FOR_REPLICATION',reason:'Evidence is mixed, uncertainty overlaps zero, or independent replication is insufficient. Keep shadow-only.',promote:false};
  }
  function analyze(input,options={}){
    const s=typeof input==='string'?parseSequence(input):assertSequence(input);
    const c=counts(s),windows=windowSummary(s),transitions=transitionMatrix(s),motifs=countMotifs(s),context=contextAndConflict(s,windows,transitions,motifs);
    const byLength={};for(let k=2;k<=5;k++)byLength[k]=motifs.filter(m=>m.length===k).length;
    return {schema:'nexus-arc-v8.3-pattern-intelligence-v1',version:VERSION,created_at:new Date().toISOString(),input:{n:s.length,counts:c,sequence:s},sufficiency:{minimum_for_basic_patterns:MIN_SEQUENCE,basic_ready:s.length>=MIN_SEQUENCE,walk_forward_seed_history:MIN_WF_HISTORY,reason:s.length<MIN_SEQUENCE?`Need at least ${MIN_SEQUENCE} outcomes for a basic pattern read.`:null},sequence_profile:{current_run:currentRun(s),max_run:maxRun(s),alternations:alternations(s),alternation_rate:s.length>1?alternations(s)/(s.length-1):null},windows:windowSummary(s,options.windows||DEFAULT_WINDOWS).map(w=>({...w,classification:classifyWindow(w)})),transition_matrix:transitions,repeated_motifs:motifs,motif_summary:{repeated_motif_count:motifs.length,by_length:byLength},context_conflict:context,suffix_sensitivity:suffixSensitivity(s,options.max_drop===undefined?3:options.max_drop),pattern_null_test:options.include_null===false?{available:false,reason:'Disabled by caller.'}:patternNullTest(s,options.replicates===undefined?999:options.replicates),walk_forward:options.include_walk_forward===false?{available:false,reason:'Disabled by caller.'}:historicalWalkForward(s),controlled_learning:{status:'SHADOW_ONLY',automatic_promotion:false,rule:'New modules cannot alter the V6.3 live lean. Consider only with independently captured prospective forecasts and independent sessions.',review_api:'reviewCandidate'},guardrails:['This module is descriptive and does not predict the next P/B outcome.','Transition ratios are historical conditional frequencies, not next-hand probabilities.','Null-test correction covers only the three displayed statistics.','Retrospective walk-forward replay on one sequence is not prospective validation.','P/B-only input cannot establish remaining-card composition, expected value, or profitability.']};
  }
  const API={VERSION,MAX_SEQUENCE,DEFAULT_WINDOWS,MIN_SEQUENCE,MIN_WF_HISTORY,parseSequence,counts,maxRun,currentRun,alternations,transitionMatrix,countMotifs,windowSummary,contextAndConflict,suffixSensitivity,patternNullTest,historicalWalkForward,reviewCandidate,analyze};
  root.NexusArcV830=API;if(typeof module!=='undefined'&&module.exports)module.exports=API;
})(typeof window!=='undefined'?window:globalThis);
