# Brain import audit — uploaded NEXUS ARC V5.9.2 export

**Verdict: BLOCK IMPORT until the source is reconciled.**

The uploaded Brain JSON's SHA-256 matches its stored checksum. That only indicates the saved bytes match the recorded hash. It does not mean the learning history is logically consistent.

- History length: 54 P/B outcomes.
- Case rows: 47.
- Distinct `at` values: 46.
- Contradictory duplicate: `at = 43` appears more than once. `history[43]` is B, while one case at that position records actual P; the other records B.
- Prefix/tail checks otherwise align for the case rows inspected.
- The per-context sample sizes are too sparse to trust fine-grained learned weights as strong evidence.
- Hazard expert loss has extreme values (13.8155) and must be treated as a known weak point pending audit.

V9 blocks the export because of the duplicate/conflict. It does not modify the input file automatically. Preserve the original and reconcile the conflicting record from trusted source records before re-importing. Do not simply delete a row or recalculate a checksum without verifying which outcome and forecast record are correct.
