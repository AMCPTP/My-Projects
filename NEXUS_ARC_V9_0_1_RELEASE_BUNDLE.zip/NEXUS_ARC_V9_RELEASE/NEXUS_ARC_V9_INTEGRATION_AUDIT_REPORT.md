# NEXUS ARC V9.0.1 — Integration Audit

## Verdict

**Partial pass. The code paths are safer after the V9.0.1 ledger-integrity patch, but the complete system is not yet integrated end-to-end and should not be described as running at full efficiency.** Core unit/regression paths pass. Real browser and target-Windows operation remain unverified. Predictive effectiveness is not established.

## Test evidence from this container

- V9 core engine: 28 assertions passed.
- V9 UI-controller integration using a simulated DOM and mocked localStorage: 4 scenarios passed, covering event registration, analysis-to-render wiring for the 12 rows, one-prefix freeze/resolve flow, and preservation of a corrupt ledger. This is not a substitute for a real browser.
- Legacy compatibility suites: 59 tests passed (V5.9.5 15; V5.10.1 14; V6.3 18; V7 12).
- Server regression suite: 55 tests passed.
- Total automated checks: 146. Python syntax and all 14 non-empty inline dashboard script syntax checks passed.
- Five browser-loaded JS assets are present and all are included in the server's explicit allowlist.
- V9 analysis at 2,000 outcomes took ~1.0 s / 1.5 s / 3.1 s with 999 / 1,999 / 4,999 null-test replicates in this Node runtime. Long runs are synchronous and may briefly block a browser UI; browser performance was not measured.

## Fixes made during this audit

1. **V9.0.0 ledger fail-open path fixed.** Previously, invalid JSON in localStorage could fall through to a newly created empty ledger, and engine normalization could filter malformed rows. That path could hide existing data and later overwrite it. V9.0.1 now validates schema/version, record shape, unique forecast IDs, valid P/B prefix and fingerprint, finite normalized probabilities, status/outcome fields, and pending-state consistency. Invalid storage is displayed as blocked; write actions are disabled; an explicit recovery export preserves the raw value instead of resetting it.
2. **History-switch/pending-forecast conflict fixed.** Importing a clean Brain history while a V9 forecast is pending now requires the operator to explicitly cancel it; it is not left orphaned with a prefix that can no longer resolve.
3. **Misleading “adaptive router” UI label removed.** The current implementation is a conservative shadow estimator, not a validated router that weights all twelve pattern groups. The section is now labelled “Pattern Intelligence / Shadow Forecast / Validation.”

## Component-by-component integration status

| Component / path | Status | Evidence / limitation |
|---|---|---|
| Local JS asset loading | PASS in server tests | All 5 `script src` assets exist and are allowlisted. Actual browser network/console behaviour not verified. |
| V9 pattern analysis | PASS for unit cases | Returns 12 multi-label groups with evidence, counter-evidence, support and limits. Statistical outputs describe the input; they do not prove predictiveness. |
| V9 shadow forecast | PARTIAL by design | Combines smoothed base P/B share, first-order transition and historical suffix estimates, then shrinks toward 50/50. The 12-pattern registry does not directly change weights; it is not yet a full adaptive pattern router. |
| Top-level main forecast vs V9 panel | PARTIAL / UI confusion risk mitigated | The top forecast is still produced by the legacy Brain/analyst `makeForecast` path; V9 is a separate shadow-analysis panel and does not control that top result. The V9.0.1 page now labels the upper output `LEGACY` and explains the distinction, but the outputs are not unified. |
| Brain import audit | PASS on supplied file | Verifies checksum and reconciles each case against the outcome history; contradictory duplicate at `at=43` is blocked. |
| V9 local forecast ledger | PASS for tested local state | Freeze locks prefix, resolve accepts exactly one new result, cancellation is not scored. V9.0.1 fails closed on malformed/contradictory records. localStorage remains user-editable and is not server-attested. |
| V6.3 server evidence ledger | PASS for API regression | Server hash-chain freeze/resolve/idempotency and integrity guards pass. V9 forecast actions do not currently post their own records into this server ledger. |
| Live-history synchronization | PARTIAL | V6.3 analyst observes the live-history UI, but V9 analysis reads the separate `arSequence` textarea. User has to sync/copy the live history and manually run V9 analysis, then lock and resolve. It is not automated every turn. |
| Ledger/model comparison | PARTIAL | V5.9.5, V6.3 local/server evidence and V9 use separate ledgers/IDs. This allows isolated experiments but does not provide a single canonical forecast record or a unified comparison row across all engines. |
| UI pruning / efficiency | PARTIAL | Several legacy panels are hidden, but the HTML still contains visible older sections (including Continuous Evaluation/Quality Lab, Domain/Integrity, Live State, Regime/Change, Memory/Context, Champion/Challenger, older learning/assurance, V5.3 audit and V5.5 operator gate). The hidden V5.9.5 pattern controller still initializes and observes history for its ledger, so some background work remains despite the panel being hidden. |
| Server startup | PASS in TestClient; NOT VERIFIED on Windows | Health/meta/dashboard version guards and launcher static regressions pass. Real PowerShell + browser launch on target Windows was not run. |
| Predictive effectiveness | NOT ESTABLISHED | Current Brain sample is very small and has a conflicting record. No independent prospective study demonstrates calibrated probabilities or a predictive edge. `live_action=WAIT` and auto-promotion remains disabled. |

## Integration gaps that remain

### P1 — one visible forecast source is not yet unified

The large forecast card at the top is generated by the legacy Brain/analyst `makeForecast` function, while the V9 panel separately computes a shadow estimate and keeps its own ledger. V9.0.1 now explicitly labels the top card as `LEGACY` and adds a warning that the outputs are separate, which reduces ambiguity but does not unify execution. The top result must not be described as V9 output. For a true V9 control plane, route the same validated history event to one canonical forecast lifecycle and render the legacy predictor only in an optional comparison/compatibility area.

### P1 — unify the forecast workflow or explicitly label the tracks

The UI presently contains several conceptually separate forecasting/audit tracks. A user can obtain a V6.3 rapid read, keep an older pattern audit ledger, and record a V9 shadow forecast, but those are not one synchronized event stream. This risks comparing different prefixes or treating unlike output types as if they were the same forecast. Recommended next change: define one canonical `ForecastRecord` contract containing engine ID/version, exact prefix hash, session, model output, decision class, and resolution link; keep model-specific ledgers as projections, not independent sources of truth.

### P1 — automate V9’s per-turn refresh without blocking the page

V9 is currently driven from the `arSequence` textarea. The current workflow is manual: copy/sync the live history, run analysis, lock before the next result, add exactly one outcome, resolve. Recommended next change: attach V9 to the same accepted-result event as the live history, create a pre-outcome forecast through an explicit lifecycle event, and use a Worker or bounded incremental computation for null tests / walk-forward metrics. Never auto-resolve from unverified or multi-step history jumps.

### P1 — keep diagnostic pattern labels separate until validated, then implement controlled routing

The twelve categories currently do not feed twelve predictor weights; this is appropriate as a safety default because those labels are highly dependent, overlapping, and easy to overfit. To reach the intended adaptive-router goal, first log feature vectors and pre-outcome predictions in shadow; compare fixed baselines and each feature family on the same rows and sessions; apply shrinkage/regularization; then allow only a human-approved router to participate after independent replication. Do not simply assign a weight to every pattern label.

### P2 — finish removing or explicitly group old panels

The release notes say duplicate/unrelated panels were hidden, but not all old groups are hidden. Keep the modules required for migration and evidence APIs, but group legacy audit panels under an optional “Compatibility / Advanced Audit” area and prevent hidden-only controllers from doing expensive work unless that background ledger is intentionally enabled.

### P2 — reduce synchronous latency

The worst tested configuration took about 3.1 seconds in Node for a 2,000-result input with 4,999 permutation replicates. Consider Web Worker execution, progress/cancel controls, caching of unchanged prefix statistics, and separate “quick read” versus “deep audit” commands. Re-run performance tests on a representative Windows browser.

## Deployment decision

**Status: CONDITIONAL SHADOW PILOT ONLY, after a Windows smoke test. Not production-ready as a fully unified per-turn FORECAST system.** The software guards and component tests are substantially better, but full integration requires the live-history event path, unified/linked forecast ledgers, and real browser/Windows verification. None of the current metrics establishes an advantage in baccarat; keep live action at WAIT.
