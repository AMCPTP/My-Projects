"""NEXUS ARC V6.3 prospective evidence ledger.

Local-server hash chain for frozen P/B forecasts and their later outcomes. The chain
is tamper-evident and server-timestamped, but is not a signature, trusted external
clock, or proof that operator-entered outcomes are true.
"""
from __future__ import annotations

import hashlib
import hmac
import json
import re
import uuid
from datetime import datetime, timezone
from typing import Any

SCHEMA = "NEXUS-ARC-V6.3-PROSPECTIVE-EVIDENCE-1"
GENESIS = "GENESIS"
MAX_EVENTS = 50000
MAX_PREFIX = 2000
SESSION_RE = re.compile(r"^[A-Za-z0-9._:-]{3,80}$")
FORECAST_ID_RE = re.compile(r"^[A-Za-z0-9._:-]{3,120}$")
CLIENT_EVENT_ID_RE = re.compile(r"^[A-Za-z0-9._:-]{10,120}$")
VALID_LEANS = {"P", "B", "NEUTRAL"}


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="microseconds").replace("+00:00", "Z")


def canonical(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False)


def sha256_text(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def new_client_event_id() -> str:
    return "v63-" + uuid.uuid4().hex


def _is_iso_timestamp(value: Any) -> bool:
    if not isinstance(value, str) or not value or len(value) > 64:
        return False
    try:
        datetime.fromisoformat(value.replace("Z", "+00:00"))
        return True
    except (ValueError, TypeError, OverflowError):
        return False


def validate_payload(event_type: Any, payload: Any) -> dict[str, Any]:
    if event_type not in {"forecast_locked", "forecast_resolved", "forecast_cancelled"}:
        raise ValueError("unsupported V6.3 evidence event type")
    if not isinstance(payload, dict):
        raise ValueError("event payload must be an object")
    p = dict(payload)
    forecast_id = p.get("forecast_id")
    if not isinstance(forecast_id, str) or not FORECAST_ID_RE.fullmatch(forecast_id):
        raise ValueError("forecast_id is missing or invalid")
    if event_type == "forecast_locked":
        required = {"forecast_id", "session_id", "model_version", "prefix_pb_sequence", "prefix_pb_count", "predicted_lean", "source_lean", "evidence_level", "lens_conflict", "client_created_at"}
        if set(p) != required:
            raise ValueError("forecast_locked payload fields do not match V6.3 schema")
        if not isinstance(p["session_id"], str) or not SESSION_RE.fullmatch(p["session_id"]):
            raise ValueError("session_id is missing or invalid")
        if not isinstance(p["model_version"], str) or len(p["model_version"]) > 40 or not p["model_version"]:
            raise ValueError("model_version is missing or invalid")
        seq = p["prefix_pb_sequence"]
        if not isinstance(seq, str) or not (4 <= len(seq) <= MAX_PREFIX) or re.fullmatch(r"[PB]+", seq) is None:
            raise ValueError("prefix_pb_sequence must contain 4 to 2000 P/B results only")
        if type(p["prefix_pb_count"]) is not int or p["prefix_pb_count"] != len(seq):
            raise ValueError("prefix_pb_count must exactly match prefix_pb_sequence length")
        if p["predicted_lean"] not in VALID_LEANS or p["source_lean"] not in VALID_LEANS:
            raise ValueError("forecast lean must be P, B or NEUTRAL")
        if not isinstance(p["evidence_level"], str) or not p["evidence_level"] or len(p["evidence_level"]) > 60:
            raise ValueError("evidence_level is missing or invalid")
        if type(p["lens_conflict"]) is not bool:
            raise ValueError("lens_conflict must be boolean")
        if not _is_iso_timestamp(p["client_created_at"]):
            raise ValueError("client_created_at must be an ISO timestamp")
    elif event_type == "forecast_resolved":
        if set(p) != {"forecast_id", "actual", "target_index"}:
            raise ValueError("forecast_resolved payload fields do not match V6.3 schema")
        if p["actual"] not in {"P", "B"}:
            raise ValueError("actual must be P or B; Tie is outside the P/B-only ledger")
        if type(p["target_index"]) is not int or p["target_index"] < 5:
            raise ValueError("target_index must be an integer result index >= 5")
    else:
        if set(p) != {"forecast_id", "cancel_reason"}:
            raise ValueError("forecast_cancelled payload fields do not match V6.3 schema")
        if not isinstance(p["cancel_reason"], str) or not p["cancel_reason"].strip() or len(p["cancel_reason"]) > 160:
            raise ValueError("cancel_reason is missing or invalid")
    # Ensure payload serializes as strict JSON, with no NaN, Infinity or custom objects.
    try:
        json.loads(canonical(p))
    except (TypeError, ValueError) as exc:
        raise ValueError("event payload must be strict JSON") from exc
    return p


def verify_chain(events: Any) -> dict[str, Any]:
    if not isinstance(events, list):
        return {"valid": False, "checked": 0, "bad_index": 0, "reason": "ledger root is not an array", "last_hash": None}
    if len(events) > MAX_EVENTS:
        return {"valid": False, "checked": 0, "bad_index": 0, "reason": "ledger exceeds event limit", "last_hash": None}
    prev = GENESIS
    forecast_state: dict[str, dict[str, Any]] = {}
    for i, row in enumerate(events):
        if not isinstance(row, dict) or type(row.get("seq")) is not int or row.get("seq") != i + 1 or row.get("prev_hash") != prev:
            return {"valid": False, "checked": i, "bad_index": i, "reason": "sequence/previous hash mismatch", "last_hash": prev}
        if not isinstance(row.get("event_id"), str) or not row["event_id"]:
            return {"valid": False, "checked": i, "bad_index": i, "reason": "event_id missing", "last_hash": prev}
        if not isinstance(row.get("client_event_id"), str) or not CLIENT_EVENT_ID_RE.fullmatch(row["client_event_id"]):
            return {"valid": False, "checked": i, "bad_index": i, "reason": "client_event_id missing or invalid", "last_hash": prev}
        if not _is_iso_timestamp(row.get("created_at")):
            return {"valid": False, "checked": i, "bad_index": i, "reason": "server timestamp missing or invalid", "last_hash": prev}
        try:
            payload = validate_payload(row.get("event_type"), row.get("payload"))
        except ValueError as exc:
            return {"valid": False, "checked": i, "bad_index": i, "reason": str(exc), "last_hash": prev}
        fid = payload["forecast_id"]
        kind = row["event_type"]
        if kind == "forecast_locked":
            if fid in forecast_state:
                return {"valid": False, "checked": i, "bad_index": i, "reason": "duplicate forecast lock", "last_hash": prev}
            if any(x["status"] == "PENDING" for x in forecast_state.values()):
                return {"valid": False, "checked": i, "bad_index": i, "reason": "another forecast is already pending", "last_hash": prev}
            forecast_state[fid] = {"status": "PENDING", "snapshot": payload}
        else:
            current = forecast_state.get(fid)
            if current is None or current["status"] != "PENDING":
                return {"valid": False, "checked": i, "bad_index": i, "reason": "resolution/cancellation requires an existing pending lock", "last_hash": prev}
            if kind == "forecast_resolved":
                expected_index = current["snapshot"]["prefix_pb_count"] + 1
                if payload["target_index"] != expected_index:
                    return {"valid": False, "checked": i, "bad_index": i, "reason": "resolved target index does not match the frozen prefix", "last_hash": prev}
                current["status"] = "RESOLVED"
                current["actual"] = payload["actual"]
                lean = current["snapshot"]["predicted_lean"]
                current["hit"] = (lean == payload["actual"]) if lean in {"P", "B"} else None
            else:
                current["status"] = "CANCELLED"
                current["cancel_reason"] = payload["cancel_reason"]
        expected = sha256_text(canonical({k: v for k, v in row.items() if k != "event_hash"}))
        if not isinstance(row.get("event_hash"), str) or not hmac.compare_digest(row["event_hash"], expected):
            return {"valid": False, "checked": i, "bad_index": i, "reason": "event hash mismatch", "last_hash": prev}
        prev = row["event_hash"]
    return {"valid": True, "checked": len(events), "bad_index": None, "reason": "hash chain and event lifecycle valid; outcome truth is not verified", "last_hash": prev}


def append_event(events: list[dict[str, Any]], event_type: str, payload: dict[str, Any], client_event_id: str, now: str | None = None) -> tuple[dict[str, Any], bool]:
    integrity = verify_chain(events)
    if not integrity["valid"]:
        raise ValueError("V6.3 evidence integrity failure; writes are blocked")
    if len(events) >= MAX_EVENTS:
        raise ValueError("V6.3 evidence ledger reached its event limit")
    if not isinstance(client_event_id, str) or not CLIENT_EVENT_ID_RE.fullmatch(client_event_id):
        raise ValueError("client_event_id is missing or invalid")
    cleaned = validate_payload(event_type, payload)
    for old in events:
        if old["client_event_id"] == client_event_id:
            if old["event_type"] == event_type and canonical(old["payload"]) == canonical(cleaned):
                return old, True
            raise ValueError("client_event_id already exists with a different event payload")
    # Validate lifecycle before append using the current verified projection.
    prospective = dict(seq=len(events)+1, event_id=uuid.uuid4().hex, event_type=event_type,
                       client_event_id=client_event_id, created_at=now or utc_now(), payload=cleaned,
                       prev_hash=integrity["last_hash"])
    # Calling verify on candidate enforces the state transition and target index.
    candidate = [*events, {**prospective, "event_hash": sha256_text(canonical(prospective))}]
    check = verify_chain(candidate)
    if not check["valid"]:
        raise ValueError(check["reason"])
    event = candidate[-1]
    events.append(event)
    return event, False


def project(events: list[dict[str, Any]]) -> dict[str, Any]:
    check = verify_chain(events)
    if not check["valid"]:
        raise ValueError("cannot project an invalid V6.3 evidence chain")
    forecasts: dict[str, dict[str, Any]] = {}
    for event in events:
        p, kind = event["payload"], event["event_type"]
        fid = p["forecast_id"]
        if kind == "forecast_locked":
            forecasts[fid] = {**p, "status": "PENDING", "server_locked_at": event["created_at"], "lock_seq": event["seq"], "lock_hash": event["event_hash"], "actual": None, "hit": None}
        elif kind == "forecast_resolved":
            f = forecasts[fid]
            f.update(status="RESOLVED", actual=p["actual"], hit=(f["predicted_lean"] == p["actual"] if f["predicted_lean"] in {"P", "B"} else None), resolved_at=event["created_at"], resolve_seq=event["seq"], resolve_hash=event["event_hash"], target_index=p["target_index"])
        else:
            forecasts[fid].update(status="CANCELLED", cancel_reason=p["cancel_reason"], cancelled_at=event["created_at"], cancel_seq=event["seq"], cancel_hash=event["event_hash"])
    return {"forecasts": forecasts, "integrity": check}
