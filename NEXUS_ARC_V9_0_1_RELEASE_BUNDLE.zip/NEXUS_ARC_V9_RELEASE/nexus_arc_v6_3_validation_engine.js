/* NEXUS ARC V6.3.0 Validation Engine
 * Fast multi-lens descriptive analyst + transparent prospective lean audit.
 * P/B only. No probability calibration, EV, or betting-edge claim is made.
 * The rolling windows overlap and are NOT independent evidence.
 */
(function(root){
  'use strict';
  const VERSION='6.3.0';
  const SCHEMA='nexus-arc-v6.0-prospective-lean-ledger-v1'; // Keep the V6.0 key/schema so prior local ledger data survives upgrade.
  const BASE=root.NexusAnalystReasoningV5101;
  if(!BASE) throw new Error('V6 requires the compatible V5.10.1 P/B analyst engine to load first.');
  const MIN_RAPID_PB=BASE.MIN_RAPID_PB||4;
  const MIN_ANALYSIS_PB=BASE.MIN_ANALYSIS_PB||12;
  const MIN_REVIEW_ROWS=100;
  const MIN_REVIEW_SESSIONS=20;
  const BASELINE=BASE.BASELINE;
  const WINDOWS=[6,12,20];
  const validSessionId=v=>typeof v==='string'&&/^[A-Za-z0-9._:-]{3,80}$/.test(v);
  const share=seq=>seq.length?seq.filter(x=>x==='P').length/seq.length:null;
  const sideFromDiff=(d,t)=>d===null?'NEUTRAL':d>=t?'P':d<=-t?'B':'NEUTRAL';
  const priorShare=(seq,k=8)=>seq.length?(seq.filter(x=>x==='P').length+k*BASELINE.P)/(seq.length+k):BASELINE.P;
  const directionName=s=>s==='P'?'P':s==='B'?'B':'NEUTRAL';
  function buildLens(seq,name,n,threshold,minN){
    const x=seq.slice(-n),p=share(x),sm=priorShare(x),diff=sm-BASELINE.P;
    const eligible=x.length>=minN;
    return {name,requested_window:n,n:x.length,P:x.filter(v=>v==='P').length,B:x.filter(v=>v==='B').length,p_share:p,smoothed_p_share:sm,delta_vs_reference:diff,threshold,eligible,directional_hint:eligible?sideFromDiff(diff,threshold):'INSUFFICIENT',interpretation:eligible?'descriptive-only; nested windows are overlapping, not independent':'too few outcomes for this lens'};
  }
  function runs(seq){return BASE.runsOf(seq);}
  function multiLens(seq,baseReport){
    const n=seq.length;
    const specs=[
      {name:'recent_6',n:6,threshold:0.085,minN:4},
      {name:'recent_12',n:12,threshold:0.055,minN:8},
      {name:'recent_20',n:20,threshold:0.035,minN:16},
      {name:'all_history',n:Math.max(1,n),threshold:0.035,minN:20}
    ];
    const lenses=specs.map(s=>buildLens(seq,s.name,s.n,s.threshold,s.minN));
    const byName=Object.fromEntries(lenses.map(x=>[x.name,x]));
    const recent=byName.recent_6, history=byName.all_history, mid=byName.recent_12;
    const conflicts=[];
    if(n>=20 && ['P','B'].includes(recent.directional_hint) && ['P','B'].includes(history.directional_hint) && recent.directional_hint!==history.directional_hint && Math.abs((recent.p_share??0.5)-(history.p_share??0.5))>=0.15){
      conflicts.push({id:'RECENT_VS_HISTORY',recent:recent.directional_hint,history:history.directional_hint,reason:'six-result window and full-history tilt disagree materially'});
    }
    if(n>=24 && ['P','B'].includes(mid.directional_hint) && ['P','B'].includes(history.directional_hint) && mid.directional_hint!==history.directional_hint && Math.abs((mid.p_share??0.5)-(history.p_share??0.5))>=0.10){
      conflicts.push({id:'MID_VS_HISTORY',mid:mid.directional_hint,history:history.directional_hint,reason:'12-result window and full-history tilt disagree'});
    }
    const baseLean=baseReport.forecast_assessment.quick_read.lean;
    // A material recent/history conflict invalidates a one-sided headline; it does not flip to the opposite side.
    const finalLean=conflicts.length?'NEUTRAL':baseLean;
    const supportLenses=lenses.filter(l=>l.eligible&&l.directional_hint===finalLean&&finalLean!=='NEUTRAL').map(l=>l.name);
    const opposingLenses=lenses.filter(l=>l.eligible&&['P','B'].includes(l.directional_hint)&&l.directional_hint!==finalLean&&finalLean!=='NEUTRAL').map(l=>l.name);
    const nonNeutral=lenses.filter(l=>l.eligible&&['P','B'].includes(l.directional_hint));
    const directionCount={P:nonNeutral.filter(l=>l.directional_hint==='P').length,B:nonNeutral.filter(l=>l.directional_hint==='B').length};
    const patternIds=new Set(baseReport.patterns.map(p=>p.id));
    const contextual=[];
    for(const id of ['ALTERNATION_4','ALTERNATION_6','TWO_BY_TWO','CURRENT_RUN','RUN_SHAPE_1_2','RUN_SHAPE_1_3','RUN_SHAPE_2_1_2','RUN_SHAPE_3_1','RUN_SHAPE_2_2']) if(patternIds.has(id)) contextual.push(id);
    const shift=baseReport.recent_vs_previous_12;
    let level=n<4?'WARMUP':n<8?'VERY_LOW':n<16?'LOW':n<32?'LIMITED':'DESCRIPTIVE_ONLY';
    if(conflicts.length) level=n<16?'VERY_LOW':'CONFLICTING_LENSES';
    const align=directionCount.P===0&&directionCount.B===0?'NO_CLEAR_WINDOW_TILT':directionCount.P>0&&directionCount.B>0?'MIXED_WINDOW_DIRECTIONS':directionCount.P>0?'WINDOWS_TILT_P':'WINDOWS_TILT_B';
    const reasons=[];
    if(n<4)reasons.push(`Need ${4-n} more accepted P/B result(s) for the first rapid read.`);
    else reasons.push(`Rapid read is available after ${n} accepted P/B results; lean is a heuristic, not a next-hand probability.`);
    if(conflicts.length)reasons.push('Recent and longer-history lenses conflict; V6 suppresses the directional headline to NEUTRAL rather than choosing one side.');
    if(n>=24&&shift.status==='SHIFT_CANDIDATE')reasons.push('12-vs-12 comparison detects a descriptive SHIFT CANDIDATE; it does not prove a new regime.');
    if(contextual.includes('TWO_BY_TWO'))reasons.push('A 2-2 shape is present as road context only; it does not add direction points.');
    if(contextual.some(id=>id.startsWith('ALTERNATION')))reasons.push('Alternation is present as road context only; V6 does not assume it must continue.');
    const against=[];
    if(nonNeutral.some(l=>l.directional_hint!==finalLean)) against.push('At least one eligible rolling/history lens points another way; windows overlap, so this is a conflict diagnostic, not independent evidence.');
    if(n<20)against.push('The full-history comparison is still below its 20-result minimum.');
    if(baseReport.data_quality.ignored_items)against.push(`${baseReport.data_quality.ignored_items} input token(s) were ignored; verify that the pasted history is clean.`);
    const invalidation=[];
    if(conflicts.length)invalidation.push('Do not treat the source lean as an actionable direction while cross-window conflict persists.');
    if(n<8)invalidation.push('Very short sample; a few outcomes can materially change the read.');
    invalidation.push('Any change to the entered history or session boundary invalidates the exact read snapshot.');
    invalidation.push('No live shoe card composition is available; road history cannot establish next-hand odds.');
    return {
      version:VERSION,accepted_pb_n:n,source_lean:baseLean,lean:finalLean,evidence_level:level,
      alignment:align,window_direction_counts:directionCount,windows:lenses,conflicts,
      supporting_windows:supportLenses,opposing_windows:opposingLenses,contextual_patterns:contextual,
      shift_status:shift.status,shift_delta_p_share:shift.delta_player_share,
      summary: finalLean==='NEUTRAL' ? (conflicts.length?'NEUTRAL — rolling windows disagree; suppressing directional headline':'NEUTRAL — no clear directional lean from this read') : `${finalLean} LEAN — low-cost heuristic; evidence level ${level}`,
      reasons,against,invalidation,
      boundaries:['Window counts overlap and are not independent samples.','No output is a calibrated probability or betting instruction.','No automatic weight update is made from one outcome.','Prospective browser ledger is locally editable, not server-attested.']
    };
  }
  function analyze(input){
    const r=BASE.analyze(input);
    const seq=BASE.parse(input).outcomes;
    const ml=multiLens(seq,r);
    const q={...r.forecast_assessment.quick_read,source_lean:r.forecast_assessment.quick_read.lean,lean:ml.lean,evidence_level:ml.evidence_level,multi_lens_conflict:ml.conflicts.length>0,multi_lens_summary:ml.summary,probability:null,validated:false,edge_claim:false};
    if(ml.conflicts.length) { q.strength='CONFLICTING_LENSES'; q.factors=(q.factors||[]).concat(['Recent-vs-history conflict detected; headline lean suppressed to NEUTRAL.']); }
    r.schema='nexus-arc-v6.0-multi-lens-analyst-v1'; r.version=VERSION;
    r.forecast_assessment.quick_read=q;
    r.forecast_assessment.decision=seq.length>=MIN_RAPID_PB?'RAPID_HEURISTIC_READ':'WARMUP_FAST_READ';
    r.multi_lens=ml;
    r.reasoning=(r.reasoning||[]).concat(ml.reasons,ml.against);
    r.methodology.rule_order=['parse and validate P/B-only input','produce rapid descriptive read without waiting for deep audit','compare recent 6 / 12 / 20 / all-history windows','detect material short-vs-history conflicts and suppress direction to neutral','report road patterns, streak, transitions, suffixes, and shifts only as context','keep historical tilt separate from quick lean','record V6 lean prospectively before next outcome; score only after outcome','do not update model weights automatically; require independent session-level validation'];
    return r;
  }
  function rapidRead(input){
    const r=BASE.analyze(input),seq=BASE.parse(input).outcomes,ml=multiLens(seq,r),q={...r.forecast_assessment.quick_read,source_lean:r.forecast_assessment.quick_read.lean,lean:ml.lean,evidence_level:ml.evidence_level,multi_lens_conflict:ml.conflicts.length>0,multi_lens_summary:ml.summary,probability:null,validated:false,edge_claim:false};
    if(ml.conflicts.length) q.strength='CONFLICTING_LENSES';
    return q;
  }
  function emptyLedger(){return{schema:SCHEMA,version:VERSION,created_at:new Date().toISOString(),records:[],pending_id:null};}
  function validateLedger(d){
    if(!d||typeof d!=='object'||d.schema!==SCHEMA||!['6.0.0','6.1.0','6.2.0','6.3.0'].includes(d.version)||!Array.isArray(d.records)||d.records.length>10000)throw new Error('V6 lean ledger schema/shape invalid. Export raw JSON and inspect it; writes blocked.');
    const ids=new Set();let pending=0;
    for(const r of d.records){
      if(!r||typeof r.forecast_id!=='string'||!r.forecast_id||ids.has(r.forecast_id))throw new Error('V6 lean ledger contains a missing/duplicate forecast ID.');ids.add(r.forecast_id);
      if(!validSessionId(r.session_id)||!['P','B','NEUTRAL'].includes(r.predicted_lean)||typeof r.prefix_pb_sequence!=='string'||!/^([PB]*)$/.test(r.prefix_pb_sequence)||!Number.isInteger(r.prefix_pb_count)||r.prefix_pb_count!==r.prefix_pb_sequence.length)throw new Error('V6 lean ledger record validation failed.');
      if(!['PENDING','RESOLVED','CANCELLED'].includes(r.status))throw new Error('V6 lean ledger has an invalid status.');if(r.status==='PENDING')pending++;
      if(r.status==='RESOLVED'&&!['P','B'].includes(r.actual))throw new Error('Resolved V6 ledger row has no valid P/B outcome.');
    }
    if(pending>1)throw new Error('Multiple V6 pending forecasts found; writes blocked.');const p=d.records.find(r=>r.status==='PENDING');if((p?p.forecast_id:null)!==(d.pending_id||null))throw new Error('V6 pending_id does not match pending record.');return d;
  }
  function makeProspectiveForecast(history,ledger,sessionId,now){
    validateLedger(ledger);if(!validSessionId(sessionId))throw new Error('Enter a session/shoe ID using 3–80 letters, digits, dot, underscore, colon or hyphen.');if(ledger.pending_id)throw new Error('A V6 forecast is already pending; resolve or cancel it first.');
    const seq=BASE.parse(history).outcomes;if(seq.length<MIN_RAPID_PB)throw new Error(`Need at least ${MIN_RAPID_PB} P/B outcomes before locking the V6 read.`);
    const report=analyze(seq),q=report.forecast_assessment.quick_read,ml=report.multi_lens;
    const record={forecast_id:`v6-${Date.now()}-${Math.random().toString(36).slice(2,10)}`,model_version:VERSION,created_at:now||new Date().toISOString(),session_id:sessionId.trim(),target_definition:'next accepted P/B result after the frozen prefix',status:'PENDING',prefix_pb_sequence:seq.join(''),prefix_pb_count:seq.length,predicted_lean:q.lean,source_lean:q.source_lean||q.lean,evidence_level:q.evidence_level||ml.evidence_level,source_score:Number.isFinite(q.score)?q.score:null,lens_conflict:!!q.multi_lens_conflict,aligned_lenses:ml.supporting_windows.slice(),conflicts:ml.conflicts.map(x=>x.id),actual:null,hit:null,baseline_b_hit:null,resolved_at:null,cancel_reason:null,score_rule:'directional hit/miss only for P/B lean; NEUTRAL is coverage-only and is not counted as a miss'};
    ledger.records.push(record);ledger.pending_id=record.forecast_id;validateLedger(ledger);return record;
  }
  function resolvePendingAgainstHistory(ledger,history,now){
    validateLedger(ledger);if(!ledger.pending_id)return{changed:false,message:'No pending V6 lean forecast.'};const r=ledger.records.find(x=>x.forecast_id===ledger.pending_id),seq=BASE.parse(history).outcomes;
    if(!seq.join('').startsWith(r.prefix_pb_sequence)){r.status='CANCELLED';r.cancel_reason='history_prefix_changed_or_session_replaced';r.resolved_at=now||new Date().toISOString();ledger.pending_id=null;validateLedger(ledger);return{changed:true,cancelled:true,record:r,message:'V6 pending forecast cancelled because history prefix changed; no score written.'};}
    if(seq.length<=r.prefix_pb_count)return{changed:false,message:'Waiting for the next accepted P/B outcome.'};
    const actual=seq[r.prefix_pb_count];r.actual=actual;r.status='RESOLVED';r.resolved_at=now||new Date().toISOString();r.hit=['P','B'].includes(r.predicted_lean)?r.predicted_lean===actual:null;r.baseline_b_hit=actual==='B';ledger.pending_id=null;validateLedger(ledger);
    return{changed:true,resolved:true,record:r,message:r.predicted_lean==='NEUTRAL'?`V6 read was NEUTRAL; actual ${actual} logged for coverage, not directional accuracy.`:`V6 ${r.predicted_lean} lean scored ${r.hit?'HIT':'MISS'}; actual ${actual}.`};
  }
  function cancelPending(ledger,reason,now){validateLedger(ledger);if(!ledger.pending_id)return{changed:false,message:'No pending V6 forecast.'};const r=ledger.records.find(x=>x.forecast_id===ledger.pending_id);r.status='CANCELLED';r.cancel_reason=String(reason||'operator_cancelled').slice(0,160);r.resolved_at=now||new Date().toISOString();ledger.pending_id=null;validateLedger(ledger);return{changed:true,record:r,message:'Pending V6 read cancelled without scoring.'};}
  const MAX_REPLAY_SESSIONS=50;
  const MAX_REPLAY_OUTCOMES=2000;
  const MIN_BOOTSTRAP_SESSIONS=5;
  const BOOTSTRAP_REPLICATES=3000;
  function parseReplaySessions(input){
    if(typeof input!=='string')throw new Error('Replay input must be text with one P/B session per line.');
    const lines=input.split(/\r?\n/).map(x=>x.trim()).filter(Boolean);
    if(!lines.length)throw new Error('Paste at least one non-empty P/B session line.');
    if(lines.length>MAX_REPLAY_SESSIONS)throw new Error(`Replay supports up to ${MAX_REPLAY_SESSIONS} session lines at a time.`);
    let total=0;
    const sessions=lines.map((line,i)=>{
      const upper=line.toUpperCase();
      if(!/^[PB\s,;|]+$/.test(upper))throw new Error(`Session line ${i+1} contains unsupported characters. Use P/B only; separate results with spaces, commas, semicolons or |. Do not include Tie.`);
      const sequence=upper.replace(/[^PB]/g,'');
      if(!sequence)throw new Error(`Session line ${i+1} contains no P/B results.`);
      total+=sequence.length;
      if(total>MAX_REPLAY_OUTCOMES)throw new Error(`Replay supports at most ${MAX_REPLAY_OUTCOMES} total P/B outcomes per run.`);
      return{session_id:`session-${String(i+1).padStart(2,'0')}`,sequence};
    });
    return sessions;
  }
  function ratio(n,d){return d?n/d:null;}
  function percentile(sorted,p){if(!sorted.length)return null;const at=(sorted.length-1)*p,lo=Math.floor(at),hi=Math.ceil(at);return sorted[lo]+(sorted[hi]-sorted[lo])*(at-lo);}
  function seededRandom(seed){let s=seed>>>0;return()=>{s=(Math.imul(1664525,s)+1013904223)>>>0;return s/4294967296;};}
  function bootstrapSessionDelta(sessionDeltas,signature){
    if(sessionDeltas.length<MIN_BOOTSTRAP_SESSIONS)return{available:false,reason:`Need at least ${MIN_BOOTSTRAP_SESSIONS} sessions with directional reads for session-cluster bootstrap; currently ${sessionDeltas.length}.`,low:null,high:null,replicates:0};
    let seed=2166136261;for(const ch of signature)seed=Math.imul(seed^ch.charCodeAt(0),16777619)>>>0;
    const rand=seededRandom(seed),means=[];const n=sessionDeltas.length;
    for(let b=0;b<BOOTSTRAP_REPLICATES;b++){let sum=0;for(let j=0;j<n;j++)sum+=sessionDeltas[Math.floor(rand()*n)];means.push(sum/n);}
    means.sort((a,b)=>a-b);
    return{available:true,method:'percentile bootstrap by session/shoe; equal session weighting',low:percentile(means,.025),high:percentile(means,.975),replicates:BOOTSTRAP_REPLICATES,session_clusters:n,interpretation:'Exploratory uncertainty interval, not proof of predictive skill; sessions may still not be independent.'};
  }
  const REPLAY_BASELINES=[
    {id:'always_B',label:'Fixed B'},
    {id:'always_P',label:'Fixed P'},
    {id:'follow_last',label:'Repeat previous outcome'},
    {id:'alternate_last',label:'Alternate previous outcome'},
    {id:'prefix_majority',label:'Prefix majority (ties → B)'}
  ];
  function predictBaseline(id,prefix){
    const last=prefix[prefix.length-1];
    if(id==='always_B')return 'B';
    if(id==='always_P')return 'P';
    if(id==='follow_last')return last;
    if(id==='alternate_last')return last==='P'?'B':'P';
    if(id==='prefix_majority'){
      const p=prefix.split('').filter(x=>x==='P').length,b=prefix.length-p;
      return p>b?'P':'B'; // fixed-B tie break, specified rather than hidden
    }
    throw new Error(`Unknown replay baseline: ${id}`);
  }
  function missStreakMetrics(rows){
    let run=0,max=0,total=0;
    for(const r of rows){
      if(['P','B'].includes(r.predicted_lean)&&r.hit===false){run++;total++;max=Math.max(max,run);}
      else run=0; // neutral and hits both break an adjacent tested-decision miss streak
    }
    return{directional_misses:total,longest_consecutive_decision_miss_streak:max,trailing_miss_streak:run,
      definition:'A neutral or hit resets the streak; streaks restart at every session boundary.'};
  }
  function walkForwardReplay(input){
    const sessions=parseReplaySessions(input),allRows=[],sessionSummaries=[];
    for(const session of sessions){
      const rows=[];
      // Every decision sees only outcomes strictly before its target; every shoe restarts warm-up.
      for(let targetIndex=MIN_RAPID_PB;targetIndex<session.sequence.length;targetIndex++){
        const prefix=session.sequence.slice(0,targetIndex),actual=session.sequence[targetIndex];
        const q=rapidRead(prefix),lean=['P','B'].includes(q.lean)?q.lean:'NEUTRAL';
        const baselinePredictions=Object.fromEntries(REPLAY_BASELINES.map(b=>[b.id,predictBaseline(b.id,prefix)]));
        const row={session_id:session.session_id,session_result_index:targetIndex+1,prefix_pb_count:prefix.length,prefix_pb_sequence:prefix,predicted_lean:lean,source_lean:['P','B'].includes(q.source_lean)?q.source_lean:lean,evidence_level:q.evidence_level||'UNKNOWN',lens_conflict:!!q.multi_lens_conflict,actual,hit:['P','B'].includes(lean)?lean===actual:null,baseline_b_hit:actual==='B',baseline_predictions:baselinePredictions};
        rows.push(row);allRows.push(row);
      }
      const directional=rows.filter(r=>['P','B'].includes(r.predicted_lean));
      const hits=directional.filter(r=>r.hit).length,bHits=directional.filter(r=>r.baseline_b_hit).length;
      const baselinePerformance={};
      for(const b of REPLAY_BASELINES){
        const allHits=rows.filter(r=>r.baseline_predictions[b.id]===r.actual).length;
        const matchedHits=directional.filter(r=>r.baseline_predictions[b.id]===r.actual).length;
        const matchedN=directional.length;
        baselinePerformance[b.id]={label:b.label,all_tested_accuracy:ratio(allHits,rows.length),accuracy_on_model_directional_rows:ratio(matchedHits,matchedN),matched_n:matchedN,delta_model_vs_baseline_on_same_directional_rows:matchedN?hits/matchedN-matchedHits/matchedN:null};
      }
      sessionSummaries.push({session_id:session.session_id,input_outcomes:session.sequence.length,tested_decisions:rows.length,directional_scored:directional.length,neutral_reads:rows.length-directional.length,directional_coverage:ratio(directional.length,rows.length),directional_hits:hits,directional_accuracy:ratio(hits,directional.length),always_b_hits_on_same_directional_rows:bHits,always_b_accuracy_on_same_directional_rows:ratio(bHits,directional.length),delta_vs_always_b_on_same_rows:directional.length?hits/directional.length-bHits/directional.length:null,always_b_accuracy_all_tested:ratio(rows.filter(r=>r.baseline_b_hit).length,rows.length),lens_conflicts:rows.filter(r=>r.lens_conflict).length,baseline_performance:baselinePerformance,miss_streaks:missStreakMetrics(rows)});
    }
    const tested=allRows.length,directional=allRows.filter(r=>['P','B'].includes(r.predicted_lean)),hits=directional.filter(r=>r.hit).length,bHits=directional.filter(r=>r.baseline_b_hit).length,overallB=allRows.filter(r=>r.baseline_b_hit).length;
    const modelAcc=ratio(hits,directional.length);
    const baselineComparisons=REPLAY_BASELINES.map(b=>{
      const allHits=allRows.filter(r=>r.baseline_predictions[b.id]===r.actual).length;
      const matchedHits=directional.filter(r=>r.baseline_predictions[b.id]===r.actual).length;
      const matchedN=directional.length;
      const sessionDeltas=sessionSummaries.map(s=>s.baseline_performance[b.id].delta_model_vs_baseline_on_same_directional_rows).filter(v=>v!==null);
      const signature=sessionSummaries.map(s=>`${s.session_id}:${s.tested_decisions}:${s.directional_hits}:${s.baseline_performance[b.id].delta_model_vs_baseline_on_same_directional_rows}`).join('|');
      const ci=bootstrapSessionDelta(sessionDeltas,`${b.id}|${signature}`);
      const positive=sessionDeltas.filter(v=>v>0).length,negative=sessionDeltas.filter(v=>v<0).length,ties=sessionDeltas.filter(v=>v===0).length;
      return{id:b.id,label:b.label,all_tested_n:tested,all_tested_hits:allHits,all_tested_accuracy:ratio(allHits,tested),same_directional_rows_n:matchedN,same_directional_rows_hits:matchedHits,same_directional_rows_accuracy:ratio(matchedHits,matchedN),model_accuracy_on_same_rows:modelAcc,delta_model_vs_baseline_on_same_directional_rows:matchedN?modelAcc-matchedHits/matchedN:null,session_deltas:sessionDeltas,mean_session_delta:sessionDeltas.length?sessionDeltas.reduce((a,v)=>a+v,0)/sessionDeltas.length:null,sessions_model_better:positive,sessions_tied:ties,sessions_model_worse:negative,bootstrap_95_ci_session_delta:ci};
    });
    const fixedB=baselineComparisons.find(b=>b.id==='always_B');
    const deltas=sessionSummaries.filter(s=>s.delta_vs_always_b_on_same_rows!==null).map(s=>s.delta_vs_always_b_on_same_rows);
    const meanSessionDelta=deltas.length?deltas.reduce((a,b)=>a+b,0)/deltas.length:null;
    const bootstrap=bootstrapSessionDelta(deltas,sessionSummaries.map(s=>`${s.session_id}:${s.tested_decisions}:${s.directional_hits}:${s.delta_vs_always_b_on_same_rows}`).join('|'));
    const missMetrics=sessionSummaries.map(s=>({session_id:s.session_id,...s.miss_streaks}));
    return{schema:'nexus-arc-v6.3-walk-forward-replay-v1',version:VERSION,created_at:new Date().toISOString(),method:'strict within-session walk-forward replay: analyze prefix only; compare lean with next result; restart warm-up for every line',input_sessions:sessions.length,input_outcomes:sessions.reduce((n,s)=>n+s.sequence.length,0),min_history_before_first_decision:MIN_RAPID_PB,tested_decisions:tested,directional_scored:directional.length,neutral_reads:tested-directional.length,directional_coverage:ratio(directional.length,tested),directional_hits:hits,directional_accuracy:modelAcc,always_b_hits_on_same_directional_rows:bHits,always_b_accuracy_on_same_directional_rows:ratio(bHits,directional.length),delta_accuracy_vs_always_b_same_rows:fixedB?.delta_model_vs_baseline_on_same_directional_rows??null,always_b_accuracy_all_tested:ratio(overallB,tested),mean_session_delta_vs_always_b:meanSessionDelta,bootstrap_95_ci_session_delta:bootstrap,baseline_comparisons:baselineComparisons,scored_sessions:sessionSummaries.filter(s=>s.tested_decisions>0).length,directional_sessions:deltas.length,lens_conflict_decisions:allRows.filter(r=>r.lens_conflict).length,miss_streaks_by_session:missMetrics,longest_consecutive_decision_miss_streak:missMetrics.reduce((m,s)=>Math.max(m,s.longest_consecutive_decision_miss_streak),0),session_summaries:sessionSummaries,decisions:allRows,warnings:['Retrospective replay is exploratory; historical sequences may have influenced design choices. It is not an untouched out-of-sample test.','Every strategy/baseline prediction uses only the prefix before the target result; warm-up restarts at every session.','Baseline suite is a diagnostic comparison, not a list of proven strategies; post-hoc selection of the best baseline is multiple comparison and not evidence of edge.','Direction accuracy is measured only on model directional reads; coverage and NEUTRAL counts must be read alongside it. Baseline all-tested accuracy is displayed separately from baseline accuracy on the same directional rows.','Session bootstrap resamples session-level deltas, not hands. It needs at least 5 sessions with directional reads and sessions may not be independent.','Miss streaks are descriptive audit metrics only; they do not justify increasing stakes or changing strategy.','No probability calibration, expected value, profit or next-hand edge is computed.','Replay input is not saved automatically; export JSON if you need a record.']};
  }
  function summarizeLedger(ledger){validateLedger(ledger);const rows=ledger.records.filter(r=>r.status==='RESOLVED'&&['P','B'].includes(r.actual)),directional=rows.filter(r=>['P','B'].includes(r.predicted_lean)),n=directional.length,hits=directional.filter(r=>r.hit).length,bHits=directional.filter(r=>r.baseline_b_hit).length,sessions=new Set(directional.map(r=>r.session_id)),neutral=rows.filter(r=>r.predicted_lean==='NEUTRAL').length;
    const acc=n?hits/n:null,baseAcc=n?bHits/n:null;let status='WARMING';if(n>=MIN_REVIEW_ROWS&&sessions.size<MIN_REVIEW_SESSIONS)status='WAIT_NOT_ENOUGH_SESSIONS';else if(n>=MIN_REVIEW_ROWS&&sessions.size>=MIN_REVIEW_SESSIONS)status='READY_FOR_INDEPENDENT_REVIEW_NOT_VALIDATED';
    return{schema:'nexus-arc-v6.1-lean-ledger-summary-v1',resolved_rows:rows.length,directional_scored:n,directional_hits:hits,directional_accuracy:acc,always_B_baseline_hits:bHits,always_B_baseline_accuracy:baseAcc,delta_accuracy_vs_always_B:acc===null||baseAcc===null?null:acc-baseAcc,neutral_rows:neutral,coverage:n+neutral? n/(n+neutral):null,directional_sessions:sessions.size,pending_rows:ledger.pending_id?1:0,cancelled_rows:ledger.records.filter(r=>r.status==='CANCELLED').length,status,criteria:{min_directional_rows:MIN_REVIEW_ROWS,min_distinct_sessions:MIN_REVIEW_SESSIONS,auto_promotion:false},limitations:['Browser localStorage is editable and not independently timestamp-attested.','The always-B reference is a fixed descriptive baseline, not a predictive model.','Accuracy alone is insufficient; sample size, session dependence and prospective capture matter.','No money, EV, profit or next-hand probability is computed.']};
  }
  const api={VERSION,SCHEMA,MIN_RAPID_PB,MIN_ANALYSIS_PB,MIN_REVIEW_ROWS,MIN_REVIEW_SESSIONS,BASELINE,validSessionId,analyze,rapidRead,multiLens,emptyLedger,validateLedger,makeProspectiveForecast,resolvePendingAgainstHistory,cancelPending,summarizeLedger,MAX_REPLAY_SESSIONS,MAX_REPLAY_OUTCOMES,MIN_BOOTSTRAP_SESSIONS,parseReplaySessions,walkForwardReplay,REPLAY_BASELINES,predictBaseline,missStreakMetrics};
  root.NexusArcV630=api;root.NexusArcV620=api;root.NexusArcV610=api;root.NexusArcV600=api; // Compatibility aliases keep older dashboard integrations readable.
  if(typeof module!=='undefined'&&module.exports)module.exports=api;
})(typeof window!=='undefined'?window:globalThis);
