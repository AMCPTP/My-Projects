/* NEXUS ARC V7.0 diagnostic layer.
 * Adds conditional order-randomization diagnostics and suffix sensitivity checks.
 * It does NOT produce next-hand probabilities or a betting edge.
 */
(function(root){
  'use strict';
  const CORE = root.NexusArcV630 || root.NexusArcV620 || root.NexusArcV600;
  if (!CORE || typeof CORE.rapidRead !== 'function') throw new Error('V7 requires the V6.3 compatible analyst engine.');
  const VERSION = '7.0.0';
  const MIN_NULL_N = 12;
  const DEFAULT_REPLICATES = 1999;
  const MAX_REPLICATES = 9999;
  const MAX_SEQUENCE = 2000;
  function validateSequence(sequence){
    if(typeof sequence!=='string' || !/^[PB]*$/.test(sequence)) throw new Error('Sequence must contain only P and B, with no separators.');
    if(sequence.length>MAX_SEQUENCE) throw new Error(`Sequence exceeds ${MAX_SEQUENCE} P/B outcomes.`);
    return sequence;
  }
  function fnv1a(s){let h=2166136261;for(let i=0;i<s.length;i++)h=Math.imul(h^s.charCodeAt(i),16777619)>>>0;return h>>>0;}
  function seededRandom(seed){let x=seed>>>0;return()=>{x=(Math.imul(1664525,x)+1013904223)>>>0;return x/4294967296;};}
  function maxRun(s){if(!s.length)return 0;let best=1,run=1;for(let i=1;i<s.length;i++){if(s[i]===s[i-1])run++;else run=1;if(run>best)best=run;}return best;}
  function transitions(s){let n=0;for(let i=1;i<s.length;i++)if(s[i]!==s[i-1])n++;return n;}
  function shuffledByFixedMargins(s,rand){const a=s.split('');for(let i=a.length-1;i>0;i--){const j=Math.floor(rand()*(i+1));[a[i],a[j]]=[a[j],a[i]];}return a.join('');}
  function percentile(a,p){if(!a.length)return null;const x=(a.length-1)*p,lo=Math.floor(x),hi=Math.ceil(x);return a[lo]+(a[hi]-a[lo])*(x-lo);}
  function conditionalOrderTest(sequence,replicates=DEFAULT_REPLICATES){
    const s=validateSequence(sequence);
    if(!Number.isInteger(replicates)||replicates<199||replicates>MAX_REPLICATES)throw new Error(`replicates must be an integer from 199 to ${MAX_REPLICATES}.`);
    const pCount=[...s].filter(x=>x==='P').length,bCount=s.length-pCount;
    const observed={n:s.length,P:pCount,B:bCount,alternations:transitions(s),max_run:maxRun(s)};
    if(s.length<MIN_NULL_N || pCount===0 || bCount===0){
      return {schema:'nexus-arc-v7-conditional-order-test-v1',version:VERSION,available:false,reason:`Need at least ${MIN_NULL_N} outcomes and both P and B to assess order conditional on counts.`,observed,replicates:0,interpretation:'No inference made.'};
    }
    const rand=seededRandom(fnv1a(`${s}|${replicates}|v7-null`));
    const runs=[],alts=[];
    for(let i=0;i<replicates;i++){const x=shuffledByFixedMargins(s,rand);runs.push(maxRun(x));alts.push(transitions(x));}
    runs.sort((a,b)=>a-b);alts.sort((a,b)=>a-b);
    const runExtreme=runs.filter(x=>x>=observed.max_run).length;
    const altMedian=percentile(alts,.5),altDistance=Math.abs(observed.alternations-altMedian);
    const altExtreme=alts.filter(x=>Math.abs(x-altMedian)>=altDistance).length;
    const pRun=(1+runExtreme)/(replicates+1),pAlt=(1+altExtreme)/(replicates+1);
    const adjusted={max_run:Math.min(1,2*pRun),alternations:Math.min(1,2*pAlt)};
    return {
      schema:'nexus-arc-v7-conditional-order-test-v1',version:VERSION,available:true,
      null_model:'Uniform random permutations of the observed P/B labels, preserving the exact P and B counts; order exchangeability is an assumption, not a fact.',
      observed,
      null_summary:{max_run_median:percentile(runs,.5),max_run_95th:percentile(runs,.95),alternations_median:altMedian,alternations_2_5th:percentile(alts,.025),alternations_97_5th:percentile(alts,.975)},
      empirical_p:{max_run_upper_tail:pRun,alternations_two_sided_about_null_median:pAlt},
      bonferroni_adjusted_p:adjusted,
      replicates,seed:fnv1a(`${s}|${replicates}|v7-null`),
      flags:{long_run_unusual_at_5pct:adjusted.max_run<.05,alternation_unusual_at_5pct:adjusted.alternations<.05},
      interpretation:'Exploratory order diagnostic only. Adjusted p-values address these two metrics only; they do not test all patterns searched, do not predict the next outcome, and do not establish betting edge.'
    };
  }
  function suffixSensitivity(sequence,maxDrop=3){
    const s=validateSequence(sequence);
    if(!Number.isInteger(maxDrop)||maxDrop<1||maxDrop>5)throw new Error('maxDrop must be an integer from 1 to 5.');
    const full=s.length?CORE.rapidRead(s):null;
    const fullLean=full&&['P','B'].includes(full.lean)?full.lean:'NEUTRAL';
    const checks=[];
    for(let drop=1;drop<=maxDrop;drop++){
      const prefix=s.slice(0,Math.max(0,s.length-drop));
      if(prefix.length<CORE.MIN_RAPID_PB){checks.push({drop_last_n:drop,prefix_n:prefix.length,available:false,lean:'INSUFFICIENT'});continue;}
      const q=CORE.rapidRead(prefix),lean=['P','B'].includes(q.lean)?q.lean:'NEUTRAL';
      checks.push({drop_last_n:drop,prefix_n:prefix.length,available:true,lean,source_lean:q.source_lean||null,changed_vs_full:lean!==fullLean});
    }
    const available=checks.filter(x=>x.available),same=available.filter(x=>x.lean===fullLean).length;
    const flips=available.filter(x=>x.lean!==fullLean).map(x=>x.drop_last_n);
    return {schema:'nexus-arc-v7-suffix-sensitivity-v1',version:VERSION,sequence_length:s.length,full_lean:fullLean,checks,available_checks:available.length,stable_checks:same,stability_fraction:available.length?same/available.length:null,changed_when_dropping:flips,fragile:flips.length>0,interpretation:'Sensitivity to deleting recent observations is a fragility diagnostic, not a way to choose the most favorable prefix and not evidence of predictive skill.'};
  }
  function diagnose(input,options={}){
    const sequence=validateSequence(typeof input==='string'?input:CORE.rapidRead(input).sequence||'');
    const coreRead=CORE.rapidRead(sequence);
    return {
      schema:'nexus-arc-v7-analysis-diagnostics-v1',version:VERSION,created_at:new Date().toISOString(),accepted_pb_n:sequence.length,
      source_lean:coreRead.source_lean||null,displayed_lean:coreRead.lean||'NEUTRAL',
      conditional_order_test:conditionalOrderTest(sequence,options.replicates===undefined?DEFAULT_REPLICATES:options.replicates),
      suffix_sensitivity:suffixSensitivity(sequence,options.max_drop===undefined?3:options.max_drop),
      weakness_checks:[
        {id:'PATTERN_MULTIPLICITY',status:'PARTIALLY_ADDRESSED',detail:'Two predeclared order metrics are tested with Bonferroni adjustment; this does not correct for every pattern previously explored by the analyst.'},
        {id:'RECENT_SUFFIX_FRAGILITY',status:'MEASURED',detail:'Recomputes the read after removing the last 1–3 outcomes; changes indicate sensitivity, not an alternative prediction.'},
        {id:'FUTURE_LEAKAGE',status:'NOT_TESTED_BY_THIS_MODULE',detail:'Use V6.3 prospective ledger and walk-forward replay; this diagnostic alone cannot prove capture-before-result.'},
        {id:'CARD_COMPOSITION',status:'UNAVAILABLE',detail:'P/B history contains no remaining-card composition and cannot estimate shoe-specific next-hand odds.'},
        {id:'MODEL_SELECTION_BIAS',status:'UNRESOLVED',detail:'The strategy was developed after examining historical patterns; prospective independent sessions remain necessary.'}
      ],
      guardrails:['No next-hand probability is generated.','A small empirical p-value does not imply predictability or wagering value.','A large p-value does not prove randomness.','Do not tune a strategy to the best-looking prefix or metric.','Keep prospective validation gate at WAIT until independent, pre-registered sessions are collected.']
    };
  }
  root.NexusArcV700={VERSION,MIN_NULL_N,DEFAULT_REPLICATES,MAX_REPLICATES,MAX_SEQUENCE,validateSequence,maxRun,transitions,conditionalOrderTest,suffixSensitivity,diagnose};
  if(typeof module!=='undefined'&&module.exports)module.exports=root.NexusArcV700;
})(typeof window!=='undefined'?window:globalThis);
