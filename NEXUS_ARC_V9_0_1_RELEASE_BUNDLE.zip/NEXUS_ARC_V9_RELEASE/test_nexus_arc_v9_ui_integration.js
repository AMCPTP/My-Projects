'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const V = require('./nexus_arc_v9_analysis_engine.js');
const html = fs.readFileSync('NEXUS_ARC_V9_ANALYSIS_DESK.html', 'utf8');
const match = html.match(/<script id="nexusArcV9PatternIntelligenceUI">([\s\S]*?)<\/script>/i);
assert.ok(match, 'V9 UI controller script must exist');

class FakeNode {
  constructor(id) { this.id=id; this.value=id==='v83Replicates'?'1999':''; this.textContent=''; this.innerHTML=''; this.className=''; this.disabled=false; this.handlers={}; this.files=[]; }
  addEventListener(name, fn) { (this.handlers[name] ||= []).push(fn); }
  click() { if (this.disabled) return; for (const fn of this.handlers.click || []) fn({target:this}); }
}
const nodes = new Map();
const document = {
  readyState:'complete',
  getElementById(id) { if (!nodes.has(id)) nodes.set(id,new FakeNode(id)); return nodes.get(id); },
  createElement(tag) { return new FakeNode(tag); },
  querySelectorAll() { return []; },
  body: new FakeNode('body')
};
const storage = new Map();
const localStorage = {
  getItem(k) { return storage.has(k) ? storage.get(k) : null; },
  setItem(k,v) { storage.set(k,String(v)); },
  removeItem(k) { storage.delete(k); }
};
const window = {NexusArcV9:V, NexusArcV830:V};
const alerts=[];
const ctx = {window,document,localStorage,console,Date,JSON,Math,Number,String,Array,Object,Set,Map,Error,RegExp,parseInt,
  confirm:()=>true, alert:m=>alerts.push(String(m)), setTimeout, Blob, URL,
  TextEncoder, crypto:require('node:crypto').webcrypto
};
vm.runInNewContext(match[1],ctx,{filename:'nexusArcV9PatternIntelligenceUI.js'});
const $=id=>document.getElementById(id);
const check=(label,fn)=>{fn();console.log('PASS '+label)};

check('UI init registers the V9 actions and renders an empty ledger',()=>{
  assert.ok($('v9RunAnalysis').handlers.click?.length);
  assert.ok($('v9LockForecast').handlers.click?.length);
  assert.ok($('v9ResolveForecast').handlers.click?.length);
  assert.equal($('v9LedgerN').textContent,'0');
});
check('V9 Analyze button routes through analysis and renders all 12 pattern rows',()=>{
  $('arSequence').value='PBPBBPPBBPBPBPPBBPBB';
  $('v9RunAnalysis').click();
  assert.equal($('v9PatternTotal').textContent,'12');
  assert.match($('v9PatternRows').innerHTML,/SUPPORT|STREAK|TRANSITIONS|REPEATED_MOTIFS/i);
  assert.match($('v9ShadowCall').textContent,/Live WAIT/);
});
check('V9 lock-resolve user flow records only the next single outcome',()=>{
  const prefix='PBPBBPPBBP';$('arSequence').value=prefix;$('v9SessionId').value='ui-integration-session';
  $('v9LockForecast').click();
  let l=JSON.parse(localStorage.getItem('nexus-arc-v9-local-forecast-ledger-v1'));
  assert.equal(l.records.length,1);assert.equal(l.records[0].status,'PENDING');assert.equal(l.records[0].prefix_sequence,prefix);
  $('arSequence').value=prefix+'B';$('v9ResolveForecast').click();
  l=JSON.parse(localStorage.getItem('nexus-arc-v9-local-forecast-ledger-v1'));
  assert.equal(l.records.length,1);assert.equal(l.records[0].status,'RESOLVED');assert.equal(l.records[0].actual,'B');assert.ok(Number.isFinite(l.records[0].log_loss));
});
check('corrupt saved ledger is blocked and is never overwritten with an empty ledger',()=>{
  const key='nexus-arc-v9-local-forecast-ledger-v1';const corrupt='{"records": ';localStorage.setItem(key,corrupt);
  $('v9LockForecast').disabled=false;$('arSequence').value='PBPBBPPBBP';$('v9LockForecast').click();
  assert.equal(localStorage.getItem(key),corrupt);
  assert.equal($('v9LockForecast').disabled,true);
  assert.match($('v9ForecastStatus').textContent,/INTEGRITY ERROR/);
});
console.log('\n4 V9 UI integration scenarios passed.');
