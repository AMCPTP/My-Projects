# NEXUS ARC V9 — Audit & Release Review

## Executive summary

V9 consolidates the active V8.3 dashboard into a V9 release while preserving the older engines/server routes that the main page and V6.3 evidence path still require. The focus is reliability of sequence analysis and pre-outcome evaluation, not a claim that more pattern labels will beat a random or market baseline.

## Phase 0 — input and Brain integrity

- Added a strict Brain export audit: SHA-256 must verify, `history` must contain only accepted P/B tokens, each case's actual result and recorded prefix must agree with the corresponding history position, and contradictory/duplicate cases are blocked.
- Imported Brain file examined during development has a valid checksum but contains two `learner.cases` rows for `at=43`; one says actual P while `history[43]` is B. The duplicate position is contradictory. It must not be imported as clean learner state.
- The validator deliberately does not rewrite source Brain data in place. A checksum proves content integrity, not semantic consistency.
- V9's persistent server store defaults to `./nexus_v9_data`, isolated from older `nexus_v5_0_data` storage.

## Phase 1 — multi-label 12-pattern registry

Registry categories: Streak/Run, Double/Short Blocks, Alternation, Two-by-Two/Block Cycle, Transition, Repeated Motifs, Local Imbalance, Rhythm/Complexity, Change Point, Multi-Scale Conflict, Historical Context, and Uncertainty/Fragility. These categories are explicit implementation labels for the V9 registry; they should not be assumed to match a prior undocumented naming catalogue one-for-one.

Each category emits evidence, counter-evidence, support level, and limits. Multiple patterns can be active at once. Pattern presence is descriptive unless prospective outcomes validate predictive usefulness.

## Phase 2 — adaptive routing and forecast restraint

- V9 shadow forecast combines smoothed descriptive evidence and shrinkage toward 50/50 rather than treating tiny support as certainty.
- The candidate direction is never authorized as a live recommendation: `live_action` is hard-coded to `WAIT`, `eligible_for_live=false`, and `calibrated=false`.
- Experts with weak or contradictory evidence do not trigger auto-promotion. A candidate review function can only nominate a further test.

## Phase 3 — evaluation and leakage controls

- Walk-forward forecasts use only the prefix available before each scored target.
- Descriptive metrics include log loss, Brier score, directional coverage, fixed baseline comparisons, and null tests/fragility checks where enough input exists.
- Small samples, dependent hands from one session, and selecting the best metric after trying many patterns can all make evidence look stronger than it is; reports keep these limitations explicit.

## Phase 4 — continuous forecast ledger

- A forecast locks the current exact P/B prefix and a user-provided session ID before the next outcome.
- Resolve accepts the frozen prefix plus exactly one result, scores once, and refuses edited prefixes/skipped outcomes.
- Multiple pending rows are treated as ledger corruption, not silently normalized. Cancellation is not scored.
- Browser localStorage is user-editable and is marked as local / not server-attested; the existing server-side V6.3 hash-chained evidence API remains available for server-backed audit records.

## Phase 5 — release and operational gates

- V9 server version is `9.0.0`; the Windows launcher opens the browser only after `/api/health` agrees on both version and exact dashboard name.
- JS assets are served through a strict allowlist; unused V6.0/V6.2 script assets are removed from the runtime bundle.
- Previous version dashboards are not redistributed; one active V9 dashboard is shipped.
- Legacy duplicated panels and unrelated general-purpose, external-event, old roadmap, and bankroll-risk sections are hidden from the active workflow while underlying compatibility IDs/modules are retained where needed to avoid breaking older routes/tests.
- Automatic model promotion remains disabled.

## Source-derived Brain diagnostics

In the uploaded V5.9.2 Brain export:
- `history` has 54 entries.
- `learner.cases` has 47 rows but only 46 distinct `at` positions.
- Every case's `pbTail` matches the preceding prefix; 46 of 47 `actual` values match the corresponding next history result. The contradictory duplicate at index 43 is blocking.
- Per-context samples are very sparse (1–6 observed examples for the listed contexts).
- The hazard expert has elevated loss (`ewma` about 2.152) and several extreme loss records (13.8155, corresponding to near-zero predicted probability on an observed result). It should not be trusted just because the expert name or internal weight suggests authority.

These facts describe the supplied small artifact only; they do not prove the long-run behaviour of every runtime path.

## Remaining deployment check

Server tests and JS unit suites passed in the development container. The container's Chromium process policy returned `ERR_BLOCKED_BY_ADMINISTRATOR` for both local HTTP and local file URLs, so browser-click E2E could not be completed here. The release still needs a final GUI smoke test on the target Windows machine. Do not describe the Windows/browser launch as verified until that is done.
