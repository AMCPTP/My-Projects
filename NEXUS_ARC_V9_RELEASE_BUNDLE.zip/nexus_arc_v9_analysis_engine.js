/* NEXUS ARC V9.0 Analysis Reliability & Adaptive Pattern Router
 * Descriptive P/B pattern detection + robustness + retrospective prequential audits.
 * Does not produce next-hand probabilities, wagering advice, or a claim of edge.
 */
(function(root){
  'use strict';
  const VERSION = '9.0.0';
  const MAX_SEQUENCE = 2000;
  const DEFAULT_WINDOWS = [4,8,12,20,40];
  const MIN_SEQUENCE = 8;
  const MIN_WF_HISTORY = 20;
  const EPS = 1e-12;

  function parseSequence(input){
    if(typeof input !== 'string') throw new Error('Sequence must be text containing P/B outcomes.');
    const raw = input.toUpperCase();
    if(/[^PB\s,;|/._-]/.test(raw)) throw new Error('Use only P and B outcomes plus spaces or separators.');
    const s = raw.replace(/[^PB]/g,'');
    if(s.length > MAX_SEQUENCE) throw new Error(`Sequence exceeds ${MAX_SEQUENCE} P/B outcomes.`);
    return s;
  }
  function assertSequence(s){
    if(typeof s !== 'string' || !/^[PB]*$/.test(s)) throw new Error('Sequence must contain only P and B outcomes.');
    if(s.length > MAX_SEQUENCE) throw new Error(`Sequence exceeds ${MAX_SEQUENCE} P/B outcomes.`);
    return s;
  }
  function maxRun(s){ let best=0, run=0, side=null; for(const x of s){run=x===side?run+1:1;side=x;if(run>best)best=run;} return best; }
  function currentRun(s){ if(!s.length)return {side:null,length:0};let i=s.length-1;while(i>0&&s[i-1]===s[s.length-1])i--;return {side:s[s.length-1],length:s.length-i}; }
  function alternations(s){let n=0;for(let i=1;i<s.length;i++)if(s[i]!==s[i-1])n++;return n;}
  function counts(s){let P=0;for(const x of s)if(x==='P')P++;return {n:s.length,P,B:s.length-P,p_share:s.length?P/s.length:null,b_share:s.length?(s.length-P)/s.length:null};}
  function transitionMatrix(s){
    const m={P:{P:0,B:0,total:0},B:{P:0,B:0,total:0}};
    for(let i=1;i<s.length;i++){m[s[i-1]][s[i]]++;m[s[i-1]].total++;}
    for(const from of ['P','B']) for(const to of ['P','B']) m[from][`${to}_share`]=m[from].total?m[from][to]/m[from].total:null;
    return m;
  }
  function countMotifs(s,minLen=2,maxLen=5){
    const all=[];
    for(let k=minLen;k<=maxLen;k++){
      if(s.length<k)continue;
      const map=new Map();
      for(let i=0;i<=s.length-k;i++){
        const motif=s.slice(i,i+k);let row=map.get(motif);
        if(!row){row={motif,length:k,count:0,positions:[]};map.set(motif,row);}
        row.count++;if(row.positions.length<10)row.positions.push(i+1);
      }
      for(const row of map.values()) if(row.count>=2) all.push(row);
    }
    all.sort((a,b)=>b.count-a.count||b.length-a.length||a.motif.localeCompare(b.motif));
    return all.slice(0,30);
  }
  function windowSummary(s,requested=DEFAULT_WINDOWS){
    return requested.map(w=>{
      const seq=s.slice(Math.max(0,s.length-w));const c=counts(seq);const a=alternations(seq);
      return {window:w,n:seq.length,P:c.P,B:c.B,p_share:c.p_share,alternations:a,alternation_rate:seq.length>1?a/(seq.length-1):null,max_run:maxRun(seq),current_run:currentRun(seq),status:seq.length===w?'FULL_WINDOW':'PARTIAL_WINDOW'};
    });
  }
  function classifyWindow(w){
    if(w.n<4)return 'INSUFFICIENT';
    const share=w.p_share;
    const balance=Math.abs(share-.5);
    const alt=w.alternation_rate===null?0:w.alternation_rate;
    const majority=balance<.1?'BALANCED':share>.5?'P_HEAVY':'B_HEAVY';
    const rhythm=alt>=.7?'ALTERNATING':alt<=.3?'PERSISTENT/CLUSTERED':'MIXED_RHYTHM';
    return `${majority} · ${rhythm}`;
  }
  function contextAndConflict(s,windows,transitions,motifs){
    const usable=windows.filter(w=>w.n>=4);
    const short=usable.find(w=>w.window===8)||usable[0]||null;
    const broad=usable.find(w=>w.window===40)||usable[usable.length-1]||null;
    const flags=[];
    if(!short||!broad||short.n<4||broad.n<8) flags.push({id:'WINDOW_COVERAGE',status:'INSUFFICIENT',detail:'Not enough history to compare short and broad contexts.'});
    else {
      const shortSide=short.P>short.B?'P':short.B>short.P?'B':'TIE';
      const broadSide=broad.P>broad.B?'P':broad.B>broad.P?'B':'TIE';
      flags.push({id:'SHORT_VS_BROAD_BALANCE',status:shortSide===broadSide?'ALIGNED':'DIFFERENT',detail:`Short window ${short.window}: ${shortSide}; broad window ${broad.window}: ${broadSide}. This is descriptive, not predictive.`});
      if(short.alternation_rate!==null&&broad.alternation_rate!==null&&Math.abs(short.alternation_rate-broad.alternation_rate)>=.25){
        flags.push({id:'RHYTHM_SHIFT',status:'DIFFERENT',detail:`Alternation rate differs by ${(Math.abs(short.alternation_rate-broad.alternation_rate)).toFixed(2)} between selected windows.`});
      } else flags.push({id:'RHYTHM_SHIFT',status:'NO_LARGE_DIFFERENCE_BY_RULE',detail:'The fixed descriptive threshold was not crossed; this does not prove stability.'});
    }
    const run=currentRun(s); const priorTransitionTotal=transitions[run.side]?.total||0;
    if(run.length>=3) flags.push({id:'CURRENT_STREAK',status:'VISIBLE_STREAK',detail:`Current ${run.side} run length ${run.length}; prior outgoing-transition sample for ${run.side} is ${priorTransitionTotal}.`});
    const repeated=motifs.find(x=>x.count>=3);
    flags.push({id:'REPEATED_MOTIF',status:repeated?'REPETITIONS_FOUND':'NO_MOTIF_REPEATED_3X',detail:repeated?`Motif ${repeated.motif} occurs ${repeated.count} times (overlapping positions possible).`:'No length-2..5 motif reached 3 occurrences.'});
    const statuses=flags.map(x=>x.status);
    const conflict=statuses.includes('DIFFERENT')||flags.some(x=>x.id==='SHORT_VS_BROAD_BALANCE'&&x.status==='DIFFERENT');
    return {flags,context_status:flags.some(x=>x.status==='INSUFFICIENT')?'INSUFFICIENT':conflict?'MIXED_CONTEXT':'NO_MATERIAL_CONFLICT_BY_RULE',note:'Context labels summarize historical sequence properties only; they do not indicate the next result.'};
  }
  function suffixSensitivity(s,maxDrop=3){
    if(!Number.isInteger(maxDrop)||maxDrop<1||maxDrop>5)throw new Error('maxDrop must be 1..5.');
    const signature=(seq)=>{
      const ws=windowSummary(seq).filter(x=>x.n>=4).map(w=>`${w.window}:${classifyWindow(w)}`);
      const run=currentRun(seq),runBand=run.length===0?'0':run.length===1?'1':run.length===2?'2':'3+';
      const motifs=countMotifs(seq).filter(x=>x.count>=3).slice(0,3).map(x=>`${x.motif}:${x.count>=5?'5+':x.count}`).join(',');
      return `${ws.join('|')}|run:${run.side||'-'}:${runBand}|motif:${motifs||'none'}`;
    };
    const base=signature(s),checks=[];
    for(let d=1;d<=maxDrop;d++){
      const p=s.slice(0,Math.max(0,s.length-d));const sig=signature(p);checks.push({drop_last_n:d,prefix_n:p.length,available:p.length>=MIN_SEQUENCE,signature:sig,changed_vs_full:sig!==base});
    }
    const valid=checks.filter(x=>x.available);return {checks,available_checks:valid.length,changed_when_dropping:valid.filter(x=>x.changed_vs_full).map(x=>x.drop_last_n),fragile:valid.some(x=>x.changed_vs_full),comparison:'Qualitative window classes, run-length band, and repeated motifs with capped frequency buckets; raw counts are not compared directly.',interpretation:'Sensitivity is not accuracy and must not be used to cherry-pick a favorable prefix.'};
  }
  function fnv1a(s){let h=2166136261;for(let i=0;i<s.length;i++)h=Math.imul(h^s.charCodeAt(i),16777619)>>>0;return h>>>0;}
  function rng(seed){let x=seed>>>0;return()=>{x=(Math.imul(1664525,x)+1013904223)>>>0;return x/4294967296;};}
  function shuffle(s,random){const a=s.split('');for(let i=a.length-1;i>0;i--){const j=Math.floor(random()*(i+1));[a[i],a[j]]=[a[j],a[i]];}return a.join('');}
  function motifMaxCount(s,minLen=2,maxLen=5){let max=0;for(let k=minLen;k<=maxLen;k++){const m=new Map();for(let i=0;i<=s.length-k;i++){const q=s.slice(i,i+k);m.set(q,(m.get(q)||0)+1);if(m.get(q)>max)max=m.get(q);} }return max;}
  function patternNullTest(s,replicates=999){
    assertSequence(s);
    if(!Number.isInteger(replicates)||replicates<199||replicates>9999)throw new Error('replicates must be integer 199..9999.');
    const c=counts(s),obs={max_run:maxRun(s),alternations:alternations(s),max_motif_count:motifMaxCount(s)};
    if(s.length<12||c.P===0||c.B===0)return {available:false,reason:'Need at least 12 outcomes and both P and B.',observed:obs,replicates:0};
    const rand=rng(fnv1a(`${s}|${replicates}|v9-null`));const sims=[];
    for(let i=0;i<replicates;i++){const x=shuffle(s,rand);sims.push({max_run:maxRun(x),alternations:alternations(x),max_motif_count:motifMaxCount(x)});}
    const p={};for(const k of Object.keys(obs)){let tail=0;if(k==='alternations'){const median=sims.map(x=>x[k]).sort((a,b)=>a-b)[Math.floor(sims.length/2)];const d=Math.abs(obs[k]-median);tail=sims.filter(x=>Math.abs(x[k]-median)>=d).length;}else tail=sims.filter(x=>x[k]>=obs[k]).length;p[k]=(1+tail)/(replicates+1);}
    const adj={};for(const k of Object.keys(p))adj[k]=Math.min(1,p[k]*3);
    return {available:true,replicates,seed:fnv1a(`${s}|${replicates}|v9-null`),null_model:'Uniformly shuffled order conditioned on fixed P/B counts; exchangeability is an assumption.',observed:obs,empirical_p:p,bonferroni_adjusted_p:adj,interpretation:'Exploratory max-run, alternation and repeated-motif checks only. Family-wise adjustment covers these three metrics only, not all prior searches. This is not a next-hand forecast.'};
  }
  function historicalWalkForward(s){
    assertSequence(s);
    const rows=[];const names=['fixed_half','follow_last','alternate_last','prefix_majority','transition_smoothed','v9_shadow_ensemble'];
    function clampProb(p){return Math.min(1-EPS,Math.max(EPS,p));}
    for(let i=MIN_WF_HISTORY;i<s.length;i++){
      const past=s.slice(0,i),actual=s[i],prev=past[past.length-1];const c=counts(past),tm=transitionMatrix(past);
      const pred={
        fixed_half:.5,
        follow_last:prev==='P'?.55:.45,
        alternate_last:prev==='P'?.45:.55,
        prefix_majority:(c.P+1)/(past.length+2),
        transition_smoothed:((tm[prev][ 'P']+1)/(tm[prev].total+2)),
        v9_shadow_ensemble:forecastFromPrefix(past).prob_P
      };
      const scored={};for(const name of names){const p=clampProb(pred[name]);const y=actual==='P'?1:0;scored[name]={p_P:p,hit:Math.abs(p-.5)<EPS?null:(p>.5?'P':'B')===actual,log_loss:-(y*Math.log(p)+(1-y)*Math.log(1-p)),brier:(p-y)*(p-y)};}
      rows.push({index_1based:i+1,prefix_n:i,prefix_end:prev,actual,scored});
    }
    const models={};for(const name of names){const v=rows.map(r=>r.scored[name]);const directional=v.filter(x=>x.hit!==null);models[name]={n:v.length,directional_n:directional.length,directional_coverage:v.length?directional.length/v.length:null,accuracy:directional.length?directional.filter(x=>x.hit).length/directional.length:null,mean_log_loss:v.length?v.reduce((a,x)=>a+x.log_loss,0)/v.length:null,mean_brier:v.length?v.reduce((a,x)=>a+x.brier,0)/v.length:null};}
    const enough=rows.length>=50;
    return {schema:'nexus-arc-v9-retrospective-walk-forward-v1',available:rows.length>0,sequence_n:s.length,scored_steps:rows.length,minimum_seed_history:MIN_WF_HISTORY,models,rows:rows.slice(-100),evaluation:'Retrospective prequential replay on this single supplied sequence; overlapping prefixes are dependent and model-selection bias remains. At least 50 scored steps is a descriptive minimum, not proof of an edge.',status:rows.length<20?'INSUFFICIENT':enough?'DESCRIPTIVE_REPLAY_READY':'SHORT_REPLAY',warnings:['These are heuristic backtest baselines, not validated baccarat odds.','Results on one historical sequence are not prospective validation.','Do not tune model choices on this same sequence and report the same rows as independent evidence.','P/B history does not reveal remaining shoe composition.']};
  }
  function reviewCandidate(input){
    const x=input||{};const n=Number(x.forecasts),sessions=Number(x.sessions),replications=Number(x.independent_replications);
    const dLL=Number(x.delta_log_loss),uLL=Number(x.upper_ci_delta_log_loss),dBr=Number(x.delta_brier),uBr=Number(x.upper_ci_delta_brier);
    const valid=[n,sessions,replications,dLL,uLL,dBr,uBr].every(Number.isFinite)&&n>=0&&sessions>=0&&replications>=0;
    if(!valid)return {status:'SHADOW_ONLY',reason:'Missing or invalid review metrics; module stays out of the live/core analyst.',promote:false};
    if(n<200||sessions<20)return {status:'SHADOW_ONLY',reason:'Require at least 200 pre-registered forecasts and 20 independent sessions before considering promotion.',promote:false};
    if(dLL>=0&&dBr>=0)return {status:'DEMOTE_CANDIDATE',reason:'Both point estimates fail to improve log loss and Brier versus champion; disable or demote in the shadow registry, not automatically in production.',promote:false};
    if(dLL<0&&dBr<0&&uLL<0&&uBr<0&&replications>=2)return {status:'ELIGIBLE_FOR_HUMAN_REVIEW',reason:'Both proper-score deltas and their supplied upper confidence bounds favor the candidate, with at least two independent replications. Still requires audit and explicit release approval.',promote:false};
    return {status:'HOLD_FOR_REPLICATION',reason:'Evidence is mixed, uncertainty overlaps zero, or independent replication is insufficient. Keep shadow-only.',promote:false};
  }
  function runs(s){
    const out=[]; if(!s.length)return out; let side=s[0],len=1,start=0;
    for(let i=1;i<s.length;i++){if(s[i]===side)len++;else{out.push({side,start_1based:start+1,end_1based:i,length:len});side=s[i];start=i;len=1;}}
    out.push({side,start_1based:start+1,end_1based:s.length,length:len});return out;
  }
  function binaryEntropy(p){if(p===null||!Number.isFinite(p)||p<=0||p>=1)return 0;return -(p*Math.log2(p)+(1-p)*Math.log2(1-p));}
  function longestRunOfSide(s,side){let best=0,cur=0;for(const x of s){cur=x===side?cur+1:0;if(cur>best)best=cur;}return best;}
  function pairBlocks(s){const countsByPair={PP:0,PB:0,BP:0,BB:0},non={PP:0,PB:0,BP:0,BB:0};for(let i=0;i+1<s.length;i++)countsByPair[s.slice(i,i+2)]++;for(let i=0;i+1<s.length;i+=2)non[s.slice(i,i+2)]++;const n=Object.values(countsByPair).reduce((a,b)=>a+b,0),nonN=Object.values(non).reduce((a,b)=>a+b,0);return{counts:countsByPair,n,non_overlapping_from_start:non,non_overlapping_n:nonN,note:'Overlapping adjacent pairs are dependent; non-overlapping pairs are shown separately.'};}
  function historicalSuffixEvidence(s,minLen=2,maxLen=5){
    const suffixes=[];
    for(let k=minLen;k<=Math.min(maxLen,s.length-1);k++){
      const suffix=s.slice(-k);let followingP=0,followingB=0,positions=[];
      for(let i=0;i+k<s.length;i++)if(s.slice(i,i+k)===suffix){if(s[i+k]==='P')followingP++;else followingB++;if(positions.length<12)positions.push({start_1based:i+1,next_index_1based:i+k+1});}
      const n=followingP+followingB;
      suffixes.push({length:k,suffix,support:n,following_P:followingP,following_B:followingB,observed_p_share:n?followingP/n:null,positions,interpretation:n<3?'VERY_SPARSE':n<8?'SPARSE':'DESCRIPTIVE_SUPPORT_ONLY'});
    }
    return suffixes;
  }
  function regimeShiftScan(s){
    if(s.length<12)return{available:false,status:'INSUFFICIENT',reason:'Need at least 12 outcomes; split scan has minimum 5 per side.',selected_split:null};
    const min=Math.max(5,Math.floor(s.length*.2));let best=null;
    for(let cut=min;cut<=s.length-min;cut++){
      const a=s.slice(0,cut),b=s.slice(cut),pa=counts(a).p_share,pb=counts(b).p_share,diff=Math.abs(pa-pb);
      const row={cut_after_1based:cut,left_n:a.length,right_n:b.length,left_p_share:pa,right_p_share:pb,absolute_p_share_difference:diff};
      if(!best||diff>best.absolute_p_share_difference)best=row;
    }
    return{available:true,status:best.absolute_p_share_difference>=.25?'POSSIBLE_CHANGE_POINT_BY_RULE':'NO_LARGE_SPLIT_DIFFERENCE_BY_RULE',selected_split:best,threshold:.25,minimum_side_n:min,interpretation:'Exploratory maximum-difference scan; selection over many split points inflates apparent differences. Not a causal claim or next-hand signal.'};
  }
  function patternRegistry(s,windows,transitions,motifs,context,suffixes){
    const c=counts(s),run=currentRun(s),allRuns=runs(s),alt= s.length>1?alternations(s)/(s.length-1):null;
    const minSupport=Math.max(1,Math.floor(s.length*.1));
    const usableWindows=windows.filter(w=>w.n>=4);const pShares=usableWindows.map(w=>w.p_share).filter(Number.isFinite);
    const scaleRange=pShares.length?Math.max(...pShares)-Math.min(...pShares):null;
    const entropy=binaryEntropy(c.p_share);const split=regimeShiftScan(s);
    const repeated=motifs.filter(m=>m.count>=3);
    const strongSuffix=suffixes.slice().filter(x=>x.support>=2).sort((a,b)=>b.length-a.length||b.support-a.support)[0]||null;
    const transitionN=transitions.P.total+transitions.B.total;
    const conflict=context.context_status==='MIXED_CONTEXT';
    const entries=[
      {id:'RUN_STRUCTURE',name:'Streak / run',status:run.length>=3?'FOUND':'OBSERVED',support:allRuns.length,evidence:`Current ${run.side||'-'} run=${run.length}; maximum run=${maxRun(s)}; run segments=${allRuns.length}.`,against:`Run length is descriptive and can occur under random ordering.`,limit:'Not evidence that a run will continue or reverse.'},
      {id:'ALTERNATION',name:'Alternation / ping-pong',status:alt===null?'INSUFFICIENT':alt>=.7?'HIGH_ALTERNATION':alt<=.3?'LOW_ALTERNATION':'MIXED',support:Math.max(0,s.length-1),evidence:`Adjacent alternations=${alternations(s)}; rate=${alt===null?'--':(alt*100).toFixed(1)+'%'}.`,against:'Rate depends on observed margins and sequence length.',limit:'Do not infer a stable alternation law from one shoe.'},
      {id:'PAIR_BLOCKS',name:'Pair / 2×2 blocks',status:s.length<4?'INSUFFICIENT':'DESCRIPTIVE',support:Math.max(0,s.length-1),evidence:`PP=${pairBlocks(s).counts.PP}, PB=${pairBlocks(s).counts.PB}, BP=${pairBlocks(s).counts.BP}, BB=${pairBlocks(s).counts.BB}; overlapping pairs.`,against:'Adjacent pair counts overlap and are dependent.',limit:'Block resemblance is not predictive by itself.'},
      {id:'TRANSITIONS',name:'Transition matrix',status:transitionN<8?'LOW_SUPPORT':'DESCRIPTIVE',support:transitionN,evidence:`After P n=${transitions.P.total}; after B n=${transitions.B.total}.`,against:`Transition counts may be unstable at low support; minimum support guidance=${minSupport}.`,limit:'Historical conditional frequencies are not validated next-hand probabilities.'},
      {id:'REPEATED_MOTIFS',name:'Repeated motifs 2–5',status:repeated.length?'FOUND':'NO_3X_MOTIF',support:motifs.length,evidence:repeated.slice(0,5).map(x=>`${x.motif} × ${x.count}`).join(', ')||'No motif has at least three overlapping occurrences.',against:'Searching many motifs increases chance of finding accidental repetitions.',limit:'The reported top motifs are exploratory; repeated appearances can overlap.'},
      {id:'MULTI_SCALE_BALANCE',name:'Multi-scale balance',status:usableWindows.length<2?'INSUFFICIENT':scaleRange>=.25?'SCALE_DISAGREEMENT':'NO_LARGE_SCALE_RANGE',support:usableWindows.reduce((a,w)=>a+w.n,0),evidence:`Usable windows=${usableWindows.length}; P-share range=${scaleRange===null?'--':scaleRange.toFixed(3)}.`,against:'Windows overlap heavily and are not independent samples.',limit:'Do not add overlapping window counts as if independent.'},
      {id:'RHYTHM_ENTROPY',name:'Rhythm / binary entropy',status:s.length<8?'LOW_SUPPORT':'DESCRIPTIVE',support:s.length,evidence:`Overall binary entropy=${entropy.toFixed(3)} bits (0–1); alternation rate=${alt===null?'--':alt.toFixed(3)}.`,against:'Entropy only describes the observed margins, not order predictability.',limit:'High entropy does not mean a predictable or profitable process.'},
      {id:'REGIME_SHIFT',name:'Possible regime / change point',status:split.status,support:s.length,evidence:split.selected_split?`Largest split difference ${(split.selected_split.absolute_p_share_difference*100).toFixed(1)} pp at prefix ${split.selected_split.cut_after_1based}.`:split.reason,against:'Maximum split search selects the strongest apparent separation by design.',limit:'Needs replication across independently captured sessions.'},
      {id:'HISTORICAL_SUFFIX',name:'Historical suffix retrieval',status:!strongSuffix?'INSUFFICIENT_MATCHES':'MATCHES_FOUND',support:strongSuffix?strongSuffix.support:0,evidence:strongSuffix?`Longest matched suffix ${strongSuffix.suffix} with ${strongSuffix.support} prior examples; outcomes P=${strongSuffix.following_P}, B=${strongSuffix.following_B}.`:'No current suffix length 2–5 has at least two prior matches.',against:'Prior occurrences within one sequence are dependent and sparse.',limit:'Retrieval is not a causal link or proof of repeatability.'},
      {id:'OVERLAP_CONFLICT',name:'Pattern overlap / conflict',status:conflict?'CONFLICT':'NO_CONFLICT_BY_FIXED_RULE',support:context.flags.length,evidence:context.flags.map(x=>`${x.id}:${x.status}`).join('; '),against:'A fixed rule may miss conflicts or flag harmless variation.',limit:'When material signals conflict, lower certainty rather than force a single pattern.'},
      {id:'SUPPORT_RELIABILITY',name:'Evidence support / reliability',status:s.length<20?'LOW_SUPPORT':s.length<50?'WARMING':'DESCRIPTIVE_ONLY',support:s.length,evidence:`History n=${s.length}; contexts require separate support accounting.`,against:'Total sequence length is not equal to independent session count.',limit:'Support count must be shown with every context-specific statistic.'},
      {id:'FRAGILITY_QUALITY',name:'Fragility / input quality',status:s.length<MIN_SEQUENCE?'INSUFFICIENT':(context.context_status==='MIXED_CONTEXT'||usableWindows.length<3)?'CHECK_CAUTION':'CHECK_SUFFIX_SENSITIVITY',support:s.length,evidence:'Suffix sensitivity and input integrity are reported separately; current summary does not certify an edge.',against:'Changing recent outcomes may change a classification without indicating the system is wrong.',limit:'Never cherry-pick a favorable prefix or edit forecast logs after seeing outcomes.'}
    ];
    return entries.map(x=>({...x,support_level:x.support<3?'VERY_LOW':x.support<10?'LOW':x.support<30?'MODERATE':'SEQUENCE_COUNT_ONLY'}));
  }
  function forecastFromPrefix(s){
    assertSequence(s);
    if(!s.length)return{schema:'nexus-arc-v9-shadow-forecast-v1',available:false,status:'WARMUP',prob_P:.5,prob_B:.5,shadow_call:'WAIT',live_action:'WAIT',eligible_for_live:false,reason:'No history.'};
    const c=counts(s),base=(c.P+1)/(s.length+2),tm=transitionMatrix(s),last=s[s.length-1];
    const trans=tm[last],transProb=(trans.P+2*base)/(trans.total+2),transReliability=trans.total/(trans.total+8);
    const suffixes=historicalSuffixEvidence(s,2,5).filter(x=>x.support>=2).sort((a,b)=>b.length-a.length||b.support-a.support);
    const selected=suffixes[0]||null;
    const suffixProb=selected?(selected.following_P+2*base)/(selected.support+2):base;
    const suffixReliability=selected?selected.support/(selected.support+6):0;
    const wb=.60,wt=.25*transReliability,ws=.15*suffixReliability,den=wb+wt+ws;
    let raw=(wb*base+wt*transProb+ws*suffixProb)/den;
    // Shrink the heuristic toward neutral because these summaries are not calibrated.
    const evidenceReliability=Math.min(.65,s.length/(s.length+25));
    let p=.5+(raw-.5)*evidenceReliability;
    p=Math.min(.98,Math.max(.02,p));
    const margin=Math.abs(p-.5),call=s.length>=20&&margin>=.035?(p>.5?'P':'B'):'WAIT';
    const minExpertSupport=Math.min(trans.total,selected?selected.support:0);
    return{schema:'nexus-arc-v9-shadow-forecast-v1',available:s.length>=MIN_SEQUENCE,status:s.length<MIN_SEQUENCE?'WARMUP':'SHADOW_ONLY',n:s.length,prob_P:p,prob_B:1-p,raw_blend_P:raw,base_P:base,transition_P:transProb,transition_support:trans.total,suffix:selected?{suffix:selected.suffix,support:selected.support,following_P:selected.following_P,following_B:selected.following_B,p_P:suffixProb}:null,weights:{base:wb/den,transition:wt/den,suffix:ws/den},shrink_factor:evidenceReliability,margin,shadow_call:call,live_action:'WAIT',eligible_for_live:false,calibrated:false,context_warning:margin>=.035&&selected&&selected.support<3?'LOW_MATCH_SUPPORT':'UNVALIDATED',interpretation:'Experimental shadow forecast only. The displayed P/B values are heuristic estimates, not validated baccarat odds. Live action remains WAIT until independent prospective evidence supports release.',reason:s.length<MIN_SEQUENCE?'Need at least 8 outcomes for exploratory estimates.':call==='WAIT'?'Insufficient history or small margin under the fixed threshold.':'A descriptive side was selected for shadow logging only.'};
  }
  function createForecastLedger(raw){
    const x=raw&&typeof raw==='object'?raw:{};
    const records=Array.isArray(x.records)?x.records.filter(r=>r&&typeof r==='object').slice(-1000):[];
    const pending=records.filter(r=>r.status==='PENDING');return{schema:'nexus-arc-v9-local-forecast-ledger-v1',version:VERSION,records,pending_id:pending.length===1?pending[0].forecast_id:pending.length?'MULTIPLE_PENDING_INVALID':null,pending_conflict:pending.length>1,storage_trust:'LOCAL_BROWSER_STORAGE_MUTABLE_NOT_SERVER_ATTESTED'};
  }
  function freezeForecast(ledgerInput,sequence,sessionId='',createdAt=new Date().toISOString()){
    const ledger=createForecastLedger(ledgerInput),s=typeof sequence==='string'?parseSequence(sequence):assertSequence(sequence);
    if(ledger.pending_conflict)throw new Error('Ledger integrity error: multiple pending forecasts exist; export and reconcile the ledger before continuing.');if(ledger.pending_id&&ledger.records.some(r=>r.forecast_id===ledger.pending_id&&r.status==='PENDING'))throw new Error('Resolve or cancel the existing V9 pending forecast before freezing another.');
    if(s.length<MIN_SEQUENCE)throw new Error(`Need at least ${MIN_SEQUENCE} outcomes before freezing a V9 forecast.`);
    const fc=forecastFromPrefix(s),id=`v9-${fnv1a(`${sessionId}|${s}|${createdAt}|${ledger.records.length}`).toString(16)}-${ledger.records.length+1}`;
    const r={forecast_id:id,session_id:String(sessionId||'UNSPECIFIED').slice(0,80),created_at:createdAt,engine_version:VERSION,prefix_n:s.length,prefix_sequence:s,prefix_fingerprint:fnv1a(s).toString(16).padStart(8,'0'),prob_P:fc.prob_P,prob_B:fc.prob_B,shadow_call:fc.shadow_call,live_action:'WAIT',forecast_status:fc.status,status:'PENDING',actual:null,hit:null,log_loss:null,brier:null,freeze_note:'Forecast saved before outcome entry. This local ledger is mutable and not independent timestamp proof.'};
    ledger.records.push(r);ledger.pending_id=id;return{ledger,record:r,forecast:fc};
  }
  function resolveForecast(ledgerInput,forecastId,updatedSequence,resolvedAt=new Date().toISOString()){
    const ledger=createForecastLedger(ledgerInput),s=typeof updatedSequence==='string'?parseSequence(updatedSequence):assertSequence(updatedSequence);
    const r=ledger.records.find(x=>x.forecast_id===forecastId);
    if(ledger.pending_conflict)throw new Error('Ledger integrity error: multiple pending forecasts exist.');if(!r||r.status!=='PENDING'||ledger.pending_id!==forecastId)throw new Error('Pending V9 forecast not found or already resolved.');
    if(s.length!==r.prefix_n+1||!s.startsWith(r.prefix_sequence))throw new Error('Resolve blocked: current history must equal the frozen prefix plus exactly one new P/B outcome.');
    const actual=s[s.length-1],y=actual==='P'?1:0,p=Math.min(1-EPS,Math.max(EPS,r.prob_P));
    r.actual=actual;r.hit=r.shadow_call==='WAIT'?null:r.shadow_call===actual;r.log_loss=-(y*Math.log(p)+(1-y)*Math.log(1-p));r.brier=(p-y)*(p-y);r.status='RESOLVED';r.resolved_at=resolvedAt;ledger.pending_id=null;
    return{ledger,record:r};
  }
  function cancelForecast(ledgerInput,forecastId,reason='operator_cancelled',cancelledAt=new Date().toISOString()){
    const ledger=createForecastLedger(ledgerInput),r=ledger.records.find(x=>x.forecast_id===forecastId);
    if(ledger.pending_conflict)throw new Error('Ledger integrity error: multiple pending forecasts exist.');if(!r||r.status!=='PENDING'||ledger.pending_id!==forecastId)throw new Error('Pending V9 forecast not found.');
    r.status='CANCELLED';r.cancel_reason=String(reason).slice(0,120);r.cancelled_at=cancelledAt;ledger.pending_id=null;return{ledger,record:r};
  }
  function canonicalize(value){
    if(Array.isArray(value))return value.map(canonicalize);
    if(value&&typeof value==='object'){const out={};for(const k of Object.keys(value).sort())out[k]=canonicalize(value[k]);return out;}
    return value;
  }
  function brainChecksumPayload(d){return{schema:d.schema,history:d.history,learner:{...d.learner,integrity:{}},events:Array.isArray(d.events)?d.events:[]};}
  function validateBrainExport(input){
    const d=typeof input==='string'?JSON.parse(input):input;const issues=[];
    const add=(severity,code,detail)=>issues.push({severity,code,detail});
    if(!d||typeof d!=='object'||Array.isArray(d)){return{schema:'nexus-arc-v9-brain-audit-v1',status:'BLOCK_IMPORT',import_allowed:false,issues:[{severity:'CRITICAL',code:'NOT_OBJECT',detail:'Brain export must be a JSON object.'}],summary:{}};}
    if(d.schema!=='NEXUS-ARC-V5.9.2-CONTEXT-ISOLATION-INTEGRITY')add('CRITICAL','UNSUPPORTED_SCHEMA',`Unsupported Brain schema: ${String(d.schema)}.`);
    if(!Array.isArray(d.history))add('CRITICAL','HISTORY_NOT_ARRAY','history must be an array.');
    const history=Array.isArray(d.history)?d.history:[];
    for(let i=0;i<history.length;i++)if(!['P','B'].includes(history[i]))add('CRITICAL','INVALID_HISTORY_TOKEN',`history[${i}] is not P/B; this Brain schema requires explicit P/B history without flattened Tie outcomes.`);
    if(!d.learner||typeof d.learner!=='object')add('CRITICAL','LEARNER_MISSING','learner object is missing.');
    const cases=Array.isArray(d.learner?.cases)?d.learner.cases:[];if(!Array.isArray(d.learner?.cases))add('WARNING','CASES_NOT_ARRAY','learner.cases is not an array; no case-level reconciliation was possible.');
    const byAt=new Map();let validIndexes=0,validActuals=0,validTails=0;
    for(let i=0;i<cases.length;i++){
      const c=cases[i];if(!c||typeof c!=='object'){add('CRITICAL','INVALID_CASE',`cases[${i}] is not an object.`);continue;}
      if(!Number.isInteger(c.at)||c.at<0||c.at>=history.length){add('CRITICAL','CASE_INDEX_RANGE',`cases[${i}].at=${String(c.at)} has no next outcome in history.`);continue;}
      validIndexes++;
      const actual=history[c.at];
      if(c.actual!==actual){add('CRITICAL','CASE_ACTUAL_MISMATCH',`cases[${i}] at=${c.at}: case actual=${String(c.actual)} but history[${c.at}]=${String(actual)}.`);}else validActuals++;
      const expectedTail=history.slice(0,c.at).filter(x=>x==='P'||x==='B').slice(-24).join('');
      if(typeof c.pbTail==='string'&&c.pbTail!==expectedTail){add('CRITICAL','CASE_PREFIX_MISMATCH',`cases[${i}] at=${c.at}: stored pbTail does not match the last 24 outcomes before this forecast.`);}else if(typeof c.pbTail==='string')validTails++;
      const prev=byAt.get(c.at);
      if(prev){if(prev.actual!==c.actual||prev.pbTail!==c.pbTail||JSON.stringify(prev.forecast?.prob)!==JSON.stringify(c.forecast?.prob)){add('CRITICAL','CONFLICTING_DUPLICATE_AT',`Multiple contradictory forecast records use at=${c.at}.`);}else add('WARNING','DUPLICATE_CASE_AT',`Duplicate equivalent case at=${c.at}; deduplicate before learning.`);}
      else byAt.set(c.at,c);
      const prob=c.forecast?.prob;
      if(prob&&(!Number.isFinite(prob.P)||!Number.isFinite(prob.B)||prob.P<0||prob.B<0||prob.P>1||prob.B>1||Math.abs(prob.P+prob.B-1)>1e-6))add('CRITICAL','INVALID_FORECAST_PROBABILITY',`cases[${i}] has invalid forecast probability distribution.`);
    }
    const critical=issues.some(x=>x.severity==='CRITICAL'),warnings=issues.some(x=>x.severity==='WARNING');
    return{schema:'nexus-arc-v9-brain-audit-v1',brain_schema:d.schema,status:critical?'BLOCK_IMPORT':warnings?'IMPORT_WITH_WARNINGS':'CLEAN',import_allowed:!critical,issues,summary:{history_n:history.length,case_n:cases.length,unique_case_indexes:byAt.size,valid_case_indexes:validIndexes,actual_matches:validActuals,prefix_matches:validTails,critical_issue_count:issues.filter(x=>x.severity==='CRITICAL').length,warning_count:issues.filter(x=>x.severity==='WARNING').length,model_names:Object.keys(d.learner?.models||{}),events_n:Array.isArray(d.events)?d.events.length:0}};
  }
  async function verifyBrainExport(input){
    const d=typeof input==='string'?JSON.parse(input):input;const audit=validateBrainExport(d);let checksum={checked:false,valid:null,reason:'No checksum verification attempted.'};
    if(d&&typeof d==='object'&&/^[a-f0-9]{64}$/i.test(String(d.checksum||''))){
      const payload=JSON.stringify(canonicalize(brainChecksumPayload(d)));let digest=null;
      if(root.crypto?.subtle){const bytes=new TextEncoder().encode(payload);const hash=await root.crypto.subtle.digest('SHA-256',bytes);digest=Array.from(new Uint8Array(hash)).map(x=>x.toString(16).padStart(2,'0')).join('');}
      else if(typeof require==='function'){try{digest=require('node:crypto').createHash('sha256').update(payload).digest('hex');}catch(_){}}
      checksum=digest?{checked:true,valid:digest.toLowerCase()===String(d.checksum).toLowerCase(),computed:digest,stored:d.checksum,reason:digest.toLowerCase()===String(d.checksum).toLowerCase()?'SHA-256 matches canonical V5.9.2 payload.':'SHA-256 mismatch.'}:{checked:false,valid:null,reason:'SHA-256 unavailable in this environment.'};
    }else checksum={checked:true,valid:false,reason:'Missing or malformed 64-character SHA-256 checksum.'};
    if(checksum.valid===false)audit.issues.push({severity:'CRITICAL',code:'CHECKSUM_MISMATCH',detail:checksum.reason});else if(checksum.valid!==true)audit.issues.push({severity:'CRITICAL',code:'CHECKSUM_UNVERIFIED',detail:'SHA-256 could not be verified; import is blocked until verification runs in a supported secure environment.'});
    const critical=audit.issues.some(x=>x.severity==='CRITICAL');audit.status=critical?'BLOCK_IMPORT':audit.issues.some(x=>x.severity==='WARNING')?'IMPORT_WITH_WARNINGS':'CLEAN';audit.import_allowed=!critical;audit.checksum=checksum;return audit;
  }
  function summarizeLedger(ledgerInput){
    const ledger=createForecastLedger(ledgerInput),resolved=ledger.records.filter(r=>r.status==='RESOLVED');
    const mean=k=>resolved.length?resolved.reduce((a,r)=>a+(Number.isFinite(r[k])?r[k]:0),0)/resolved.length:null;
    const predicted=resolved.filter(r=>r.shadow_call==='P'||r.shadow_call==='B');
    return{records:ledger.records.length,pending:ledger.records.filter(r=>r.status==='PENDING').length,resolved:resolved.length,cancelled:ledger.records.filter(r=>r.status==='CANCELLED').length,directional_n:predicted.length,directional_accuracy:predicted.length?predicted.filter(r=>r.hit===true).length/predicted.length:null,mean_log_loss:mean('log_loss'),mean_brier:mean('brier'),trust:ledger.storage_trust,note:'Descriptive local record summary only; do not treat browser storage as independently authenticated prospective evidence.'};
  }

  function analyze(input,options={}){
    const s=typeof input==='string'?parseSequence(input):assertSequence(input);
    const c=counts(s),windows=windowSummary(s),transitions=transitionMatrix(s),motifs=countMotifs(s),context=contextAndConflict(s,windows,transitions,motifs);
    const suffixes=historicalSuffixEvidence(s,2,5),registry=patternRegistry(s,windows,transitions,motifs,context,suffixes);
    const byLength={};for(let k=2;k<=5;k++)byLength[k]=motifs.filter(m=>m.length===k).length;
    const wf=options.include_walk_forward===false?{available:false,reason:'Disabled by caller.'}:historicalWalkForward(s);
    return {
      schema:'nexus-arc-v9-analysis-reliability-v1',version:VERSION,created_at:new Date().toISOString(),
      input:{n:s.length,counts:c,sequence:s},
      sufficiency:{minimum_for_basic_patterns:MIN_SEQUENCE,basic_ready:s.length>=MIN_SEQUENCE,walk_forward_seed_history:MIN_WF_HISTORY,reason:s.length<MIN_SEQUENCE?`Need at least ${MIN_SEQUENCE} outcomes for a basic pattern read.`:null},
      sequence_profile:{current_run:currentRun(s),runs:runs(s),max_run:maxRun(s),alternations:alternations(s),alternation_rate:s.length>1?alternations(s)/(s.length-1):null,entropy_bits:binaryEntropy(c.p_share)},
      windows:windowSummary(s,options.windows||DEFAULT_WINDOWS).map(w=>({...w,classification:classifyWindow(w)})),
      transition_matrix:transitions,repeated_motifs:motifs,motif_summary:{repeated_motif_count:motifs.length,by_length:byLength},
      context_conflict:context,suffix_sensitivity:suffixSensitivity(s,options.max_drop===undefined?3:options.max_drop),
      pattern_null_test:options.include_null===false?{available:false,reason:'Disabled by caller.'}:patternNullTest(s,options.replicates===undefined?999:options.replicates),
      walk_forward:wf,
      pattern_registry:registry,
      pattern_registry_summary:{total:registry.length,found:registry.filter(x=>['FOUND','HIGH_ALTERNATION','LOW_ALTERNATION','POSSIBLE_CHANGE_POINT_BY_RULE','MATCHES_FOUND'].includes(x.status)).length,conflicts:registry.filter(x=>x.status==='CONFLICT').length,low_support:registry.filter(x=>['INSUFFICIENT','LOW_SUPPORT','VERY_LOW'].includes(x.status)).length,mode:'MULTI_LABEL; patterns may overlap'},
      historical_suffix_evidence:suffixes,
      regime_shift:regimeShiftScan(s),
      shadow_forecast:forecastFromPrefix(s),
      controlled_learning:{status:'SHADOW_ONLY',automatic_promotion:false,rule:'V9 shadow forecasts are logged and scored but do not override the V6.3 live lean. Release needs independent prospective evidence, multiple sessions, uncertainty intervals and explicit human approval.',review_api:'reviewCandidate'},
      guardrails:['Pattern registry is descriptive; 12 groups are not 12 independent evidence sources.','Shadow P/B estimates are experimental heuristics, not calibrated baccarat odds; live_action remains WAIT.','Transition ratios and suffix retrieval are historical conditional frequencies, not validated next-hand probabilities.','Null-test correction covers only the three displayed statistics.','Retrospective walk-forward on a single sequence is not prospective validation.','P/B-only history does not reveal remaining-card composition or establish expected value/profitability.','Local browser logs are editable and do not replace the server prospective evidence chain.']
    };
  }
  const API={VERSION,MAX_SEQUENCE,DEFAULT_WINDOWS,MIN_SEQUENCE,MIN_WF_HISTORY,parseSequence,counts,maxRun,currentRun,alternations,transitionMatrix,countMotifs,windowSummary,contextAndConflict,suffixSensitivity,patternNullTest,historicalWalkForward,reviewCandidate,analyze,runs,binaryEntropy,pairBlocks,historicalSuffixEvidence,regimeShiftScan,patternRegistry,forecastFromPrefix,createForecastLedger,freezeForecast,resolveForecast,cancelForecast,summarizeLedger,validateBrainExport,verifyBrainExport,canonicalize,brainChecksumPayload};
  root.NexusArcV9=API;root.NexusArcV830=API;if(typeof module!=='undefined'&&module.exports)module.exports=API;
})(typeof window!=='undefined'?window:globalThis);
