@echo off
setlocal
cd /d "%~dp0"
echo === V9 JavaScript syntax ===
node --check nexus_arc_v9_analysis_engine.js || goto :fail
node test_nexus_arc_v9_analysis_engine.js || goto :fail
node test_nexus_arc_v5_9_5_pattern_engine.js || goto :fail
node test_nexus_arc_v5_10_1_rapid_analyst_engine.js || goto :fail
node test_nexus_arc_v6_3_validation_engine.js || goto :fail
node test_nexus_arc_v7_diagnostics_engine.js || goto :fail
echo === V9 Python syntax ===
py -3 -m py_compile nexus_arc_v9_server.py || goto :fail
echo === V9 server regression ===
py -3 -m unittest -v test_nexus_arc_v9_server_regression.py || goto :fail
echo.
echo All included V9 validation suites passed.
exit /b 0
:fail
echo.
echo V9 test suite failed. See output above.
exit /b 1
