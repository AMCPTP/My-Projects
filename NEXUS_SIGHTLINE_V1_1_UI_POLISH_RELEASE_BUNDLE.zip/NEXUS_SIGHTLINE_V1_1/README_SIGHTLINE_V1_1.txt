NEXUS SIGHTLINE V1.1 — GAME READING CORE
========================================
Release: 1.1.0
Purpose: Lean local-first P/B/T sequence analysis with an explicit experimental next-outcome estimate.

WHAT CHANGED IN V1.1
--------------------
- Added a dedicated NEXT ESTIMATE panel showing estimated shares for P/B/T and the model's highest-ranked outcome.
- The estimate blends a standard eight-deck Punto Banco baseline, smoothed overall historical shares, and a shrunk first-order transition after the latest known outcome.
- Shows transition support count, transition weight, the margin between the top two outcomes, divergence from the baseline, and an evidence limitation label.
- Repeated suffixes/motifs and window changes remain visible as separate context checks; rare motifs are not allowed to drive the numeric estimate.
- Migrates locally stored V1.0.0 sessions without discarding the user's saved sequence.

FORECAST METHOD (EXPERIMENTAL)
------------------------------
Reference baseline for standard eight-deck Punto Banco:
- Player (P): 44.6247%
- Banker (B): 45.8597%
- Tie (T): 9.5156%
Source: Wizard of Odds, Baccarat Basics — https://wizardofodds.com/games/baccarat/basics/
This base may differ for a non-standard variant, and it is not a shoe-specific forecast.

Let base[s] be the reference probability and N[s] the observed count:
Global[s] = (N[s] + 40 * base[s]) / (N + 40)

Let last be the most recent observed event and C[last,s] the number of historical transitions from last to s; support is the number of observed transitions from last:
Transition[s] = (C[last,s] + 12 * Global[s]) / (support + 12)
weight = min(0.65, support / (support + 20))
Estimate[s] = (1 - weight) * Global[s] + weight * Transition[s]

The model intentionally shrinks the transition signal and caps its contribution. It does not add a rare-motif adjustment because repeatedly searching patterns creates a high risk of overfitting. The displayed outcome is only the highest-ranked model estimate, not a recommended bet.

CORE CAPABILITIES
-----------------
- Read up to 2,000 ordered outcomes: P (Player), B (Banker), T (Tie).
- Preserve T in the original timeline and full transition matrix.
- Read P/B streaks and side switch rate (a Tie does not change the active P/B side).
- Count transition and repeated suffix/motif evidence with visible support.
- Compare trailing 12/24/48 windows and adjacent 24-outcome windows.
- Experimental next-outcome estimate with visible P/B/T values and model support details.
- Local browser storage and JSON import/export; no game sequence is uploaded to a server.
- No external packages or remote JavaScript/font/image dependencies.

IMPORTANT LIMITATIONS
--------------------
- The next-outcome estimate is UNVALIDATED. It has not passed a prospective, independent-session experiment or probability calibration review.
- P/B/T history alone does not reveal the remaining card composition in the shoe. This model must not be mistaken for a card-composition engine.
- Historical frequencies and transitions can fluctuate by chance. A higher modeled percentage is not proof of predictive advantage.
- “Evidence level” means the volume of relevant history only; it is not calibrated confidence.
- The app does not tell the user which side to bet on, estimate betting value, or guarantee outcomes.

START ON WINDOWS
----------------
1. Install Python 3.10+ with the Windows Python launcher (py).
2. Extract this folder to a writable location.
3. Double-click start_sightline_v1.bat.
4. The browser opens at http://127.0.0.1:8765/.
5. Enter outcomes oldest-to-newest, using P/B/T; press Ctrl+Enter to analyze.
6. Use Export JSON to make a portable backup.

RUN TESTS
---------
Double-click run_sightline_tests.bat. Node.js 18+ is used for engine unit tests; Python 3.10+
is used for package and local HTTP smoke tests. Normal app usage needs only Python/browser.

DATA / PRIVACY
--------------
- Server binds only to 127.0.0.1 and serves a fixed allowlist of local app assets.
- It does not provide an endpoint for uploading game sequences.
- Sequence and session name stay in this browser's localStorage. Clear site data to remove them.
- JSON exports include sequence and session name; treat them as user data.


INTERFACE FLOW
--------------
The dashboard is organized in this order: enter history -> inspect the experimental next-outcome estimate -> review the snapshot -> inspect mix, tempo, context windows, transitions, motifs, and audit notes. Use the quick-navigation strip near the top to jump between sections. On wide screens the input panel stays visible while scrolling; on smaller screens it returns to the normal page flow.
