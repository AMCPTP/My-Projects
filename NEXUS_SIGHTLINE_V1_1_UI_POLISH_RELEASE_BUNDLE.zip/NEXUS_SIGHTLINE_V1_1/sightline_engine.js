/* NEXUS SIGHTLINE V1 — compact, evidence-first game-reading engine.
 * P/B/T sequence analysis only. Descriptive statistics are not a promise of predictive edge.
 * No dependencies; usable in browser and Node.js tests.
 */
(function (root, factory) {
  const api = factory();
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  if (root) root.SightlineEngine = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  const VERSION = '1.1.0';
  // Standard eight-deck Punto Banco outcome probabilities (not a shoe-specific forecast).
  const STANDARD_8_DECK_BASELINE = Object.freeze({ P: 0.446247, B: 0.458597, T: 0.095156 });
  const GLOBAL_PRIOR_STRENGTH = 40;
  const TRANSITION_PRIOR_STRENGTH = 12;
  const MAX_TRANSITION_WEIGHT = 0.65;
  const MAX_OUTCOMES = 2000;
  const SIDES = ['P', 'B', 'T'];
  const SIDE_NAMES = { P: 'Player', B: 'Banker', T: 'Tie' };

  function parseSequence(input) {
    if (typeof input !== 'string') throw new TypeError('ประวัติต้องเป็นข้อความ');
    let text = input.toUpperCase();
    text = text.replace(/\bPLAYER\b/g, 'P').replace(/\bBANKER\b/g, 'B').replace(/\bTIE\b/g, 'T');
    const out = [];
    for (const ch of text) {
      if (SIDES.includes(ch)) out.push(ch);
      else if (/[\s,;|/_.:>\-()[\]{}]/.test(ch)) continue;
      else throw new Error(`พบสัญลักษณ์ที่ไม่รองรับ: “${ch}” — ใช้ P, B, T เท่านั้น`);
    }
    if (out.length > MAX_OUTCOMES) throw new Error(`รองรับประวัติสูงสุด ${MAX_OUTCOMES} ผลต่อการวิเคราะห์`);
    return out.join('');
  }

  function countOutcomes(sequence) {
    const counts = { P: 0, B: 0, T: 0 };
    for (const x of sequence) counts[x]++;
    return {
      n: sequence.length, counts,
      shares: Object.fromEntries(SIDES.map(s => [s, sequence.length ? counts[s] / sequence.length : null]))
    };
  }

  function distribution(sequence) {
    const info = countOutcomes(sequence);
    return Object.fromEntries(SIDES.map(s => [s, info.n ? info.counts[s] / info.n : 0]));
  }

  function totalVariation(a, b) {
    return SIDES.reduce((sum, s) => sum + Math.abs((a[s] || 0) - (b[s] || 0)), 0) / 2;
  }

  function sideProjection(sequence) {
    // Ties remain in the original event sequence and are reported separately.
    // For classic P/B side-streak reading, a tie does not change the active side.
    return sequence.replace(/T/g, '');
  }

  function runProfile(sideSequence) {
    if (!sideSequence.length) return { runs: [], currentSide: null, currentLength: 0, maxLength: 0, runCount: 0 };
    const runs = [];
    let start = 0;
    for (let i = 1; i <= sideSequence.length; i++) {
      if (i === sideSequence.length || sideSequence[i] !== sideSequence[start]) {
        runs.push({ side: sideSequence[start], length: i - start, startIndex: start, endIndexExclusive: i });
        start = i;
      }
    }
    return {
      runs,
      currentSide: runs[runs.length - 1].side,
      currentLength: runs[runs.length - 1].length,
      maxLength: Math.max(...runs.map(r => r.length)),
      runCount: runs.length,
      meanLength: sideSequence.length / runs.length,
      recentRuns: runs.slice(-24)
    };
  }

  function transitionMatrix(sequence) {
    const matrix = {};
    for (const from of SIDES) {
      matrix[from] = { total: 0, counts: { P: 0, B: 0, T: 0 }, shares: { P: null, B: null, T: null } };
    }
    for (let i = 0; i + 1 < sequence.length; i++) {
      const from = sequence[i], to = sequence[i + 1];
      matrix[from].counts[to]++;
      matrix[from].total++;
    }
    for (const from of SIDES) {
      const row = matrix[from];
      for (const to of SIDES) row.shares[to] = row.total ? row.counts[to] / row.total : null;
    }
    return matrix;
  }

  function conditionalReference(matrix, lastEvent) {
    if (!lastEvent || !matrix[lastEvent]) return null;
    const row = matrix[lastEvent];
    // Jeffreys-like light smoothing is intentionally not used here: this is an
    // empirical follow-up reference, and unobserved rows must remain visibly empty.
    return {
      after: lastEvent,
      support: row.total,
      counts: { ...row.counts },
      shares: { ...row.shares },
      interpretation: row.total < 8 ? 'LOW_SUPPORT' : 'DESCRIPTIVE_ONLY'
    };
  }

  function forecastNext(sequence, transitions) {
    if (!sequence.length) return null;
    const summary = countOutcomes(sequence);
    const globalEstimate = {};
    for (const side of SIDES) {
      globalEstimate[side] = (summary.counts[side] + GLOBAL_PRIOR_STRENGTH * STANDARD_8_DECK_BASELINE[side]) /
        (summary.n + GLOBAL_PRIOR_STRENGTH);
    }
    const lastEvent = sequence[sequence.length - 1];
    const row = transitions[lastEvent];
    const transitionEstimate = {};
    for (const side of SIDES) {
      transitionEstimate[side] = (row.counts[side] + TRANSITION_PRIOR_STRENGTH * globalEstimate[side]) /
        (row.total + TRANSITION_PRIOR_STRENGTH);
    }
    // A shrunk first-order transition estimate can only affect at most 65% of the blend.
    // Rare sequences/motifs are intentionally excluded from the numeric estimate to limit overfit.
    const transitionWeight = row.total > 0
      ? Math.min(MAX_TRANSITION_WEIGHT, row.total / (row.total + 20))
      : 0;
    const probabilities = {};
    let sum = 0;
    for (const side of SIDES) {
      probabilities[side] = (1 - transitionWeight) * globalEstimate[side] +
        transitionWeight * transitionEstimate[side];
      sum += probabilities[side];
    }
    for (const side of SIDES) probabilities[side] /= sum;
    const ranked = SIDES.slice().sort((a, b) => probabilities[b] - probabilities[a]);
    let evidenceLevel = 'HISTORICAL_SUPPORT_ONLY';
    let evidenceText = 'มีประวัติประกอบมากขึ้น แต่ยังไม่ผ่านการทดสอบล่วงหน้า';
    if (summary.n < 20 || row.total < 8) {
      evidenceLevel = 'LOW';
      evidenceText = 'หลักฐานต่ำ — จำนวนผลทั้งหมดหรือจำนวน transition หลังผลล่าสุดยังน้อย';
    } else if (summary.n < 100 || row.total < 20) {
      evidenceLevel = 'LIMITED';
      evidenceText = 'หลักฐานจำกัด — มีตัวอย่างมากขึ้น แต่ยังสรุปความได้เปรียบในการทำนายไม่ได้';
    }
    return {
      method: 'BASELINE_PLUS_SHRUNK_MARKOV1',
      probabilities,
      topOutcome: ranked[0],
      topProbability: probabilities[ranked[0]],
      runnerUp: ranked[1],
      marginToRunnerUp: probabilities[ranked[0]] - probabilities[ranked[1]],
      lastEvent,
      supportAfterLatest: row.total,
      globalEstimate,
      transitionEstimate,
      transitionWeight,
      baseline: { ...STANDARD_8_DECK_BASELINE },
      divergenceFromBaseline: totalVariation(probabilities, STANDARD_8_DECK_BASELINE),
      evidenceLevel,
      evidenceText,
      validationStatus: 'UNVALIDATED_EXPERIMENTAL',
      note: 'เป็นค่าประมาณเชิงทดลองจากอัตราตั้งต้นมาตรฐานและลำดับผลย้อนหลัง ไม่ใช่ความน่าจะเป็นที่สอบเทียบแล้ว และไม่พิสูจน์ความได้เปรียบ'
    };
  }

  function suffixEvidence(sequence, maxLength = 5) {
    if (sequence.length < 3) return null;
    const maxK = Math.min(maxLength, sequence.length - 1);
    for (let k = maxK; k >= 2; k--) {
      const pattern = sequence.slice(-k);
      const following = { P: 0, B: 0, T: 0 };
      const indexes = [];
      for (let i = 0; i + k < sequence.length; i++) {
        if (sequence.slice(i, i + k) === pattern) {
          following[sequence[i + k]]++;
          indexes.push(i);
        }
      }
      const support = indexes.length;
      if (support > 0) {
        const leader = SIDES.slice().sort((a, b) => following[b] - following[a])[0];
        return {
          pattern, length: k, support, following,
          dominantFollow: following[leader] > 0 ? leader : null,
          dominantShare: support ? following[leader] / support : null,
          sourceIndexes: indexes,
          reliability: support < 3 ? 'VERY_LOW' : support < 8 ? 'LOW' : 'DESCRIPTIVE_ONLY'
        };
      }
    }
    return null;
  }

  function topMotifs(sequence, limit = 8, minSupport = 2) {
    const found = new Map();
    const maxK = Math.min(5, sequence.length - 1);
    for (let k = 2; k <= maxK; k++) {
      for (let i = 0; i + k < sequence.length; i++) {
        const pattern = sequence.slice(i, i + k);
        if (!found.has(pattern)) found.set(pattern, { pattern, support: 0, following: { P: 0, B: 0, T: 0 } });
        const item = found.get(pattern);
        item.support++;
        item.following[sequence[i + k]]++;
      }
    }
    return Array.from(found.values())
      .filter(x => x.support >= minSupport)
      .map(x => {
        const top = SIDES.slice().sort((a, b) => x.following[b] - x.following[a])[0];
        return { ...x, dominantFollow: x.following[top] ? top : null, dominantShare: x.following[top] / x.support };
      })
      .sort((a, b) => b.support - a.support || b.pattern.length - a.pattern.length || a.pattern.localeCompare(b.pattern))
      .slice(0, limit);
  }

  function windowProfile(sequence, globalDistribution, size) {
    const window = sequence.slice(-Math.min(sequence.length, size));
    const info = countOutcomes(window);
    return {
      size: window.length,
      requestedSize: size,
      counts: info.counts,
      shares: info.shares,
      divergenceFromWhole: window.length ? totalVariation(info.shares, globalDistribution) : null
    };
  }

  function adjacentWindowShift(sequence, size = 24) {
    if (sequence.length < size * 2) {
      return { available: false, windowSize: size, reason: `ต้องมีอย่างน้อย ${size * 2} ผลเพื่อเปรียบเทียบสองหน้าต่าง` };
    }
    const previous = sequence.slice(-size * 2, -size);
    const recent = sequence.slice(-size);
    const previousDist = distribution(previous), recentDist = distribution(recent);
    const tv = totalVariation(previousDist, recentDist);
    let level = 'SMALL_DIFFERENCE';
    if (tv >= 0.35) level = 'LARGE_DIFFERENCE_CANDIDATE';
    else if (tv >= 0.20) level = 'VISIBLE_DIFFERENCE';
    return {
      available: true, windowSize: size,
      previous: { counts: countOutcomes(previous).counts, shares: previousDist },
      recent: { counts: countOutcomes(recent).counts, shares: recentDist },
      totalVariation: tv, level,
      caveat: 'ตัวชี้วัดเชิงพรรณนา ไม่ใช่การทดสอบนัยสำคัญและไม่ยืนยันว่ากลไกของเกมเปลี่ยน'
    };
  }

  function entropy(shares) {
    const positive = SIDES.map(s => shares[s]).filter(p => p > 0);
    const h = -positive.reduce((sum, p) => sum + p * Math.log2(p), 0);
    return { bits: h, normalized3Way: h / Math.log2(3) };
  }

  function analyze(input) {
    const sequence = parseSequence(input);
    const summary = countOutcomes(sequence);
    const dist = distribution(sequence);
    const sideSequence = sideProjection(sequence);
    const runs = runProfile(sideSequence);
    const transitions = transitionMatrix(sequence);
    const eventChanges = Math.max(0, sequence.length - 1);
    let eventChangeCount = 0;
    for (let i = 1; i < sequence.length; i++) if (sequence[i] !== sequence[i - 1]) eventChangeCount++;
    let sideSwitchCount = 0;
    for (let i = 1; i < sideSequence.length; i++) if (sideSequence[i] !== sideSequence[i - 1]) sideSwitchCount++;
    const windows = [12, 24, 48].filter(n => sequence.length > 0).map(size => windowProfile(sequence, dist, size));
    const latestEvent = sequence ? sequence[sequence.length - 1] : null;
    const latestSide = sideSequence ? sideSequence[sideSequence.length - 1] : null;
    const suffix = suffixEvidence(sequence);
    const diagnostics = [];
    if (!sequence.length) diagnostics.push({ level: 'INFO', code: 'NO_DATA', message: 'เพิ่มประวัติ P/B/T เพื่อเริ่มวิเคราะห์' });
    else {
      if (sequence.length < 20) diagnostics.push({ level: 'CAUTION', code: 'SMALL_SAMPLE', message: 'ข้อมูลยังน้อย รูปแบบระยะสั้นเปลี่ยนได้ง่าย' });
      if (sequence.length < 48) diagnostics.push({ level: 'INFO', code: 'LIMITED_CONTEXT', message: 'ยังมีประวัติไม่ครบ 48 ผล จึงประเมินภาพหลายช่วงได้จำกัด' });
      if (summary.counts.T > 0) diagnostics.push({ level: 'INFO', code: 'TIES_PRESERVED', message: `เก็บผลเสมอ ${summary.counts.T} ครั้งไว้ในลำดับจริง; ไม่นำ T ไปปะปนกับ P/B` });
      if (suffix && suffix.support < 3) diagnostics.push({ level: 'CAUTION', code: 'RARE_SUFFIX', message: `ลำดับท้าย ${suffix.pattern} มีตัวอย่างเดิมเพียง ${suffix.support} ครั้ง ใช้เป็นหลักฐานทำนายไม่ได้` });
    }
    const shift = adjacentWindowShift(sequence, 24);
    if (shift.available && shift.level !== 'SMALL_DIFFERENCE') diagnostics.push({ level: 'CAUTION', code: 'LOCAL_MIX_DIFFERENCE', message: `สัดส่วนผล 24 รายการล่าสุดต่างจาก 24 รายการก่อนหน้าในระดับ ${shift.level === 'LARGE_DIFFERENCE_CANDIDATE' ? 'มาก' : 'ที่มองเห็นได้'}; เป็นเพียงสัญญาณเชิงพรรณนา` });
    if (sequence.length && transitions[latestEvent].total < 8) diagnostics.push({ level: 'CAUTION', code: 'LOW_TRANSITION_SUPPORT', message: `ข้อมูลผลที่ตามหลัง ${latestEvent} มีเพียง ${transitions[latestEvent].total} ครั้ง` });
    return {
      version: VERSION,
      schema: 'nexus-sightline-analysis-v1',
      generatedAt: new Date().toISOString(),
      sequence,
      summary,
      distribution: dist,
      sideSequenceLength: sideSequence.length,
      latestEvent,
      latestSide,
      runs,
      eventChangeRate: eventChanges ? eventChangeCount / eventChanges : null,
      eventChangeCount,
      sideSwitchRate: sideSequence.length > 1 ? sideSwitchCount / (sideSequence.length - 1) : null,
      sideSwitchCount,
      entropy: entropy(dist),
      transitions,
      conditionalReference: conditionalReference(transitions, latestEvent),
      forecast: forecastNext(sequence, transitions),
      windows,
      adjacentWindowShift: shift,
      suffixEvidence: suffix,
      topMotifs: topMotifs(sequence),
      diagnostics,
      limits: {
        maxOutcomes: MAX_OUTCOMES,
        predictionsNotProvided: !sequence.length,
        forecastExperimental: Boolean(sequence.length),
        forecastValidationStatus: 'UNVALIDATED_EXPERIMENTAL',
        note: 'ค่าคาดการณ์เป็นค่าทดลอง ไม่ผ่านการทดสอบล่วงหน้า และไม่ใช่หลักฐานว่ามีความได้เปรียบในการทำนาย'
      }
    };
  }

  return { VERSION, MAX_OUTCOMES, SIDES, SIDE_NAMES, STANDARD_8_DECK_BASELINE, parseSequence, countOutcomes, distribution, totalVariation, sideProjection, runProfile, transitionMatrix, conditionalReference, forecastNext, suffixEvidence, topMotifs, windowProfile, adjacentWindowShift, entropy, analyze };
});
