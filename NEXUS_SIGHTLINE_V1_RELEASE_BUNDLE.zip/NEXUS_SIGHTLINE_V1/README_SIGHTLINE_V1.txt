NEXUS SIGHTLINE V1 — GAME READING CORE
======================================
Release: 1.0.0
Purpose: Lean, local-first P/B/T sequence analysis, focused on descriptive structure.

WHY THIS IS A NEW V1
--------------------
This is a separate, deliberately simplified product line rather than a rename of V10.3.
The previous bundle's legacy version engines, multiple validators/learning modules,
server-side forecast ledger, overlapping dashboards, API integrations and duplicated
release artifacts have been removed from this focused build. They are not required for
reading a sequence and would make the analysis harder to inspect and maintain.

CORE CAPABILITIES
-----------------
- Read up to 2,000 ordered outcomes: P (Player), B (Banker), T (Tie).
- Preserve T outcomes in the original sequence and in the full transition matrix.
- P/B side-run analysis treats a T as not changing the active side, while still retaining
  T in the original event timeline and counting it separately.
- Outcome counts and observed shares.
- P/B streak lengths and side switch rate.
- Full P/B/T transition counts and within-row historical shares.
- Repeated suffix/motif summaries with visible support counts.
- Compare trailing 12/24/48 windows with the whole sample.
- Compare two adjacent 24-outcome windows as a descriptive shift candidate only.
- Local browser storage, JSON import/export. No game history is sent to a server.
- No external packages, cloud services, AI API, or internet connection required after install.

WHAT IT DOES NOT CLAIM
----------------------
- It does not claim to predict every possible game pattern or guarantee the next result.
- P/B/T frequencies and transition shares describe supplied history, not calibrated future odds.
- A repeated suffix with a few examples is not reliable evidence of a predictive edge.
- Window differences are exploratory descriptions, not a significance test and not proof that
the underlying game process changed.
- The app does not tell you which side to bet on or calculate a betting advantage.

START ON WINDOWS
----------------
1. Install Python 3.10+ with the Windows Python launcher (py).
2. Extract this entire folder to a normal writable location.
3. Double-click start_sightline_v1.bat.
4. The browser opens at http://127.0.0.1:8765/.
5. Enter outcomes oldest-to-newest; use P/B/T. Press Ctrl+Enter to analyze quickly.
6. Use Export JSON to make a portable backup.

RUN TESTS
---------
Double-click run_sightline_tests.bat. Node.js 18+ is used for engine unit tests; Python 3.10+
is used for the package and local HTTP smoke tests. The app itself needs only Python/browser.

DATA / PRIVACY
--------------
- The server binds only to 127.0.0.1 and serves a fixed allowlist of app assets.
- It does not provide API endpoints for uploading game sequences.
- Sequence and session name are kept in this browser's localStorage and can remain on the
  machine after closing the browser. Clear the app data or browser storage to remove them.
- Exported JSON contains the sequence and session name; treat exports as user data.

FILES
-----
index.html             User interface
sightline_engine.js    Analysis core (also testable via Node.js)
app.js                 Browser interaction and local storage
server.py              Python standard-library local static server
start_sightline_v1.bat Windows launcher
run_sightline_tests.bat Test launcher
test_sightline_engine.js Engine unit tests
test_release.py        Release and HTTP smoke tests
CHANGELOG_SIGHTLINE_V1.txt Release scope and intentional removals
TEST_REPORT_SIGHTLINE_V1.txt Automated release test report
SHA256SUMS.txt         Integrity hashes of release payload files
