(function () {
  'use strict';
  const $ = id => document.getElementById(id);
  const STORE_KEY = 'nexus.sightline.v1.session';
  const nameInput = $('sessionName'), seqInput = $('sequence');
  let lastAnalysis = null;
  let toastTimer = null;
  const labels = { P: 'Player', B: 'Banker', T: 'Tie' };
  const cls = { P: 'p', B: 'b', T: 't' };
  const pct = x => x == null || !Number.isFinite(x) ? '—' : `${(x * 100).toFixed(1)}%`;
  const safe = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const escPct = x => x == null ? '—' : pct(x);

  function notify(message) {
    const el = $('toast'); el.textContent = message; el.classList.add('show');
    clearTimeout(toastTimer); toastTimer = setTimeout(() => el.classList.remove('show'), 2300);
  }
  function saveLocal() {
    try {
      localStorage.setItem(STORE_KEY, JSON.stringify({ version: '1.0.0', sessionName: nameInput.value, sequenceText: seqInput.value, savedAt: new Date().toISOString() }));
      $('saveStatus').textContent = 'บันทึกแล้วในเครื่อง';
    } catch (_) { $('saveStatus').textContent = 'เบราว์เซอร์ปิดการบันทึก'; }
  }
  function restoreLocal() {
    try {
      const data = JSON.parse(localStorage.getItem(STORE_KEY) || 'null');
      if (data && data.version === '1.0.0') {
        nameInput.value = typeof data.sessionName === 'string' ? data.sessionName : '';
        seqInput.value = typeof data.sequenceText === 'string' ? data.sequenceText : '';
        $('saveStatus').textContent = 'กู้คืนข้อมูลในเครื่องแล้ว';
      }
    } catch (_) { /* corrupted local state is ignored */ }
  }
  function sidePill(s) { return `<span class="pill ${cls[s]}">${s}</span>`; }
  function percentBar(side, count, total) {
    const share = total ? count / total : 0;
    return `<div class="baritem"><div class="barlabel"><span>${labels[side]} (${side})</span><span>${count} · ${pct(share)}</span></div><div class="track"><div class="fill ${cls[side]}" style="width:${(share*100).toFixed(2)}%"></div></div></div>`;
  }
  function renderMetrics(a) {
    const run = a.runs;
    const currentRun = run.currentSide ? `${run.currentSide} × ${run.currentLength}` : '—';
    const items = [
      ['ผลรวม', a.summary.n, 'รายการที่ป้อน'],
      ['ผลล่าสุด', a.latestEvent || '—', a.latestEvent ? labels[a.latestEvent] : 'ยังไม่มีผล'],
      ['P/B ต่อเนื่อง', currentRun, run.currentSide ? labels[run.currentSide] : 'ไม่มีข้อมูล'],
      ['การสลับฝั่ง', a.sideSwitchRate == null ? '—' : pct(a.sideSwitchRate), `${a.sideSwitchCount} ครั้งจาก ${Math.max(0,a.sideSequenceLength-1)} คู่`]
    ];
    $('metrics').innerHTML = items.map((x,i) => `<div class="metric"><div class="mlabel">${x[0]}</div><div class="value ${i===1 && a.latestEvent ? cls[a.latestEvent]+'text' : ''}">${x[1]}</div><div class="detail">${x[2]}</div></div>`).join('');
  }
  function renderMix(a) {
    const total = a.summary.n;
    $('mix').className = 'barlist';
    $('mix').innerHTML = ['P','B','T'].map(s => percentBar(s, a.summary.counts[s], total)).join('') + `<div class="subnote">ดัชนีการกระจายผล (entropy) ${a.entropy.bits.toFixed(3)} บิต จากสูงสุด ${Math.log2(3).toFixed(3)} บิต · ใช้อธิบายส่วนผสมย้อนหลังเท่านั้น</div>`;
  }
  function renderTempo(a) {
    const run = a.runs;
    const cside = run.currentSide ? `<span class="pill ${cls[run.currentSide]}">${run.currentSide} × ${run.currentLength}</span>` : '—';
    $('tempo').className = 'readouts';
    $('tempo').innerHTML = [
      ['ฝั่งล่าสุด (ไม่รวม T)', cside, `นับช่วง P/B โดยให้ผลเสมอไม่เปลี่ยนฝั่งล่าสุด; ผล T ยังคงอยู่ในชุดข้อมูลจริง`],
      ['ความยาว streak สูงสุด', `${run.maxLength || 0} ครั้ง`, `พบ ${run.runCount} ช่วงในลำดับฝั่ง P/B`],
      ['อัตราสลับฝั่ง P/B', pct(a.sideSwitchRate), `${a.sideSwitchCount} การเปลี่ยนฝั่งจาก ${Math.max(0,a.sideSequenceLength-1)} คู่ P/B`],
      ['อัตราเปลี่ยนผลติดกัน', pct(a.eventChangeRate), `${a.eventChangeCount} ครั้ง โดย T นับเป็นผลต่างในลำดับเหตุการณ์`]
    ].map((x,i) => `<div class="readout"><div class="r-icon">${i+1}</div><div><strong>${x[0]} · ${x[1]}</strong><p>${x[2]}</p></div></div>`).join('');
  }
  function renderWindows(a) {
    const rows = a.windows.map(w => `<tr><td>ล่าสุด ${w.requestedSize}</td><td>${w.size}</td><td>${w.counts.P} / ${w.counts.B} / ${w.counts.T}</td><td>${pct(w.shares.P)} / ${pct(w.shares.B)} / ${pct(w.shares.T)}</td><td>${w.divergenceFromWhole == null ? '—' : pct(w.divergenceFromWhole)}</td></tr>`).join('');
    const shift = a.adjacentWindowShift;
    const shiftHtml = shift.available ? `<div class="readout ${shift.level==='SMALL_DIFFERENCE'?'':'caution'}" style="margin-top:12px"><div class="r-icon">${shift.level==='SMALL_DIFFERENCE'?'i':'!'}</div><div><strong>เปรียบเทียบ 24 ผลล่าสุดกับ 24 ผลก่อนหน้า: ${pct(shift.totalVariation)} ความต่างรวม</strong><p>${shift.level==='LARGE_DIFFERENCE_CANDIDATE'?'พบความต่างเชิงสัดส่วนค่อนข้างมาก ควรระบุว่าเป็น candidate ไม่ใช่ข้อพิสูจน์ว่ากลไกเปลี่ยน':shift.level==='VISIBLE_DIFFERENCE'?'เห็นความต่างของส่วนผสมในสองช่วง แต่ยังไม่ยืนยันว่ามีการเปลี่ยนสถานะ':'ไม่เห็นความต่างของส่วนผสมขนาดใหญ่ตามเกณฑ์เชิงสำรวจนี้'} · ${shift.caveat}</p></div></div>` : `<div class="subnote">${shift.reason}</div>`;
    $('windows').className = '';
    $('windows').innerHTML = `<div class="tablewrap"><table><thead><tr><th>หน้าต่าง</th><th>ข้อมูล</th><th>จำนวน P/B/T</th><th>สัดส่วน P/B/T</th><th>ต่างจากทั้งหมด</th></tr></thead><tbody>${rows || '<tr><td colspan="5">รอข้อมูล</td></tr>'}</tbody></table></div>${shiftHtml}<div class="subnote">ค่า “ต่างจากทั้งหมด” คือ Total Variation Distance ของการกระจายผล (0–100%) ไม่ใช่ p-value ไม่ใช่โอกาสเกิดการเปลี่ยนเกม และหน้าต่างที่ซ้อนกันไม่เป็นอิสระจากกัน</div>`;
  }
  function renderTransitions(a) {
    const sides = ['P','B','T'];
    const body = sides.map(from => {
      const row = a.transitions[from];
      const cells = sides.map(to => `<td>${row.counts[to]}<div class="smallmuted">${escPct(row.shares[to])}</div></td>`).join('');
      return `<tr><td>${sidePill(from)} <span class="smallmuted">${labels[from]}</span></td>${cells}<td>${row.total}</td></tr>`;
    }).join('');
    $('transitions').className = 'tablewrap';
    $('transitions').innerHTML = `<table><thead><tr><th>ผลก่อนหน้า ↓</th><th>${sidePill('P')}</th><th>${sidePill('B')}</th><th>${sidePill('T')}</th><th>ตัวอย่าง</th></tr></thead><tbody>${body}</tbody></table>`;
    const c = a.conditionalReference;
    $('conditionalNote').textContent = c ? `ผลล่าสุด ${c.after}: ในประวัติ มีผลถัดไปหลัง ${c.after} ทั้งหมด ${c.support} ครั้ง. ค่านี้เป็นสถิติเชิงพรรณนา และไม่ใช่ความน่าจะเป็นที่ผ่านการสอบเทียบสำหรับผลถัดไป.` : 'ข้อมูลยังไม่พอคำนวณการเปลี่ยนผ่าน';
  }
  function renderMotifs(a) {
    const current = a.suffixEvidence;
    const items = [];
    if (current) items.push(`<div class="readout ${current.support<3?'caution':''}"><div class="r-icon">↳</div><div><strong>ลำดับท้าย ${safe(current.pattern)} เคยพบมาก่อน ${current.support} ครั้ง <span class="evidence-chip">${current.support<3?'หลักฐานน้อย':'ข้อมูลย้อนหลัง'}</span></strong><p>ผลที่ตามมาในตัวอย่างเดิม: P ${current.following.P} · B ${current.following.B} · T ${current.following.T}. ชุดนี้มีขนาด ${current.support} จึงยังไม่ใช่ข้อสรุปเกี่ยวกับผลถัดไป</p></div></div>`);
    if (a.topMotifs.length) {
      items.push(...a.topMotifs.slice(0,6).map(m => `<div class="motif"><div><div class="seq">${safe(m.pattern)}</div><div class="smallmuted">พบ ${m.support} ครั้ง</div></div><div class="meta">P ${m.following.P} · B ${m.following.B} · T ${m.following.T}<br>สัดส่วนผลที่นำสูงสุด ${pct(m.dominantShare)}</div></div>`));
    }
    $('motifs').className = items.length ? 'motifs' : 'empty';
    $('motifs').innerHTML = items.length ? items.join('') : 'ไม่พบลำดับซ้ำตามเกณฑ์ขั้นต่ำในข้อมูลนี้';
  }
  function renderReadouts(a) {
    const notes = [];
    notes.push({c:false,title:'ขนาดตัวอย่าง',text:`วิเคราะห์ ${a.summary.n} ผล: P ${a.summary.counts.P}, B ${a.summary.counts.B}, T ${a.summary.counts.T}. จำนวนนี้บอกขนาดข้อมูล ไม่ได้บอกว่ารูปแบบจะเกิดซ้ำในอนาคต`});
    if (a.latestEvent) notes.push({c:false,title:'บริบทปลายลำดับ',text:`ผลล่าสุดคือ ${a.latestEvent} (${labels[a.latestEvent]}) และฝั่ง P/B ล่าสุดคือ ${a.latestSide || '—'}. ตาราง transition ใช้ผลที่ติดกันจริง รวม T ไม่ลบทิ้ง`});
    const shift = a.adjacentWindowShift;
    if (shift.available && shift.level !== 'SMALL_DIFFERENCE') notes.push({c:true,title:'จุดสังเกตที่ควรระวัง',text:`องค์ประกอบผลในสองหน้าต่างล่าสุดต่างกัน ${pct(shift.totalVariation)}. ใช้เป็นคำถามเพื่อตรวจข้อมูล ไม่ใช่สัญญาณให้เลือกฝั่ง`});
    if (a.suffixEvidence) notes.push({c:a.suffixEvidence.support<3,title:'หลักฐานลำดับท้าย',text:`${a.suffixEvidence.pattern} มีตัวอย่างย้อนหลัง ${a.suffixEvidence.support} ครั้ง: หลังลำดับนี้พบ P ${a.suffixEvidence.following.P}, B ${a.suffixEvidence.following.B}, T ${a.suffixEvidence.following.T}. ยิ่งตัวอย่างน้อย ยิ่งสรุปไม่ได้`});
    notes.push({c:true,title:'สิ่งที่ระบบไม่อ้าง',text:'ผลวิเคราะห์นี้ไม่ได้พิสูจน์ว่าเกมมี pattern ที่ทำนายได้ ไม่คำนวณความได้เปรียบในการเดิมพัน และไม่ออกคำสั่งเดิมพัน ต้องใช้การทดสอบล่วงหน้ากับหลายเซสชันแยกอิสระหากต้องการประเมินพลังการทำนาย'});
    $('readouts').className = 'readouts';
    $('readouts').innerHTML = notes.map((n,i) => `<div class="readout ${n.c?'caution':''}"><div class="r-icon">${n.c?'!':'i'}</div><div><strong>${n.title}</strong><p>${n.text}</p></div></div>`).join('');
  }
  function render() {
    let a;
    try { a = window.SightlineEngine.analyze(seqInput.value); }
    catch (err) { notify(err.message || 'ตรวจสอบข้อมูลไม่สำเร็จ'); return; }
    lastAnalysis = a;
    saveLocal();
    $('sessionTitle').textContent = nameInput.value.trim() || 'เซสชันที่ไม่ได้ตั้งชื่อ';
    $('roundTag').textContent = `${a.summary.n} RESULTS`;
    if (!a.summary.n) {
      $('metrics').innerHTML = '<div class="empty" style="grid-column:1/-1"><strong>ยังไม่มีข้อมูล</strong>ใส่ประวัติผลเกม แล้วกด “วิเคราะห์โครงสร้าง”</div>';
      ['mix','tempo','windows','transitions','motifs','readouts'].forEach(id => { $(id).className = 'empty'; $(id).textContent = 'ยังไม่มีข้อมูล'; });
      $('conditionalNote').textContent = '';
      return;
    }
    renderMetrics(a); renderMix(a); renderTempo(a); renderWindows(a); renderTransitions(a); renderMotifs(a); renderReadouts(a);
  }
  function appendOutcome(side) {
    try { const seq = window.SightlineEngine.parseSequence(seqInput.value); seqInput.value = seq + side; saveLocal(); render(); seqInput.focus(); }
    catch (err) { notify(err.message); }
  }
  function exportData() {
    let seq;
    try { seq = window.SightlineEngine.parseSequence(seqInput.value); }
    catch (err) { notify(err.message); return; }
    const payload = { product: 'NEXUS SIGHTLINE', version: '1.0.0', sessionName: nameInput.value.trim(), sequence: seq, exportedAt: new Date().toISOString(), note: 'Outcomes are historical observations; not a forecast.' };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob); const a = document.createElement('a'); a.href = url; a.download = `sightline-v1-${new Date().toISOString().slice(0,10)}.json`; document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(url); notify('ส่งออก JSON แล้ว');
  }
  function importData(file) {
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const x = JSON.parse(String(reader.result));
        if (!x || typeof x !== 'object' || Array.isArray(x)) throw new Error('โครงสร้าง JSON ต้องเป็นออบเจ็กต์');
        const rawSequence = typeof x.sequence === 'string' ? x.sequence : (typeof x.sequenceText === 'string' ? x.sequenceText : null);
        if (rawSequence === null) throw new Error('ไม่พบฟิลด์ sequence ที่เป็นข้อความในไฟล์');
        const seq = window.SightlineEngine.parseSequence(rawSequence);
        seqInput.value = seq; nameInput.value = typeof x.sessionName === 'string' ? x.sessionName.slice(0,80) : '';
        render(); notify('นำเข้าข้อมูลแล้ว');
      } catch (err) { notify(`นำเข้าไม่สำเร็จ: ${err.message || 'ไฟล์ไม่ถูกต้อง'}`); }
      $('fileInput').value = '';
    };
    reader.onerror = () => notify('อ่านไฟล์ไม่สำเร็จ'); reader.readAsText(file);
  }
  document.querySelectorAll('[data-add]').forEach(btn => btn.addEventListener('click', () => appendOutcome(btn.dataset.add)));
  $('analyzeBtn').addEventListener('click', render);
  $('demoBtn').addEventListener('click', () => { nameInput.value = 'DEMO · ข้อมูลจำลอง'; seqInput.value = 'P B P P B T B B P B P B B B P T P B P P B P B T B B P B P B B P B P P B T P B B P B P B P B B P'; render(); notify('โหลดข้อมูลจำลองแล้ว — ไม่ใช่ผลจริง'); });
  $('clearBtn').addEventListener('click', () => { seqInput.value = ''; nameInput.value = ''; render(); saveLocal(); notify('ล้างข้อมูลในช่องแล้ว'); });
  $('exportBtn').addEventListener('click', exportData);
  $('importBtn').addEventListener('click', () => $('fileInput').click());
  $('fileInput').addEventListener('change', e => importData(e.target.files && e.target.files[0]));
  [seqInput,nameInput].forEach(el => el.addEventListener('input', () => { saveLocal(); }));
  seqInput.addEventListener('keydown', e => { if (e.ctrlKey && e.key === 'Enter') render(); });
  restoreLocal();
  if (seqInput.value.trim()) render(); else render();
})();
