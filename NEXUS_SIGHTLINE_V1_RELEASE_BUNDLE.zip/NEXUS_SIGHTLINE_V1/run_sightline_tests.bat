@echo off
setlocal
cd /d "%~dp0"
py -3 test_release.py
if errorlevel 1 (
  echo SIGHTLINE V1 tests FAILED.
  pause
  exit /b 1
)
echo SIGHTLINE V1 tests passed.
pause
endlocal
