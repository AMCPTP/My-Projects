"""Release verification: runs JS unit tests and local-only HTTP smoke tests."""
from __future__ import annotations
import json, os, re, socket, subprocess, sys, time, urllib.request, urllib.error
from pathlib import Path

ROOT = Path(__file__).resolve().parent

def choose_port():
    with socket.socket() as s:
        s.bind(('127.0.0.1', 0))
        return s.getsockname()[1]

def request(url, timeout=2):
    with urllib.request.urlopen(url, timeout=timeout) as r:
        return r.status, r.headers, r.read()

def main():
    checks = []
    def record(name, ok, detail=''):
        checks.append((name, bool(ok), detail))
        print(('PASS' if ok else 'FAIL') + ' ' + name + ((': ' + detail) if detail else ''))

    required = ['index.html','sightline_engine.js','app.js','server.py','README_SIGHTLINE_V1.txt','CHANGELOG_SIGHTLINE_V1.txt','test_sightline_engine.js']
    record('Required release files exist', all((ROOT / f).is_file() for f in required))
    html = (ROOT/'index.html').read_text(encoding='utf-8')
    record('UI refers only to the focused local engine/app', 'sightline_engine.js' in html and 'app.js' in html and 'NEXUS SIGHTLINE' in html)
    record('UI has no remote script/image/font dependencies', not any(x in html.lower() for x in ['https://','http://']) )
    app_source = (ROOT/'app.js').read_text(encoding='utf-8')
    html_ids = set(re.findall(r'\bid=["\']([^"\']+)', html))
    app_ids = set(re.findall(r"\$\(['\"]([^'\"]+)['\"]\)", app_source))
    record('All literal app element IDs exist in HTML', app_ids <= html_ids, f'{len(app_ids)} selectors checked')
    record('Browser app does not upload history through network APIs', not re.search(r'\bfetch\s*\(|XMLHttpRequest|WebSocket|https?://', app_source))

    node = 'node'
    try:
        version = subprocess.run([node, '--version'], capture_output=True, text=True, timeout=5, check=True).stdout.strip()
        syntax_results = [subprocess.run([node, '--check', str(ROOT/f)], capture_output=True, text=True, timeout=10) for f in ['app.js','sightline_engine.js']]
        record('Browser JS syntax checks', all(x.returncode == 0 for x in syntax_results), 'app.js + sightline_engine.js')
        proc = subprocess.run([node, str(ROOT/'test_sightline_engine.js')], capture_output=True, text=True, timeout=30)
        print(proc.stdout, end='')
        if proc.stderr: print(proc.stderr, file=sys.stderr, end='')
        record('Engine unit tests', proc.returncode == 0, version)
        if proc.returncode != 0:
            raise RuntimeError('Engine tests failed')
        tail = [x for x in proc.stdout.splitlines() if x.startswith('SIGHTLINE_ENGINE_TESTS=')]
        engine_count = int(tail[-1].split('=')[1]) if tail else 0
    except (FileNotFoundError, subprocess.SubprocessError) as e:
        engine_count = 0
        record('Engine unit tests', False, f'Node.js is required for test run: {e}')

    port = choose_port()
    env = os.environ.copy(); env['SIGHTLINE_PORT'] = str(port)
    proc = subprocess.Popen([sys.executable, str(ROOT/'server.py')], cwd=ROOT, env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    base = f'http://127.0.0.1:{port}'
    try:
        health = None
        for _ in range(35):
            if proc.poll() is not None: break
            try:
                health = request(base+'/health')[2]
                break
            except Exception:
                time.sleep(0.15)
        ok_health = health is not None and json.loads(health).get('localOnly') is True and json.loads(health).get('version') == '1.0.0'
        record('Local /health returns version and localOnly flag', ok_health)
        if health is not None:
            for route, expected in [('/',b'NEXUS SIGHTLINE'),('/sightline_engine.js',b'SightlineEngine'),('/app.js',b'localStorage')]:
                try:
                    status, headers, body = request(base+route)
                    record(f'HTTP route {route}', status == 200 and expected in body and 'no-store' in headers.get('Cache-Control',''))
                except Exception as e: record(f'HTTP route {route}', False, str(e))
        try:
            request(base+'/api/analyze')
            record('No legacy analysis API surface', False, 'unexpected endpoint response')
        except urllib.error.HTTPError as e:
            record('No legacy analysis API surface', e.code == 404, f'HTTP {e.code}')
        try:
            request(base+'/%2e%2e/server.py')
            record('Unknown/traversal-style route is not served', False)
        except urllib.error.HTTPError as e:
            record('Unknown/traversal-style route is not served', e.code == 404)
        except Exception as e:
            record('Unknown/traversal-style route is not served', False, str(e))
    finally:
        proc.terminate()
        try: proc.wait(timeout=3)
        except subprocess.TimeoutExpired: proc.kill()

    passed = sum(1 for _, ok, _ in checks if ok)
    total = len(checks)
    report = [
        'NEXUS SIGHTLINE V1.0.0 — RELEASE TEST REPORT',
        '================================================',
        f'Generated (UTC): {time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime())}',
        f'Result: {passed}/{total} release checks passed',
        f'Engine unit tests: {engine_count}',
        '', 'Detailed checks:'
    ]
    report += [f'[{"PASS" if ok else "FAIL"}] {name}' + (f' — {detail}' if detail else '') for name,ok,detail in checks]
    report += ['', 'Scope note:', '- Automated unit and local HTTP smoke tests only.', '- Full interactive click-through in Windows desktop browsers has not been executed by this test script.', '- No prospective independent-session experiment is included; analytical validity or prediction edge is not claimed.']
    (ROOT/'TEST_REPORT_SIGHTLINE_V1.txt').write_text('\n'.join(report)+'\n',encoding='utf-8')
    print(f'\nRELEASE_TESTS={passed}/{total}; ENGINE_TESTS={engine_count}')
    return 0 if passed == total else 1

if __name__ == '__main__':
    raise SystemExit(main())
