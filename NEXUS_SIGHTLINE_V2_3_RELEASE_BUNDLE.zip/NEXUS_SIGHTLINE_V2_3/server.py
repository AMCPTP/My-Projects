"""Local-only static server for NEXUS SIGHTLINE V2.3 (Python standard library only)."""
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit
import json
import os

ROOT = Path(__file__).resolve().parent
HOST = '127.0.0.1'
PORT = int(os.environ.get('SIGHTLINE_PORT', '8765'))
ALLOWED = {
    '/': ('index.html', 'text/html; charset=utf-8'),
    '/index.html': ('index.html', 'text/html; charset=utf-8'),
    '/sightline_engine.js': ('sightline_engine.js', 'text/javascript; charset=utf-8'),
    '/app.js': ('app.js', 'text/javascript; charset=utf-8'),
}

class Handler(BaseHTTPRequestHandler):
    server_version = 'SightlineLocal/2.3'
    def log_message(self, fmt, *args):
        # Do not log query strings or user history.
        print('[Sightline] ' + (fmt % args).split('?')[0])
    def do_GET(self):
        path = urlsplit(self.path).path
        if path == '/health':
            body = json.dumps({'ok': True, 'name': 'NEXUS SIGHTLINE', 'version': '2.3.0', 'localOnly': True}).encode()
            self.send_response(200); self.send_header('Content-Type', 'application/json; charset=utf-8'); self.send_header('Content-Length', str(len(body))); self.send_header('Cache-Control', 'no-store'); self.end_headers(); self.wfile.write(body); return
        spec = ALLOWED.get(path)
        if not spec:
            self.send_error(404, 'Not found'); return
        filename, content_type = spec
        target = (ROOT / filename).resolve()
        if target.parent != ROOT or not target.is_file():
            self.send_error(404, 'Not found'); return
        body = target.read_bytes()
        self.send_response(200)
        self.send_header('Content-Type', content_type)
        self.send_header('Content-Length', str(len(body)))
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('Referrer-Policy', 'no-referrer')
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        self.wfile.write(body)
    def do_POST(self):
        self.send_error(405, 'This local server is read-only; analysis happens in the browser')

if __name__ == '__main__':
    server = ThreadingHTTPServer((HOST, PORT), Handler)
    print(f'NEXUS SIGHTLINE V2.3 running locally at http://{HOST}:{PORT}/')
    print('This server serves the app only. Game history is not uploaded to it.')
    try:
        server.serve_forever(poll_interval=0.5)
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
