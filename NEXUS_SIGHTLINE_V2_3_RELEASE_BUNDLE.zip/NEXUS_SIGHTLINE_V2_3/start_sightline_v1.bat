@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 (
  echo Python launcher 'py' was not found. Install Python 3.10+ and enable the launcher.
  pause
  exit /b 1
)
start "NEXUS SIGHTLINE V2.3 server" /min cmd /c "py -3 server.py"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$u='http://127.0.0.1:8765/health'; $ok=$false; for($i=0;$i -lt 30;$i++){try{$r=Invoke-RestMethod $u -TimeoutSec 1; if($r.ok -and $r.name -eq 'NEXUS SIGHTLINE' -and $r.version -eq '2.3.0'){$ok=$true;break}}catch{}; Start-Sleep -Milliseconds 300}; if($ok){Start-Process 'http://127.0.0.1:8765/'}else{Write-Host 'Local server did not start. Port 8765 may already be in use.'; exit 1}"
if errorlevel 1 pause
endlocal
