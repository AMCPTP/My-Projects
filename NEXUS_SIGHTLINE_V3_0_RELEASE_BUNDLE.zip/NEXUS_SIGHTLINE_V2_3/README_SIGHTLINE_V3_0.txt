NEXUS SIGHTLINE V3.0 — EVIDENCE-FIRST BACCARAT ANALYSIS CORE
===========================================================
Release: 3.0.0
Runtime: Local browser + Python standard-library static server
Dependencies: No external JavaScript packages, fonts, images, or network APIs
Privacy: Outcome/card inputs stay in the current browser localStorage unless the user exports a JSON file.

V3.0 RELEASE SCOPE
------------------
V2.0 — Data Integrity & Evidence Core
- Preserves full P/B/T event chronology, including Tie outcomes.
- Keeps descriptive pattern evidence separate from the forecasting numbers.
- Adds explicit warnings for low sample support and local distribution shifts.
- Adds a local Shoe archive. Each Shoe is analyzed separately so no transition is counted across shoe boundaries. JSON backup includes the archive; archive storage is capped at 200 Shoe records.
- Export/import JSON remains backward-compatible with V1.0/V1.1 sequence files.

V2.1 — Multi-Model Forecast & Validation
- Forecast candidates: standard 8-deck reference baseline, smoothed historical frequency, first-order transition, last-2 context, last-3 context.
- Model performance is tracked prequentially: each historical prediction uses only outcomes observed before the target outcome.
- Reports multiclass Brier score, log loss, and top-ranked outcome hit rate for each candidate and the adaptive ensemble.
- Model weights are based on recent rolling Brier scores; relative skill weights are clamped and the adaptive contribution is anchored to the fixed reference baseline.
- Adaptive contribution is capped at 45% of the final estimate. If no walk-forward predictions exist, the forecast remains the reference baseline.

V2.2 — Adaptive Analysis & Shift Detection
- Compares recent 24 and 48 result windows against their adjacent preceding windows, when enough data exists.
- Reports Total Variation and Jensen–Shannon divergence as descriptive shift indicators.
- A shift candidate is an alert to inspect the data, not proof the game's generating process has changed and not an automatic prediction boost.
- Model losses use a rolling window of up to 120 previous walk-forward forecasts for weight updates.

V3.0 — Card-Aware Monte Carlo (Beta)
- Adds a separate card-aware simulator for standard 8-deck Punto Banco.
- Accepts known removed card ranks A, 2–9, T/10, J, Q, K. Each of the 13 ranks appears 32 times in an untouched 8-deck shoe.
- Accepts a count of additional unseen cards removed from the shoe. These unknown ranks are sampled without replacement for each simulation, so uncertainty about them is integrated approximately.
- Simulates standard natural, Player third-card, and Banker third-card rules.
- Uses deterministic-seed Monte Carlo for reproducible results at the same inputs, with 2,000–50,000 trials and Wilson intervals for simulation uncertainty. A workload guard caps hidden-card removal simulation at 2,000,000 draws per run to avoid freezing the browser.
- The card-aware output is distinct from P/B/T-only analysis and is NOT run automatically from outcome history.

FORECAST INTERPRETATION
-----------------------
The outcome-only estimate is a baseline-anchored exploratory ensemble, not a betting instruction. Walk-forward is a retrospective backtest: although no target outcome leaks into its own forecast, the model design and hyperparameters have already been selected by the developer. It is not a pre-registered prospective experiment on independent Shoes. Better retrospective scores do not prove a predictive edge.

The usual standard 8-deck Punto Banco reference values embedded in the app are:
- Player (P): 44.6247%
- Banker (B): 45.8597%
- Tie (T): 9.5156%
These are general reference probabilities, not shoe-specific outcomes and not necessarily correct for variant rules or a non-standard number of decks.

CARD-AWARE INPUT RULES — READ BEFORE USING
------------------------------------------
1. Supply every card whose rank is known and that has already been removed from the current shoe, including all exposed cards dealt in prior rounds and the exposed burn card, if known. Do not enter the same physical card twice.
2. Enter only the number of additional removed cards whose ranks are unknown in the next field. The engine models those ranks as random unseen cards. It does not infer them from outcome labels.
3. The simulator assumes a standard 8-deck shoe and standard Punto Banco drawing rules. Non-standard rules, wrong card entries, missed cards, or incorrect removed-card counts can invalidate the estimate.
4. The reported Wilson bands capture Monte Carlo sampling noise only; they do not include uncertainty from input errors or model assumptions.
5. This is a research/analysis tool. Neither mode guarantees accurate prediction or positive expected value for a wager.

RUN ON WINDOWS
--------------
1. Extract the folder to a writable location.
2. Install Python 3.10+ with the Windows launcher `py`.
3. Double-click `start_sightline_v3_0.bat` (or the compatibility launcher `start_sightline_v1.bat`).
4. Browser opens at http://127.0.0.1:8765/.
5. Enter P/B/T outcomes oldest-to-newest and press “วิเคราะห์โครงสร้าง” (Ctrl+Enter also works).
6. For Card-Aware, enter known removed ranks correctly, set unknown removed count and simulations, then click “จำลองไพ่ถัดไป”.
7. Use “เก็บ Shoe แล้วเริ่มใหม่” to archive one shoe before entering the next, preventing cross-shoe transitions.
8. Use Export JSON to back up the current session, archive, and Card-Aware settings.

RUN TESTS
---------
Double-click `run_sightline_tests.bat`. The automated suite uses Node.js 18+ and Python 3.10+. It checks engine behavior, local HTTP routes, version metadata, no upload endpoints, and the Card-Aware simulator. The script does not perform a full manual browser click-through.

LOCAL DATA / PRIVACY
--------------------
- Server binds only to 127.0.0.1 and serves a fixed allowlist of static app assets.
- No network API receives outcome history or card inputs.
- Session name, current sequence, Card-Aware parameters, and up to 200 archived Shoe sequences are saved in this browser's localStorage.
- JSON exports contain the sequence and any Card-Aware input; treat them as user data.
- Clear browser site data to remove saved local state.

ENGINEERING CAVEATS
-------------------
- P/B/T history does not reveal remaining cards in a shoe.
- The simulator conditions on correctly entered cards and the entered number of additional unknown removed cards; it does not track casino-specific cut-card procedure or non-standard rules.
- Sequence data should contain one Shoe/session only. Do not concatenate separate shoes, because transitions across the boundary are not valid same-shoe transitions.
- Pattern counts, shift indicators, and model weights must not be interpreted as proof of a stable exploitable pattern.


V3.0 CROSS-SHOE VALIDATION
1. Archive multiple completed Shoes using “เก็บ Shoe แล้วเริ่มใหม่”.
2. Click “ทดสอบคลังหลาย Shoe” in the Cross-Shoe Audit section.
3. Each Shoe is held out from pooled cross-Shoe training while being evaluated. Shoe sequences are never concatenated across boundaries.
4. Interpret all results as retrospective research. A candidate signal is not a verified edge; prospective, pre-registered evaluation on new Shoes is required.
5. For an initial screening, aim for at least 10 Shoes and 500 predictions; substantially more independent Shoes may be needed for reliable inference.
