(function () {
  'use strict';
  const $ = id => document.getElementById(id);
  const STORE_KEY = 'nexus.sightline.v1.session';
  const ARCHIVE_STORE_KEY = 'nexus.sightline.v2.shoe-archive';
  const APP_VERSION = '3.0.0';
  const nameInput = $('sessionName'), seqInput = $('sequence');
  const knownCardsInput = $('knownCards'), unknownRemovedInput = $('unknownRemoved'), simulationsInput = $('simulations');
  let lastCardAnalysis = null;
  let lastAnalysis = null;
  let toastTimer = null;
  const labels = { P: 'Player', B: 'Banker', T: 'Tie' };
  const cls = { P: 'p', B: 'b', T: 't' };
  const pct = x => x == null || !Number.isFinite(x) ? '—' : `${(x * 100).toFixed(1)}%`;
  const safe = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const escPct = x => x == null ? '—' : pct(x);

  function notify(message) {
    const el = $('toast'); el.textContent = message; el.classList.add('show');
    clearTimeout(toastTimer); toastTimer = setTimeout(() => el.classList.remove('show'), 2300);
  }
  function getArchives() {
    try {
      const raw = JSON.parse(localStorage.getItem(ARCHIVE_STORE_KEY) || '[]');
      if (!Array.isArray(raw)) return [];
      return raw.filter(x => x && typeof x.id === 'string' && typeof x.sequence === 'string')
        .map(x => ({ id: x.id.slice(0,100), name: typeof x.name === 'string' ? x.name.slice(0,80) : 'Shoe', sequence: window.SightlineEngine.parseSequence(x.sequence), savedAt: typeof x.savedAt === 'string' ? x.savedAt : '' }));
    } catch (_) { return []; }
  }
  function populateArchiveSelect() {
    const select = $('shoeArchive');
    if (!select) return;
    const previous = select.value;
    const archive = getArchives();
    select.innerHTML = '<option value="">— เลือก Shoe จากคลัง —</option>' + archive.map(x => {
      const stamp = x.savedAt ? x.savedAt.slice(0,16).replace('T',' ') : 'ไม่ทราบวันที่';
      return `<option value="${safe(x.id)}">${safe(x.name)} · ${x.sequence.length} ผล · ${safe(stamp)}</option>`;
    }).join('');
    if (archive.some(x => x.id === previous)) select.value = previous;
  }
  function saveArchives(archive) {
    localStorage.setItem(ARCHIVE_STORE_KEY, JSON.stringify(archive));
    populateArchiveSelect();
  }
  function archiveCurrentShoe() {
    try {
      const sequence = window.SightlineEngine.parseSequence(seqInput.value);
      if (!sequence.length) throw new Error('ยังไม่มีผล P/B/T ให้เก็บเข้าคลัง');
      const archive = getArchives();
      if (archive.length >= 200) throw new Error('คลังเต็ม 200 Shoe แล้ว โปรดส่งออกหรือลบรายการเก่าก่อน');
      const now = new Date();
      const name = nameInput.value.trim() || `Shoe · ${now.toLocaleString()}`;
      const id = `shoe-${now.getTime()}-${sequence.length}-${archive.length}`;
      archive.unshift({ id, name: name.slice(0,80), sequence, savedAt: now.toISOString() });
      saveArchives(archive);
      seqInput.value = '';
      nameInput.value = '';
      lastAnalysis = null;
      render();
      saveLocal();
      $('shoeArchive').value = id;
      notify(`เก็บ ${name} แล้ว · เริ่ม Shoe ใหม่ได้`);
    } catch (err) { notify(err.message || 'เก็บ Shoe ไม่สำเร็จ'); }
  }
  function loadSelectedShoe() {
    const id = $('shoeArchive').value;
    if (!id) { notify('เลือก Shoe จากคลังก่อน'); return; }
    const item = getArchives().find(x => x.id === id);
    if (!item) { notify('ไม่พบ Shoe ที่เลือกในคลัง'); populateArchiveSelect(); return; }
    if (seqInput.value.trim() && window.confirm && !window.confirm('แทนที่ข้อมูล Shoe ปัจจุบันด้วย Shoe ที่เลือกหรือไม่? ข้อมูลปัจจุบันถูกบันทึกใน draft ภายในเครื่องแล้ว แต่หากต้องการเก็บเป็นรายการแยก ให้กด “เก็บ Shoe แล้วเริ่มใหม่” ก่อน')) return;
    seqInput.value = item.sequence;
    nameInput.value = item.name;
    render();
    notify(`โหลด ${item.name} แล้ว · วิเคราะห์เฉพาะ Shoe นี้`);
  }
  function deleteSelectedShoe() {
    const id = $('shoeArchive').value;
    if (!id) { notify('เลือก Shoe จากคลังก่อน'); return; }
    const archive = getArchives(), item = archive.find(x => x.id === id);
    if (!item) { notify('ไม่พบ Shoe ที่เลือกในคลัง'); populateArchiveSelect(); return; }
    if (window.confirm && !window.confirm(`ลบ ${item.name} ออกจากคลังในเบราว์เซอร์นี้หรือไม่?`)) return;
    saveArchives(archive.filter(x => x.id !== id));
    notify(`ลบ ${item.name} ออกจากคลังแล้ว`);
  }

  function saveLocal() {
    try {
      localStorage.setItem(STORE_KEY, JSON.stringify({ version: APP_VERSION, sessionName: nameInput.value, sequenceText: seqInput.value, knownCardsText: knownCardsInput.value, unknownRemoved: unknownRemovedInput.value, simulations: simulationsInput.value, savedAt: new Date().toISOString() }));
      $('saveStatus').textContent = 'บันทึกแล้วในเครื่อง';
    } catch (_) { $('saveStatus').textContent = 'เบราว์เซอร์ปิดการบันทึก'; }
  }
  function restoreLocal() {
    try {
      const data = JSON.parse(localStorage.getItem(STORE_KEY) || 'null');
      if (data && ['1.0.0','1.1.0','3.0.0'].includes(data.version)) {
        nameInput.value = typeof data.sessionName === 'string' ? data.sessionName : '';
        seqInput.value = typeof data.sequenceText === 'string' ? data.sequenceText : '';
        knownCardsInput.value = typeof data.knownCardsText === 'string' ? data.knownCardsText : '';
        unknownRemovedInput.value = data.unknownRemoved == null ? '0' : String(data.unknownRemoved);
        simulationsInput.value = ['5000','20000','50000'].includes(String(data.simulations)) ? String(data.simulations) : '20000';
        $('saveStatus').textContent = 'กู้คืนข้อมูลในเครื่องแล้ว';
      }
      populateArchiveSelect();
    } catch (_) { /* corrupted local state is ignored */ }
  }
  function sidePill(s) { return `<span class="pill ${cls[s]}">${s}</span>`; }
  function percentBar(side, count, total) {
    const share = total ? count / total : 0;
    return `<div class="baritem"><div class="barlabel"><span>${labels[side]} (${side})</span><span>${count} · ${pct(share)}</span></div><div class="track"><div class="fill ${cls[side]}" style="width:${(share*100).toFixed(2)}%"></div></div></div>`;
  }
  function renderMetrics(a) {
    const run = a.runs;
    const currentRun = run.currentSide ? `${run.currentSide} × ${run.currentLength}` : '—';
    const items = [
      ['ผลรวม', a.summary.n, 'รายการที่ป้อน'],
      ['ผลล่าสุด', a.latestEvent || '—', a.latestEvent ? labels[a.latestEvent] : 'ยังไม่มีผล'],
      ['P/B ต่อเนื่อง', currentRun, run.currentSide ? labels[run.currentSide] : 'ไม่มีข้อมูล'],
      ['การสลับฝั่ง', a.sideSwitchRate == null ? '—' : pct(a.sideSwitchRate), `${a.sideSwitchCount} ครั้งจาก ${Math.max(0,a.sideSequenceLength-1)} คู่`]
    ];
    $('metrics').innerHTML = items.map((x,i) => `<div class="metric"><div class="mlabel">${x[0]}</div><div class="value ${i===1 && a.latestEvent ? cls[a.latestEvent]+'text' : ''}">${x[1]}</div><div class="detail">${x[2]}</div></div>`).join('');
  }
  function renderMix(a) {
    const total = a.summary.n;
    $('mix').className = 'barlist';
    $('mix').innerHTML = ['P','B','T'].map(s => percentBar(s, a.summary.counts[s], total)).join('') + `<div class="subnote">ดัชนีการกระจายผล (entropy) ${a.entropy.bits.toFixed(3)} บิต จากสูงสุด ${Math.log2(3).toFixed(3)} บิต · ใช้อธิบายส่วนผสมย้อนหลังเท่านั้น</div>`;
  }
  function renderTempo(a) {
    const run = a.runs;
    const cside = run.currentSide ? `<span class="pill ${cls[run.currentSide]}">${run.currentSide} × ${run.currentLength}</span>` : '—';
    $('tempo').className = 'readouts';
    $('tempo').innerHTML = [
      ['ฝั่งล่าสุด (ไม่รวม T)', cside, `นับช่วง P/B โดยให้ผลเสมอไม่เปลี่ยนฝั่งล่าสุด; ผล T ยังคงอยู่ในชุดข้อมูลจริง`],
      ['ความยาว streak สูงสุด', `${run.maxLength || 0} ครั้ง`, `พบ ${run.runCount} ช่วงในลำดับฝั่ง P/B`],
      ['อัตราสลับฝั่ง P/B', pct(a.sideSwitchRate), `${a.sideSwitchCount} การเปลี่ยนฝั่งจาก ${Math.max(0,a.sideSequenceLength-1)} คู่ P/B`],
      ['อัตราเปลี่ยนผลติดกัน', pct(a.eventChangeRate), `${a.eventChangeCount} ครั้ง โดย T นับเป็นผลต่างในลำดับเหตุการณ์`]
    ].map((x,i) => `<div class="readout"><div class="r-icon">${i+1}</div><div><strong>${x[0]} · ${x[1]}</strong><p>${x[2]}</p></div></div>`).join('');
  }
  function renderWindows(a) {
    const rows = a.windows.map(w => `<tr><td>ล่าสุด ${w.requestedSize}</td><td>${w.size}</td><td>${w.counts.P} / ${w.counts.B} / ${w.counts.T}</td><td>${pct(w.shares.P)} / ${pct(w.shares.B)} / ${pct(w.shares.T)}</td><td>${w.divergenceFromWhole == null ? '—' : pct(w.divergenceFromWhole)}</td></tr>`).join('');
    const shift = a.adjacentWindowShift;
    const shiftHtml = shift.available ? `<div class="readout ${shift.level==='SMALL_DIFFERENCE'?'':'caution'}" style="margin-top:12px"><div class="r-icon">${shift.level==='SMALL_DIFFERENCE'?'i':'!'}</div><div><strong>เปรียบเทียบ 24 ผลล่าสุดกับ 24 ผลก่อนหน้า: ${pct(shift.totalVariation)} ความต่างรวม</strong><p>${shift.level==='LARGE_DIFFERENCE_CANDIDATE'?'พบความต่างเชิงสัดส่วนค่อนข้างมาก ควรระบุว่าเป็น candidate ไม่ใช่ข้อพิสูจน์ว่ากลไกเปลี่ยน':shift.level==='VISIBLE_DIFFERENCE'?'เห็นความต่างของส่วนผสมในสองช่วง แต่ยังไม่ยืนยันว่ามีการเปลี่ยนสถานะ':'ไม่เห็นความต่างของส่วนผสมขนาดใหญ่ตามเกณฑ์เชิงสำรวจนี้'} · ${shift.caveat}</p></div></div>` : `<div class="subnote">${shift.reason}</div>`;
    $('windows').className = '';
    $('windows').innerHTML = `<div class="tablewrap"><table><thead><tr><th>หน้าต่าง</th><th>ข้อมูล</th><th>จำนวน P/B/T</th><th>สัดส่วน P/B/T</th><th>ต่างจากทั้งหมด</th></tr></thead><tbody>${rows || '<tr><td colspan="5">รอข้อมูล</td></tr>'}</tbody></table></div>${shiftHtml}<div class="subnote">ค่า “ต่างจากทั้งหมด” คือ Total Variation Distance ของการกระจายผล (0–100%) ไม่ใช่ p-value ไม่ใช่โอกาสเกิดการเปลี่ยนเกม และหน้าต่างที่ซ้อนกันไม่เป็นอิสระจากกัน</div>`;
  }
  function renderTransitions(a) {
    const sides = ['P','B','T'];
    const body = sides.map(from => {
      const row = a.transitions[from];
      const cells = sides.map(to => `<td>${row.counts[to]}<div class="smallmuted">${escPct(row.shares[to])}</div></td>`).join('');
      return `<tr><td>${sidePill(from)} <span class="smallmuted">${labels[from]}</span></td>${cells}<td>${row.total}</td></tr>`;
    }).join('');
    $('transitions').className = 'tablewrap';
    $('transitions').innerHTML = `<table><thead><tr><th>ผลก่อนหน้า ↓</th><th>${sidePill('P')}</th><th>${sidePill('B')}</th><th>${sidePill('T')}</th><th>ตัวอย่าง</th></tr></thead><tbody>${body}</tbody></table>`;
    const c = a.conditionalReference;
    $('conditionalNote').textContent = c ? `ผลล่าสุด ${c.after}: ในประวัติ มีผลถัดไปหลัง ${c.after} ทั้งหมด ${c.support} ครั้ง. ค่านี้เป็นสถิติเชิงพรรณนา และไม่ใช่ความน่าจะเป็นที่ผ่านการสอบเทียบสำหรับผลถัดไป.` : 'ข้อมูลยังไม่พอคำนวณการเปลี่ยนผ่าน';
  }
  function renderMotifs(a) {
    const current = a.suffixEvidence;
    const items = [];
    if (current) items.push(`<div class="readout ${current.support<3?'caution':''}"><div class="r-icon">↳</div><div><strong>ลำดับท้าย ${safe(current.pattern)} เคยพบมาก่อน ${current.support} ครั้ง <span class="evidence-chip">${current.support<3?'หลักฐานน้อย':'ข้อมูลย้อนหลัง'}</span></strong><p>ผลที่ตามมาในตัวอย่างเดิม: P ${current.following.P} · B ${current.following.B} · T ${current.following.T}. ชุดนี้มีขนาด ${current.support} จึงยังไม่ใช่ข้อสรุปเกี่ยวกับผลถัดไป</p></div></div>`);
    if (a.topMotifs.length) {
      items.push(...a.topMotifs.slice(0,6).map(m => `<div class="motif"><div><div class="seq">${safe(m.pattern)}</div><div class="smallmuted">พบ ${m.support} ครั้ง</div></div><div class="meta">P ${m.following.P} · B ${m.following.B} · T ${m.following.T}<br>สัดส่วนผลที่นำสูงสุด ${pct(m.dominantShare)}</div></div>`));
    }
    $('motifs').className = items.length ? 'motifs' : 'empty';
    $('motifs').innerHTML = items.length ? items.join('') : 'ไม่พบลำดับซ้ำตามเกณฑ์ขั้นต่ำในข้อมูลนี้';
  }
  function renderForecast(a) {
    const f = a.forecast;
    if (!f) {
      $('forecast').className = 'empty';
      $('forecast').innerHTML = 'ยังไม่มีประวัติ จึงยังคำนวณค่าประมาณไม่ได้';
      return;
    }
    const sideName = labels[f.topOutcome];
    const bars = ['P','B','T'].map(side => `<div class="forecast-item"><div class="f-label"><span>${labels[side]} (${side})</span><span>${pct(f.probabilities[side])}</span></div><div class="f-value ${cls[side]}text">${pct(f.probabilities[side])}</div><div class="track"><div class="fill ${cls[side]}" style="width:${Math.max(0,Math.min(100,f.probabilities[side]*100)).toFixed(2)}%"></div></div><div class="smallmuted" style="margin-top:6px">ฐานอ้างอิง ${pct(f.baseline[side])}</div></div>`).join('');
    const suffix = a.suffixEvidence;
    let context = 'ไม่พบลำดับท้ายซ้ำที่มีตัวอย่างเพียงพอ';
    if (suffix) context = `ลำดับท้าย ${safe(suffix.pattern)} พบก่อนหน้า ${suffix.support} ครั้ง; ผลตามหลังในอดีต P ${suffix.following.P} / B ${suffix.following.B} / T ${suffix.following.T}. ใช้เป็นบริบทเท่านั้น ไม่ถูกใช้ดันค่าคาดการณ์โดยตรง`;
    const shift = a.adjacentWindowShift;
    if (shift.available && shift.level !== 'SMALL_DIFFERENCE') context += ` ความต่างระหว่างหน้าต่าง 24 ผลอยู่ที่ ${pct(shift.totalVariation)} จึงควรระวังการสรุปจากค่าเฉลี่ยรวม`;
    const weightRows = Object.entries(f.modelWeights).map(([name, weight]) => `<div class="weightrow"><span class="wname">${safe(window.SightlineEngine.MODEL_LABELS[name] || name)}</span><div class="track"><div class="fill" style="width:${Math.max(0,Math.min(100,weight*100)).toFixed(2)}%;background:#66dfd0"></div></div><strong>${pct(weight)}</strong></div>`).join('');
    $('forecast').className = 'forecast-wrap';
    $('forecast').innerHTML = `<div class="forecast-head"><div class="forecast-big ${cls[f.topOutcome]}">${f.topOutcome}</div><div><h4>อันดับสูงสุดของ Adaptive Ensemble: ${sideName} (${f.topOutcome}) · ${pct(f.topProbability)}</h4><p>อันดับสอง ${f.runnerUp} ที่ ${pct(f.probabilities[f.runnerUp])} · ส่วนต่าง ${pct(f.marginToRunnerUp)}</p><p style="margin-top:7px"><strong>${safe(f.evidenceText)}</strong></p></div></div><div class="forecast-grid">${bars}</div><div class="readout"><div class="r-icon">AI</div><div><strong>โมเดลไหนมีอิทธิพลในค่าประมาณนี้</strong><p>สัดส่วนปรับออกจากค่าฐานสูงสุดที่ใช้อยู่: ${pct(f.adaptiveShare)} · ผลทดสอบ walk-forward ที่สะสมได้: ${f.validatedPredictionCount} ตา · น้ำหนักของโมเดลเป็นการปรับเชิงทดลอง ไม่ใช่ระดับความมั่นใจ</p><div class="modelgrid" style="margin-top:10px">${weightRows}</div></div></div><div class="forecast-note"><strong>สถานะ: ยังไม่ยืนยันความได้เปรียบในการคาดการณ์</strong><br>ค่าตัวเลขคือการประมาณจากค่าฐานและโมเดลย้อนหลัง ไม่ใช่ความแน่นอนของผลถัดไปและไม่ใช่คำแนะนำเดิมพัน</div><div class="forecast-detail"><div><strong>หลักฐาน transition ล่าสุด:</strong> มี ${f.supportAfterLatest} คู่ประวัติที่เริ่มจากผล ${f.lastEvent}; น้ำหนักเฉพาะโมเดล Markov1 ${pct(f.transitionWeight)}</div><div><strong>ความต่างจากค่าฐาน:</strong> ${pct(f.divergenceFromBaseline)} Total Variation ซึ่งไม่ใช่ผลทดสอบนัยสำคัญ</div><div><strong>ตรวจบริบท:</strong> ${context}</div><div><strong>เหตุผลที่ไม่มั่นใจเกินจริง:</strong> adaptive share ถูกจำกัดไว้ไม่เกิน 45% และเริ่มจากค่าฐานเมื่อไม่มีผล walk-forward ที่สะสมไว้</div><div><strong>ข้อจำกัด:</strong> P/B/T ไม่เปิดเผยองค์ประกอบไพ่ที่เหลือ และผลย้อนหลังใน Shoe เดียวไม่ใช่การยืนยันกับหลาย Shoe อิสระ</div></div>`;
  }

  function renderValidation(a) {
    const v = a.validation;
    if (!v || !v.available) {
      $('validation').className = 'empty';
      $('validation').innerHTML = `ข้อมูลยังไม่พอทำ walk-forward: ต้องมีอย่างน้อย ${v ? v.minTrainingOutcomes + 1 : 41} ผล เพื่อเริ่มทดสอบผลถัดไปจากข้อมูลก่อนหน้า`;
      return;
    }
    const format = x => x == null ? '—' : Number(x).toFixed(4);
    const modelOrder = ['baseline','frequency','markov1','markov2','markov3','ensemble'];
    const rows = modelOrder.map(name => {
      const m = v.metrics[name];
      return `<tr><td>${safe(m.label)}</td><td>${m.count}</td><td>${format(m.brier)}</td><td>${format(m.logLoss)}</td><td>${pct(m.topAccuracy)}</td></tr>`;
    }).join('');
    const baseline = v.metrics.baseline, ensemble = v.metrics.ensemble;
    const compare = ensemble.brier < baseline.brier ? 'ชุดย้อนหลังนี้มี Brier score ต่ำกว่าค่าฐาน แต่ยังไม่ยืนยันผลใน Shoe อิสระ' : ensemble.brier > baseline.brier ? 'ชุดย้อนหลังนี้ Adaptive Ensemble ยังไม่ชนะค่าฐานตาม Brier score' : 'Brier score เท่ากับค่าฐานในชุดย้อนหลังนี้';
    const weights = Object.entries(v.learnedWeights).map(([name, weight]) => `<div class="weightrow"><span class="wname">${safe(window.SightlineEngine.MODEL_LABELS[name] || name)}</span><div class="track"><div class="fill" style="width:${Math.max(0,Math.min(100,weight*100)).toFixed(2)}%;background:#8bb8ff"></div></div><strong>${pct(weight)}</strong></div>`).join('');
    const populatedCalibration = ['P','B','T'].map(side => {
      const bins = v.calibration[side].filter(b => b.count > 0);
      if (!bins.length) return '';
      return `<div class="readout"><div class="r-icon">${side}</div><div><strong>Calibration แบบ top-outcome · ${labels[side]}</strong><p>${bins.map(b => `${pct(b.lower)}–${pct(b.upper)}: n=${b.count}, confidence เฉลี่ย ${pct(b.meanConfidence)}, hit rate จริง ${pct(b.observedAccuracy)}`).join(' · ')}</p></div></div>`;
    }).filter(Boolean).join('');
    $('validation').className = 'modelgrid';
    $('validation').innerHTML = `<div class="results-meta"><span class="results-chip">ทดสอบ ${v.predictions} ตา</span><span class="results-chip">train ขั้นต่ำ ${v.minTrainingOutcomes} ผล</span><span class="results-chip">หน้าต่าง score ล่าสุด ${v.rollingWindow} predictions</span><span class="results-chip">สถานะ ${safe(v.validationStatus)}</span></div><div class="tablewrap"><table><thead><tr><th>โมเดล</th><th>ทดสอบ</th><th>Brier ↓</th><th>Log loss ↓</th><th>ทายอันดับ 1 ถูก</th></tr></thead><tbody>${rows}</tbody></table></div><div class="readout ${ensemble.brier <= baseline.brier ? '' : 'caution'}"><div class="r-icon">!</div><div><strong>${safe(compare)}</strong><p>เปรียบเทียบด้วย Brier score แบบ multiclass (ผลรวมความคลาดเคลื่อนกำลังสอง) และ Log loss; อัตราทายอันดับ 1 ถูกเป็นเพียงข้อมูลเสริม ไม่ใช่ metric หลัก</p></div></div><div><strong>น้ำหนักที่เรียนรู้จากผลที่เกิดขึ้นก่อนหน้า</strong><p class="smallmuted">สัดส่วนปรับจากค่าฐานสำหรับการคาดการณ์ถัดไป: ${pct(v.adaptiveShare)} · ค่าฐานยังเป็นแกนหลัก</p><div class="modelgrid" style="margin-top:9px">${weights}</div></div>${populatedCalibration ? `<div><strong>ตรวจสอบ calibration แบบหยาบ</strong><div class="modelgrid" style="margin-top:9px">${populatedCalibration}</div></div>` : ''}<div class="fieldnote">${safe(v.caveat)} · ผลทดสอบเป็นแบบย้อนหลัง ไม่ใช่การทดลองล่วงหน้าที่ลงทะเบียนไว้ก่อน และไม่ใช่หลักฐานว่าผลเกมมีรูปแบบที่เอาชนะได้</div>`;
  }

  function renderCrossShoeAudit() {
    const target = $('crossShoeResults');
    try {
      const archive = getArchives();
      if (archive.length < 2) { target.className='empty'; target.innerHTML='ต้องมีอย่างน้อย 2 Shoe ในคลังเพื่อเริ่มทดสอบแบบกัน Shoe ออกจากชุดฝึก'; return; }
      const report = window.SightlineEngine.crossShoeValidation(archive);
      const m = report.metrics;
      if (!m) { target.className='empty'; target.textContent=report.note; return; }
      const f=x=>x==null?'—':Number(x).toFixed(4);
      const status = report.status==='CANDIDATE_EDGE_NEEDS_PROSPECTIVE_CONFIRMATION' ? 'พบสัญญาณเบื้องต้นเท่านั้น — ยังไม่ใช่ความได้เปรียบที่ยืนยันแล้ว' : report.status==='INSUFFICIENT_EVIDENCE' ? 'หลักฐานยังไม่เพียงพอ' : 'ยังไม่พบความได้เปรียบที่ยืนยันได้';
      const rows=[['Pooled cross-Shoe',m.pooled],['ค่าฐาน 8 สำรับ',m.baseline],['ความถี่เฉพาะ Shoe',m.localFrequency]].map(([n,x])=>`<tr><td>${safe(n)}</td><td>${f(x.brier)}</td><td>${f(x.logLoss)}</td><td>${pct(x.topAccuracy)}</td></tr>`).join('');
      const per=report.perShoe.map(x=>`<tr><td>${safe(x.name)}</td><td>${x.sequenceLength}</td><td>${x.predictions}</td><td>${f(x.pooledBrier)}</td><td>${f(x.baselineBrier)}</td></tr>`).join('');
      const ci=m.approxPaired95CI;
      target.className='modelgrid';
      target.innerHTML=`<div class="results-meta"><span class="results-chip">Shoe ${report.shoeCount}</span><span class="results-chip">คำทำนายที่ประเมิน ${report.predictions}</span><span class="results-chip">สถานะ ${safe(report.status)}</span></div><div class="readout ${report.status==='CANDIDATE_EDGE_NEEDS_PROSPECTIVE_CONFIRMATION'?'caution':''}"><div class="r-icon">V3</div><div><strong>${safe(status)}</strong><p>${safe(report.note)}</p></div></div><div class="tablewrap"><table><thead><tr><th>วิธี</th><th>Brier ↓</th><th>Log loss ↓</th><th>อันดับ 1 ถูก</th></tr></thead><tbody>${rows}</tbody></table></div><div class="fieldnote">Brier skill เทียบค่าฐาน: ${f(m.brierSkillVsBaseline)} · ช่วง 95% โดยประมาณ: ${ci?`${f(ci.low)} ถึง ${f(ci.high)}`:'—'}<br>ช่วงนี้คำนวณแบบรายคำทำนายอย่างหยาบและอาจแคบเกินจริง เพราะผลภายใน Shoe พึ่งพากัน ต้องใช้การวิเคราะห์แบบ cluster ต่อ Shoe และทดสอบล่วงหน้าเพื่อยืนยัน<br><strong>ไม่ใช่คำแนะนำเดิมพัน และระบบจะไม่เรียกสิ่งนี้ว่าความได้เปรียบจริงจากผลย้อนหลังเพียงอย่างเดียว</strong></div><div><strong>ผลแยกแต่ละ Shoe</strong><div class="tablewrap"><table><thead><tr><th>Shoe</th><th>ผลทั้งหมด</th><th>ทดสอบ</th><th>Pooled Brier</th><th>Baseline Brier</th></tr></thead><tbody>${per}</tbody></table></div></div>`;
    } catch(err) { target.className='empty'; target.textContent=`ทดสอบไม่สำเร็จ: ${err.message||err}`; }
  }

  function renderCardResults(result) {
    const rows = ['P','B','T'].map(side => `<tr><td>${labels[side]} (${side})</td><td>${result.counts[side].toLocaleString()}</td><td>${pct(result.probabilities[side])}</td><td>${pct(result.intervals[side].low)} – ${pct(result.intervals[side].high)}</td></tr>`).join('');
    $('cardResults').className = 'modelgrid';
    $('cardResults').innerHTML = `<div class="results-meta"><span class="results-chip">ผลที่จำลอง ${result.simulations.toLocaleString()} รอบ</span><span class="results-chip">ไพ่รู้หน้าออกจาก Shoe ${result.knownRemoved} ใบ</span><span class="results-chip">ไพ่ไม่ทราบหน้าเพิ่ม ${result.unknownRemoved} ใบ</span><span class="results-chip">อันดับจาก simulation ${result.topOutcome}</span></div><div class="tablewrap card-result-table"><table><thead><tr><th>ผล</th><th>จำนวนจำลอง</th><th>สัดส่วน</th><th>ช่วง Wilson 95%</th></tr></thead><tbody>${rows}</tbody></table></div><div class="fieldnote"><strong>สมมติฐานสำคัญ</strong><br>${result.assumptions.map(safe).join('<br>')}<br><br>${safe(result.limitation)}</div>`;
  }

  function runCardAnalysis() {
    try {
      const cards = window.SightlineEngine.parseCards(knownCardsInput.value);
      const result = window.SightlineEngine.cardAwareEstimate(cards, unknownRemovedInput.value === '' ? 0 : Number(unknownRemovedInput.value), Number(simulationsInput.value));
      lastCardAnalysis = result;
      renderCardResults(result);
      saveLocal();
      notify('จำลอง Card-Aware เสร็จแล้ว');
    } catch (err) {
      lastCardAnalysis = null;
      $('cardResults').className = 'empty';
      $('cardResults').textContent = err.message || 'ตรวจสอบข้อมูลไพ่ไม่สำเร็จ';
    }
  }

  function clearCardResultForEdit() {
    lastCardAnalysis = null;
    $('cardResults').className = 'empty';
    $('cardResults').textContent = 'ข้อมูลไพ่เปลี่ยนแล้ว · กด “จำลองไพ่ถัดไป” เพื่อคำนวณใหม่';
    saveLocal();
  }
  function renderReadouts(a) {
    const notes = [];
    notes.push({c:false,title:'ขนาดตัวอย่าง',text:`วิเคราะห์ ${a.summary.n} ผล: P ${a.summary.counts.P}, B ${a.summary.counts.B}, T ${a.summary.counts.T}. จำนวนนี้บอกขนาดข้อมูล ไม่ได้บอกว่ารูปแบบจะเกิดซ้ำในอนาคต`});
    if (a.latestEvent) notes.push({c:false,title:'บริบทปลายลำดับ',text:`ผลล่าสุดคือ ${a.latestEvent} (${labels[a.latestEvent]}) และฝั่ง P/B ล่าสุดคือ ${a.latestSide || '—'}. ตาราง transition ใช้ผลที่ติดกันจริง รวม T ไม่ลบทิ้ง`});
    const shift = a.adjacentWindowShift;
    if (shift.available && shift.level !== 'SMALL_DIFFERENCE') notes.push({c:true,title:'จุดสังเกตที่ควรระวัง',text:`องค์ประกอบผลในสองหน้าต่างล่าสุดต่างกัน ${pct(shift.totalVariation)}. ใช้เป็นคำถามเพื่อตรวจข้อมูล ไม่ใช่สัญญาณให้เลือกฝั่ง`});
    if (a.suffixEvidence) notes.push({c:a.suffixEvidence.support<3,title:'หลักฐานลำดับท้าย',text:`${a.suffixEvidence.pattern} มีตัวอย่างย้อนหลัง ${a.suffixEvidence.support} ครั้ง: หลังลำดับนี้พบ P ${a.suffixEvidence.following.P}, B ${a.suffixEvidence.following.B}, T ${a.suffixEvidence.following.T}. ยิ่งตัวอย่างน้อย ยิ่งสรุปไม่ได้`});
    notes.push({c:true,title:'สิ่งที่ระบบไม่อ้าง',text:'ผลวิเคราะห์นี้ไม่ได้พิสูจน์ว่าเกมมี pattern ที่ทำนายได้ ไม่คำนวณความได้เปรียบในการเดิมพัน และไม่ออกคำสั่งเดิมพัน ต้องใช้การทดสอบล่วงหน้ากับหลายเซสชันแยกอิสระหากต้องการประเมินพลังการทำนาย'});
    $('readouts').className = 'readouts';
    $('readouts').innerHTML = notes.map((n,i) => `<div class="readout ${n.c?'caution':''}"><div class="r-icon">${n.c?'!':'i'}</div><div><strong>${n.title}</strong><p>${n.text}</p></div></div>`).join('');
  }
  function render() {
    let a;
    try { a = window.SightlineEngine.analyze(seqInput.value); }
    catch (err) { notify(err.message || 'ตรวจสอบข้อมูลไม่สำเร็จ'); return; }
    lastAnalysis = a;
    saveLocal();
    $('sessionTitle').textContent = nameInput.value.trim() || 'เซสชันที่ไม่ได้ตั้งชื่อ';
    $('roundTag').textContent = `${a.summary.n} RESULTS`;
    if (!a.summary.n) {
      $('metrics').innerHTML = '<div class="empty" style="grid-column:1/-1"><strong>ยังไม่มีข้อมูล</strong>ใส่ประวัติผลเกม แล้วกด “วิเคราะห์โครงสร้าง”</div>';
      ['forecast','mix','tempo','windows','transitions','motifs','readouts'].forEach(id => { $(id).className = 'empty'; $(id).textContent = 'ยังไม่มีข้อมูล'; });
      $('conditionalNote').textContent = '';
      renderValidation(a);
      return;
    }
    renderMetrics(a); renderForecast(a); renderValidation(a); renderMix(a); renderTempo(a); renderWindows(a); renderTransitions(a); renderMotifs(a); renderReadouts(a);
  }
  function appendOutcome(side) {
    try { const seq = window.SightlineEngine.parseSequence(seqInput.value); seqInput.value = seq + side; saveLocal(); render(); seqInput.focus(); }
    catch (err) { notify(err.message); }
  }
  function exportData() {
    let seq;
    try { seq = window.SightlineEngine.parseSequence(seqInput.value); }
    catch (err) { notify(err.message); return; }
    const payload = { product: 'NEXUS SIGHTLINE', version: APP_VERSION, sessionName: nameInput.value.trim(), sequence: seq, cardAware: { knownCardsText: knownCardsInput.value, unknownRemoved: unknownRemovedInput.value, simulations: simulationsInput.value }, shoeArchive: getArchives(), exportedAt: new Date().toISOString(), note: 'Outcome forecasts are experimental; walk-forward scores are retrospective and do not prove a prospective edge.' };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob); const a = document.createElement('a'); a.href = url; a.download = `sightline-v3-0-${new Date().toISOString().slice(0,10)}.json`; document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(url); notify('ส่งออก JSON แล้ว');
  }
  function importData(file) {
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const x = JSON.parse(String(reader.result));
        if (!x || typeof x !== 'object' || Array.isArray(x)) throw new Error('โครงสร้าง JSON ต้องเป็นออบเจ็กต์');
        const rawSequence = typeof x.sequence === 'string' ? x.sequence : (typeof x.sequenceText === 'string' ? x.sequenceText : null);
        if (rawSequence === null) throw new Error('ไม่พบฟิลด์ sequence ที่เป็นข้อความในไฟล์');
        const seq = window.SightlineEngine.parseSequence(rawSequence);
        seqInput.value = seq; nameInput.value = typeof x.sessionName === 'string' ? x.sessionName.slice(0,80) : '';
        const cards = x.cardAware && typeof x.cardAware === 'object' ? x.cardAware : {};
        knownCardsInput.value = typeof cards.knownCardsText === 'string' ? cards.knownCardsText : '';
        unknownRemovedInput.value = cards.unknownRemoved == null ? '0' : String(cards.unknownRemoved);
        simulationsInput.value = ['5000','20000','50000'].includes(String(cards.simulations)) ? String(cards.simulations) : '20000';
        if (Array.isArray(x.shoeArchive)) {
          const importedArchive = x.shoeArchive.map((item, i) => {
            if (!item || typeof item !== 'object' || typeof item.sequence !== 'string') throw new Error(`รายการ Shoe ในคลังลำดับที่ ${i + 1} ไม่ถูกต้อง`);
            return { id: typeof item.id === 'string' ? item.id.slice(0,100) : `imported-${Date.now()}-${i}`, name: typeof item.name === 'string' ? item.name.slice(0,80) : `Shoe ${i + 1}`, sequence: window.SightlineEngine.parseSequence(item.sequence), savedAt: typeof item.savedAt === 'string' ? item.savedAt : new Date().toISOString() };
          });
          if (importedArchive.length > 200) throw new Error('ไฟล์มี Shoe มากกว่า 200 รายการ');
          saveArchives(importedArchive);
        }
        lastCardAnalysis = null; $('cardResults').className = 'empty'; $('cardResults').textContent = 'นำเข้าข้อมูลแล้ว · กด “จำลองไพ่ถัดไป” เพื่อประเมินจากข้อมูลไพ่';
        render(); notify('นำเข้าข้อมูลแล้ว');
      } catch (err) { notify(`นำเข้าไม่สำเร็จ: ${err.message || 'ไฟล์ไม่ถูกต้อง'}`); }
      $('fileInput').value = '';
    };
    reader.onerror = () => notify('อ่านไฟล์ไม่สำเร็จ'); reader.readAsText(file);
  }
  document.querySelectorAll('[data-add]').forEach(btn => btn.addEventListener('click', () => appendOutcome(btn.dataset.add)));
  $('analyzeBtn').addEventListener('click', render);
  $('demoBtn').addEventListener('click', () => { nameInput.value = 'DEMO · ข้อมูลจำลอง'; seqInput.value = 'P B P P B T B B P B P B B B P T P B P P B P B T B B P B P B B P B P P B T P B B P B P B P B B P'; render(); notify('โหลดข้อมูลจำลองแล้ว — ไม่ใช่ผลจริง'); });
  $('clearBtn').addEventListener('click', () => { seqInput.value = ''; nameInput.value = ''; render(); saveLocal(); notify('ล้างข้อมูลในช่องแล้ว'); });
  $('exportBtn').addEventListener('click', exportData);
  $('importBtn').addEventListener('click', () => $('fileInput').click());
  $('fileInput').addEventListener('change', e => importData(e.target.files && e.target.files[0]));
  $('cardAnalyzeBtn').addEventListener('click', runCardAnalysis);
  $('cardResetBtn').addEventListener('click', () => { knownCardsInput.value = ''; unknownRemovedInput.value = '0'; simulationsInput.value = '20000'; lastCardAnalysis = null; $('cardResults').className = 'empty'; $('cardResults').textContent = 'ล้างข้อมูลไพ่แล้ว'; saveLocal(); });
  $('archiveCurrentBtn').addEventListener('click', archiveCurrentShoe);
  $('crossShoeBtn').addEventListener('click', renderCrossShoeAudit);
  $('loadArchiveBtn').addEventListener('click', loadSelectedShoe);
  $('deleteArchiveBtn').addEventListener('click', deleteSelectedShoe);
  [knownCardsInput,unknownRemovedInput,simulationsInput].forEach(el => el.addEventListener('input', clearCardResultForEdit));
  [seqInput,nameInput].forEach(el => el.addEventListener('input', () => { saveLocal(); }));
  seqInput.addEventListener('keydown', e => { if (e.ctrlKey && e.key === 'Enter') render(); });
  restoreLocal();
  if (seqInput.value.trim()) render(); else render();
})();
