/* NEXUS SIGHTLINE V3.0 — evidence-first baccarat analysis core.
 * Outcome-only analysis plus an experimental, explicitly assumption-bound card-aware simulator.
 * No network dependencies. Usable in browser and Node.js.
 */
(function (root, factory) {
  const api = factory();
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  if (root) root.SightlineEngine = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  const VERSION = '3.0.0';
  const STANDARD_8_DECK_BASELINE = Object.freeze({ P: 0.446247, B: 0.458597, T: 0.095156 });
  const GLOBAL_PRIOR_STRENGTH = 40;
  const TRANSITION_PRIOR_STRENGTH = 12;
  const MAX_TRANSITION_WEIGHT = 0.65;
  const MAX_OUTCOMES = 2000;
  const MIN_TRAINING_OUTCOMES = 40;
  const VALIDATION_WINDOW = 120;
  const CARD_RANKS = ['A','2','3','4','5','6','7','8','9','T','J','Q','K'];
  const SIDES = ['P', 'B', 'T'];
  const SIDE_NAMES = { P: 'Player', B: 'Banker', T: 'Tie' };
  const MODEL_NAMES = ['baseline', 'frequency', 'markov1', 'markov2', 'markov3'];
  const MODEL_LABELS = { baseline: 'ค่าฐาน 8 สำรับ', frequency: 'สัดส่วนรวมแบบ smoothing', markov1: 'Transition ลำดับ 1', markov2: 'Context ลำดับ 2', markov3: 'Context ลำดับ 3' };
  const EPSILON = 1e-12;

  function parseSequence(input) {
    if (typeof input !== 'string') throw new TypeError('ประวัติต้องเป็นข้อความ');
    let text = input.toUpperCase();
    text = text.replace(/\bPLAYER\b/g, 'P').replace(/\bBANKER\b/g, 'B').replace(/\bTIE\b/g, 'T');
    const out = [];
    for (const ch of text) {
      if (SIDES.includes(ch)) out.push(ch);
      else if (/[\s,;|/_.:>\-()[\]{}]/.test(ch)) continue;
      else throw new Error(`พบสัญลักษณ์ที่ไม่รองรับ: “${ch}” — ใช้ P, B, T เท่านั้น`);
    }
    if (out.length > MAX_OUTCOMES) throw new Error(`รองรับประวัติสูงสุด ${MAX_OUTCOMES} ผลต่อการวิเคราะห์`);
    return out.join('');
  }

  function parseCards(input) {
    if (typeof input !== 'string') throw new TypeError('ข้อมูลไพ่ต้องเป็นข้อความ');
    // Supports compact ranks (A2345TJQK) or separated tokens (A, 2, 10, J, Q, K).
    const text = input.toUpperCase().replace(/10/g, 'T').replace(/[\s,;|/._\-()[\]{}:]+/g, '');
    const cards = [];
    for (const ch of text) {
      if (!CARD_RANKS.includes(ch)) throw new Error(`อันดับไพ่ไม่รองรับ: “${ch}” — ใช้ A, 2–9, 10/T, J, Q, K`);
      cards.push(ch);
    }
    if (cards.length > 416) throw new Error('ข้อมูลไพ่มีมากกว่า 416 ใบ ซึ่งเกินจำนวนไพ่ 8 สำรับ');
    return cards;
  }

  function countOutcomes(sequence) {
    const counts = { P: 0, B: 0, T: 0 };
    for (const x of sequence) counts[x]++;
    return { n: sequence.length, counts, shares: Object.fromEntries(SIDES.map(s => [s, sequence.length ? counts[s] / sequence.length : null])) };
  }

  function distribution(sequence) {
    const info = countOutcomes(sequence);
    return Object.fromEntries(SIDES.map(s => [s, info.n ? info.counts[s] / info.n : 0]));
  }

  function totalVariation(a, b) {
    return SIDES.reduce((sum, s) => sum + Math.abs((a[s] || 0) - (b[s] || 0)), 0) / 2;
  }

  function jensenShannonDivergence(a, b) {
    const m = {};
    for (const s of SIDES) m[s] = ((a[s] || 0) + (b[s] || 0)) / 2;
    const kl = (x, y) => SIDES.reduce((sum, s) => {
      const p = x[s] || 0, q = y[s] || 0;
      return p > 0 && q > 0 ? sum + p * Math.log2(p / q) : sum;
    }, 0);
    return (kl(a, m) + kl(b, m)) / 2;
  }

  function sideProjection(sideSequence) { return sideSequence.replace(/T/g, ''); }

  function runProfile(sideSequence) {
    if (!sideSequence.length) return { runs: [], currentSide: null, currentLength: 0, maxLength: 0, runCount: 0 };
    const runs = [];
    let start = 0;
    for (let i = 1; i <= sideSequence.length; i++) {
      if (i === sideSequence.length || sideSequence[i] !== sideSequence[start]) {
        runs.push({ side: sideSequence[start], length: i - start, startIndex: start, endIndexExclusive: i });
        start = i;
      }
    }
    return { runs, currentSide: runs[runs.length - 1].side, currentLength: runs[runs.length - 1].length,
      maxLength: Math.max(...runs.map(r => r.length)), runCount: runs.length, meanLength: sideSequence.length / runs.length, recentRuns: runs.slice(-24) };
  }

  function transitionMatrix(sequence) {
    const matrix = {};
    for (const from of SIDES) matrix[from] = { total: 0, counts: { P: 0, B: 0, T: 0 }, shares: { P: null, B: null, T: null } };
    for (let i = 0; i + 1 < sequence.length; i++) { matrix[sequence[i]].counts[sequence[i + 1]]++; matrix[sequence[i]].total++; }
    for (const from of SIDES) {
      const row = matrix[from];
      for (const to of SIDES) row.shares[to] = row.total ? row.counts[to] / row.total : null;
    }
    return matrix;
  }

  function conditionalReference(matrix, lastEvent) {
    if (!lastEvent || !matrix[lastEvent]) return null;
    const row = matrix[lastEvent];
    return { after: lastEvent, support: row.total, counts: { ...row.counts }, shares: { ...row.shares }, interpretation: row.total < 8 ? 'LOW_SUPPORT' : 'DESCRIPTIVE_ONLY' };
  }

  function normalized(probs) {
    const out = {};
    let sum = 0;
    for (const s of SIDES) { out[s] = Math.max(EPSILON, Number.isFinite(probs[s]) ? probs[s] : STANDARD_8_DECK_BASELINE[s]); sum += out[s]; }
    for (const s of SIDES) out[s] /= sum;
    return out;
  }

  function frequencyEstimate(sequence) {
    const info = countOutcomes(sequence);
    return normalized(Object.fromEntries(SIDES.map(s => [s, (info.counts[s] + GLOBAL_PRIOR_STRENGTH * STANDARD_8_DECK_BASELINE[s]) / (info.n + GLOBAL_PRIOR_STRENGTH)])));
  }

  function contextEvidence(sequence, order) {
    if (sequence.length <= order) return { pattern: sequence, support: 0, following: { P: 0, B: 0, T: 0 } };
    const pattern = sequence.slice(-order), following = { P: 0, B: 0, T: 0 };
    for (let i = 0; i + order < sequence.length; i++) {
      if (sequence.slice(i, i + order) === pattern) following[sequence[i + order]]++;
    }
    return { pattern, support: SIDES.reduce((sum, s) => sum + following[s], 0), following };
  }

  function forecastModels(sequence, transitions) {
    if (!sequence.length) return null;
    const info = countOutcomes(sequence);
    const globalEstimate = frequencyEstimate(sequence);
    const matrix = transitions || transitionMatrix(sequence);
    const lastEvent = sequence[sequence.length - 1];
    const row = matrix[lastEvent];
    const transitionEstimate = {};
    for (const side of SIDES) transitionEstimate[side] = (row.counts[side] + TRANSITION_PRIOR_STRENGTH * globalEstimate[side]) / (row.total + TRANSITION_PRIOR_STRENGTH);
    const transitionWeight = row.total > 0 ? Math.min(MAX_TRANSITION_WEIGHT, row.total / (row.total + 20)) : 0;
    const markov1 = normalized(Object.fromEntries(SIDES.map(s => [s, (1 - transitionWeight) * globalEstimate[s] + transitionWeight * transitionEstimate[s]])));
    const c2 = contextEvidence(sequence, 2), c3 = contextEvidence(sequence, 3);
    const contextEstimate = (ctx, strength) => normalized(Object.fromEntries(SIDES.map(s => [s, (ctx.following[s] + strength * globalEstimate[s]) / (ctx.support + strength)])));
    return {
      baseline: { ...STANDARD_8_DECK_BASELINE },
      frequency: globalEstimate,
      markov1,
      markov2: contextEstimate(c2, 18),
      markov3: contextEstimate(c3, 36),
      details: { lastEvent, supportAfterLatest: row.total, transitionWeight, transitionEstimate, globalEstimate, context2: c2, context3: c3 }
    };
  }

  function brierScore(probabilities, actual) {
    return SIDES.reduce((sum, s) => sum + Math.pow(probabilities[s] - (s === actual ? 1 : 0), 2), 0);
  }
  function logLoss(probabilities, actual) { return -Math.log(Math.max(EPSILON, Math.min(1, probabilities[actual]))); }
  function argmax(probabilities) { return SIDES.slice().sort((a, b) => probabilities[b] - probabilities[a])[0]; }
  function mean(xs) { return xs.length ? xs.reduce((a, b) => a + b, 0) / xs.length : null; }

  function deriveWeights(lossHistory, totalPredictions = null) {
    const baselineMean = mean(lossHistory.baseline || []);
    if (baselineMean == null) return { weights: { baseline: 1, frequency: 0, markov1: 0, markov2: 0, markov3: 0 }, sampleCount: 0, lossWindowSize: 0, adaptiveShare: 0 };
    const raws = {};
    for (const name of MODEL_NAMES) {
      const modelMean = mean(lossHistory[name] || []);
      // Relative historical Brier skill; clamp to prevent runaway weights from noisy small samples.
      const skill = modelMean == null ? 0 : Math.max(-2, Math.min(2, (baselineMean - modelMean) * 18));
      raws[name] = Math.exp(skill);
    }
    const total = MODEL_NAMES.reduce((sum, name) => sum + raws[name], 0);
    const weights = Object.fromEntries(MODEL_NAMES.map(name => [name, raws[name] / total]));
    const lossWindowSize = (lossHistory.baseline || []).length;
    const sampleCount = Number.isFinite(totalPredictions) ? Math.max(0, totalPredictions) : lossWindowSize;
    // Trust grows with the number of genuinely prequential forecasts, while losses use a rolling window.
    // At most 45% of the final estimate can move away from the fixed reference baseline.
    const adaptiveShare = Math.min(0.45, 0.45 * sampleCount / (sampleCount + 100));
    return { weights, sampleCount, lossWindowSize, adaptiveShare };
  }

  function blendModels(modelProbabilities, weightInfo) {
    const base = modelProbabilities.baseline;
    const weighted = {};
    for (const side of SIDES) weighted[side] = MODEL_NAMES.reduce((sum, name) => sum + (weightInfo.weights[name] || 0) * modelProbabilities[name][side], 0);
    return normalized(Object.fromEntries(SIDES.map(s => [s, (1 - weightInfo.adaptiveShare) * base[s] + weightInfo.adaptiveShare * weighted[s]])));
  }

  function buildStats(records, modelName) {
    const selected = records.map(r => ({ ...r[modelName], actual: r.actual }));
    if (!selected.length) return { count: 0, brier: null, logLoss: null, topAccuracy: null };
    return {
      count: selected.length,
      brier: mean(selected.map(x => x.brier)),
      logLoss: mean(selected.map(x => x.logLoss)),
      topAccuracy: selected.filter(x => x.predicted === x.actual).length / selected.length
    };
  }

  function walkForwardValidation(sequence, options = {}) {
    const minTrain = Math.max(10, Math.floor(options.minTrain || MIN_TRAINING_OUTCOMES));
    const window = Math.max(20, Math.floor(options.window || VALIDATION_WINDOW));
    const losses = Object.fromEntries(MODEL_NAMES.map(name => [name, []]));
    const records = [];
    const modelLossRows = [];
    for (let i = minTrain; i < sequence.length; i++) {
      const prefix = sequence.slice(0, i);
      const candidates = forecastModels(prefix);
      const weightInfo = deriveWeights(losses, records.length);
      const ensemble = blendModels(candidates, weightInfo);
      const actual = sequence[i];
      const record = { actual, ensemble: { probabilities: ensemble, predicted: argmax(ensemble), brier: brierScore(ensemble, actual), logLoss: logLoss(ensemble, actual) } };
      for (const name of MODEL_NAMES) {
        const p = candidates[name];
        record[name] = { probabilities: p, predicted: argmax(p), brier: brierScore(p, actual), logLoss: logLoss(p, actual) };
        losses[name].push(record[name].brier);
        if (losses[name].length > window) losses[name].shift();
      }
      // The ensemble score is tracked separately but never used to tune its own candidate weights.
      records.push(record);
    }
    const models = {};
    for (const name of MODEL_NAMES) models[name] = { label: MODEL_LABELS[name], ...buildStats(records, name) };
    models.ensemble = { label: 'Adaptive ensemble', ...buildStats(records, 'ensemble') };
    const predictions = records.length;
    const calibration = { P: [], B: [], T: [] };
    // Top-outcome reliability bins: 0.33–0.45, 0.45–0.55, 0.55–0.65, 0.65–0.75, 0.75–1.00.
    const edges = [0.333333, 0.45, 0.55, 0.65, 0.75, 1.000001];
    for (const side of SIDES) {
      calibration[side] = [];
      for (let b = 0; b < edges.length - 1; b++) {
        const group = records.filter(r => r.ensemble.predicted === side && r.ensemble.probabilities[side] >= edges[b] && r.ensemble.probabilities[side] < edges[b + 1]);
        calibration[side].push({ lower: edges[b], upper: Math.min(1, edges[b + 1]), count: group.length,
          meanConfidence: mean(group.map(r => r.ensemble.probabilities[side])), observedAccuracy: group.length ? group.filter(r => r.actual === side).length / group.length : null });
      }
    }
    const weightInfo = deriveWeights(losses, predictions);
    const validationStatus = predictions >= 100 ? 'RETROSPECTIVE_WALK_FORWARD' : predictions > 0 ? 'VERY_SMALL_WALK_FORWARD_SAMPLE' : 'INSUFFICIENT_HISTORY';
    return {
      available: predictions > 0, minTrainingOutcomes: minTrain, predictions, rollingWindow: window, validationStatus,
      metrics: models, learnedWeights: weightInfo.weights, adaptiveShare: weightInfo.adaptiveShare,
      calibration, caveat: 'การทดสอบย้อนหลังแบบ walk-forward ใช้เฉพาะข้อมูลก่อนผลที่กำลังทดสอบ แต่ยังไม่ใช่การทดลองล่วงหน้ากับ Shoe/เซสชันอิสระ และการเลือกโมเดลจากประวัติเดิมยังมีความเสี่ยง overfit'
    };
  }

  function forecastNext(sequence, transitions, validation) {
    if (!sequence.length) return null;
    const candidates = forecastModels(sequence, transitions);
    const wf = validation || walkForwardValidation(sequence);
    const weightInfo = wf.available ? { weights: wf.learnedWeights, adaptiveShare: wf.adaptiveShare, sampleCount: wf.predictions } : deriveWeights({ baseline: [] });
    const probabilities = blendModels(candidates, weightInfo);
    const ranked = SIDES.slice().sort((a, b) => probabilities[b] - probabilities[a]);
    const top = ranked[0], second = ranked[1];
    const detail = candidates.details;
    let evidenceLevel = 'LOW', evidenceText = 'หลักฐานต่ำ — ยังไม่มีผลทดสอบ walk-forward เพียงพอ';
    if (sequence.length >= 100 && wf.predictions >= 60) { evidenceLevel = 'EXPLORATORY'; evidenceText = 'มีข้อมูลย้อนหลังสำหรับเปรียบเทียบโมเดล แต่ยังไม่ใช่หลักฐานความได้เปรียบที่ผ่านการยืนยันอิสระ'; }
    else if (sequence.length >= 40) { evidenceLevel = 'LIMITED'; evidenceText = 'มีข้อมูลสำหรับทดลองบางส่วน แต่จำนวนการทดสอบยังจำกัด'; }
    return {
      method: 'BASELINE_ANCHORED_WALK_FORWARD_ADAPTIVE_ENSEMBLE', probabilities, topOutcome: top, topProbability: probabilities[top], runnerUp: second,
      marginToRunnerUp: probabilities[top] - probabilities[second], lastEvent: detail.lastEvent, supportAfterLatest: detail.supportAfterLatest,
      globalEstimate: detail.globalEstimate, transitionEstimate: detail.transitionEstimate, transitionWeight: detail.transitionWeight,
      baseline: { ...STANDARD_8_DECK_BASELINE }, divergenceFromBaseline: totalVariation(probabilities, STANDARD_8_DECK_BASELINE),
      candidateProbabilities: { baseline: candidates.baseline, frequency: candidates.frequency, markov1: candidates.markov1, markov2: candidates.markov2, markov3: candidates.markov3 },
      modelWeights: weightInfo.weights, adaptiveShare: weightInfo.adaptiveShare, validatedPredictionCount: wf.predictions,
      evidenceLevel, evidenceText, validationStatus: 'UNVALIDATED_FOR_PROSPECTIVE_EDGE',
      note: 'โมเดลผสานค่าฐานกับผลทดสอบย้อนหลังแบบ walk-forward และจำกัดส่วนปรับตามโมเดลไว้ไม่เกิน 45%; ยังไม่พิสูจน์ความได้เปรียบในการทำนายหรือเดิมพัน'
    };
  }

  function suffixEvidence(sequence, maxLength = 5) {
    if (sequence.length < 3) return null;
    const maxK = Math.min(maxLength, sequence.length - 1);
    for (let k = maxK; k >= 2; k--) {
      const pattern = sequence.slice(-k), following = { P: 0, B: 0, T: 0 }, indexes = [];
      for (let i = 0; i + k < sequence.length; i++) if (sequence.slice(i, i + k) === pattern) { following[sequence[i + k]]++; indexes.push(i); }
      const support = indexes.length;
      if (support > 0) {
        const leader = SIDES.slice().sort((a, b) => following[b] - following[a])[0];
        return { pattern, length: k, support, following, dominantFollow: following[leader] > 0 ? leader : null,
          dominantShare: support ? following[leader] / support : null, sourceIndexes: indexes, reliability: support < 3 ? 'VERY_LOW' : support < 8 ? 'LOW' : 'DESCRIPTIVE_ONLY' };
      }
    }
    return null;
  }

  function topMotifs(sequence, limit = 8, minSupport = 2) {
    const found = new Map(), maxK = Math.min(5, sequence.length - 1);
    for (let k = 2; k <= maxK; k++) for (let i = 0; i + k < sequence.length; i++) {
      const pattern = sequence.slice(i, i + k);
      if (!found.has(pattern)) found.set(pattern, { pattern, support: 0, following: { P: 0, B: 0, T: 0 } });
      const item = found.get(pattern); item.support++; item.following[sequence[i + k]]++;
    }
    return Array.from(found.values()).filter(x => x.support >= minSupport).map(x => {
      const top = SIDES.slice().sort((a, b) => x.following[b] - x.following[a])[0];
      return { ...x, dominantFollow: x.following[top] ? top : null, dominantShare: x.following[top] / x.support };
    }).sort((a, b) => b.support - a.support || b.pattern.length - a.pattern.length || a.pattern.localeCompare(b.pattern)).slice(0, limit);
  }

  function windowProfile(sequence, globalDistribution, size) {
    const window = sequence.slice(-Math.min(sequence.length, size)), info = countOutcomes(window);
    return { size: window.length, requestedSize: size, counts: info.counts, shares: info.shares,
      divergenceFromWhole: window.length ? totalVariation(info.shares, globalDistribution) : null };
  }

  function adjacentWindowShift(sequence, size = 24) {
    if (sequence.length < size * 2) return { available: false, windowSize: size, reason: `ต้องมีอย่างน้อย ${size * 2} ผลเพื่อเปรียบเทียบสองหน้าต่าง` };
    const previous = sequence.slice(-size * 2, -size), recent = sequence.slice(-size);
    const previousDist = distribution(previous), recentDist = distribution(recent), tv = totalVariation(previousDist, recentDist);
    let level = 'SMALL_DIFFERENCE';
    if (tv >= 0.35) level = 'LARGE_DIFFERENCE_CANDIDATE'; else if (tv >= 0.20) level = 'VISIBLE_DIFFERENCE';
    return { available: true, windowSize: size, previous: { counts: countOutcomes(previous).counts, shares: previousDist }, recent: { counts: countOutcomes(recent).counts, shares: recentDist },
      totalVariation: tv, jensenShannonBits: jensenShannonDivergence(previousDist, recentDist), level,
      caveat: 'ตัวชี้วัดเชิงพรรณนาและ candidate detector ไม่ใช่การทดสอบนัยสำคัญและไม่ยืนยันว่ากลไกของเกมเปลี่ยน' };
  }

  function detectShifts(sequence) {
    const shifts = [adjacentWindowShift(sequence, 24), adjacentWindowShift(sequence, 48)];
    return { shifts, hasCandidate: shifts.some(s => s.available && s.level !== 'SMALL_DIFFERENCE'), note: 'หน้าต่างอาจซ้อนทับกันและความแตกต่างเกิดจากความผันผวนสุ่มได้ จึงใช้แจ้งเตือนให้ตรวจ ไม่ใช้เพิ่มความมั่นใจในการคาดการณ์โดยอัตโนมัติ' };
  }

  function entropy(shares) {
    const positive = SIDES.map(s => shares[s]).filter(p => p > 0), h = -positive.reduce((sum, p) => sum + p * Math.log2(p), 0);
    return { bits: h, normalized3Way: h / Math.log2(3) };
  }

  function cardValue(rank) { if (rank === 'A') return 1; if (rank === 'T' || rank === 'J' || rank === 'Q' || rank === 'K') return 0; return Number(rank); }
  function handTotal(cards) { return cards.reduce((sum, rank) => sum + cardValue(rank), 0) % 10; }
  function nextRandom(seed) {
    let x = seed >>> 0;
    if (!x) x = 0x9e3779b9;
    return function () { x ^= x << 13; x ^= x >>> 17; x ^= x << 5; return (x >>> 0) / 4294967296; };
  }
  function hashSeed(text) { let h = 2166136261; for (let i = 0; i < text.length; i++) { h ^= text.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0 || 1; }
  function drawRank(counts, rng) {
    let total = 0; for (const n of counts) total += n;
    if (total <= 0) throw new Error('ไพ่ที่เหลือไม่เพียงพอสำหรับจำลองไพ่ถัดไป');
    let pick = Math.floor(rng() * total);
    for (let i = 0; i < counts.length; i++) { if (pick < counts[i]) { counts[i]--; return CARD_RANKS[i]; } pick -= counts[i]; }
    throw new Error('สุ่มไพ่ไม่สำเร็จ');
  }
  function bankerDraws(bankerTotal, playerDrew, playerThird) {
    if (!playerDrew) return bankerTotal <= 5;
    if (bankerTotal <= 2) return true;
    if (bankerTotal === 3) return playerThird !== 8;
    if (bankerTotal === 4) return playerThird >= 2 && playerThird <= 7;
    if (bankerTotal === 5) return playerThird >= 4 && playerThird <= 7;
    if (bankerTotal === 6) return playerThird === 6 || playerThird === 7;
    return false;
  }
  function playOneHand(counts, rng) {
    const p = [drawRank(counts, rng), drawRank(counts, rng)];
    const b = [drawRank(counts, rng), drawRank(counts, rng)];
    let pt = handTotal(p), bt = handTotal(b);
    if (pt >= 8 || bt >= 8) return pt === bt ? 'T' : pt > bt ? 'P' : 'B';
    let playerThird = null;
    if (pt <= 5) { playerThird = drawRank(counts, rng); p.push(playerThird); playerThird = cardValue(playerThird); pt = handTotal(p); }
    if (bankerDraws(bt, playerThird !== null, playerThird)) { b.push(drawRank(counts, rng)); bt = handTotal(b); }
    return pt === bt ? 'T' : pt > bt ? 'P' : 'B';
  }

  function cardAwareEstimate(knownCardsInput, unknownRemovedInput = 0, simulationsInput = 20000) {
    const knownCards = Array.isArray(knownCardsInput) ? knownCardsInput.slice() : parseCards(knownCardsInput);
    if (knownCards.some(c => !CARD_RANKS.includes(c))) throw new Error('รายการไพ่มีอันดับที่ไม่ถูกต้อง');
    const unknownRemoved = Number(unknownRemovedInput);
    const simulations = Number(simulationsInput);
    if (!Number.isInteger(unknownRemoved) || unknownRemoved < 0 || unknownRemoved > 300) throw new Error('จำนวนไพ่ที่ถูกนำออกโดยไม่ทราบหน้า ต้องเป็นจำนวนเต็ม 0–300');
    if (!Number.isInteger(simulations) || simulations < 2000 || simulations > 50000) throw new Error('จำนวนรอบจำลองต้องเป็นจำนวนเต็ม 2,000–50,000');
    if (unknownRemoved * simulations > 2000000) throw new Error('ภาระจำลองสูงเกินกำหนด: ลดจำนวนไพ่ไม่ทราบหน้าหรือจำนวนรอบจำลอง (จำกัดงานสุ่มไพ่ไม่ทราบหน้า 2,000,000 draws ต่อครั้ง)');
    const remaining = CARD_RANKS.map(() => 32);
    for (const rank of knownCards) { const ix = CARD_RANKS.indexOf(rank); remaining[ix]--; if (remaining[ix] < 0) throw new Error(`ไพ่ ${rank} ถูกระบุออกจาก Shoe มากกว่า 32 ใบ ซึ่งเกินจำนวนใน 8 สำรับ`); }
    const remainingAfterKnown = remaining.reduce((a, b) => a + b, 0);
    if (remainingAfterKnown - unknownRemoved < 6) throw new Error('ไพ่ที่เหลือหลังหักไพ่ที่รู้หน้าและไพ่ที่ไม่ทราบหน้า น้อยเกินไป');
    const seed = hashSeed(knownCards.join('') + `|${unknownRemoved}|${simulations}|SIGHTLINE23`), rng = nextRandom(seed);
    const counts = { P: 0, B: 0, T: 0 };
    for (let i = 0; i < simulations; i++) {
      const shoe = remaining.slice();
      for (let u = 0; u < unknownRemoved; u++) drawRank(shoe, rng);
      const outcome = playOneHand(shoe, rng); counts[outcome]++;
    }
    const probabilities = Object.fromEntries(SIDES.map(s => [s, counts[s] / simulations]));
    const intervals = {};
    for (const s of SIDES) {
      const p = probabilities[s], z = 1.96, den = 1 + z*z/simulations;
      const center = (p + z*z/(2*simulations))/den;
      const half = z * Math.sqrt((p*(1-p)/simulations) + (z*z/(4*simulations*simulations))) / den;
      intervals[s] = { low: Math.max(0, center-half), high: Math.min(1, center+half) };
    }
    const topOutcome = argmax(probabilities);
    return { method: 'EIGHT_DECK_REMAINING_COMPOSITION_MONTE_CARLO', decks: 8, knownRemoved: knownCards.length, knownRemovedCounts: Object.fromEntries(CARD_RANKS.map((r, i) => [r, 32 - remaining[i]]).filter(([, n]) => n)),
      unknownRemoved, remainingBeforeUnknownRemoval: remainingAfterKnown, simulations, seed, counts, probabilities, intervals, topOutcome,
      assumptions: ['Standard 8-deck Punto Banco and standard third-card rules.', 'Every known removed card must be entered once, including exposed cards already dealt and any known burn card.', 'Unknown removed cards are modelled as random unseen cards, with their count supplied by the user.', 'This is Monte Carlo, so estimates include simulation noise; interval bands reflect binomial simulation uncertainty only, not errors in input data or assumptions.'],
      limitation: 'ไม่ใช่การทำนายจาก P/B/T อย่างเดียว และไม่รับประกันความได้เปรียบ; หากนับไพ่ที่ถูกนำออกไม่ครบ ผลประมาณอาจคลาดเคลื่อนมาก' };
  }


  // V3: pooled cross-shoe learning with leave-one-shoe-out evaluation.
  // Shoe boundaries are never concatenated; context counts are accumulated within each shoe only.
  function pooledContextCounts(shoes, order) {
    const following = { P: 0, B: 0, T: 0 }, contexts = new Map();
    let n = 0;
    for (const raw of shoes) {
      const seq = parseSequence(typeof raw === 'string' ? raw : raw.sequence);
      n += seq.length;
      for (let i = order; i < seq.length; i++) {
        const key = seq.slice(i - order, i), side = seq[i];
        if (!contexts.has(key)) contexts.set(key, { P: 0, B: 0, T: 0 });
        contexts.get(key)[side]++;
        following[side]++;
      }
    }
    return { following, contexts, n };
  }
  function pooledForecast(prefix, trainingShoes, order = 2) {
    const prior = pooledContextCounts(trainingShoes, order);
    const local = parseSequence(prefix);
    const localDist = frequencyEstimate(local);
    const globalTotal = SIDES.reduce((a,s)=>a+prior.following[s],0);
    const pooledGlobal = normalized(Object.fromEntries(SIDES.map(s => [s, (prior.following[s] + 40 * STANDARD_8_DECK_BASELINE[s]) / (globalTotal + 40)])));
    const key = local.slice(-order), row = prior.contexts.get(key) || { P:0, B:0, T:0 };
    const support = SIDES.reduce((a,s)=>a+row[s],0);
    const combinedPrior = normalized(Object.fromEntries(SIDES.map(s=>[s, 0.65*pooledGlobal[s]+0.35*localDist[s]])));
    const probabilities = normalized(Object.fromEntries(SIDES.map(s=>[s, (row[s]+18*combinedPrior[s])/(support+18)])));
    return { probabilities, support, pattern:key, trainingShoes:trainingShoes.length, pooledOutcomes:prior.n };
  }
  function crossShoeValidation(inputShoes, options = {}) {
    const shoes = (inputShoes || []).map((x,i)=>({id:typeof x.id==='string'?x.id:`shoe-${i+1}`,name:typeof x.name==='string'?x.name:`Shoe ${i+1}`,sequence:parseSequence(typeof x==='string'?x:x.sequence)})).filter(x=>x.sequence.length>=1);
    const minTrain = Math.max(10, Math.floor(options.minTrain || 20));
    const rows=[]; const perShoe=[];
    if (shoes.length < 2) return {version:'3.0.0',status:'INSUFFICIENT_SHOES',shoeCount:shoes.length,predictions:0,minimumRecommendedShoes:10,note:'ต้องมีอย่างน้อย 2 Shoe เพื่อทดสอบแบบกัน Shoe ออกจากชุดฝึก; 10+ Shoe และจำนวนคำทำนายมากพอจึงเหมาะกับการประเมินเบื้องต้น'};
    for(let held=0;held<shoes.length;held++){
      const target=shoes[held], train=shoes.filter((_,i)=>i!==held);
      const shoeRows=[];
      for(let i=minTrain;i<target.sequence.length;i++){
        const prefix=target.sequence.slice(0,i), actual=target.sequence[i];
        const pooled=pooledForecast(prefix,train,2);
        const base=STANDARD_8_DECK_BASELINE;
        const local=forecastModels(prefix);
        const p=pooled.probabilities;
        const row={shoeId:target.id,actual,pooled:{probabilities:p,brier:brierScore(p,actual),logLoss:logLoss(p,actual),predicted:argmax(p)},baseline:{probabilities:base,brier:brierScore(base,actual),logLoss:logLoss(base,actual),predicted:argmax(base)},local:{probabilities:local.frequency,brier:brierScore(local.frequency,actual),logLoss:logLoss(local.frequency,actual),predicted:argmax(local.frequency)}};
        rows.push(row); shoeRows.push(row);
      }
      perShoe.push({id:target.id,name:target.name,sequenceLength:target.sequence.length,predictions:shoeRows.length,pooledBrier:mean(shoeRows.map(r=>r.pooled.brier)),baselineBrier:mean(shoeRows.map(r=>r.baseline.brier)),pooledLogLoss:mean(shoeRows.map(r=>r.pooled.logLoss)),baselineLogLoss:mean(shoeRows.map(r=>r.baseline.logLoss))});
    }
    const stats=(key)=>({brier:mean(rows.map(r=>r[key].brier)),logLoss:mean(rows.map(r=>r[key].logLoss)),topAccuracy:rows.length?rows.filter(r=>r[key].predicted===r.actual).length/rows.length:null});
    const pooled=stats('pooled'), baseline=stats('baseline'), local=stats('local');
    const delta=rows.map(r=>r.baseline.brier-r.pooled.brier), skill=mean(delta);
    // Approximate paired 95% CI for Brier-skill difference; shoe-cluster dependence is noted below.
    const variance=delta.length>1?delta.reduce((a,x)=>a+(x-skill)**2,0)/(delta.length-1):0;
    const se=delta.length?Math.sqrt(variance/delta.length):null;
    const ci=se==null?null:{low:skill-1.96*se,high:skill+1.96*se};
    const enough=shoes.length>=10&&rows.length>=500;
    const apparentEdge=Boolean(enough&&ci&&ci.low>0&&pooled.logLoss<baseline.logLoss);
    return {version:'3.0.0',status:enough?(apparentEdge?'CANDIDATE_EDGE_NEEDS_PROSPECTIVE_CONFIRMATION':'NO_VERIFIED_EDGE'):'INSUFFICIENT_EVIDENCE',shoeCount:shoes.length,predictions:rows.length,minimumRecommendedShoes:10,minimumRecommendedPredictions:500,metrics:{pooled,baseline,localFrequency:local,brierSkillVsBaseline:skill,approxPaired95CI:ci},perShoe,method:'LEAVE_ONE_SHOE_OUT_POOLED_CONTEXT_ORDER_2',guardrails:{heldOutShoeExcludedFromCrossShoeTraining:true,shoeBoundariesPreserved:true,prospectiveValidationRequired:true,confidenceInterval:'Approximate per-prediction paired interval; may be too narrow because predictions within a Shoe are dependent.',bettingEdgeProven:false},note:apparentEdge?'พบสัญญาณเบื้องต้นในข้อมูลย้อนหลังเท่านั้น ต้องยืนยันกับ Shoe ใหม่ที่ล็อกแผนทดสอบไว้ก่อนเห็นผล':'ยังไม่มีหลักฐานเพียงพอว่าการเรียนรู้ข้าม Shoe ให้ความได้เปรียบที่ยืนยันได้; ไม่ควรตีความว่า pattern ย้อนหลังคือสัญญาณเดิมพัน'};
  }

  function analyze(input) {
    const sequence = parseSequence(input), summary = countOutcomes(sequence), dist = distribution(sequence), sideSequence = sideProjection(sequence), runs = runProfile(sideSequence);
    const transitions = transitionMatrix(sequence), eventChanges = Math.max(0, sequence.length - 1);
    let eventChangeCount = 0, sideSwitchCount = 0;
    for (let i = 1; i < sequence.length; i++) if (sequence[i] !== sequence[i - 1]) eventChangeCount++;
    for (let i = 1; i < sideSequence.length; i++) if (sideSequence[i] !== sideSequence[i - 1]) sideSwitchCount++;
    const windows = [12, 24, 48].filter(n => sequence.length > 0).map(size => windowProfile(sequence, dist, size));
    const latestEvent = sequence ? sequence[sequence.length - 1] : null, latestSide = sideSequence ? sideSequence[sideSequence.length - 1] : null;
    const suffix = suffixEvidence(sequence), diagnostics = [];
    if (!sequence.length) diagnostics.push({ level: 'INFO', code: 'NO_DATA', message: 'เพิ่มประวัติ P/B/T เพื่อเริ่มวิเคราะห์' });
    else {
      if (sequence.length < 20) diagnostics.push({ level: 'CAUTION', code: 'SMALL_SAMPLE', message: 'ข้อมูลยังน้อย รูปแบบระยะสั้นเปลี่ยนได้ง่าย' });
      if (sequence.length < 48) diagnostics.push({ level: 'INFO', code: 'LIMITED_CONTEXT', message: 'ยังมีประวัติไม่ครบ 48 ผล จึงประเมินภาพหลายช่วงได้จำกัด' });
      if (summary.counts.T > 0) diagnostics.push({ level: 'INFO', code: 'TIES_PRESERVED', message: `เก็บผลเสมอ ${summary.counts.T} ครั้งไว้ในลำดับจริง; ไม่นำ T ไปปะปนกับ P/B` });
      if (suffix && suffix.support < 3) diagnostics.push({ level: 'CAUTION', code: 'RARE_SUFFIX', message: `ลำดับท้าย ${suffix.pattern} มีตัวอย่างเดิมเพียง ${suffix.support} ครั้ง ใช้เป็นหลักฐานทำนายไม่ได้` });
    }
    const shift = adjacentWindowShift(sequence, 24), shiftAnalysis = detectShifts(sequence);
    if (shift.available && shift.level !== 'SMALL_DIFFERENCE') diagnostics.push({ level: 'CAUTION', code: 'LOCAL_MIX_DIFFERENCE', message: `สัดส่วนผล 24 รายการล่าสุดต่างจาก 24 รายการก่อนหน้าในระดับ ${shift.level === 'LARGE_DIFFERENCE_CANDIDATE' ? 'มาก' : 'ที่มองเห็นได้'}; เป็นเพียงสัญญาณเชิงพรรณนา` });
    if (sequence.length && transitions[latestEvent].total < 8) diagnostics.push({ level: 'CAUTION', code: 'LOW_TRANSITION_SUPPORT', message: `ข้อมูลผลที่ตามหลัง ${latestEvent} มีเพียง ${transitions[latestEvent].total} ครั้ง` });
    const validation = walkForwardValidation(sequence);
    return {
      version: VERSION, schema: 'nexus-sightline-analysis-v3.0', generatedAt: new Date().toISOString(), sequence, summary, distribution: dist,
      sideSequenceLength: sideSequence.length, latestEvent, latestSide, runs, eventChangeRate: eventChanges ? eventChangeCount / eventChanges : null,
      eventChangeCount, sideSwitchRate: sideSequence.length > 1 ? sideSwitchCount / (sideSequence.length - 1) : null, sideSwitchCount,
      entropy: entropy(dist), transitions, conditionalReference: conditionalReference(transitions, latestEvent), validation,
      forecast: forecastNext(sequence, transitions, validation), windows, adjacentWindowShift: shift, shiftAnalysis, suffixEvidence: suffix,
      topMotifs: topMotifs(sequence), diagnostics,
      limits: { maxOutcomes: MAX_OUTCOMES, predictionsNotProvided: !sequence.length, forecastExperimental: Boolean(sequence.length),
        forecastValidationStatus: 'UNVALIDATED_FOR_PROSPECTIVE_EDGE', note: 'walk-forward เป็นการประเมินย้อนหลังเท่านั้น ยังไม่ยืนยันความได้เปรียบใน Shoe/เซสชันอิสระ และไม่ใช่หลักฐานว่ามีความได้เปรียบในการทำนาย; P/B/T อย่างเดียวไม่เปิดเผยองค์ประกอบไพ่ที่เหลือ' }
    };
  }

  return { VERSION, MAX_OUTCOMES, MIN_TRAINING_OUTCOMES, VALIDATION_WINDOW, SIDES, SIDE_NAMES, MODEL_NAMES, MODEL_LABELS,
    STANDARD_8_DECK_BASELINE, CARD_RANKS, parseSequence, parseCards, countOutcomes, distribution, totalVariation, jensenShannonDivergence,
    sideProjection, runProfile, transitionMatrix, conditionalReference, forecastModels, forecastNext, walkForwardValidation,
    suffixEvidence, topMotifs, windowProfile, adjacentWindowShift, detectShifts, entropy, cardAwareEstimate, pooledForecast, crossShoeValidation, analyze };
});
