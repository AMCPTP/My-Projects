'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const ROOT = __dirname;
const html = fs.readFileSync(path.join(ROOT, 'index.html'), 'utf8');
const ids = [...html.matchAll(/\bid=["']([^"']+)["']/g)].map(m => m[1]);
const elements = Object.create(null);
function makeElement(id) {
  const listeners = Object.create(null);
  const classes = new Set();
  return {
    id, value: '', textContent: '', innerHTML: '', className: '', style: {}, files: [], dataset: {}, listeners,
    classList: { add: x => classes.add(x), remove: x => classes.delete(x), contains: x => classes.has(x) },
    addEventListener: (type, fn) => { listeners[type] = fn; },
    focus() {}, click() {}, remove() {},
  };
}
for (const id of ids) elements[id] = makeElement(id);
const store = new Map();
const localStorage = {
  getItem: key => store.has(key) ? store.get(key) : null,
  setItem: (key, value) => store.set(key, String(value)),
  removeItem: key => store.delete(key)
};
const document = {
  getElementById: id => elements[id] || (elements[id] = makeElement(id)),
  querySelectorAll: () => [],
  createElement: tag => makeElement(tag),
  body: { appendChild() {} }
};
const engine = require('./sightline_engine.js');
const window = { SightlineEngine: engine };
const context = { window, document, localStorage, console, setTimeout: () => 1, clearTimeout() {}, Blob: class {}, URL: { createObjectURL: () => '', revokeObjectURL() {} }, Date, Math, JSON, String, Number, Object, Array, Error, TypeError };
vm.runInNewContext(fs.readFileSync(path.join(ROOT, 'app.js'), 'utf8'), context, { filename: 'app.js', timeout: 10000 });
assert.equal(elements.roundTag.textContent, '0 RESULTS');
assert.match(elements.validation.innerHTML, /อย่างน้อย 41 ผล/);

elements.sessionName.value = 'UI smoke session';
elements.sequence.value = 'PBTBPB'.repeat(20);
elements.analyzeBtn.listeners.click();
assert.match(elements.forecast.innerHTML, /Adaptive Ensemble/);
assert.match(elements.validation.innerHTML, /Brier/);
assert.match(elements.metrics.innerHTML, /120/);
assert.equal(JSON.parse(store.get('nexus.sightline.v1.session')).version, '3.0.0');

elements.knownCards.value = 'A23456789TJQK';
elements.unknownRemoved.value = '0';
elements.simulations.value = '5000';
elements.cardAnalyzeBtn.listeners.click();
assert.match(elements.cardResults.innerHTML, /Wilson 95%/);
assert.match(elements.cardResults.innerHTML, /5,000/);

// Invalid ranks must display a validation message instead of crashing the app.
elements.knownCards.value = 'APB';
elements.cardAnalyzeBtn.listeners.click();
assert.match(elements.cardResults.textContent, /ไม่รองรับ/);

// Each shoe is archived independently; loading one shoe must not concatenate it with another.
elements.sessionName.value = 'Shoe A';
elements.sequence.value = 'PBPB';
elements.archiveCurrentBtn.listeners.click();
assert.equal(elements.sequence.value, '');
elements.sessionName.value = 'Shoe B';
elements.sequence.value = 'BTBT';
elements.archiveCurrentBtn.listeners.click();
const savedShoes = JSON.parse(store.get('nexus.sightline.v2.shoe-archive'));
assert.equal(savedShoes.length, 2);
elements.shoeArchive.value = savedShoes[1].id;
elements.loadArchiveBtn.listeners.click();
assert.equal(elements.sequence.value, 'PBPB');
assert.equal(elements.roundTag.textContent, '4 RESULTS');
console.log('APP_SMOKE_TESTS=12');

assert.ok(fs.readFileSync(path.join(__dirname, 'index.html'), 'utf8').includes('id="crossShoePanel"'));
assert.ok(fs.readFileSync(path.join(__dirname, 'app.js'), 'utf8').includes("$('crossShoeBtn').addEventListener"));
console.log('CROSS_SHOE_UI_SMOKE=PASS');
