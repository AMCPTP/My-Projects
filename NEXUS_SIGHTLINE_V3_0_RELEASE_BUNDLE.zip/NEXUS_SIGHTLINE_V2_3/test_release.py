"""Release verification: runs JS unit tests and local-only HTTP smoke tests."""
from __future__ import annotations
import json, os, re, socket, subprocess, sys, time, urllib.request, urllib.error
from pathlib import Path

ROOT = Path(__file__).resolve().parent

def choose_port():
    with socket.socket() as s:
        s.bind(('127.0.0.1', 0))
        return s.getsockname()[1]

def request(url, timeout=2):
    with urllib.request.urlopen(url, timeout=timeout) as r:
        return r.status, r.headers, r.read()

def main():
    checks = []
    def record(name, ok, detail=''):
        checks.append((name, bool(ok), detail))
        print(('PASS' if ok else 'FAIL') + ' ' + name + ((': ' + detail) if detail else ''))

    required = ['index.html','sightline_engine.js','app.js','server.py','README_SIGHTLINE_V3_0.txt','CHANGELOG_SIGHTLINE_V3_0.txt','test_sightline_engine.js','test_app_smoke.js','start_sightline_v3_0.bat','run_sightline_tests.bat']
    record('Required release files exist', all((ROOT / f).is_file() for f in required))
    html = (ROOT/'index.html').read_text(encoding='utf-8')
    record('UI refers only to the focused local engine/app', 'sightline_engine.js' in html and 'app.js' in html and 'NEXUS SIGHTLINE' in html)
    record('Dedicated forecast panel and explanatory guardrails exist', 'id="forecast"' in html and 'NEXT ESTIMATE' in html and 'id="validation"' in html and 'id="cardPanel"' in html and 'id="crossShoePanel"' in html and 'id="crossShoeBtn"' in html and 'crossShoeValidation' in (ROOT/'sightline_engine.js').read_text(encoding='utf-8'))
    record('UI has no remote script/image/font dependencies', not any(x in html.lower() for x in ['https://','http://']) )
    app_source = (ROOT/'app.js').read_text(encoding='utf-8')
    html_ids = set(re.findall(r'\bid=["\']([^"\']+)', html))
    app_ids = set(re.findall(r"\$\(['\"]([^'\"]+)['\"]\)", app_source))
    record('All literal app element IDs exist in HTML', app_ids <= html_ids, f'{len(app_ids)} selectors checked')
    record('Browser app does not upload history through network APIs', not re.search(r'\bfetch\s*\(|XMLHttpRequest|WebSocket|https?://', app_source))
    record('Card-Aware controls and engine are present', 'cardAnalyzeBtn' in html and 'cardAwareEstimate' in (ROOT/'sightline_engine.js').read_text(encoding='utf-8'))
    record('Walk-forward scoring and adaptive ensemble are wired', 'walkForwardValidation' in (ROOT/'sightline_engine.js').read_text(encoding='utf-8') and 'renderValidation' in app_source)
    record('Shoe archive keeps Shoe histories separate', 'id="shoeArchive"' in html and 'archiveCurrentShoe' in app_source and 'nexus.sightline.v2.shoe-archive' in app_source)

    node = 'node'
    try:
        version = subprocess.run([node, '--version'], capture_output=True, text=True, timeout=5, check=True).stdout.strip()
        syntax_results = [subprocess.run([node, '--check', str(ROOT/f)], capture_output=True, text=True, timeout=10) for f in ['app.js','sightline_engine.js']]
        record('Browser JS syntax checks', all(x.returncode == 0 for x in syntax_results), 'app.js + sightline_engine.js')
        proc = subprocess.run([node, str(ROOT/'test_sightline_engine.js')], capture_output=True, text=True, timeout=30)
        print(proc.stdout, end='')
        if proc.stderr: print(proc.stderr, file=sys.stderr, end='')
        record('Engine unit tests', proc.returncode == 0, version)
        if proc.returncode != 0:
            raise RuntimeError('Engine tests failed')
        tail = [x for x in proc.stdout.splitlines() if x.startswith('SIGHTLINE_ENGINE_TOTAL_PASSED=')]
        engine_count = int(tail[-1].split('=')[1]) if tail else 0
        ui_proc = subprocess.run([node, str(ROOT/'test_app_smoke.js')], capture_output=True, text=True, timeout=30)
        if ui_proc.stdout: print(ui_proc.stdout, end='')
        if ui_proc.stderr: print(ui_proc.stderr, file=sys.stderr, end='')
        record('UI integration smoke tests', ui_proc.returncode == 0, 'simulated DOM startup + analysis + Card-Aware actions')
        if ui_proc.returncode != 0:
            raise RuntimeError('UI smoke tests failed')
    except (FileNotFoundError, subprocess.SubprocessError) as e:
        engine_count = 0
        record('Engine unit tests', False, f'Node.js is required for test run: {e}')

    port = choose_port()
    env = os.environ.copy(); env['SIGHTLINE_PORT'] = str(port)
    proc = subprocess.Popen([sys.executable, str(ROOT/'server.py')], cwd=ROOT, env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    base = f'http://127.0.0.1:{port}'
    try:
        health = None
        for _ in range(35):
            if proc.poll() is not None: break
            try:
                health = request(base+'/health')[2]
                break
            except Exception:
                time.sleep(0.15)
        ok_health = health is not None and json.loads(health).get('localOnly') is True and json.loads(health).get('version') == '3.0.0'
        record('Local /health returns version and localOnly flag', ok_health)
        if health is not None:
            for route, expected in [('/',b'NEXUS SIGHTLINE'),('/sightline_engine.js',b'SightlineEngine'),('/app.js',b'localStorage')]:
                try:
                    status, headers, body = request(base+route)
                    record(f'HTTP route {route}', status == 200 and expected in body and 'no-store' in headers.get('Cache-Control',''))
                except Exception as e: record(f'HTTP route {route}', False, str(e))
        try:
            request(base+'/api/analyze')
            record('No legacy analysis API surface', False, 'unexpected endpoint response')
        except urllib.error.HTTPError as e:
            record('No legacy analysis API surface', e.code == 404, f'HTTP {e.code}')
        try:
            request(base+'/%2e%2e/server.py')
            record('Unknown/traversal-style route is not served', False)
        except urllib.error.HTTPError as e:
            record('Unknown/traversal-style route is not served', e.code == 404)
        except Exception as e:
            record('Unknown/traversal-style route is not served', False, str(e))
    finally:
        proc.terminate()
        try: proc.wait(timeout=3)
        except subprocess.TimeoutExpired: proc.kill()

    passed = sum(1 for _, ok, _ in checks if ok)
    total = len(checks)
    report = [
        'NEXUS SIGHTLINE V3.0.0 — RELEASE TEST REPORT',
        '================================================',
        f'Generated (UTC): {time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime())}',
        f'Result: {passed}/{total} release checks passed',
        f'Engine unit tests: {engine_count}',
        '', 'Detailed checks:'
    ]
    report += [f'[{"PASS" if ok else "FAIL"}] {name}' + (f' — {detail}' if detail else '') for name,ok,detail in checks]
    report += ['', 'Scope note:', '- Automated unit and local HTTP smoke tests only.', '- UI integration smoke tests use a simulated DOM; full interactive click-through in a Windows desktop browser has not been executed by this test script.', '- Cross-Shoe validation uses held-out Shoe evaluation but remains retrospective; it is not independent prospective evidence.', '- Card-aware output is Monte Carlo and depends on correct input cards / unknown-card removal assumptions.']
    (ROOT/'TEST_REPORT_SIGHTLINE_V3_0.txt').write_text('\n'.join(report)+'\n',encoding='utf-8')
    print(f'\nRELEASE_TESTS={passed}/{total}; ENGINE_TESTS={engine_count}')
    return 0 if passed == total else 1

if __name__ == '__main__':
    raise SystemExit(main())
