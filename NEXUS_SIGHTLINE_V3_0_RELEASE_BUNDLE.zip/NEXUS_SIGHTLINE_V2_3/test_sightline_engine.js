'use strict';
const assert = require('node:assert/strict');
const E = require('./sightline_engine.js');
let passed = 0;
function test(name, fn) { try { fn(); passed++; console.log(`PASS ${String(passed).padStart(2,'0')} ${name}`); } catch (e) { console.error(`FAIL ${name}\n${e.stack}`); process.exitCode = 1; } }
function throws(fn, re) { assert.throws(fn, re); }

test('version and outcome cap are declared', () => { assert.equal(E.VERSION, '3.0.0'); assert.equal(E.MAX_OUTCOMES, 2000); });
test('parses compact PBT sequence', () => assert.equal(E.parseSequence('PBTPBT'), 'PBTPBT'));
test('parses comma and whitespace separators', () => assert.equal(E.parseSequence('P, B\nT | P / B'), 'PBTPB'));
test('parses full outcome names', () => assert.equal(E.parseSequence('Player Banker Tie'), 'PBT'));
test('normalizes lower-case input', () => assert.equal(E.parseSequence('p b t'), 'PBT'));
test('rejects unsupported letters instead of silently dropping them', () => throws(() => E.parseSequence('PBX'), /ไม่รองรับ/));
test('rejects non-string sequence', () => throws(() => E.parseSequence(null), /ข้อความ/));
test('allows empty sequence for blank UI state', () => assert.equal(E.parseSequence('  , ; '), ''));
test('rejects input over the outcome cap', () => throws(() => E.parseSequence('P'.repeat(2001)), /สูงสุด 2000/));
test('counts P/B/T without losing ties', () => { const x=E.countOutcomes('PBTTPB'); assert.equal(x.n,6); assert.deepEqual(x.counts,{P:2,B:2,T:2}); });
test('empty distribution is safe', () => assert.deepEqual(E.distribution(''), {P:0,B:0,T:0}));
test('distribution sums to one for non-empty sequences', () => { const d=E.distribution('PBBTPT'); assert.ok(Math.abs(d.P+d.B+d.T-1)<1e-12); });
test('ties stay in original events but are ignored for P/B side streaks', () => { assert.equal(E.sideProjection('P T P B T B'.replace(/ /g,'')), 'PPBB'); });
test('run profile recognizes current streak after a tie', () => { const r=E.runProfile(E.sideProjection('PTPPBTB')); assert.equal(r.currentSide,'B'); assert.equal(r.currentLength,2); assert.equal(r.maxLength,3); assert.equal(r.runCount,2); });
test('run profile handles empty input', () => { const r=E.runProfile(''); assert.equal(r.currentSide,null); assert.equal(r.runCount,0); });
test('transition matrix contains transitions including T', () => { const m=E.transitionMatrix('PBTP'); assert.equal(m.P.counts.B,1); assert.equal(m.B.counts.T,1); assert.equal(m.T.counts.P,1); });
test('transition proportions are null for unsupported rows', () => { const m=E.transitionMatrix('PPP'); assert.equal(m.B.total,0); assert.equal(m.B.shares.P,null); });
test('transition proportions sum to one for supported rows', () => { const m=E.transitionMatrix('PBPBT'); assert.ok(Math.abs(m.P.shares.P+m.P.shares.B+m.P.shares.T-1)<1e-12); });
test('conditional reference identifies low support', () => { const c=E.conditionalReference(E.transitionMatrix('PBPBP'), 'P'); assert.equal(c.support,2); assert.equal(c.interpretation,'LOW_SUPPORT'); });
test('suffix evidence only uses historical occurrences with a following outcome', () => { const c=E.suffixEvidence('PBBPBBPBBPBB'); assert.equal(c.pattern,'BBPBB'); assert.equal(c.support,2); assert.deepEqual(c.following,{P:2,B:0,T:0}); });
test('suffix evidence remains absent if there is no prior occurrence', () => assert.equal(E.suffixEvidence('PBTBP'), null));
test('top motifs has no items when there is insufficient repetition', () => assert.equal(E.topMotifs('PBT').length,0));
test('top motifs reports support and follower counts', () => { const m=E.topMotifs('PBPBPBPB',20,2); assert.ok(m.length>0); for (const x of m) assert.equal(x.support,x.following.P+x.following.B+x.following.T); });
test('total variation stays in range and is symmetric', () => { const a={P:1,B:0,T:0}, b={P:0,B:1,T:0}; assert.equal(E.totalVariation(a,b),1); assert.equal(E.totalVariation(a,b),E.totalVariation(b,a)); });
test('window profile uses only the trailing window', () => { const w=E.windowProfile('PPPPBBBB',E.distribution('PPPPBBBB'),4); assert.equal(w.size,4); assert.deepEqual(w.counts,{P:0,B:4,T:0}); });
test('adjacent-window comparison refuses inadequate sample', () => assert.equal(E.adjacentWindowShift('PBT'.repeat(10)).available,false));
test('adjacent-window comparison becomes available at 48 outcomes', () => { const x=E.adjacentWindowShift('P'.repeat(24)+'B'.repeat(24)); assert.equal(x.available,true); assert.equal(x.windowSize,24); assert.equal(x.totalVariation,1); assert.equal(x.level,'LARGE_DIFFERENCE_CANDIDATE'); });
test('analysis reports empty input without errors', () => { const a=E.analyze(''); assert.equal(a.summary.n,0); assert.equal(a.latestEvent,null); assert.equal(a.forecast,null); assert.equal(a.limits.predictionsNotProvided,true); });
test('analysis preserves original T-containing sequence', () => { const a=E.analyze('PBTPT'); assert.equal(a.sequence,'PBTPT'); assert.equal(a.summary.counts.T,2); });
test('analysis counts every input outcome', () => { const s='PBTPBBTTPT'; const a=E.analyze(s); assert.equal(a.summary.n,s.length); assert.equal(a.summary.counts.P+a.summary.counts.B+a.summary.counts.T,s.length); });
test('analysis separates latest event from latest P/B side', () => { const a=E.analyze('PBT'); assert.equal(a.latestEvent,'T'); assert.equal(a.latestSide,'B'); });
test('forecast is explicitly experimental and never a betting instruction', () => { const a=E.analyze('PBPBPBPB'); assert.ok(a.forecast); assert.equal(a.limits.predictionsNotProvided,false); assert.equal(a.limits.forecastValidationStatus,'UNVALIDATED_FOR_PROSPECTIVE_EDGE'); assert.match(a.limits.note,/ไม่ใช่หลักฐาน/); });
test('short sample emits a caution diagnostic', () => { const a=E.analyze('PBPB'); assert.ok(a.diagnostics.some(d=>d.code==='SMALL_SAMPLE')); });
test('large sample has 12/24/48 descriptive windows', () => { const a=E.analyze('PBT'.repeat(20)); assert.deepEqual(a.windows.map(x=>x.requestedSize),[12,24,48]); });
test('analyze does not mutate caller input', () => { const s='PBTPBB'; E.analyze(s); assert.equal(s,'PBTPBB'); });
test('tie-heavy sequence records all ties and still profiles P/B sides', () => { const a=E.analyze('PTPTPT'); assert.equal(a.summary.counts.T,3); assert.equal(a.sideSequenceLength,3); assert.equal(a.runs.runCount,1); assert.equal(a.runs.currentLength,3); });
test('result schema and audit fields are stable', () => { const a=E.analyze('PBTBPP'); assert.equal(a.schema,'nexus-sightline-analysis-v3.0'); assert.ok(Array.isArray(a.diagnostics)); assert.ok(a.transitions.P); assert.ok(a.adjacentWindowShift); assert.ok(a.forecast); });
test('forecast probabilities are finite and sum to one', () => { const f=E.analyze('PBTBPPBTBBPT').forecast; assert.ok(['P','B','T'].includes(f.topOutcome)); assert.ok(Math.abs(f.probabilities.P+f.probabilities.B+f.probabilities.T-1)<1e-12); for (const s of E.SIDES) assert.ok(Number.isFinite(f.probabilities[s]) && f.probabilities[s]>=0 && f.probabilities[s]<=1); });
test('forecast carries support and baseline transparently', () => { const a=E.analyze('PB'.repeat(40)); const f=a.forecast; assert.equal(f.supportAfterLatest,a.transitions.B.total); assert.deepEqual(f.baseline,E.STANDARD_8_DECK_BASELINE); assert.equal(f.validationStatus,'UNVALIDATED_FOR_PROSPECTIVE_EDGE'); assert.ok(f.transitionWeight<=0.65); });
test('forecast does not over-weight a one-observation transition', () => { const f=E.analyze('P').forecast; assert.equal(f.supportAfterLatest,0); assert.equal(f.transitionWeight,0); assert.deepEqual(f.probabilities,f.baseline); });
test('rare motif is excluded from numerical forecast method', () => { const f=E.analyze('PBBPBBPBBPBB').forecast; assert.equal(f.method,'BASELINE_ANCHORED_WALK_FORWARD_ADAPTIVE_ENSEMBLE'); assert.match(f.note,/ไม่พิสูจน์ความได้เปรียบ/); });


test('parses compact and separated card ranks including ten', () => {
  assert.deepEqual(E.parseCards('A23456789TJQK'), ['A','2','3','4','5','6','7','8','9','T','J','Q','K']);
  assert.deepEqual(E.parseCards('A, 10, J | Q K'), ['A','T','J','Q','K']);
});
test('card parser rejects baccarat outcome symbols and unsupported ranks', () => { throws(() => E.parseCards('APB'), /ไม่รองรับ/); });
test('forecast models expose five normalized candidates', () => {
  const ms = E.forecastModels('PBTBPB'.repeat(12));
  for (const name of E.MODEL_NAMES) assert.ok(Math.abs(Object.values(ms[name]).reduce((a,b)=>a+b,0)-1)<1e-10);
});
test('walk-forward requires a prior history and makes no prediction for training rows', () => {
  assert.equal(E.walkForwardValidation('PBT'.repeat(10)).available, false);
  const v = E.walkForwardValidation('PBT'.repeat(20));
  assert.equal(v.predictions, 20);
  assert.equal(v.available, true);
  assert.equal(v.metrics.ensemble.count, 20);
});
test('adaptive forecast is baseline anchored and limits model adjustment to 45 percent', () => {
  const f = E.analyze('PBTBPB'.repeat(25)).forecast;
  assert.ok(f.adaptiveShare >= 0 && f.adaptiveShare <= 0.45);
  assert.ok(Math.abs(f.probabilities.P + f.probabilities.B + f.probabilities.T - 1) < 1e-10);
  assert.ok(f.validatedPredictionCount > 0);
  assert.equal(f.validationStatus, 'UNVALIDATED_FOR_PROSPECTIVE_EDGE');
  const longer = E.analyze('PBTBPPBT'.repeat(63)).forecast;
  assert.ok(longer.adaptiveShare > f.adaptiveShare, 'adaptive share may grow with accumulated prequential forecasts');
  assert.ok(longer.adaptiveShare <= 0.45);
});
test('walk-forward model metrics include scores and top-hit rate', () => {
  const v = E.walkForwardValidation('PBBPT'.repeat(22));
  for (const key of ['baseline','frequency','markov1','markov2','markov3','ensemble']) {
    assert.ok(Number.isFinite(v.metrics[key].brier));
    assert.ok(Number.isFinite(v.metrics[key].logLoss));
    assert.ok(v.metrics[key].topAccuracy >= 0 && v.metrics[key].topAccuracy <= 1);
  }
  assert.ok(v.metrics.markov2.topAccuracy > 0, 'actual hit rates must be compared against recorded outcomes');
});
test('shift detector compares 24 and 48 result windows only when supported', () => {
  const s = E.detectShifts('P'.repeat(48)+'B'.repeat(48));
  assert.equal(s.shifts[0].available, true);
  assert.equal(s.shifts[1].available, true);
  assert.equal(s.hasCandidate, true);
  assert.ok(s.shifts[1].jensenShannonBits >= 0);
});
test('Card-Aware Monte Carlo is deterministic for identical supplied information', () => {
  const a = E.cardAwareEstimate('A23456789TJQK', 0, 2000);
  const b = E.cardAwareEstimate('A23456789TJQK', 0, 2000);
  assert.deepEqual(a.counts, b.counts);
  assert.equal(a.counts.P + a.counts.B + a.counts.T, 2000);
  assert.ok(Math.abs(a.probabilities.P + a.probabilities.B + a.probabilities.T - 1) < 1e-12);
  for (const s of E.SIDES) {
    assert.ok(a.intervals[s].low <= a.probabilities[s]);
    assert.ok(a.intervals[s].high >= a.probabilities[s]);
  }
});
test('Card-Aware standard 8-deck output is in plausible range against known reference', () => {
  const a = E.cardAwareEstimate('', 0, 5000);
  assert.ok(Math.abs(a.probabilities.P - E.STANDARD_8_DECK_BASELINE.P) < 0.035);
  assert.ok(Math.abs(a.probabilities.B - E.STANDARD_8_DECK_BASELINE.B) < 0.035);
  assert.ok(Math.abs(a.probabilities.T - E.STANDARD_8_DECK_BASELINE.T) < 0.035);
});
test('Card-Aware validates duplicate ranks beyond eight-deck capacity', () => {
  throws(() => E.cardAwareEstimate('A'.repeat(33), 0, 2000), /มากกว่า 32 ใบ/);
});
test('card simulator rejects impossible removed-card counts and simulation sizes', () => {
  throws(() => E.cardAwareEstimate('', 301, 2000), /0–300/);
  throws(() => E.cardAwareEstimate('', 0, 100), /2,000–50,000/);
  throws(() => E.cardAwareEstimate('', 100, 50000), /ภาระจำลองสูงเกินกำหนด/);
});

console.log(`\nSIGHTLINE_ENGINE_CORE_TESTS=${passed}`);
if (process.exitCode) process.exit(process.exitCode);


test('cross-Shoe validation refuses one Shoe and preserves held-out evaluation', () => {
  const x=E.crossShoeValidation([{name:'only',sequence:'P'.repeat(60)}]);
  assert.equal(x.status,'INSUFFICIENT_SHOES');
  assert.equal(x.predictions,0);
});
test('cross-Shoe validation scores held-out Shoes without joining boundaries', () => {
  const shoes=[
    {name:'s1',sequence:'PBTB'.repeat(18)},
    {name:'s2',sequence:'BBPT'.repeat(18)},
    {name:'s3',sequence:'TPPB'.repeat(18)}
  ];
  const x=E.crossShoeValidation(shoes,{minTrain:20});
  assert.equal(x.shoeCount,3);
  assert.ok(x.predictions>0);
  assert.equal(x.guardrails.heldOutShoeExcludedFromCrossShoeTraining,true);
  assert.equal(x.guardrails.shoeBoundariesPreserved,true);
  assert.equal(x.guardrails.bettingEdgeProven,false);
  assert.equal(x.perShoe.length,3);
});
test('pooled forecast normalizes probabilities', () => {
  const x=E.pooledForecast('PBTBPBTB',[{sequence:'PBTBPBTB'.repeat(5)},{sequence:'BBPTBBPT'.repeat(5)}]);
  assert.ok(Math.abs(x.probabilities.P+x.probabilities.B+x.probabilities.T-1)<1e-10);
});
console.log(`\nSIGHTLINE_ENGINE_TOTAL_PASSED=${passed}`);
